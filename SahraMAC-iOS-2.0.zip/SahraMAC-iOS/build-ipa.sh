#!/bin/bash
# Build an ad hoc IPA on macOS or GitHub Actions.
# SAHRA_BUILD=full includes MobileVLCKit. SAHRA_BUILD=apple builds without it.
set -eo pipefail
cd "$(dirname "$0")"

variant="${SAHRA_BUILD:-full}"
if [ -z "${SAHRA_BUILD:-}" ] && [ "${SAHRA_NO_VLC:-0}" = "1" ]; then variant=apple; fi
case "$variant" in
  full|apple) ;;
  *) echo "Use SAHRA_BUILD=full or SAHRA_BUILD=apple." >&2; exit 2 ;;
esac
if ! command -v xcrun >/dev/null || ! command -v npm >/dev/null; then
  echo "Building the IPA requires Xcode and Node.js (npm) on macOS." >&2
  exit 1
fi
sdk="$(xcrun --sdk iphoneos --show-sdk-path)"
xcodebuild -version

out="$PWD/build"
app="$out/Payload/SahraMAC.app"
rm -rf "$out" SahraMAC.ipa
mkdir -p "$app" "$out/dependencies"
cp App/Info.plist "$app/Info.plist"
app_version="$(plutil -extract CFBundleShortVersionString raw -o - "$app/Info.plist")"
cp App/Resources/* "$app/"
printf 'APPL????' > "$app/PkgInfo"

hls_version=1.7.4
echo "Bundling HLS.js $hls_version"
(
  cd "$out/dependencies"
  npm pack --ignore-scripts --fetch-retries=1 --fetch-timeout=45000 --silent "hls.js@$hls_version"
  tar -xOf "hls.js-$hls_version.tgz" package/dist/hls.min.js > "$app/hls.min.js"
  tar -xOf "hls.js-$hls_version.tgz" package/LICENSE > "$app/HLS.js-LICENSE.txt"
)
test -s "$app/hls.min.js"
test -s "$app/HLS.js-LICENSE.txt"

swift_flags=(-swift-version 5 -parse-as-library -O -whole-module-optimization
  -target arm64-apple-ios15.0 -sdk "$sdk"
  -framework UIKit -framework WebKit -framework JavaScriptCore
  -framework AVFoundation -framework AVKit -framework MediaPlayer)
engine_summary="AVPlayer + HLS.js $hls_version"

if [ "$variant" = full ]; then
  vlc_version=3.7.5-a213fd11-6de05adc
  vlc_archive="$out/dependencies/MobileVLCKit.tar.xz"
  vlc_dir="$out/dependencies/vlc"
  echo "Downloading VideoLAN MobileVLCKit ${vlc_version%%-*}"
  if ! curl -fSL --retry 1 --connect-timeout 15 --max-time 360 \
    -o "$vlc_archive" "https://download.videolan.org/pub/cocoapods/prod/MobileVLCKit-$vlc_version.tar.xz"; then
    curl -fSL --retry 1 --connect-timeout 15 --max-time 360 \
      -o "$vlc_archive" "https://download.videolan.org/cocoapods/prod/MobileVLCKit-$vlc_version.tar.xz"
  fi
  mkdir -p "$vlc_dir"
  tar -xf "$vlc_archive" -C "$vlc_dir"

  # Select the physical iPhone slice from the xcframework manifest.
  framework="$(python3 - "$vlc_dir" <<'PY'
from pathlib import Path
import plistlib
import sys

folder = Path(sys.argv[1])
for xcframework in sorted(folder.rglob("MobileVLCKit.xcframework")):
    with (xcframework / "Info.plist").open("rb") as info:
        manifest = plistlib.load(info)
    for entry in manifest["AvailableLibraries"]:
        if entry["SupportedPlatform"] == "ios" and not entry.get("SupportedPlatformVariant") and "arm64" in entry["SupportedArchitectures"]:
            path = xcframework / entry["LibraryIdentifier"] / entry["LibraryPath"]
            if (path / "MobileVLCKit").is_file():
                print(path)
                sys.exit(0)
    sys.exit("MobileVLCKit.xcframework does not contain an iPhone arm64 framework.")
for path in sorted(folder.rglob("MobileVLCKit.framework")):
    if any("simulator" in part.lower() or "maccatalyst" in part.lower() for part in path.parts):
        continue
    if (path / "MobileVLCKit").is_file():
        print(path)
        sys.exit(0)
sys.exit("MobileVLCKit.framework was not found in the download.")
PY
)"
  xcrun lipo -verify_arch arm64 "$framework/MobileVLCKit"
  if [ ! -f "$framework/Modules/module.modulemap" ]; then
    mkdir -p "$framework/Modules"
    cat > "$framework/Modules/module.modulemap" <<'MAP'
framework module MobileVLCKit {
  umbrella header "MobileVLCKit.h"
  export *
  module * { export * }
}
MAP
  fi
  swift_flags+=(-D SAHRA_VLC -F "$(dirname "$framework")" -framework MobileVLCKit
    -Xlinker -ObjC -lc++ -lxml2 -lz -lbz2 -liconv -lresolv)
  for name in QuartzCore CoreText CoreFoundation Foundation Security CFNetwork \
    AudioToolbox CoreAudio OpenGLES CoreGraphics VideoToolbox CoreMedia CoreVideo \
    CoreImage Metal Network SystemConfiguration; do
    swift_flags+=(-framework "$name")
  done
  if xcrun otool -hv "$framework/MobileVLCKit" | awk '$0 ~ /(^|[[:space:]])DYLIB([[:space:]]|$)/ { found=1 } END { exit !found }'; then
    swift_flags+=(-Xlinker -rpath -Xlinker @executable_path/Frameworks)
    mkdir -p "$app/Frameworks"
    embedded="$app/Frameworks/MobileVLCKit.framework"
    cp -R "$framework" "$embedded"
    rm -rf "$embedded/Headers" "$embedded/Modules"
    codesign --force --sign - --timestamp=none "$embedded"
  fi
  engine_summary="$engine_summary + MobileVLCKit ${vlc_version%%-*} (automatic decode and software preference)"
fi

echo "Compiling for iPhone arm64"
xcrun --sdk iphoneos swiftc "${swift_flags[@]}" App/Sources/*.swift -o "$app/SahraMAC"
plutil -lint "$app/Info.plist"
codesign --force --sign - --timestamp=none "$app"
codesign --verify --deep "$app"
(cd "$out" && zip -qry ../SahraMAC.ipa Payload)
echo "SahraMAC.ipa ($app_version) — $engine_summary"
if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
  echo "**SahraMAC.ipa ($app_version)** — $engine_summary" >> "$GITHUB_STEP_SUMMARY"
fi
