#if SAHRA_VLC
import UIKit
import MobileVLCKit

/// VLCKit (MobileVLCKit): VideoLAN's engine inside the app. Plays what AVPlayer can't: MKV, AVI, HEVC,
/// AC-3/E-AC-3/DTS sound, live MPEG-TS, the file's own audio and subtitle tracks.
final class VLCEngineController: EngineController {
    private let player = VLCMediaPlayer()
    private var subtitle: URL?

    override func startPlayback(_ u: URL) {
        let media = VLCMedia(url: u)
        let cache = o.profile.vlcCache(live: o.live)
        media.addOption(":network-caching=\(cache)")
        media.addOption(":live-caching=\(cache)")
        media.addOption(":http-reconnect")
        if engineID == "vlc-sw" {
            // Prefer libavcodec software decoding. The remaining decoders can
            // still handle tracks (for example subtitles) that it cannot.
            media.addOption(":codec=avcodec,all")
            media.addOption(":avcodec-hw=none")
        }
        if !o.ua.isEmpty { media.addOption(":http-user-agent=" + o.ua) }
        if !o.live && o.start >= 1 { media.addOption(":start-time=" + String(Int(o.start))) }
        player.drawable = videoView
        player.media = media
        player.play()
        subtitle = o.subtitleFile()
        if let subtitle = subtitle { _ = player.addPlaybackSlave(subtitle, type: .subtitle, enforce: true) }
    }

    override func stopPlayback() {
        super.stopPlayback()
        player.stop()
        player.drawable = nil
        if let subtitle = subtitle {
            try? FileManager.default.removeItem(at: subtitle)
            self.subtitle = nil
        }
    }
    override func isPlaying() -> Bool { player.isPlaying }
    override func isBusy() -> Bool {
        let st = player.state
        return !player.isPlaying && st != .paused && st != .ended && st != .error && st != .stopped
    }
    override func hasEnded() -> Bool { player.state == .ended || player.state == .stopped }
    override func engineError() -> String { player.state == .error ? "تعذّر فتح الرابط" : "" }

    // (works whether VLCKit's headers mark these optional or not)
    override func currentTime() -> Double {
        let tt: VLCTime? = player.time
        return Double(tt?.intValue ?? 0) / 1000
    }
    override func duration() -> Double {
        let m: VLCMedia? = player.media
        let lt: VLCTime? = m?.length
        return Double(lt?.intValue ?? 0) / 1000
    }

    override func canSeek() -> Bool { super.canSeek() && player.isSeekable }
    override func setPaused(_ paused: Bool) { if paused { player.pause() } else { player.play() } }
    override func seek(toFraction f: Double) { player.position = Float(f) }
    override func jump(_ seconds: Double) {
        if seconds < 0 { player.jumpBackward(Int32(-seconds)) } else { player.jumpForward(Int32(seconds)) }
    }
    override func setRate(_ r: Float) { player.rate = r }
    override func videoSize() -> CGSize { player.videoSize }

    private func tracks(_ names: [Any]?, _ ids: [Any]?) -> [(String, Int)] {
        let n = (names as? [String]) ?? []
        let i = ((ids as? [NSNumber]) ?? []).map { $0.intValue }
        return zip(n, i).map { ($0.0, $0.1) }
    }
    override func audioTracks() -> [(String, Int)] { tracks(player.audioTrackNames, player.audioTrackIndexes) }
    override func currentAudio() -> Int { Int(player.currentAudioTrackIndex) }
    override func setAudio(_ id: Int) { player.currentAudioTrackIndex = Int32(id) }
    override func subtitleTracks() -> [(String, Int)] { tracks(player.videoSubTitlesNames, player.videoSubTitlesIndexes) }
    override func currentSubtitle() -> Int { Int(player.currentVideoSubTitleIndex) }
    override func setSubtitle(_ id: Int) { player.currentVideoSubTitleIndex = Int32(id) }
}
#endif
