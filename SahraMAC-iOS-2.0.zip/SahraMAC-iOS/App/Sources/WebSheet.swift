import UIKit
import WebKit
import AVFoundation

/// A web page over the app (YouTube): a script given by the app runs in it before the site's own
/// scripts — that is how the ads are taken out of the site.
final class WebSheet: UIViewController, WKNavigationDelegate, WKUIDelegate {
    private let url: URL
    private let script: String
    private let done: () -> Void
    private var web: WKWebView!
    private let bar = UIView()
    private var finished = false

    init(url: URL, script: String, done: @escaping () -> Void) {
        self.url = url
        self.script = script
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    static func present(_ s: String, script: String, from host: UIViewController?, done: @escaping () -> Void) {
        guard let host = host, let url = Net.makeURL(s) else { done(); return }
        var top: UIViewController = host
        while let p = top.presentedViewController { top = p }
        top.present(WebSheet(url: url, script: script, done: done), animated: true, completion: nil)
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.allowsPictureInPictureMediaPlayback = true
        cfg.allowsAirPlayForMediaPlayback = true
        let ucc = WKUserContentController()
        if !script.isEmpty {
            ucc.addUserScript(WKUserScript(source: script, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        cfg.userContentController = ucc

        let wv = WKWebView(frame: .zero, configuration: cfg)
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Mobile/15E148 Safari/604.1"
        wv.allowsBackForwardNavigationGestures = true
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(wv)
        web = wv

        bar.backgroundColor = UIColor(white: 0.06, alpha: 1)
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)
        let close = makeButton("xmark", #selector(closeTap))
        let back = makeButton("chevron.backward", #selector(backTap))
        let reload = makeButton("arrow.clockwise", #selector(reloadTap))
        let title = UILabel()
        title.text = "يوتيوب · بدون إعلانات"
        title.textColor = UIColor(white: 1, alpha: 0.75)
        title.font = UIFont.systemFont(ofSize: 14, weight: .semibold)
        title.textAlignment = .center
        let stack = UIStackView(arrangedSubviews: [back, reload, title, close])
        stack.axis = .horizontal
        stack.alignment = .center
        stack.spacing = 4
        stack.translatesAutoresizingMaskIntoConstraints = false
        bar.addSubview(stack)

        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 46),
            stack.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 8),
            stack.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -8),
            stack.bottomAnchor.constraint(equalTo: bar.bottomAnchor, constant: -1),
            stack.heightAnchor.constraint(equalToConstant: 44),
            wv.topAnchor.constraint(equalTo: bar.bottomAnchor),
            wv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            wv.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        wv.load(URLRequest(url: url))
        // YouTube keeps playing with the screen locked / the app in the background
        NotificationCenter.default.addObserver(self, selector: #selector(wentBackground),
                                               name: UIApplication.didEnterBackgroundNotification, object: nil)
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    @objc private func wentBackground() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .moviePlayback, options: [])
        try? s.setActive(true, options: [])
        let js = "window.__sahraBG && window.__sahraBG(); 0"
        web.evaluateJavaScript(js, completionHandler: nil)
        // WebKit may pause the video right after this moment: ask again shortly after
        for delay in [0.6, 1.5] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                self?.web.evaluateJavaScript(js, completionHandler: nil)
            }
        }
    }

    private func makeButton(_ symbol: String, _ action: Selector) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: symbol), for: .normal)
        b.tintColor = .white
        b.addTarget(self, action: action, for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.widthAnchor.constraint(equalToConstant: 44).isActive = true
        b.heightAnchor.constraint(equalToConstant: 44).isActive = true
        return b
    }

    @objc private func closeTap() {
        web.stopLoading()
        web.evaluateJavaScript("document.querySelectorAll('video').forEach(function (v) { v.pause(); })", completionHandler: nil)
        dismiss(animated: true) { self.finish() }
    }

    @objc private func backTap() { if web.canGoBack { web.goBack() } }
    @objc private func reloadTap() { web.reload() }

    private func finish() {
        if finished { return }
        finished = true
        done()
    }

    // links to the YouTube app (youtube://, intent://) stay inside
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let s = navigationAction.request.url?.scheme?.lowercased(), !["http", "https", "about", "blob", "data"].contains(s) {
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    // pages that open a new window: load them here
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil, let u = navigationAction.request.url { webView.load(URLRequest(url: u)) }
        return nil
    }
}
