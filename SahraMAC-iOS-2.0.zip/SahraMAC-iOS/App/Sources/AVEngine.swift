import UIKit
import AVKit

/// Own the session outside AVKit. Apple's controller still supplies the playback UI,
/// AirPlay and picture in picture.
final class AVEngineController: PlaybackSessionController, AVPlayerViewControllerDelegate {
    private let playerScreen = AVPlayerViewController()
    private var statusObservation: NSKeyValueObservation?
    private var notes: [NSObjectProtocol] = []
    private var timer: Timer?
    private var overlay: SubtitleOverlay?
    private var opened = false

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        addChild(playerScreen)
        playerScreen.view.frame = view.bounds
        playerScreen.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(playerScreen.view)
        playerScreen.didMove(toParent: self)
        playerScreen.delegate = self
        playerScreen.allowsPictureInPicturePlayback = o.background
        playerScreen.canStartPictureInPictureAutomaticallyFromInline = o.background
        playerScreen.updatesNowPlayingInfoCenter = true
        addControls()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !opened, !finished else { return }
        opened = true
        guard let url = o.mediaURL else { finish(error: "رابط غير صالح"); return }
        var options: [String: Any] = [:]
        if #available(iOS 16.0, *), !o.ua.isEmpty {
            options[AVURLAssetHTTPUserAgentKey] = o.ua
        }
        let item = AVPlayerItem(asset: AVURLAsset(url: url, options: options))
        item.preferredForwardBufferDuration = o.profile.appleBuffer(live: o.live)
        if o.adaptive && o.profile == .saver {
            item.preferredPeakBitRate = 1_500_000
            item.preferredMaximumResolution = CGSize(width: 1280, height: 720)
        }
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = true
        player.allowsExternalPlayback = true
        if #available(iOS 15.0, *) {
            player.audiovisualBackgroundPlaybackPolicy = o.background ? .continuesIfPossible : .pauses
        }
        playerScreen.player = player
        if let subtitle = SubtitleOverlay(srt: o.subs), let host = playerScreen.contentOverlayView {
            overlay = subtitle
            subtitle.attach(to: host)
        }

        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] _, _ in
            DispatchQueue.main.async { self?.itemStatusChanged() }
        }
        let center = NotificationCenter.default
        notes.append(center.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            DispatchQueue.main.async { self?.didEnd() }
        })
        notes.append(center.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            DispatchQueue.main.async { self?.finish(error: "انقطع التشغيل في AVPlayer", retryable: true) }
        })
        if !o.live {
            notes.append(center.addObserver(forName: .AVPlayerItemTimeJumped, object: item, queue: .main) { [weak self] _ in
                DispatchQueue.main.async { self?.monitor.seek() }
            })
        }

        let timer = Timer(timeInterval: 0.33, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { self?.tick() }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
        // Restore the playhead before starting to avoid showing the beginning of a resumed title.
        if o.live || o.start < 1 { requestPlay(player) }
    }

    private func requestPlay(_ player: AVPlayer) {
        if o.profile == .fast {
            player.playImmediately(atRate: 1)
        } else {
            player.play()
        }
    }

    private var resumeRequested = false

    private func itemStatusChanged() {
        guard !finished, let player = playerScreen.player, let item = player.currentItem else { return }
        switch item.status {
        case .readyToPlay:
            guard !o.live, o.start >= 1, !resumeRequested else { return }
            resumeRequested = true
            let duration = item.duration.seconds
            guard !duration.isFinite || o.start < duration - 1 else { requestPlay(player); return }
            monitor.seek()
            let time = CMTime(seconds: o.start, preferredTimescale: 600)
            player.seek(to: time, toleranceBefore: .zero, toleranceAfter: CMTime(seconds: 1, preferredTimescale: 600)) { [weak self] _ in
                DispatchQueue.main.async {
                    guard let self = self, !self.finished, let player = self.playerScreen.player else { return }
                    self.requestPlay(player)
                }
            }
        case .failed:
            finish(error: "تعذّر تشغيل المصدر في AVPlayer", retryable: monitor.started)
        default:
            break
        }
    }

    private func tick() {
        guard !finished, let player = playerScreen.player, let item = player.currentItem else { return }
        let position = player.currentTime().seconds
        let duration = item.duration.seconds
        if position.isFinite && position >= 0 {
            lastPos = position
            overlay?.show(at: position)
        }
        if duration.isFinite && duration > 0 { lastDur = duration }
        let paused = monitor.started && player.timeControlStatus == .paused
        let suspended = UIApplication.shared.applicationState != .active || paused
        if let timeout = monitor.sample(position, suspended: suspended) {
            finish(error: timeout, retryable: true)
        }
    }

    private func didEnd() {
        guard !finished else { return }
        if monitor.started {
            if lastDur > 0 && !o.live { lastPos = lastDur }
            finish(next: !o.live && o.hasNext && o.autoNext, ended: true)
        } else {
            finish(error: "انتهى المصدر قبل بدء الفيديو")
        }
    }

    private func addControls() {
        let close = control("xmark", label: "إغلاق المشغّل")
        close.addTarget(self, action: #selector(closeTap), for: .touchUpInside)
        let options = control("ellipsis", label: "خيارات التشغيل")
        options.menu = optionsMenu()
        options.showsMenuAsPrimaryAction = true
        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            close.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 10),
            close.topAnchor.constraint(equalTo: safe.topAnchor, constant: 10),
            options.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -10),
            options.topAnchor.constraint(equalTo: safe.topAnchor, constant: 52)
        ])
    }

    private func control(_ symbol: String, label: String) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: symbol), for: .normal)
        button.tintColor = .white
        button.accessibilityLabel = label
        button.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        button.layer.cornerRadius = 22
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(button)
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 44),
            button.heightAnchor.constraint(equalToConstant: 44)
        ])
        return button
    }

    @objc private func closeTap() { finish() }

    override func stopPlayback() {
        timer?.invalidate()
        timer = nil
        statusObservation?.invalidate()
        statusObservation = nil
        for note in notes { NotificationCenter.default.removeObserver(note) }
        notes.removeAll()
        playerScreen.player?.currentItem?.cancelPendingSeeks()
        playerScreen.player?.pause()
        playerScreen.player?.replaceCurrentItem(with: nil)
        playerScreen.player = nil
    }

    func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool { false }

    func playerViewController(_ playerViewController: AVPlayerViewController,
                              restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(viewIfLoaded?.window != nil)
    }
}
