import UIKit
import AVFoundation

// سهرة MAC — the app runs the same script that runs in Scriptable, inside its own small runtime
// (JavaScriptCore + WKWebView), so the interface, the portal client and the players are identical.
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // sound keeps going with the screen locked or in picture-in-picture
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback, options: [])
        try? session.setActive(true)

        let host = HostViewController()
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = .black
        w.rootViewController = host
        w.makeKeyAndVisible()
        window = w
        return true
    }

    /// iOS wakes the app when a download that went on in the background has finished
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        Downloader.shared.bgCompletion = completionHandler
    }

    /// Back from the background: the local server's socket may have been taken while the app slept.
    func applicationWillEnterForeground(_ application: UIApplication) {
        _ = LocalServer.shared.ensure()
    }

    /// What of each film is on the phone is written down before the app sleeps.
    func applicationDidEnterBackground(_ application: UIApplication) {
        StreamCache.shared.saveAll()
    }

    /// The system is short of memory: the page frees the video it has already shown, so it is not the one closed.
    func applicationDidReceiveMemoryWarning(_ application: UIApplication) {
        Runtime.shared.web.memoryWarning()
    }
}
