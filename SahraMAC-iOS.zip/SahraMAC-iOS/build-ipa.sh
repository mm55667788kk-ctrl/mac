#!/bin/bash
# Builds SahraMAC.ipa on a Mac (or on GitHub's free macOS machines, see .github/workflows/build-ipa.yml).
#
# The iPhone's native engines go into the app:
#   AVPlayer (AVFoundation)  — always (it is part of iOS)
#   VLCKit / MobileVLCKit    — VideoLAN's package, downloaded here
#   KSPlayer                 — Swift package https://github.com/kingslay/KSPlayer (FFmpeg + Metal)
#   libmpv / MPVKit          — Swift package https://github.com/mpvkit/MPVKit (mpv + FFmpeg + MoltenVK)
#
# KSPlayer and MPVKit each bring their own FFmpeg, and VLCKit carries one inside too, so not every
# combination can live in one app. The script tries the biggest combination first and steps down until one
# builds; whatever happens an IPA comes out (at worst the simple build with AVPlayer and the web engines).
# The last line of the log says which engines got in.
#
#   SAHRA_ENGINES="ks vlc"   only try these (any of: ks mpv vlc)
#   SAHRA_SIMPLE=1           skip Xcode packages (quick build: AVPlayer + VLC only)
#   SAHRA_NO_VLC=1           don't download VLCKit
set -o pipefail   # (no -u: macOS bash 3.2 treats empty arrays as unset)
cd "$(dirname "$0")"
ROOT="$PWD"

# «السهرة ماك» 3.21: VLC / KSPlayer / mpv are internal players again (chips in "المشغلات الداخلية"), so the
# full build is the default. SAHRA_SIMPLE=1 gives the quick build (AVPlayer + the web engines only, 3–5 minutes).
SAHRA_SIMPLE="${SAHRA_SIMPLE:-0}"
SAHRA_NO_VLC="${SAHRA_NO_VLC:-0}"

APP="build/Payload/SahraMAC.app"
rm -rf build SahraMAC.ipa SahraMAC-lite.ipa SahraMAC.xcodeproj project.yml
mkdir -p build/logs

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "SDK: $SDK"
xcodebuild -version || true

note() { echo "$1"; if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then echo "$1" >> "$GITHUB_STEP_SUMMARY"; fi; }

# ---------------- VLCKit (VideoLAN's official CocoaPods packages) ----------------
VLC_FW=""
fetch_vlc() {
  local v b
  for v in 3.7.2-3e42ae47-79128878 3.7.1-00ae8f87-79128878 3.6.0-c73b779f-dd8bfdba; do
    for b in https://download.videolan.org/pub/cocoapods/prod https://download.videolan.org/cocoapods/prod https://downloads.videolan.org/cocoapods/prod; do
      echo "VLCKit: trying $b/MobileVLCKit-$v.tar.xz"
      if curl -fsSL --retry 2 --connect-timeout 20 -o vlc.tar.xz "$b/MobileVLCKit-$v.tar.xz"; then echo "VLCKit $v downloaded"; return 0; fi
    done
  done
  return 1
}
if [ "${SAHRA_NO_VLC:-}" != "1" ] && fetch_vlc; then
  rm -rf vlc && mkdir -p vlc
  if tar -xJf vlc.tar.xz -C vlc; then
    # the iPhone slice of the framework (not the simulator one)
    VLC_FW="$(find "$ROOT/vlc" -type d -name MobileVLCKit.framework | grep -v -i -e simulator -e tvos -e maccatalyst | head -1 || true)"
  fi
  rm -f vlc.tar.xz
fi

VLC_DIR=""
VLC_LIBS="-lc++ -lxml2 -lz -lbz2 -liconv"
VLC_SYS="QuartzCore CoreText Security CFNetwork AudioToolbox OpenGLES CoreGraphics VideoToolbox CoreMedia CoreVideo CoreImage Metal MediaPlayer CoreFoundation Foundation"
VLC_DYNAMIC=0
VLC_LINK="-framework MobileVLCKit"
if [ -n "$VLC_FW" ]; then
  echo "VLCKit framework: $VLC_FW"
  # a clean copy: real files instead of links, no old signature, only the iPhone's arm64 slice
  # (an armv7 slice or a leftover signature is what makes iOS refuse the app:
  #  "ApplicationVerificationFailed … MobileVLCKit.framework : 0xe8008001")
  rm -rf build/vlcfw && mkdir -p build/vlcfw
  cp -RL "$VLC_FW" build/vlcfw/ 2>/dev/null || cp -R "$VLC_FW" build/vlcfw/
  VLC_FW="$ROOT/build/vlcfw/MobileVLCKit.framework"
  rm -rf "$VLC_FW/_CodeSignature" "$VLC_FW/CodeResources"
  find "$VLC_FW" -name '.DS_Store' -delete 2>/dev/null || true
  # a module map so Swift can `import MobileVLCKit`
  if [ ! -f "$VLC_FW/Modules/module.modulemap" ]; then
    mkdir -p "$VLC_FW/Modules"
    printf 'framework module MobileVLCKit {\n  umbrella header "MobileVLCKit.h"\n  export *\n  module * { export * }\n}\n' > "$VLC_FW/Modules/module.modulemap"
  fi
  ARCHS="$(lipo -archs "$VLC_FW/MobileVLCKit" 2>/dev/null || true)"
  echo "VLCKit architectures: $ARCHS"
  if [ -n "$ARCHS" ] && [ "$ARCHS" != "arm64" ] && echo " $ARCHS " | grep -q " arm64 "; then
    lipo "$VLC_FW/MobileVLCKit" -thin arm64 -output "$VLC_FW/MobileVLCKit.arm64" && mv "$VLC_FW/MobileVLCKit.arm64" "$VLC_FW/MobileVLCKit"
    echo "VLCKit thinned to arm64"
  fi
  KIND="$(file -b "$VLC_FW/MobileVLCKit" || true)"
  echo "VLCKit binary: $KIND"
  if echo "$KIND" | grep -qi "dynamically linked"; then
    VLC_DYNAMIC=1
    # what iOS checks in an embedded framework
    PL="$VLC_FW/Info.plist"
    [ -f "$PL" ] || printf '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict/></plist>\n' > "$PL"
    plutil -convert xml1 "$PL" 2>/dev/null || true
    setp() { plutil -replace "$1" -string "$2" "$PL" 2>/dev/null || true; }
    setp CFBundleExecutable MobileVLCKit
    /usr/libexec/PlistBuddy -c "Print :CFBundleIdentifier" "$PL" >/dev/null 2>&1 || setp CFBundleIdentifier org.videolan.mobilevlckit
    setp CFBundlePackageType FMWK
    setp CFBundleName MobileVLCKit
    /usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "$PL" >/dev/null 2>&1 || setp CFBundleShortVersionString 3.6.0
    /usr/libexec/PlistBuddy -c "Print :CFBundleVersion" "$PL" >/dev/null 2>&1 || setp CFBundleVersion 1
    setp MinimumOSVersion 15.0
    plutil -remove CFBundleSupportedPlatforms "$PL" 2>/dev/null || true
    plutil -insert CFBundleSupportedPlatforms -xml '<array><string>iPhoneOS</string></array>' "$PL" 2>/dev/null || true
    install_name_tool -id @rpath/MobileVLCKit.framework/MobileVLCKit "$VLC_FW/MobileVLCKit" 2>/dev/null || true
    # linked weakly: SahraMAC-lite.ipa (without this framework) still opens
    VLC_LINK="-weak_framework MobileVLCKit"
  fi
  VLC_DIR="$(dirname "$VLC_FW")"
fi

# ---------------- packaging (shared by both ways of building) ----------------
sign_and_zip() {
  local label="$1" embedded=0
  cp App/Resources/* "$APP/" 2>/dev/null || true
  printf 'APPL????' > "$APP/PkgInfo"
  plutil -lint "$APP/Info.plist" || true
  if [ -n "$VLC_FW" ] && [ "$VLC_DYNAMIC" = "1" ] && echo "$label" | grep -q VLC; then
    mkdir -p "$APP/Frameworks"
    rm -rf "$APP/Frameworks/MobileVLCKit.framework"
    cp -RL "$VLC_FW" "$APP/Frameworks/"
    rm -rf "$APP/Frameworks/MobileVLCKit.framework/Headers" "$APP/Frameworks/MobileVLCKit.framework/PrivateHeaders" "$APP/Frameworks/MobileVLCKit.framework/Modules"
    embedded=1
  fi
  sign_app "$APP"
  (cd build && rm -f ../SahraMAC.ipa && zip -qry ../SahraMAC.ipa Payload)
  ls -la SahraMAC.ipa
  note "Done: SahraMAC.ipa — engines: $label"
  # the same app without MobileVLCKit.framework — for when a signing tool still refuses that framework
  if [ "$embedded" = "1" ]; then
    if otool -l "$APP/SahraMAC" | grep -B2 -A4 LC_LOAD_WEAK_DYLIB | grep -q MobileVLCKit; then
      rm -rf build/lite && mkdir -p build/lite
      cp -R build/Payload build/lite/
      rm -rf build/lite/Payload/SahraMAC.app/Frameworks/MobileVLCKit.framework
      rmdir build/lite/Payload/SahraMAC.app/Frameworks 2>/dev/null || true
      sign_app build/lite/Payload/SahraMAC.app
      (cd build/lite && rm -f ../../SahraMAC-lite.ipa && zip -qry ../../SahraMAC-lite.ipa Payload)
      ls -la SahraMAC-lite.ipa
      note "Also: SahraMAC-lite.ipa — engines: $(echo "$label" | sed 's/ + VLC (VLCKit)//') (no VLC framework, installs everywhere)"
    else
      note "⚠️ VLCKit is not weakly linked — no lite IPA"
    fi
  fi
}

# ad-hoc signature, frameworks first; Sideloadly / AltStore / ESign sign it again with your own certificate
sign_app() {
  local app="$1"
  find "$app" -name '_CodeSignature' -type d -prune -exec rm -rf {} + 2>/dev/null || true
  if [ -d "$app/Frameworks" ]; then
    find "$app/Frameworks" -maxdepth 1 \( -name '*.framework' -o -name '*.dylib' \) -print0 |
      while IFS= read -r -d '' f; do codesign --force --sign - --timestamp=none --generate-entitlement-der "$f" >/dev/null 2>&1 ||
        codesign --force --sign - --timestamp=none "$f" >/dev/null 2>&1 || echo "codesign skipped: $f"; done
  fi
  codesign --force --sign - --timestamp=none "$app" || echo "codesign skipped"
  if codesign --verify --deep --strict "$app" > build/logs/verify.log 2>&1; then echo "signature check: OK"
  else echo "::warning::signature check failed"; tail -5 build/logs/verify.log; fi
}

engine_label() {
  local l="AVPlayer"
  case " $1 " in *" ks "*) l="$l + KSPlayer";; esac
  case " $1 " in *" mpv "*) l="$l + mpv (MPVKit)";; esac
  case " $1 " in *" vlc "*) l="$l + VLC (VLCKit)";; esac
  echo "$l"
}

# ---------------- Xcode + Swift packages (KSPlayer, MPVKit) ----------------
XCODEGEN=""
get_xcodegen() {
  if command -v xcodegen >/dev/null 2>&1; then XCODEGEN="$(command -v xcodegen)"; return 0; fi
  echo "Installing XcodeGen…"
  if command -v brew >/dev/null 2>&1 && HOMEBREW_NO_AUTO_UPDATE=1 HOMEBREW_NO_INSTALL_CLEANUP=1 brew install xcodegen >/dev/null 2>&1; then
    XCODEGEN="$(command -v xcodegen)"; [ -n "$XCODEGEN" ] && return 0
  fi
  rm -rf build/xcodegen && mkdir -p build/xcodegen
  if curl -fsSL --retry 2 -o build/xcodegen/x.zip https://github.com/yonaskolb/XcodeGen/releases/latest/download/xcodegen.zip &&
     (cd build/xcodegen && unzip -q x.zip); then
    XCODEGEN="$(find "$ROOT/build/xcodegen" -type f -name xcodegen -perm -u+x | head -1)"
    [ -n "$XCODEGEN" ] && return 0
  fi
  return 1
}

# writes project.yml for one combination of engines
gen_project() {
  local engines="$1" dt="$2"
  local conds="" ld='$(inherited)' fw='$(inherited)' swf='$(inherited)' has_pkg=0
  case " $engines " in *" ks "*) conds="$conds SAHRA_KS"; has_pkg=1;; esac
  case " $engines " in *" mpv "*) conds="$conds SAHRA_MPV"; has_pkg=1;; esac
  case " $engines " in *" vlc "*)
    conds="$conds SAHRA_VLC"
    fw="$fw \"$VLC_DIR\""
    ld="$ld $VLC_LINK -ObjC $VLC_LIBS"
    swf='$(inherited) -Xfrontend -disable-autolink-framework -Xfrontend MobileVLCKit'
    for f in $VLC_SYS; do ld="$ld -framework $f"; done
    [ "$VLC_DYNAMIC" = "1" ] && ld="$ld -Xlinker -rpath -Xlinker @executable_path/Frameworks"
    ;;
  esac
  # the deployment target the packages need (the plain build stays at iOS 15)
  cp App/Info.plist build/Info-xc.plist
  plutil -replace MinimumOSVersion -string "$dt" build/Info-xc.plist
  {
    echo "name: SahraMAC"
    echo "options:"
    echo "  deploymentTarget:"
    echo "    iOS: \"$dt\""
    if [ "$has_pkg" = "1" ]; then
      echo "packages:"
      case " $engines " in *" ks "*) printf '  KSPlayer:\n    url: https://github.com/kingslay/KSPlayer.git\n    branch: main\n';; esac
      case " $engines " in *" mpv "*) printf '  MPVKit:\n    url: https://github.com/mpvkit/MPVKit.git\n    from: "0.38.0"\n';; esac
    fi
    cat <<EOF
targets:
  SahraMAC:
    type: application
    platform: iOS
    deploymentTarget: "$dt"
    sources:
      - path: App/Sources
      - path: App/Resources
        buildPhase: resources
    scheme: {}
    settings:
      base:
        PRODUCT_NAME: SahraMAC
        PRODUCT_BUNDLE_IDENTIFIER: app.sahra.mac
        INFOPLIST_FILE: build/Info-xc.plist
        GENERATE_INFOPLIST_FILE: NO
        TARGETED_DEVICE_FAMILY: "1,2"
        SWIFT_VERSION: "5.0"
        CODE_SIGNING_ALLOWED: NO
        CODE_SIGNING_REQUIRED: NO
        CODE_SIGN_IDENTITY: ""
        ENABLE_BITCODE: NO
        SWIFT_ACTIVE_COMPILATION_CONDITIONS: "\$(inherited)$conds"
        OTHER_LDFLAGS: '$ld'
        FRAMEWORK_SEARCH_PATHS: '$fw'
        OTHER_SWIFT_FLAGS: '$swf'
EOF
    if [ "$has_pkg" = "1" ]; then
      echo "    dependencies:"
      case " $engines " in *" ks "*) printf '      - package: KSPlayer\n        product: KSPlayer\n';; esac
      case " $engines " in *" mpv "*) printf '      - package: MPVKit\n        product: MPVKit\n';; esac
    fi
  } > project.yml
}

try_xcode() {
  local engines="$1" dt="$2"
  local name; name="$(echo "$engines" | tr ' ' '+')-ios$dt"
  local log="build/logs/$name.log"
  echo "::group::Xcode build: $(engine_label "$engines") (iOS $dt)"
  rm -rf SahraMAC.xcodeproj build/dd
  gen_project "$engines" "$dt"
  if ! "$XCODEGEN" generate --spec project.yml > "$log" 2>&1; then
    tail -20 "$log"; echo "::endgroup::"; return 1
  fi
  local common=(-project SahraMAC.xcodeproj -scheme SahraMAC -configuration Release -sdk iphoneos -destination "generic/platform=iOS"
                -derivedDataPath build/dd -clonedSourcePackagesDirPath "$ROOT/.spm" -skipPackagePluginValidation -skipMacroValidation)
  if ! xcodebuild -resolvePackageDependencies -project SahraMAC.xcodeproj -scheme SahraMAC -derivedDataPath build/dd \
       -clonedSourcePackagesDirPath "$ROOT/.spm" >> "$log" 2>&1; then
    echo "✗ the packages don't fit together:"; grep -E "error|conflict|multiple|duplicate|minimum" "$log" | tail -15
    echo "::endgroup::"; return 2
  fi
  if ! xcodebuild "${common[@]}" CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build >> "$log" 2>&1; then
    echo "✗ build failed:"; grep -E "error:|duplicate symbol|Undefined symbol|ld: |minimum|requires" "$log" | sort -u | head -40
    echo "::endgroup::"; return 3
  fi
  local built="build/dd/Build/Products/Release-iphoneos/SahraMAC.app"
  if [ ! -x "$built/SahraMAC" ]; then echo "✗ no app came out"; echo "::endgroup::"; return 4; fi
  mkdir -p build/Payload
  cp -R "$built" "$APP"
  echo "::endgroup::"
  return 0
}

# ---------------- the plain build (no Xcode project): AVPlayer, VLC when present ----------------
build_plain() {
  local with_vlc="$1"
  local args=()
  if [ "$with_vlc" = "1" ]; then
    args=(-D SAHRA_VLC -F "$VLC_DIR" -Xfrontend -disable-autolink-framework -Xfrontend MobileVLCKit -Xlinker -ObjC -lc++ -lxml2 -lz -lbz2 -liconv)
    for w in $VLC_LINK; do args+=(-Xlinker "$w"); done
    for f in $VLC_SYS; do args+=(-framework "$f"); done
    [ "$VLC_DYNAMIC" = "1" ] && args+=(-Xlinker -rpath -Xlinker @executable_path/Frameworks)
  fi
  mkdir -p "$APP"
  xcrun --sdk iphoneos swiftc \
    -parse-as-library -O -whole-module-optimization \
    -target arm64-apple-ios15.0 -sdk "$SDK" \
    -framework UIKit -framework WebKit -framework JavaScriptCore -framework AVFoundation -framework AVKit \
    ${args[@]+"${args[@]}"} App/Sources/*.swift -o "$APP/SahraMAC"
}

# ---------------- go ----------------
HAVE_VLC=0; [ -n "$VLC_FW" ] && HAVE_VLC=1
COMBOS=()
if [ "${SAHRA_SIMPLE:-}" != "1" ]; then
  if [ -n "${SAHRA_ENGINES:-}" ]; then
    COMBOS=("$SAHRA_ENGINES")
  else
    COMBOS=("ks mpv vlc" "ks vlc" "mpv vlc" "ks mpv" "ks" "mpv")
  fi
fi

DONE=""
if [ "${#COMBOS[@]}" -gt 0 ] && get_xcodegen; then
  echo "XcodeGen: $XCODEGEN"
  SEEN=" "
  for combo in "${COMBOS[@]}"; do
    # without the VLCKit download, "vlc" drops out of every combination
    engines=""
    for e in $combo; do
      if [ "$e" = "vlc" ] && [ "$HAVE_VLC" = "0" ]; then continue; fi
      engines="$engines $e"
    done
    engines="$(echo $engines)"
    [ -z "$engines" ] && continue
    case "$SEEN" in *"|$engines|"*) continue;; esac
    SEEN="$SEEN|$engines|"
    case " $engines " in *" ks "*|*" mpv "*) ;; *) continue;; esac   # VLC alone: the plain build does it faster
    try_xcode "$engines" "16.0"; rc=$?
    if [ "$rc" != "0" ] && grep -qE "minimum (platform|deployment)|requires a minimum|is only available in iOS 17" "build/logs/$(echo "$engines" | tr ' ' '+')-ios16.0.log" 2>/dev/null; then
      try_xcode "$engines" "17.0"; rc=$?
    fi
    if [ "$rc" = "0" ]; then DONE="$engines"; break; fi
    note "⚠️ $(engine_label "$engines"): didn't build — trying fewer engines"
    rm -rf "$APP"
  done
else
  [ "${#COMBOS[@]}" -gt 0 ] && note "⚠️ XcodeGen unavailable — KSPlayer and MPVKit skipped"
fi

if [ -n "$DONE" ]; then
  sign_and_zip "$(engine_label "$DONE")"
  exit 0
fi

# the plain build: AVPlayer + VLC (+ the web engines inside the page)
rm -rf build/Payload
if [ "$HAVE_VLC" = "1" ] && build_plain 1 2> build/logs/plain-vlc.log; then
  cp App/Info.plist "$APP/Info.plist"
  sign_and_zip "$(engine_label "vlc")"
  exit 0
fi
[ "$HAVE_VLC" = "1" ] && { echo "::warning::VLC could not be built in"; tail -40 build/logs/plain-vlc.log || true; }
rm -rf build/Payload
build_plain 0 || exit 1
cp App/Info.plist "$APP/Info.plist"
sign_and_zip "$(engine_label "")"
