import Foundation
import UIKit
import UserNotifications

/// Downloads of movies and episodes. It is a *background* URLSession: the transfer goes on while the phone is locked
/// or the app is closed, and iOS wakes the app when it ends. The state of every download lives in
/// Documents/Downloads/state.json; the script asks for it (`info()`) and the page shows it.
/// The files stay in Documents/Downloads/<file> and the page plays them from sahra://app/Downloads/<file>.
final class Downloader: NSObject, URLSessionDownloadDelegate {
    static let shared = Downloader()
    static let dir: String = (Runtime.docs as NSString).appendingPathComponent("Downloads")
    private static let stateFile: String = (Downloader.dir as NSString).appendingPathComponent("state.json")

    struct Item: Codable {
        var id: String
        var url: String
        var ua: String
        var file: String
        var state: String          // queued | downloading | paused | done | error
        var bytes: Int64 = 0
        var total: Int64 = 0
        var err: String = ""
        var resume: Data? = nil    // what iOS gives to carry on a stopped transfer
        var title: String? = nil   // 3.26: the film's name (for the «download finished» notification)
        var tries: Int? = nil      // 3.26: automatic retries after a dropped connection
        var part: Part? = nil      // 3.27: only a part of the film (from–to)
    }

    /// 3.27: only a part of the film. The file keeps its full size on the phone — what is not downloaded takes no room
    /// (a sparse file) — so every byte sits where the players look for it: the beginning (the film's description), the
    /// chosen minutes, and the index at the end for MP4 / MKV / AVI. The players open it at «from».
    struct Part: Codable {
        var from: Double
        var to: Double
        var dur: Double
        var total: Int64 = 0          // the whole file's size
        var ranges: [[Int64]] = []    // [a, b] (b included) to fetch, in order
        var idx: Int = -1             // -1: the first look (the file's beginning); then the range being fetched
        var got: Int64 = 0            // bytes in place
        var need: Int64 = 0           // bytes in all
        var base: Int64 = -1          // MPEG-TS: the chosen minutes only, as a file of their own (offset of its first byte)
    }

    private var items: [Item] = []
    private var taskOf: [String: URLSessionDownloadTask] = [:]
    private var spaceChecked = Set<String>()
    private var lastSave = Date.distantPast
    private let maxActive = 2
    private var session: URLSession!
    /// 3.26: a dropped connection is tried again by itself, a little later each time (not kept across launches)
    private var retryAt: [String: Date] = [:]
    private var askedNotify = false
    /// iOS hands this over when it wakes the app for a finished background transfer
    var bgCompletion: (() -> Void)?

    override init() {
        super.init()
        let fm = FileManager.default
        try? fm.createDirectory(atPath: Downloader.dir, withIntermediateDirectories: true, attributes: nil)
        // the movies must not fill the phone's iCloud backup
        var dirURL = URL(fileURLWithPath: Downloader.dir)
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true
        try? dirURL.setResourceValues(rv)
        load()
        let c = URLSessionConfiguration.background(withIdentifier: (Bundle.main.bundleIdentifier ?? "sahra.mac") + ".downloads")
        c.sessionSendsLaunchEvents = true
        c.isDiscretionary = false
        c.allowsCellularAccess = true
        c.timeoutIntervalForResource = 60 * 60 * 24 * 3
        session = URLSession(configuration: c, delegate: self, delegateQueue: OperationQueue.main)
        session.getAllTasks { tasks in
            DispatchQueue.main.async { self.reattach(tasks) }
        }
    }

    // ---- what the script calls ----
    /// fresh: forget what was downloaded so far and start the file again from the beginning
    func start(id: String, url: String, ua: String, file: String, fresh: Bool) {
        askNotify()
        retryAt.removeValue(forKey: id)
        if let i = items.firstIndex(where: { $0.id == id }) {
            if items[i].state == "done" && fileSize(items[i].file) > 0 && !fresh { return }
            if fresh {
                if let t = taskOf.removeValue(forKey: id) { t.cancel() }
                try? FileManager.default.removeItem(atPath: path(items[i].file))
                items[i].resume = nil
                items[i].bytes = 0
                items[i].total = 0
                if let p = items[i].part { items[i].part = Part(from: p.from, to: p.to, dur: p.dur) }
            }
            // a part goes on from the range it stopped at; a new link can't carry on the old transfer
            if items[i].part != nil && !url.isEmpty && url != items[i].url { items[i].resume = nil }
            if !url.isEmpty { items[i].url = url }
            items[i].ua = ua
            items[i].file = file
            items[i].state = "queued"
            items[i].err = ""
            items[i].tries = nil
            spaceChecked.remove(id)
        } else {
            items.append(Item(id: id, url: url, ua: ua, file: file, state: "queued"))
        }
        save()
        pump()
    }

    /// 3.27: only the minutes from–to of a film of `dur` seconds
    func startPart(id: String, url: String, ua: String, file: String, from: Double, to: Double, dur: Double) {
        askNotify()
        retryAt.removeValue(forKey: id)
        if let i = items.firstIndex(where: { $0.id == id }) {
            if items[i].state == "done" && fileSize(items[i].file) > 0 { return }
            if !url.isEmpty && url != items[i].url { items[i].resume = nil }
            if !url.isEmpty { items[i].url = url }
            items[i].ua = ua
            items[i].state = "queued"
            items[i].err = ""
            items[i].tries = nil
            if items[i].part == nil { items[i].part = Part(from: from, to: to, dur: dur) }
        } else {
            var it = Item(id: id, url: url, ua: ua, file: file, state: "queued")
            it.part = Part(from: from, to: to, dur: dur)
            items.append(it)
        }
        save()
        pump()
    }

    /// the film's name, shown in the notification when the download ends
    func setTitle(_ id: String, _ title: String) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        items[i].title = String(title.prefix(120))
        save()
    }

    func pause(_ id: String) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        if items[i].state == "queued" {
            items[i].state = "paused"
            save()
            return
        }
        guard items[i].state == "downloading", let t = taskOf.removeValue(forKey: id) else { return }
        items[i].state = "paused"
        save()
        t.cancel(byProducingResumeData: { data in
            DispatchQueue.main.async {
                if let j = self.items.firstIndex(where: { $0.id == id }) {
                    self.items[j].resume = data
                    self.save()
                }
                self.pump()
            }
        })
    }

    func remove(_ id: String) {
        if let t = taskOf.removeValue(forKey: id) { t.cancel() }
        if let i = items.firstIndex(where: { $0.id == id }) {
            try? FileManager.default.removeItem(atPath: path(items[i].file))
            items.remove(at: i)
        }
        try? FileManager.default.removeItem(atPath: Downloader.piecePath(id))
        spaceChecked.remove(id)
        save()
        pump()
    }

    /// [{id, state, bytes, total, file, err, size}] — size is what is on the disk now
    func info() -> String {
        let arr: [[String: Any]] = items.map { it in
            var e: [String: Any] = ["id": it.id, "state": it.state, "bytes": it.bytes, "total": it.total,
                                    "file": it.file, "err": it.err, "size": fileSize(it.file)]
            if let p = it.part {
                // a part: what is really on the phone, not the file's full (mostly empty) size
                e["size"] = it.state == "done" ? p.got : it.bytes
                e["part"] = [p.from, p.to]
                // MPEG-TS part: a file of its own that plays from its start (the others open at «from»)
                e["compact"] = p.base >= 0
            }
            return e
        }
        guard let d = try? JSONSerialization.data(withJSONObject: arr, options: []),
              let s = String(data: d, encoding: .utf8) else { return "[]" }
        return s
    }

    // ---- the queue: two at a time ----
    private func pump() {
        var running = items.filter { $0.state == "downloading" }.count
        let now = Date()
        for i in items.indices where items[i].state == "queued" {
            if running >= maxActive { break }
            if let w = retryAt[items[i].id], w > now { continue }
            retryAt.removeValue(forKey: items[i].id)
            let task: URLSessionDownloadTask
            if let rd = items[i].resume {
                task = session.downloadTask(withResumeData: rd)
            } else {
                guard let u = Net.makeURL(items[i].url) else {
                    items[i].state = "error"
                    items[i].err = "رابط غير صالح"
                    continue
                }
                var req = URLRequest(url: u)
                if !items[i].ua.isEmpty { req.setValue(items[i].ua, forHTTPHeaderField: "User-Agent") }
                req.setValue("*/*", forHTTPHeaderField: "Accept")
                if let p = items[i].part {
                    // a part: first the film's beginning, then each range in turn
                    if p.idx < 0 {
                        req.setValue("bytes=0-\(PartPlan.headBytes - 1)", forHTTPHeaderField: "Range")
                    } else if p.idx < p.ranges.count {
                        req.setValue("bytes=\(p.ranges[p.idx][0])-\(p.ranges[p.idx][1])", forHTTPHeaderField: "Range")
                    }
                    req.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
                }
                task = session.downloadTask(with: req)
            }
            task.taskDescription = items[i].id
            taskOf[items[i].id] = task
            items[i].state = "downloading"
            items[i].resume = nil
            task.resume()
            running += 1
        }
        save()
    }

    /// after the app is opened again: the transfers iOS kept going in the background
    private func reattach(_ tasks: [URLSessionTask]) {
        for t in tasks {
            guard let dt = t as? URLSessionDownloadTask, let id = t.taskDescription,
                  let i = items.firstIndex(where: { $0.id == id }) else { t.cancel(); continue }
            if t.state == .canceling || t.state == .completed { continue }
            taskOf[id] = dt
            items[i].state = "downloading"
            if t.state == .suspended { t.resume() }
        }
        // saved as «downloading» but nothing carries it on any more → wait in the queue
        for i in items.indices where items[i].state == "downloading" && taskOf[items[i].id] == nil { items[i].state = "queued" }
        save()
        pump()
    }

    // ---- URLSession ----
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = downloadTask.taskDescription, let i = items.firstIndex(where: { $0.id == id }) else { return }
        if let p = items[i].part {
            if p.idx < 0 {
                // asked for the beginning, got the whole film: this server has no parts
                if totalBytesWritten > PartPlan.headBytes + 1_048_576 {
                    taskOf.removeValue(forKey: id)
                    downloadTask.cancel()
                    failPart(i, "هذا الخادم لا يسمح بتنزيل جزء من الفيلم — نزّله كاملاً")
                    return
                }
                items[i].bytes = totalBytesWritten
            } else {
                items[i].bytes = p.got + totalBytesWritten
                items[i].total = p.need
            }
            if items[i].tries != nil && bytesWritten > 0 { items[i].tries = nil; items[i].err = "" }
            if Date().timeIntervalSince(lastSave) > 3 { save() }
            return
        }
        items[i].bytes = totalBytesWritten
        if totalBytesExpectedToWrite > 0 { items[i].total = totalBytesExpectedToWrite }
        if items[i].tries != nil && bytesWritten > 0 { items[i].tries = nil; items[i].err = "" }
        if totalBytesExpectedToWrite > 0 && !spaceChecked.contains(id) {
            spaceChecked.insert(id)
            if let free = freeSpace(), free < totalBytesExpectedToWrite + 300_000_000 {
                items[i].state = "error"
                items[i].err = "مساحة التخزين في الجهاز غير كافية"
                items[i].resume = nil
                taskOf.removeValue(forKey: id)
                downloadTask.cancel()
                save()
                pump()
                return
            }
        }
        if Date().timeIntervalSince(lastSave) > 3 { save() }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = downloadTask.taskDescription, let i = items.firstIndex(where: { $0.id == id }) else { return }
        if items[i].part != nil { finishPart(i, downloadTask, location); return }
        // an error page instead of the movie
        if let h = downloadTask.response as? HTTPURLResponse, !(200..<300).contains(h.statusCode) {
            items[i].state = "error"
            items[i].err = "رفض الخادم التنزيل (HTTP \(h.statusCode))"
            save()
            notifyEnd(items[i], ok: false)
            return
        }
        // a small web page instead of the movie (an expired link, a «not allowed» page)
        let got = ((try? FileManager.default.attributesOfItem(atPath: location.path))?[.size] as? NSNumber)?.int64Value ?? 0
        let mime = (downloadTask.response?.mimeType ?? "").lowercased()
        if got < 2_000_000 && (mime.hasPrefix("text/") || mime.contains("json") || mime.contains("xml")) {
            items[i].state = "error"
            items[i].err = "الخادم أرسل صفحة بدل الفيلم (الرابط انتهى غالباً)"
            items[i].resume = nil
            save()
            notifyEnd(items[i], ok: false)
            return
        }
        let dest = path(items[i].file)
        try? FileManager.default.removeItem(atPath: dest)
        do {
            try FileManager.default.moveItem(at: location, to: URL(fileURLWithPath: dest))
        } catch {
            items[i].state = "error"
            items[i].err = "تعذّر حفظ الملف: " + error.localizedDescription
            save()
            return
        }
        let n = fileSize(items[i].file)
        items[i].state = "done"
        items[i].resume = nil
        items[i].bytes = n
        items[i].total = n
        items[i].err = ""
        items[i].tries = nil
        save()
        notifyEnd(items[i], ok: true)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = task.taskDescription else { return }
        if taskOf[id]?.taskIdentifier == task.taskIdentifier { taskOf.removeValue(forKey: id) }
        defer { pump() }
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        // paused, finished or already marked as failed: nothing more to record
        guard items[i].state == "downloading", let e = error as NSError? else { save(); return }
        if let rd = e.userInfo[NSURLSessionDownloadTaskResumeData] as? Data { items[i].resume = rd }
        // the network dropped (lift, tunnel, Wi-Fi ↔ 4G): tried again by itself from where it stopped, up to 6 times
        let transient: Set<Int> = [NSURLErrorTimedOut, NSURLErrorNetworkConnectionLost, NSURLErrorNotConnectedToInternet,
                                   NSURLErrorCannotConnectToHost, NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed,
                                   NSURLErrorDataNotAllowed, NSURLErrorInternationalRoamingOff, NSURLErrorCallIsActive,
                                   NSURLErrorBackgroundSessionWasDisconnected, NSURLErrorSecureConnectionFailed]
        let tries = items[i].tries ?? 0
        if e.domain == NSURLErrorDomain && transient.contains(e.code) && tries < 6 {
            let wait: [Double] = [4, 12, 30, 60, 120, 240]
            items[i].tries = tries + 1
            items[i].state = "queued"
            items[i].err = "انقطع الاتصال — إعادة المحاولة تلقائياً (\(tries + 1)/6)…"
            retryAt[id] = Date().addingTimeInterval(wait[tries])
            save()
            DispatchQueue.main.asyncAfter(deadline: .now() + wait[tries] + 0.2) { [weak self] in self?.pump() }
            return
        }
        items[i].state = "error"
        items[i].err = e.code == NSURLErrorCancelled ? "أُلغي" : e.localizedDescription
        save()
        if e.code != NSURLErrorCancelled { notifyEnd(items[i], ok: false) }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            self.bgCompletion?()
            self.bgCompletion = nil
        }
    }

    /// many IPTV servers have a certificate that is not valid
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }

    // ---- 3.27: a part of the film ----
    static func piecePath(_ id: String) -> String {
        let dir = (Downloader.dir as NSString).appendingPathComponent(".parts")
        try? FileManager.default.createDirectory(atPath: dir, withIntermediateDirectories: true, attributes: nil)
        return (dir as NSString).appendingPathComponent(id + ".piece")
    }

    private func failPart(_ i: Int, _ msg: String) {
        items[i].state = "error"
        items[i].err = msg
        items[i].resume = nil
        save()
        notifyEnd(items[i], ok: false)
    }

    /// the next range, or the end
    private func advancePart(_ i: Int) {
        guard let p = items[i].part else { return }
        items[i].resume = nil
        items[i].bytes = p.got
        items[i].total = p.need
        if p.idx >= p.ranges.count {
            items[i].state = "done"
            items[i].err = ""
            items[i].tries = nil
            save()
            notifyEnd(items[i], ok: true)
            pump()
            return
        }
        items[i].state = "queued"
        save()
        pump()
    }

    private func finishPart(_ i: Int, _ task: URLSessionDownloadTask, _ location: URL) {
        guard var p = items[i].part else { return }
        let id = items[i].id
        let h = task.response as? HTTPURLResponse
        let code = h?.statusCode ?? 0
        let cr = StreamCache.parseContentRange(StreamCache.header(h, "Content-Range"))
        // iOS deletes `location` when this returns: the piece is kept aside
        let piece = URL(fileURLWithPath: Downloader.piecePath(id))
        try? FileManager.default.removeItem(at: piece)
        do { try FileManager.default.moveItem(at: location, to: piece) } catch { failPart(i, "تعذّر حفظ الجزء على الجهاز"); return }
        let dest = path(items[i].file)
        if p.idx < 0 {
            // the film's beginning: its size, its kind and where its index sits give the ranges to fetch
            guard code == 206, let r = cr, r.start == 0, r.total > 0 else {
                try? FileManager.default.removeItem(at: piece)
                failPart(i, code == 200 || code == 206 ? "هذا الخادم لا يسمح بتنزيل جزء من الفيلم — نزّله كاملاً" : "رفض الخادم التنزيل (HTTP \(code))")
                return
            }
            let head = (try? Data(contentsOf: piece)) ?? Data()
            try? FileManager.default.removeItem(at: piece)
            p.total = r.total
            p.idx = 0
            if PartPlan.kind(head) == "ts" {
                // MPEG-TS needs no description: the chosen minutes alone make a file that plays from its start
                p.ranges = PartPlan.tsRanges(total: r.total, from: p.from, to: p.to, dur: p.dur)
                p.base = p.ranges.first?[0] ?? 0
                p.got = 0
                p.need = p.ranges.reduce(Int64(0)) { $0 + ($1[1] - $1[0] + 1) }
                if let free = freeSpace(), free < p.need + 300_000_000 {
                    failPart(i, "مساحة التخزين في الجهاز غير كافية")
                    return
                }
                try? FileManager.default.removeItem(atPath: dest)
                FileManager.default.createFile(atPath: dest, contents: nil, attributes: nil)
                items[i].part = p
                advancePart(i)
                return
            }
            p.ranges = PartPlan.ranges(head: head, total: r.total, from: p.from, to: p.to, dur: p.dur)
            p.got = Int64(head.count)
            p.need = p.got + p.ranges.reduce(Int64(0)) { $0 + ($1[1] - $1[0] + 1) }
            if let free = freeSpace(), free < p.need - p.got + 300_000_000 {
                failPart(i, "مساحة التخزين في الجهاز غير كافية")
                return
            }
            // the file at its full size (what is not written takes no room), the beginning in place
            try? FileManager.default.removeItem(atPath: dest)
            FileManager.default.createFile(atPath: dest, contents: nil, attributes: nil)
            guard let fh = FileHandle(forWritingAtPath: dest) else { failPart(i, "تعذّر تجهيز الملف"); return }
            do {
                try fh.truncate(atOffset: UInt64(r.total))
                try fh.seek(toOffset: 0)
                try fh.write(contentsOf: head)
                try fh.close()
            } catch {
                try? fh.close()
                failPart(i, "تعذّر تجهيز الملف")
                return
            }
            items[i].part = p
            advancePart(i)
            return
        }
        guard p.idx < p.ranges.count else { advancePart(i); return }
        let want = p.ranges[p.idx]
        let size = ((try? FileManager.default.attributesOfItem(atPath: piece.path))?[.size] as? NSNumber)?.int64Value ?? 0
        // the server sent the whole film instead of the range: keep the whole film
        let whole = code == 200 && p.total > 0 && size == p.total
        guard whole || (code == 206 && cr?.start == want[0]) else {
            try? FileManager.default.removeItem(at: piece)
            failPart(i, code == 200 || code == 206 ? "الخادم أرسل جزءاً غير المطلوب — حاول مرة أخرى" : "رفض الخادم التنزيل (HTTP \(code))")
            return
        }
        // written where it belongs, away from the screen's thread (it can be hundreds of MB); the slot stays busy meanwhile
        let fullSize = p.total
        let at = want[0] - max(Int64(0), p.base)
        items[i].state = "downloading"
        DispatchQueue.global(qos: .utility).async {
            var ok = false
            if whole {
                try? FileManager.default.removeItem(atPath: dest)
                ok = (try? FileManager.default.moveItem(at: piece, to: URL(fileURLWithPath: dest))) != nil
            } else {
                ok = PartPlan.write(piece, to: dest, at: at)
            }
            try? FileManager.default.removeItem(at: piece)
            DispatchQueue.main.async {
                guard let j = self.items.firstIndex(where: { $0.id == id }), var q = self.items[j].part else { return }
                if !ok { self.failPart(j, "تعذّر كتابة الجزء على الجهاز"); return }
                if whole {
                    q.idx = q.ranges.count
                    q.got = fullSize
                    q.need = fullSize
                    q.base = -1
                } else {
                    q.got += want[1] - want[0] + 1
                    q.idx += 1
                }
                self.items[j].part = q
                self.advancePart(j)
            }
        }
    }

    // ---- 3.26: a notification when a download ends while the app is not on screen ----
    private func askNotify() {
        if askedNotify { return }
        askedNotify = true
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func notifyEnd(_ it: Item, ok: Bool) {
        guard UIApplication.shared.applicationState != .active else { return }
        let c = UNMutableNotificationContent()
        let name = (it.title ?? "").isEmpty ? "الفيلم" : (it.title ?? "")
        c.title = ok ? "✓ اكتمل التنزيل" : "تعذّر التنزيل"
        c.body = ok ? name + " — جاهز للمشاهدة بدون إنترنت" : name + " — " + it.err
        c.sound = .default
        let req = UNNotificationRequest(identifier: "sahra.dl." + it.id, content: c, trigger: nil)
        UNUserNotificationCenter.current().add(req, withCompletionHandler: nil)
    }

    // ---- helpers ----
    private func path(_ file: String) -> String { (Downloader.dir as NSString).appendingPathComponent(file) }

    private func fileSize(_ file: String) -> Int64 {
        ((try? FileManager.default.attributesOfItem(atPath: path(file)))?[.size] as? NSNumber)?.int64Value ?? 0
    }

    private func freeSpace() -> Int64? {
        let v = try? URL(fileURLWithPath: NSHomeDirectory()).resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return v?.volumeAvailableCapacityForImportantUsage
    }

    private func save() {
        lastSave = Date()
        guard let d = try? JSONEncoder().encode(items) else { return }
        try? d.write(to: URL(fileURLWithPath: Downloader.stateFile), options: .atomic)
    }

    private func load() {
        guard let d = FileManager.default.contents(atPath: Downloader.stateFile),
              let a = try? JSONDecoder().decode([Item].self, from: d) else { return }
        items = a
    }
}

/// 3.27: which bytes of a film a part needs, and writing a piece in place.
enum PartPlan {
    /// the first look: enough for MKV's / AVI's description and for an MP4 whose index comes first
    static let headBytes: Int64 = 4 * 1024 * 1024

    static func ranges(head: Data, total: Int64, from: Double, to: Double, dur: Double) -> [[Int64]] {
        let have = Int64(head.count)
        var want: [[Int64]] = []
        // the chosen minutes, with a minute and a bit on each side (a film's bitrate is not even)
        if dur > 0 && total > 0 {
            let rate = Double(total) / dur
            let pad = Int64(rate * 60) + 1_048_576
            let a = max(Int64(0), Int64(rate * max(0, from)) - pad)
            let b = min(total - 1, Int64(rate * min(dur, max(to, from))) + pad)
            if b > a { want.append([a, b]) }
        }
        // the index: MP4's moov wherever it is, the end of MKV (Cues) and AVI (idx1); MPEG-TS has none
        let k = kind(head)
        if k == "mp4" {
            if let m = moov(head, total: total) { want.append([m.start, min(total - 1, m.end)]) }
        } else if k != "ts" {
            let tail: Int64 = k == "avi" ? 8 << 20 : 6 << 20
            want.append([max(Int64(0), total - tail), total - 1])
        }
        // what the beginning brought is not fetched again; sorted and joined
        var out: [[Int64]] = []
        for r in want.sorted(by: { $0[0] < $1[0] }) {
            let a = max(r[0], have)
            let b = r[1]
            if b < a { continue }
            if let last = out.last, a <= last[1] + 1 {
                out[out.count - 1] = [last[0], max(last[1], b)]
            } else {
                out.append([a, b])
            }
        }
        // big ranges in pieces of 256 MB: a dropped connection loses less, and the progress moves
        var split: [[Int64]] = []
        let step: Int64 = 256 << 20
        for r in out {
            var a = r[0]
            while a <= r[1] {
                let b = min(r[1], a + step - 1)
                split.append([a, b])
                a = b + 1
            }
        }
        return split
    }

    /// MPEG-TS: the chosen minutes (with the same margin), on 188-byte packet boundaries
    static func tsRanges(total: Int64, from: Double, to: Double, dur: Double) -> [[Int64]] {
        guard dur > 0, total > 0 else { return [] }
        let rate = Double(total) / dur
        let pad = Int64(rate * 60) + 1_048_576
        let a = max(Int64(0), Int64(rate * max(0, from)) - pad) / 188 * 188
        let b = min(total - 1, Int64(rate * min(dur, max(to, from))) + pad)
        guard b > a else { return [] }
        var split: [[Int64]] = []
        let step: Int64 = 256 << 20
        var x = a
        while x <= b {
            let y = min(b, x + step - 1)
            split.append([x, y])
            x = y + 1
        }
        return split
    }

    static func kind(_ d: Data) -> String {
        let b = [UInt8](d.prefix(12))
        if b.count >= 8 {
            let t = String(bytes: b[4..<8], encoding: .ascii) ?? ""
            if ["ftyp", "moov", "mdat", "free", "wide", "skip"].contains(t) { return "mp4" }
        }
        if b.count >= 4 && b[0] == 0x1A && b[1] == 0x45 && b[2] == 0xDF && b[3] == 0xA3 { return "mkv" }
        if b.count >= 4 && b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46 { return "avi" }
        if b.count >= 1 && b[0] == 0x47 { return "ts" }
        return "other"
    }

    /// where MP4's index (moov) sits: read from the boxes in the beginning; after a big mdat it runs to the end
    static func moov(_ d: Data, total: Int64) -> (start: Int64, end: Int64)? {
        let b = [UInt8](d)
        var off: Int64 = 0
        var n = 0
        while off + 8 <= total && n < 64 {
            n += 1
            if off + 8 > Int64(b.count) { return (off, total - 1) }
            let i = Int(off)
            var size: Int64 = 0
            for k in 0..<4 { size = (size << 8) | Int64(b[i + k]) }
            let type = String(bytes: b[(i + 4)..<(i + 8)], encoding: .ascii) ?? ""
            var hdr: Int64 = 8
            if size == 1 {
                guard i + 16 <= b.count else { return nil }
                size = 0
                for k in 8..<16 { size = (size << 8) | Int64(b[i + k]) }
                hdr = 16
            } else if size == 0 {
                size = total - off
            }
            if type == "moov" { return (off, off + size - 1) }
            if size < hdr { return nil }
            off += size
        }
        return nil
    }

    /// copies a downloaded piece into the film's file at its place
    static func write(_ src: URL, to dest: String, at offset: Int64) -> Bool {
        guard let input = try? FileHandle(forReadingFrom: src), let out = FileHandle(forWritingAtPath: dest) else { return false }
        defer {
            try? input.close()
            try? out.close()
        }
        do {
            try out.seek(toOffset: UInt64(offset))
            var more = true
            while more {
                more = try autoreleasepool { () -> Bool in
                    guard let chunk = try input.read(upToCount: 4 << 20), !chunk.isEmpty else { return false }
                    try out.write(contentsOf: chunk)
                    return true
                }
            }
            return true
        } catch {
            return false
        }
    }
}
