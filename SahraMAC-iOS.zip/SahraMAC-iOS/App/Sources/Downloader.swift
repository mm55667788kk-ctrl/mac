import Foundation
import UIKit
import UserNotifications

/// Downloads of movies and episodes. It is a *background* URLSession: the transfer goes on while the phone is locked
/// or the app is closed, and iOS wakes the app when it ends. The state of every download lives in
/// Documents/Downloads/state.json; the script asks for it (`info()`) and the page shows it.
/// The files stay in Documents/Downloads/<file> and the page plays them from sahra://app/Downloads/<file>.
final class Downloader: NSObject, URLSessionDownloadDelegate {
    static let shared = Downloader()
    static let dir: String = (Runtime.docs as NSString).appendingPathComponent("Downloads")
    private static let stateFile: String = (Downloader.dir as NSString).appendingPathComponent("state.json")

    struct Item: Codable {
        var id: String
        var url: String
        var ua: String
        var file: String
        var state: String          // queued | downloading | paused | done | error
        var bytes: Int64 = 0
        var total: Int64 = 0
        var err: String = ""
        var resume: Data? = nil    // what iOS gives to carry on a stopped transfer
        var title: String? = nil   // 3.26: the film's name (for the «download finished» notification)
        var tries: Int? = nil      // 3.26: automatic retries after a dropped connection
    }

    private var items: [Item] = []
    private var taskOf: [String: URLSessionDownloadTask] = [:]
    private var spaceChecked = Set<String>()
    private var lastSave = Date.distantPast
    private let maxActive = 2
    private var session: URLSession!
    /// 3.26: a dropped connection is tried again by itself, a little later each time (not kept across launches)
    private var retryAt: [String: Date] = [:]
    private var askedNotify = false
    /// iOS hands this over when it wakes the app for a finished background transfer
    var bgCompletion: (() -> Void)?

    override init() {
        super.init()
        let fm = FileManager.default
        try? fm.createDirectory(atPath: Downloader.dir, withIntermediateDirectories: true, attributes: nil)
        // the movies must not fill the phone's iCloud backup
        var dirURL = URL(fileURLWithPath: Downloader.dir)
        var rv = URLResourceValues()
        rv.isExcludedFromBackup = true
        try? dirURL.setResourceValues(rv)
        load()
        let c = URLSessionConfiguration.background(withIdentifier: (Bundle.main.bundleIdentifier ?? "sahra.mac") + ".downloads")
        c.sessionSendsLaunchEvents = true
        c.isDiscretionary = false
        c.allowsCellularAccess = true
        c.timeoutIntervalForResource = 60 * 60 * 24 * 3
        session = URLSession(configuration: c, delegate: self, delegateQueue: OperationQueue.main)
        session.getAllTasks { tasks in
            DispatchQueue.main.async { self.reattach(tasks) }
        }
    }

    // ---- what the script calls ----
    /// fresh: forget what was downloaded so far and start the file again from the beginning
    func start(id: String, url: String, ua: String, file: String, fresh: Bool) {
        askNotify()
        retryAt.removeValue(forKey: id)
        if let i = items.firstIndex(where: { $0.id == id }) {
            if items[i].state == "done" && fileSize(items[i].file) > 0 && !fresh { return }
            if fresh {
                if let t = taskOf.removeValue(forKey: id) { t.cancel() }
                try? FileManager.default.removeItem(atPath: path(items[i].file))
                items[i].resume = nil
                items[i].bytes = 0
                items[i].total = 0
            }
            if !url.isEmpty { items[i].url = url }
            items[i].ua = ua
            items[i].file = file
            items[i].state = "queued"
            items[i].err = ""
            items[i].tries = nil
            spaceChecked.remove(id)
        } else {
            items.append(Item(id: id, url: url, ua: ua, file: file, state: "queued"))
        }
        save()
        pump()
    }

    /// the film's name, shown in the notification when the download ends
    func setTitle(_ id: String, _ title: String) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        items[i].title = String(title.prefix(120))
        save()
    }

    func pause(_ id: String) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        if items[i].state == "queued" {
            items[i].state = "paused"
            save()
            return
        }
        guard items[i].state == "downloading", let t = taskOf.removeValue(forKey: id) else { return }
        items[i].state = "paused"
        save()
        t.cancel(byProducingResumeData: { data in
            DispatchQueue.main.async {
                if let j = self.items.firstIndex(where: { $0.id == id }) {
                    self.items[j].resume = data
                    self.save()
                }
                self.pump()
            }
        })
    }

    func remove(_ id: String) {
        if let t = taskOf.removeValue(forKey: id) { t.cancel() }
        if let i = items.firstIndex(where: { $0.id == id }) {
            try? FileManager.default.removeItem(atPath: path(items[i].file))
            items.remove(at: i)
        }
        spaceChecked.remove(id)
        save()
        pump()
    }

    /// [{id, state, bytes, total, file, err, size}] — size is what is on the disk now
    func info() -> String {
        let arr: [[String: Any]] = items.map { it in
            ["id": it.id, "state": it.state, "bytes": it.bytes, "total": it.total,
             "file": it.file, "err": it.err, "size": fileSize(it.file)]
        }
        guard let d = try? JSONSerialization.data(withJSONObject: arr, options: []),
              let s = String(data: d, encoding: .utf8) else { return "[]" }
        return s
    }

    // ---- the queue: two at a time ----
    private func pump() {
        var running = items.filter { $0.state == "downloading" }.count
        let now = Date()
        for i in items.indices where items[i].state == "queued" {
            if running >= maxActive { break }
            if let w = retryAt[items[i].id], w > now { continue }
            retryAt.removeValue(forKey: items[i].id)
            let task: URLSessionDownloadTask
            if let rd = items[i].resume {
                task = session.downloadTask(withResumeData: rd)
            } else {
                guard let u = Net.makeURL(items[i].url) else {
                    items[i].state = "error"
                    items[i].err = "رابط غير صالح"
                    continue
                }
                var req = URLRequest(url: u)
                if !items[i].ua.isEmpty { req.setValue(items[i].ua, forHTTPHeaderField: "User-Agent") }
                req.setValue("*/*", forHTTPHeaderField: "Accept")
                task = session.downloadTask(with: req)
            }
            task.taskDescription = items[i].id
            taskOf[items[i].id] = task
            items[i].state = "downloading"
            items[i].resume = nil
            task.resume()
            running += 1
        }
        save()
    }

    /// after the app is opened again: the transfers iOS kept going in the background
    private func reattach(_ tasks: [URLSessionTask]) {
        for t in tasks {
            guard let dt = t as? URLSessionDownloadTask, let id = t.taskDescription,
                  let i = items.firstIndex(where: { $0.id == id }) else { t.cancel(); continue }
            if t.state == .canceling || t.state == .completed { continue }
            taskOf[id] = dt
            items[i].state = "downloading"
            if t.state == .suspended { t.resume() }
        }
        // saved as «downloading» but nothing carries it on any more → wait in the queue
        for i in items.indices where items[i].state == "downloading" && taskOf[items[i].id] == nil { items[i].state = "queued" }
        save()
        pump()
    }

    // ---- URLSession ----
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = downloadTask.taskDescription, let i = items.firstIndex(where: { $0.id == id }) else { return }
        items[i].bytes = totalBytesWritten
        if totalBytesExpectedToWrite > 0 { items[i].total = totalBytesExpectedToWrite }
        if items[i].tries != nil && bytesWritten > 0 { items[i].tries = nil; items[i].err = "" }
        if totalBytesExpectedToWrite > 0 && !spaceChecked.contains(id) {
            spaceChecked.insert(id)
            if let free = freeSpace(), free < totalBytesExpectedToWrite + 300_000_000 {
                items[i].state = "error"
                items[i].err = "مساحة التخزين في الجهاز غير كافية"
                items[i].resume = nil
                taskOf.removeValue(forKey: id)
                downloadTask.cancel()
                save()
                pump()
                return
            }
        }
        if Date().timeIntervalSince(lastSave) > 3 { save() }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = downloadTask.taskDescription, let i = items.firstIndex(where: { $0.id == id }) else { return }
        // an error page instead of the movie
        if let h = downloadTask.response as? HTTPURLResponse, !(200..<300).contains(h.statusCode) {
            items[i].state = "error"
            items[i].err = "رفض الخادم التنزيل (HTTP \(h.statusCode))"
            save()
            notifyEnd(items[i], ok: false)
            return
        }
        // a small web page instead of the movie (an expired link, a «not allowed» page)
        let got = ((try? FileManager.default.attributesOfItem(atPath: location.path))?[.size] as? NSNumber)?.int64Value ?? 0
        let mime = (downloadTask.response?.mimeType ?? "").lowercased()
        if got < 2_000_000 && (mime.hasPrefix("text/") || mime.contains("json") || mime.contains("xml")) {
            items[i].state = "error"
            items[i].err = "الخادم أرسل صفحة بدل الفيلم (الرابط انتهى غالباً)"
            items[i].resume = nil
            save()
            notifyEnd(items[i], ok: false)
            return
        }
        let dest = path(items[i].file)
        try? FileManager.default.removeItem(atPath: dest)
        do {
            try FileManager.default.moveItem(at: location, to: URL(fileURLWithPath: dest))
        } catch {
            items[i].state = "error"
            items[i].err = "تعذّر حفظ الملف: " + error.localizedDescription
            save()
            return
        }
        let n = fileSize(items[i].file)
        items[i].state = "done"
        items[i].resume = nil
        items[i].bytes = n
        items[i].total = n
        items[i].err = ""
        items[i].tries = nil
        save()
        notifyEnd(items[i], ok: true)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = task.taskDescription else { return }
        if taskOf[id]?.taskIdentifier == task.taskIdentifier { taskOf.removeValue(forKey: id) }
        defer { pump() }
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        // paused, finished or already marked as failed: nothing more to record
        guard items[i].state == "downloading", let e = error as NSError? else { save(); return }
        if let rd = e.userInfo[NSURLSessionDownloadTaskResumeData] as? Data { items[i].resume = rd }
        // the network dropped (lift, tunnel, Wi-Fi ↔ 4G): tried again by itself from where it stopped, up to 6 times
        let transient: Set<Int> = [NSURLErrorTimedOut, NSURLErrorNetworkConnectionLost, NSURLErrorNotConnectedToInternet,
                                   NSURLErrorCannotConnectToHost, NSURLErrorCannotFindHost, NSURLErrorDNSLookupFailed,
                                   NSURLErrorDataNotAllowed, NSURLErrorInternationalRoamingOff, NSURLErrorCallIsActive,
                                   NSURLErrorBackgroundSessionWasDisconnected, NSURLErrorSecureConnectionFailed]
        let tries = items[i].tries ?? 0
        if e.domain == NSURLErrorDomain && transient.contains(e.code) && tries < 6 {
            let wait: [Double] = [4, 12, 30, 60, 120, 240]
            items[i].tries = tries + 1
            items[i].state = "queued"
            items[i].err = "انقطع الاتصال — إعادة المحاولة تلقائياً (\(tries + 1)/6)…"
            retryAt[id] = Date().addingTimeInterval(wait[tries])
            save()
            DispatchQueue.main.asyncAfter(deadline: .now() + wait[tries] + 0.2) { [weak self] in self?.pump() }
            return
        }
        items[i].state = "error"
        items[i].err = e.code == NSURLErrorCancelled ? "أُلغي" : e.localizedDescription
        save()
        if e.code != NSURLErrorCancelled { notifyEnd(items[i], ok: false) }
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            self.bgCompletion?()
            self.bgCompletion = nil
        }
    }

    /// many IPTV servers have a certificate that is not valid
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }

    // ---- 3.26: a notification when a download ends while the app is not on screen ----
    private func askNotify() {
        if askedNotify { return }
        askedNotify = true
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }

    private func notifyEnd(_ it: Item, ok: Bool) {
        guard UIApplication.shared.applicationState != .active else { return }
        let c = UNMutableNotificationContent()
        let name = (it.title ?? "").isEmpty ? "الفيلم" : (it.title ?? "")
        c.title = ok ? "✓ اكتمل التنزيل" : "تعذّر التنزيل"
        c.body = ok ? name + " — جاهز للمشاهدة بدون إنترنت" : name + " — " + it.err
        c.sound = .default
        let req = UNNotificationRequest(identifier: "sahra.dl." + it.id, content: c, trigger: nil)
        UNUserNotificationCenter.current().add(req, withCompletionHandler: nil)
    }

    // ---- helpers ----
    private func path(_ file: String) -> String { (Downloader.dir as NSString).appendingPathComponent(file) }

    private func fileSize(_ file: String) -> Int64 {
        ((try? FileManager.default.attributesOfItem(atPath: path(file)))?[.size] as? NSNumber)?.int64Value ?? 0
    }

    private func freeSpace() -> Int64? {
        let v = try? URL(fileURLWithPath: NSHomeDirectory()).resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        return v?.volumeAvailableCapacityForImportantUsage
    }

    private func save() {
        lastSave = Date()
        guard let d = try? JSONEncoder().encode(items) else { return }
        try? d.write(to: URL(fileURLWithPath: Downloader.stateFile), options: .atomic)
    }

    private func load() {
        guard let d = FileManager.default.contents(atPath: Downloader.stateFile),
              let a = try? JSONDecoder().decode([Item].self, from: d) else { return }
        items = a
    }
}
