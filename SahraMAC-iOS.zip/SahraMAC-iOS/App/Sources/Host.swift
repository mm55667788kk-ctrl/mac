import UIKit
import WebKit

/// The one screen of the app: a loading spinner, then the web interface full screen.
final class HostViewController: UIViewController {
    private let spinner = UIActivityIndicatorView(style: .large)
    private let errorLabel = UILabel()
    private let copyButton = UIButton(type: .system)
    private(set) var shown: WKWebView?

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)

        errorLabel.textColor = UIColor(white: 1, alpha: 0.85)
        errorLabel.font = UIFont.systemFont(ofSize: 13)
        errorLabel.numberOfLines = 0
        errorLabel.textAlignment = .center
        errorLabel.isHidden = true
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorLabel)

        // 3.26: the error can be copied and sent (instead of a photo of the screen)
        copyButton.setTitle("نسخ الخطأ", for: .normal)
        copyButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .bold)
        copyButton.tintColor = .white
        copyButton.backgroundColor = UIColor(white: 1, alpha: 0.14)
        copyButton.layer.cornerRadius = 12
        copyButton.contentEdgeInsets = UIEdgeInsets(top: 10, left: 22, bottom: 10, right: 22)
        copyButton.isHidden = true
        copyButton.addTarget(self, action: #selector(copyError), for: .touchUpInside)
        copyButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(copyButton)

        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            errorLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 24),
            errorLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -24),
            errorLabel.topAnchor.constraint(equalTo: spinner.bottomAnchor, constant: 24),
            copyButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            copyButton.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: 18)
        ])
        spinner.startAnimating()

        DispatchQueue.main.async { Runtime.shared.start(host: self) }
    }

    /// Puts a web view behind the spinner so it loads at the real screen size.
    func attach(_ wv: WKWebView) {
        wv.frame = view.bounds
        wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.insertSubview(wv, at: 0)
    }

    /// Shows the web view (Scriptable's `present`).
    func reveal(_ wv: WKWebView) {
        if wv.superview !== view { attach(wv) }
        shown = wv
        view.bringSubviewToFront(wv)
        spinner.stopAnimating()
        spinner.isHidden = true
        errorLabel.isHidden = true
    }

    func showError(_ text: String) {
        errorLabel.text = text
        errorLabel.isHidden = false
        view.bringSubviewToFront(errorLabel)
        copyButton.isHidden = false
        copyButton.setTitle("نسخ الخطأ", for: .normal)
        view.bringSubviewToFront(copyButton)
    }

    @objc private func copyError() {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        let ver = (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "?"
        UIPasteboard.general.string = "السهرة ماك \(ver) · " + Runtime.machine() + " · iOS \(v.majorVersion).\(v.minorVersion).\(v.patchVersion)\n" + (errorLabel.text ?? "")
        copyButton.setTitle("✓ تم النسخ", for: .normal)
    }
}

/// The share sheet for a file of the app (the backup): save it to Files or iCloud, send it, AirDrop it.
enum ShareSheet {
    static func present(path: String, from host: UIViewController?) {
        guard let host = host, FileManager.default.fileExists(atPath: path) else { return }
        let vc = UIActivityViewController(activityItems: [URL(fileURLWithPath: path)], applicationActivities: nil)
        var top: UIViewController = host
        while let p = top.presentedViewController { top = p }
        if let pop = vc.popoverPresentationController {
            // iPad: the sheet comes up in the middle of the screen
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY, width: 1, height: 1)
            pop.permittedArrowDirections = []
        }
        top.present(vc, animated: true, completion: nil)
    }
}
