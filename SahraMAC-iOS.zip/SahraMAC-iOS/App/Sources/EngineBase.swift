import UIKit
import AVFoundation
import MediaPlayer

/// What every native engine is told: the stream, where to start, what to show.
struct EngineOpts {
    var url: String
    var title: String
    var start: Double
    var ua: String
    var subs: String
    var hasNext: Bool
    var live: Bool
    /// «التخزين حتى نهاية الفيلم»: the app fetches the whole film to the phone ahead of the player (StreamCache)
    var cache: Bool = false
    var ckey: String = ""
    var ext: String = ""
    /// the server's own link when the engine reads the phone's copy
    var remote: String = ""
    var cacheId: String = ""
    var cacheGen: Int = 0

    static func parse(_ json: String) -> EngineOpts? {
        guard let data = json.data(using: .utf8),
              let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any],
              let url = d["url"] as? String, !url.isEmpty else { return nil }
        var o = EngineOpts(url: url, title: (d["title"] as? String) ?? "", start: (d["start"] as? NSNumber)?.doubleValue ?? 0,
                           ua: (d["ua"] as? String) ?? "", subs: (d["subs"] as? String) ?? "", hasNext: (d["next"] as? Bool) ?? false,
                           live: (d["live"] as? Bool) ?? false)
        o.cache = (d["cache"] as? Bool) ?? false
        o.ckey = (d["ckey"] as? String) ?? ""
        o.ext = (d["ext"] as? String) ?? ""
        return o
    }

    var mediaURL: URL? {
        URL(string: url) ?? URL(string: url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")
    }

    /// the Arabic subtitles found by the app, as a file the engines can open
    func subtitleFile() -> URL? {
        if subs.isEmpty { return nil }
        let f = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("sahra-subtitle.srt")
        return (try? subs.write(to: f, atomically: true, encoding: .utf8)) != nil ? f : nil
    }
}

/// The answer an engine gives back when it closes: the minute reached, whether the viewer asked for
/// the next one, or why it couldn't play (then the app tries the next engine).
func engineAnswer(pos: Double, dur: Double, next: Bool, error: String, started: Bool, ended: Bool = false) -> String {
    let p = pos.isFinite ? pos : 0, d = dur.isFinite ? dur : 0
    let e = error.replacingOccurrences(of: "\\", with: "").replacingOccurrences(of: "\"", with: "'")
        .replacingOccurrences(of: "\n", with: " ")
    return "{\"pos\":\(p),\"dur\":\(d),\"next\":\(next ? "true" : "false"),\"started\":\(started ? "true" : "false"),\"ended\":\(ended ? "true" : "false")"
        + (e.isEmpty ? "" : ",\"error\":\"\(e)\"") + "}"
}

/// The film's bar: what was watched (orange), what is already on the phone (light), the rest (dim).
/// A wide touch area; the knob grows while dragging.
final class SeekBar: UIControl {
    var value: Double = 0 { didSet { if !dragging { setNeedsLayout() } } }
    /// [[from, to]] fractions of the film already on the phone
    var cached: [[Double]] = [] { didSet { setNeedsLayout() } }
    private(set) var dragging = false
    var onStart: (() -> Void)?
    var onChange: ((Double) -> Void)?
    var onEnd: ((Double) -> Void)?
    private let base = CALayer()
    private let store = CAShapeLayer()
    private let played = CALayer()
    private let knob = UIView()
    private var shown: Double = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
        base.backgroundColor = UIColor(white: 1, alpha: 0.2).cgColor
        store.fillColor = UIColor(white: 1, alpha: 0.5).cgColor
        played.backgroundColor = UIColor(red: 1, green: 0.55, blue: 0.1, alpha: 1).cgColor
        layer.addSublayer(base)
        layer.addSublayer(store)
        layer.addSublayer(played)
        knob.backgroundColor = .white
        knob.isUserInteractionEnabled = false
        knob.layer.shadowColor = UIColor.black.cgColor
        knob.layer.shadowOpacity = 0.45
        knob.layer.shadowRadius = 3
        knob.layer.shadowOffset = .zero
        addSubview(knob)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override var intrinsicContentSize: CGSize { CGSize(width: UIView.noIntrinsicMetric, height: 36) }

    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let h: CGFloat = dragging ? 6 : 4
        let r = CGRect(x: 8, y: (bounds.height - h) / 2, width: max(0, bounds.width - 16), height: h)
        base.frame = r
        base.cornerRadius = h / 2
        let path = UIBezierPath()
        for s in cached where s.count == 2 {
            let a = CGFloat(max(0, min(1, s[0]))), b = CGFloat(max(0, min(1, s[1])))
            if b <= a { continue }
            let w = max(2, (b - a) * r.width)
            path.append(UIBezierPath(roundedRect: CGRect(x: r.minX + a * r.width, y: r.minY, width: w, height: h), cornerRadius: h / 2))
        }
        store.path = path.cgPath
        let v = CGFloat(max(0, min(1, dragging ? shown : value)))
        played.frame = CGRect(x: r.minX, y: r.minY, width: v * r.width, height: h)
        played.cornerRadius = h / 2
        let k: CGFloat = dragging ? 22 : 14
        knob.frame = CGRect(x: r.minX + v * r.width - k / 2, y: bounds.midY - k / 2, width: k, height: k)
        knob.layer.cornerRadius = k / 2
        CATransaction.commit()
    }

    private func fraction(_ t: UITouch) -> Double {
        let w = max(1, bounds.width - 16)
        return Double(max(0, min(1, (t.location(in: self).x - 8) / w)))
    }

    override func beginTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        dragging = true
        shown = fraction(touch)
        onStart?()
        onChange?(shown)
        setNeedsLayout()
        return true
    }

    override func continueTracking(_ touch: UITouch, with event: UIEvent?) -> Bool {
        shown = fraction(touch)
        onChange?(shown)
        setNeedsLayout()
        return true
    }

    override func endTracking(_ touch: UITouch?, with event: UIEvent?) {
        if let t = touch { shown = fraction(t) }
        dragging = false
        value = shown
        onEnd?(shown)
        setNeedsLayout()
    }

    override func cancelTracking(with event: UIEvent?) {
        dragging = false
        value = shown
        onEnd?(shown)
        setNeedsLayout()
    }
}

/// A full-screen player with the app's own controls; an engine (VLC, mpv) fills in the playback.
class EngineController: UIViewController {
    var o: EngineOpts
    /// asks the app for a fresh link when the server stopped accepting this one (the phone's copy goes on with it)
    var relink: (() -> Void)?
    private let done: (String) -> Void
    let videoView = UIView()
    private let topBar = UIView()
    private let bottomBar = UIView()
    private let titleLabel = UILabel()
    private let timeLabel = UILabel()
    private let lengthLabel = UILabel()
    let noteLabel = UILabel()
    private let cacheLabel = UILabel()
    private let hud = UILabel()
    private let seekBar = SeekBar()
    private let playButton = UIButton(type: .system)
    private let spinner = UIActivityIndicatorView(style: .large)
    private var timer: Timer?
    private var hideAt = Date().addingTimeInterval(4)
    private var seeking = false
    private var fill = false
    private var finished = false
    private var rate: Float = 1
    /// nothing on screen by then: this engine can't play it, the next one gets a go
    private let deadline = Date().addingTimeInterval(30)
    var started = false
    var wantNext = false
    var streamEnded = false
    var lastPos: Double = 0
    var lastDur: Double = 0
    var failure = ""
    // stall recovery: a picture stuck on «loading» gets its connection reopened from the same second;
    // stuck again and again → this engine closes and the app goes on with the next one from that minute
    private var busySince: Date?
    private var stalls: [Date] = []
    private var graceUntil = Date.distantPast
    // the film's copy on the phone
    private var cacheState: CacheStatus?
    private var relinkAt = Date.distantPast
    // swipes: across = seek, up/down on the left = brightness, on the right = volume
    private var panMode = 0
    private var panFrom: Double = 0
    private var panTarget: Double = -1
    private var panStart: CGFloat = 0
    private let volumeView = MPVolumeView(frame: CGRect(x: -2000, y: -2000, width: 10, height: 10))
    // lock screen and Control Center
    private var remote: [(MPRemoteCommand, Any)] = []
    private var nowAt = Date.distantPast

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    // ---- what an engine provides ----
    func engineName() -> String { "" }
    func startPlayback(_ url: URL) {}
    func stopPlayback() {}
    func isPlaying() -> Bool { false }
    func isBusy() -> Bool { false }
    func hasEnded() -> Bool { false }
    func currentTime() -> Double { 0 }
    func duration() -> Double { 0 }
    func setPaused(_ paused: Bool) {}
    func seek(toFraction f: Double) {}
    func jump(_ seconds: Double) {}
    func setRate(_ r: Float) {}
    func videoSize() -> CGSize { .zero }
    func audioTracks() -> [(String, Int)] { [] }
    func currentAudio() -> Int { -1 }
    func setAudio(_ id: Int) {}
    func subtitleTracks() -> [(String, Int)] { [] }
    func currentSubtitle() -> Int { -1 }
    func setSubtitle(_ id: Int) {}
    /// why the engine stopped, if it did ("" while all is well)
    func engineError() -> String { "" }
    /// engines with an event queue (mpv) read it here, twice a second
    func pump() {}
    /// true when the engine reads the phone's copy (StreamCache) instead of the server
    var fromCache: Bool { !o.cacheId.isEmpty }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        videoView.frame = view.bounds
        videoView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoView.backgroundColor = .black
        view.addSubview(videoView)
        volumeView.alpha = 0.01
        volumeView.isUserInteractionEnabled = false
        view.addSubview(volumeView)
        let tap = UITapGestureRecognizer(target: self, action: #selector(toggleControls))
        videoView.addGestureRecognizer(tap)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(doubleTap(_:)))
        dbl.numberOfTapsRequired = 2
        videoView.addGestureRecognizer(dbl)
        tap.require(toFail: dbl)
        let pan = UIPanGestureRecognizer(target: self, action: #selector(swipe(_:)))
        pan.maximumNumberOfTouches = 1
        videoView.addGestureRecognizer(pan)

        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        spinner.startAnimating()
        noteLabel.textColor = .white
        noteLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        noteLabel.numberOfLines = 0
        noteLabel.textAlignment = .center
        noteLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(noteLabel)
        hud.textColor = .white
        hud.font = UIFont.monospacedDigitSystemFont(ofSize: 24, weight: .bold)
        hud.textAlignment = .center
        hud.backgroundColor = UIColor(white: 0, alpha: 0.6)
        hud.layer.cornerRadius = 14
        hud.clipsToBounds = true
        hud.alpha = 0
        hud.isUserInteractionEnabled = false
        hud.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hud)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            noteLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noteLabel.topAnchor.constraint(equalTo: spinner.bottomAnchor, constant: 16),
            noteLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -40),
            hud.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            hud.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -60),
            hud.heightAnchor.constraint(equalToConstant: 52),
            hud.widthAnchor.constraint(greaterThanOrEqualToConstant: 150)
        ])
        buildControls()
        setupRemote()
        guard let u = o.mediaURL else { fail("رابط غير صالح"); return }
        startPlayback(u)
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.tick() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFill()
        layoutVideo()
    }

    /// engines that draw into a layer resize it here
    func layoutVideo() {}

    // ---- controls ----
    private func button(_ symbol: String, _ action: Selector, size: CGFloat = 22) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: symbol, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .semibold)), for: .normal)
        b.tintColor = .white
        b.addTarget(self, action: action, for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.widthAnchor.constraint(equalToConstant: 46).isActive = true
        b.heightAnchor.constraint(equalToConstant: 46).isActive = true
        return b
    }

    private func buildControls() {
        for bar in [topBar, bottomBar] {
            bar.backgroundColor = UIColor(white: 0, alpha: 0.55)
            bar.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(bar)
        }
        titleLabel.text = o.title
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        titleLabel.lineBreakMode = .byTruncatingTail
        let badge = UILabel()
        badge.text = " " + engineName() + " "
        badge.textColor = .black
        badge.backgroundColor = UIColor(red: 1, green: 0.62, blue: 0.18, alpha: 1)
        badge.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        badge.layer.cornerRadius = 5
        badge.clipsToBounds = true
        let close = button("xmark", #selector(closeTap))
        let audio = button("speaker.wave.2", #selector(audioTap))
        let subs = button("captions.bubble", #selector(subsTap))
        let aspect = button("aspectratio", #selector(aspectTap))
        let speed = button("gauge", #selector(speedTap))
        let topStack = UIStackView(arrangedSubviews: [close, titleLabel, badge, speed, aspect, subs, audio])
        topStack.axis = .horizontal
        topStack.alignment = .center
        topStack.spacing = 4
        topStack.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(topStack)
        titleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        playButton.setImage(UIImage(systemName: "pause.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        playButton.tintColor = .white
        playButton.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        playButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        let back = button("gobackward.10", #selector(backTap))
        let fwd = button("goforward.10", #selector(fwdTap))
        for l in [timeLabel, lengthLabel] {
            l.textColor = .white
            l.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
            l.text = "0:00"
        }
        seekBar.translatesAutoresizingMaskIntoConstraints = false
        seekBar.heightAnchor.constraint(equalToConstant: 36).isActive = true
        seekBar.setContentHuggingPriority(.defaultLow, for: .horizontal)
        seekBar.onStart = { [weak self] in
            self?.seeking = true
            self?.hideAt = Date().addingTimeInterval(8)
        }
        seekBar.onChange = { [weak self] f in
            guard let self = self, self.lastDur > 0 else { return }
            let t = f * self.lastDur
            self.timeLabel.text = self.fmt(t)
            self.showHUD(self.fmt(t) + " / " + self.fmt(self.lastDur))
        }
        seekBar.onEnd = { [weak self] f in
            guard let self = self else { return }
            self.seek(toFraction: f)
            self.seeking = false
            self.hideHUD()
            self.setControls(true)
        }
        var items: [UIView] = [back, playButton, fwd, timeLabel, seekBar, lengthLabel]
        if o.hasNext { items.append(button("forward.end.fill", #selector(nextTap))) }
        let bottomStack = UIStackView(arrangedSubviews: items)
        bottomStack.axis = .horizontal
        bottomStack.alignment = .center
        bottomStack.spacing = 6
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(bottomStack)
        // how much of the film is already on the phone, and how fast the rest comes
        cacheLabel.textColor = UIColor(white: 1, alpha: 0.78)
        cacheLabel.font = UIFont.systemFont(ofSize: 11.5, weight: .semibold)
        cacheLabel.textAlignment = .center
        cacheLabel.translatesAutoresizingMaskIntoConstraints = false
        cacheLabel.isHidden = !fromCache
        bottomBar.addSubview(cacheLabel)
        // left to right like a timeline, whatever the phone's language
        topStack.semanticContentAttribute = .forceLeftToRight
        bottomStack.semanticContentAttribute = .forceLeftToRight

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: g.topAnchor, constant: 54),
            topStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            topStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            topStack.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -4),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.topAnchor.constraint(equalTo: g.bottomAnchor, constant: fromCache ? -76 : -58),
            cacheLabel.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 5),
            cacheLabel.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 12),
            cacheLabel.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
            bottomStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            bottomStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            bottomStack.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: fromCache ? 22 : 6)
        ])
    }

    private func setControls(_ on: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.topBar.alpha = on ? 1 : 0
            self.bottomBar.alpha = on ? 1 : 0
        }
        if on { hideAt = Date().addingTimeInterval(4) }
    }

    @objc private func toggleControls() { setControls(topBar.alpha < 0.5) }

    @objc private func doubleTap(_ g: UITapGestureRecognizer) {
        let x = g.location(in: videoView).x
        let d: Double = x < videoView.bounds.width / 2 ? -10 : 10
        jump(d)
        showHUD(d < 0 ? "↺ 10" : "10 ↻")
        hideHUD(after: 0.7)
        setControls(true)
    }

    // ---- swipes ----
    private var volumeSlider: UISlider? { volumeView.subviews.compactMap { $0 as? UISlider }.first }

    @objc private func swipe(_ g: UIPanGestureRecognizer) {
        let tr = g.translation(in: videoView)
        switch g.state {
        case .began:
            let v = g.velocity(in: videoView)
            if abs(v.x) > abs(v.y) {
                panMode = !o.live && lastDur > 0 ? 1 : 0
                panFrom = currentTime() > 0 ? currentTime() : lastPos
                panTarget = -1
            } else {
                panMode = g.location(in: videoView).x < videoView.bounds.width / 2 ? 2 : 3
                panStart = panMode == 2 ? UIScreen.main.brightness : CGFloat(volumeSlider?.value ?? AVAudioSession.sharedInstance().outputVolume)
            }
        case .changed:
            if panMode == 1 {
                // a swipe across the whole screen ≈ 3 minutes
                let w = Double(max(1, videoView.bounds.width))
                let delta = Double(tr.x) / w * min(lastDur, 180)
                panTarget = max(0, min(lastDur - 1, panFrom + delta))
                showHUD((delta >= 0 ? "+" : "−") + fmt(abs(delta)) + "   " + fmt(panTarget))
            } else if panMode == 2 {
                let b = max(0, min(1, panStart - tr.y / 260))
                UIScreen.main.brightness = b
                showHUD("☀︎ \(Int(b * 100))٪")
            } else if panMode == 3 {
                let vol = max(0, min(1, panStart - tr.y / 260))
                volumeSlider?.value = Float(vol)
                showHUD("🔊 \(Int(vol * 100))٪")
            }
        case .ended, .cancelled, .failed:
            if panMode == 1 && panTarget >= 0 && lastDur > 0 { seek(toFraction: panTarget / lastDur) }
            panMode = 0
            hideHUD(after: 0.5)
        default:
            break
        }
    }

    private func showHUD(_ t: String) {
        hud.text = "  " + t + "  "
        hud.alpha = 1
    }

    private func hideHUD(after: Double = 0) {
        UIView.animate(withDuration: 0.25, delay: after, options: [.beginFromCurrentState], animations: { self.hud.alpha = 0 }, completion: nil)
    }

    // ---- lock screen / Control Center ----
    private func setupRemote() {
        let rc = MPRemoteCommandCenter.shared()
        func on(_ c: MPRemoteCommand, _ f: @escaping (MPRemoteCommandEvent) -> MPRemoteCommandHandlerStatus) {
            c.isEnabled = true
            remote.append((c, c.addTarget(handler: f)))
        }
        on(rc.playCommand) { [weak self] _ in
            self?.setPaused(false)
            return .success
        }
        on(rc.pauseCommand) { [weak self] _ in
            self?.setPaused(true)
            return .success
        }
        on(rc.togglePlayPauseCommand) { [weak self] _ in
            guard let s = self else { return .commandFailed }
            s.setPaused(s.isPlaying())
            return .success
        }
        if !o.live {
            rc.skipForwardCommand.preferredIntervals = [10]
            rc.skipBackwardCommand.preferredIntervals = [10]
            on(rc.skipForwardCommand) { [weak self] _ in
                self?.jump(10)
                return .success
            }
            on(rc.skipBackwardCommand) { [weak self] _ in
                self?.jump(-10)
                return .success
            }
            on(rc.changePlaybackPositionCommand) { [weak self] e in
                guard let s = self, let ev = e as? MPChangePlaybackPositionCommandEvent, s.lastDur > 0 else { return .commandFailed }
                s.seek(toFraction: ev.positionTime / s.lastDur)
                return .success
            }
        }
    }

    private func teardownRemote() {
        for (c, t) in remote { c.removeTarget(t) }
        remote.removeAll()
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }

    private func nowPlaying(_ playing: Bool) {
        if Date().timeIntervalSince(nowAt) < 1 { return }
        nowAt = Date()
        var i: [String: Any] = [MPMediaItemPropertyTitle: o.title.isEmpty ? "السهرة ماك" : o.title,
                                MPNowPlayingInfoPropertyPlaybackRate: playing ? Double(rate) : 0.0,
                                MPNowPlayingInfoPropertyIsLiveStream: o.live]
        if lastDur > 0 {
            i[MPMediaItemPropertyPlaybackDuration] = lastDur
            i[MPNowPlayingInfoPropertyElapsedPlaybackTime] = lastPos
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = i
    }

    // ---- state ----
    func fmt(_ s: Double) -> String {
        let t = Int(max(0, s.isFinite ? s : 0))
        let h = t / 3600, m = (t / 60) % 60, x = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, x) : String(format: "%d:%02d", m, x)
    }

    /// the phone's copy: tell it the player is still here, show how far it got, ask for a new link if the old one died
    private func cacheTick(_ t: Double, _ len: Double) {
        guard fromCache else { return }
        StreamCache.shared.touch(o.cacheId, gen: o.cacheGen, pos: t, dur: len)
        guard let s = StreamCache.shared.status(o.cacheId) else { return }
        cacheState = s
        seekBar.cached = s.spans
        cacheLabel.text = s.text
        if s.dead && Date().timeIntervalSince(relinkAt) > 25, let r = relink {
            relinkAt = Date()
            r()
        }
    }

    private func tick() {
        if !failure.isEmpty || finished { return }
        pump()
        let err = engineError()
        if !err.isEmpty { fail(err); return }
        let t = currentTime(), len = duration()
        if t > 0 { lastPos = t }
        if len > 0 { lastDur = len }
        cacheTick(t > 0 ? t : lastPos, lastDur)
        if !started && Date() > deadline {
            // reading the phone's copy of a slow server: not a failure while the bytes keep coming (up to 90 s)
            let flowing = cacheState.map { $0.quiet < 8 && !$0.dead } ?? false
            if !flowing || Date() > deadline.addingTimeInterval(60) { fail("لم يبدأ خلال 30 ثانية"); return }
        }
        let playing = isPlaying()
        if playing { started = true; noteLabel.text = "" }
        if isBusy() || !started { spinner.startAnimating() } else { spinner.stopAnimating() }
        if started && !seeking && isBusy() && Date() > graceUntil {
            if busySince == nil { busySince = Date() }
            else if let b = busySince, Date().timeIntervalSince(b) > (o.live ? 7 : 10) {
                if let s = cacheState {
                    // waiting for the phone's copy: a new connection to it would not bring the bytes sooner
                    if s.ahead > 4 * 1024 * 1024 { busySince = nil; recoverStall(); return }   // the bytes are there: the engine itself is stuck
                    if s.quiet > 60 && !s.dead { busySince = nil; fail("لا تصل بيانات من الخادم"); return }
                    noteLabel.text = s.dead ? "جاري طلب رابط جديد…" : "جاري التخزين — " + s.text
                } else {
                    busySince = nil
                    recoverStall()
                    return
                }
            }
        } else if !isBusy() {
            busySince = nil
            if playing && Date() > graceUntil && (noteLabel.text == "أعيد الاتصال…" || (noteLabel.text ?? "").hasPrefix("جاري")) { noteLabel.text = "" }
        }
        if started && hasEnded() && Date() > graceUntil {
            streamEnded = true
            if o.hasNext { wantNext = true }
            finish()
            return
        }
        if !seeking && len > 0 { seekBar.value = t / len }
        seekBar.isEnabled = len > 0
        if !seeking { timeLabel.text = fmt(t) }
        lengthLabel.text = len > 0 ? fmt(len) : "مباشر"
        let sym = playing ? "pause.fill" : "play.fill"
        playButton.setImage(UIImage(systemName: sym, withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        if playing && topBar.alpha > 0.5 && Date() > hideAt && !seeking { setControls(false) }
        nowPlaying(playing)
    }

    /// reopen the stream: from the same second (a film) or at the live edge (a channel)
    private func recoverStall() {
        let now = Date()
        stalls = stalls.filter { now.timeIntervalSince($0) < 120 } + [now]
        if stalls.count >= 3 { fail("تقطيع متكرر"); return }
        let at = currentTime()
        noteLabel.text = "أعيد الاتصال…"
        graceUntil = now.addingTimeInterval(12)
        stopPlayback()
        o.start = o.live ? 0 : max(0, (at > 0 ? at : lastPos) - 2)
        if let u = o.mediaURL { startPlayback(u) }
    }

    /// the engine couldn't play it: close at once and let the app try the next engine
    func fail(_ why: String) {
        if !failure.isEmpty || finished { return }
        failure = why
        spinner.stopAnimating()
        noteLabel.text = engineName() + ": " + why
        DispatchQueue.main.asyncAfter(deadline: .now() + (started ? 2.5 : 0.8)) { [weak self] in self?.finish() }
    }

    // ---- actions ----
    @objc private func playTap() {
        setPaused(isPlaying())
        setControls(true)
    }
    @objc private func backTap() { jump(-10); setControls(true) }
    @objc private func fwdTap() { jump(10); setControls(true) }
    @objc private func nextTap() { wantNext = true; finish() }
    @objc private func closeTap() { finish() }

    private func applyFill() {
        let vs = videoSize()
        guard fill, vs.width > 0, vs.height > 0, videoView.bounds.width > 0, videoView.bounds.height > 0 else {
            videoView.transform = .identity
            return
        }
        let sx = videoView.bounds.width / vs.width, sy = videoView.bounds.height / vs.height
        let s = max(sx, sy) / min(sx, sy)
        videoView.transform = CGAffineTransform(scaleX: s, y: s)
    }

    @objc private func aspectTap() {
        fill.toggle()
        UIView.animate(withDuration: 0.25) { self.applyFill() }
        setControls(true)
    }

    @objc private func speedTap() {
        let a = UIAlertController(title: "السرعة", message: nil, preferredStyle: .actionSheet)
        for r: Float in [0.75, 1, 1.25, 1.5, 2] {
            a.addAction(UIAlertAction(title: (r == rate ? "✓ " : "") + String(format: "%g×", r), style: .default) { _ in
                self.rate = r
                self.setRate(r)
            })
        }
        show(a)
    }

    @objc private func audioTap() { pick("الصوت", audioTracks(), current: currentAudio()) { self.setAudio($0) } }
    @objc private func subsTap() { pick("الترجمة", subtitleTracks(), current: currentSubtitle()) { self.setSubtitle($0) } }

    private func show(_ a: UIAlertController) {
        a.addAction(UIAlertAction(title: "إلغاء", style: .cancel, handler: nil))
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true, completion: nil)
        hideAt = Date().addingTimeInterval(8)
    }

    private func pick(_ title: String, _ tracks: [(String, Int)], current: Int, _ set: @escaping (Int) -> Void) {
        let a = UIAlertController(title: title, message: tracks.isEmpty ? "لا توجد مسارات" : nil, preferredStyle: .actionSheet)
        for (name, id) in tracks {
            a.addAction(UIAlertAction(title: (id == current ? "✓ " : "") + name, style: .default) { _ in set(id) })
        }
        show(a)
    }

    func finish() {
        if finished { return }
        finished = true
        timer?.invalidate()
        timer = nil
        teardownRemote()
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        stopPlayback()
        dismiss(animated: true) { self.done(answer) }
    }
}
