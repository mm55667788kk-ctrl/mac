import UIKit

enum PlaybackBuffer: String {
    case low, normal, high, max

    var startup: TimeInterval {
        switch self {
        case .low: return 1
        case .normal: return 2
        case .high: return 4
        case .max: return 7
        }
    }

    var refill: TimeInterval {
        switch self {
        case .low: return 2
        case .normal: return 4
        case .high: return 6
        case .max: return 9
        }
    }
}

/// What every native engine is told: the stream, where to start, what to show.
struct EngineOpts {
    var url: String
    var title: String
    var start: Double
    var ua: String
    var subs: String
    var hasNext: Bool
    var live: Bool
    var buffer: PlaybackBuffer
    var reconnect: Bool

    static func parse(_ json: String) -> EngineOpts? {
        guard let data = json.data(using: .utf8),
              let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any],
              let url = d["url"] as? String, !url.isEmpty else { return nil }
        return EngineOpts(url: url, title: (d["title"] as? String) ?? "", start: (d["start"] as? NSNumber)?.doubleValue ?? 0,
                          ua: (d["ua"] as? String) ?? "", subs: (d["subs"] as? String) ?? "", hasNext: (d["next"] as? Bool) ?? false,
                          live: (d["live"] as? Bool) ?? false,
                          buffer: PlaybackBuffer(rawValue: d["buffer"] as? String ?? "") ?? .normal,
                          reconnect: d["reconnect"] as? Bool ?? true)
    }

    var mediaURL: URL? {
        URL(string: url) ?? URL(string: url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")
    }

    /// the Arabic subtitles found by the app, as a file the engines can open
    func subtitleFile() -> URL? {
        if subs.isEmpty { return nil }
        let f = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("sahra-subtitle.srt")
        return (try? subs.write(to: f, atomically: true, encoding: .utf8)) != nil ? f : nil
    }
}

/// The answer an engine gives back when it closes: the minute reached, whether the viewer asked for
/// the next one, or why it couldn't play (then the app tries the next engine).
func engineAnswer(pos: Double, dur: Double, next: Bool, error: String, started: Bool, ended: Bool = false) -> String {
    let p = pos.isFinite ? pos : 0, d = dur.isFinite ? dur : 0
    let e = error.replacingOccurrences(of: "\\", with: "").replacingOccurrences(of: "\"", with: "'")
        .replacingOccurrences(of: "\n", with: " ")
    return "{\"pos\":\(p),\"dur\":\(d),\"next\":\(next ? "true" : "false"),\"started\":\(started ? "true" : "false"),\"ended\":\(ended ? "true" : "false")"
        + (e.isEmpty ? "" : ",\"error\":\"\(e)\"") + "}"
}

/// A full-screen player with the app's own controls; an engine (VLC, mpv) fills in the playback.
class EngineController: UIViewController {
    var o: EngineOpts
    private let done: (String) -> Void
    let videoView = UIView()
    private let topBar = UIView()
    private let bottomBar = UIView()
    private let titleLabel = UILabel()
    private let timeLabel = UILabel()
    private let lengthLabel = UILabel()
    let noteLabel = UILabel()
    private let slider = UISlider()
    private let playButton = UIButton(type: .system)
    private let spinner = UIActivityIndicatorView(style: .large)
    private var timer: Timer?
    private var hideAt = Date().addingTimeInterval(4)
    private var seeking = false
    private var fill = false
    private var finished = false
    private var rate: Float = 1
    /// nothing on screen by then: this engine can't play it, the next one gets a go
    private var deadline = Date().addingTimeInterval(30)
    var started = false
    var wantNext = false
    var streamEnded = false
    var lastPos: Double = 0
    var lastDur: Double = 0
    var failure = ""
    // stall recovery: a picture stuck on «loading» gets its connection reopened from the same second;
    // stuck again and again → this engine closes and the app goes on with the next one from that minute
    private var busySince: Date?
    private var stalls: [Date] = []
    private var graceUntil = Date.distantPast
    private(set) var recoveryCount = 0
    private var userPaused = false
    private var lastClock: Double?
    private var lastAdvance = Date()
    private var clockAdvanced = false

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    // ---- what an engine provides ----
    func engineName() -> String { "" }
    func startPlayback(_ url: URL) {}
    func stopPlayback() {}
    func isPlaying() -> Bool { false }
    func isBusy() -> Bool { false }
    func hasEnded() -> Bool { false }
    func currentTime() -> Double { 0 }
    func duration() -> Double { 0 }
    func setPaused(_ paused: Bool) {}
    func seek(toFraction f: Double) {}
    func jump(_ seconds: Double) {}
    func setRate(_ r: Float) {}
    func videoSize() -> CGSize { .zero }
    func audioTracks() -> [(String, Int)] { [] }
    func currentAudio() -> Int { -1 }
    func setAudio(_ id: Int) {}
    func subtitleTracks() -> [(String, Int)] { [] }
    func currentSubtitle() -> Int { -1 }
    func setSubtitle(_ id: Int) {}
    /// why the engine stopped, if it did ("" while all is well)
    func engineError() -> String { "" }
    /// engines with an event queue (mpv) read it here, twice a second
    func pump() {}

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        videoView.frame = view.bounds
        videoView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoView.backgroundColor = .black
        view.addSubview(videoView)
        let tap = UITapGestureRecognizer(target: self, action: #selector(toggleControls))
        videoView.addGestureRecognizer(tap)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(doubleTap(_:)))
        dbl.numberOfTapsRequired = 2
        videoView.addGestureRecognizer(dbl)
        tap.require(toFail: dbl)

        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        spinner.startAnimating()
        noteLabel.textColor = .white
        noteLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        noteLabel.numberOfLines = 0
        noteLabel.textAlignment = .center
        noteLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(noteLabel)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            noteLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noteLabel.topAnchor.constraint(equalTo: spinner.bottomAnchor, constant: 16),
            noteLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -40)
        ])
        buildControls()
        guard let u = o.mediaURL else { fail("رابط غير صالح"); return }
        startPlayback(u)
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in self?.tick() }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFill()
        layoutVideo()
    }

    /// engines that draw into a layer resize it here
    func layoutVideo() {}

    // ---- controls ----
    private func button(_ symbol: String, _ action: Selector, size: CGFloat = 22) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: symbol, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .semibold)), for: .normal)
        b.tintColor = .white
        b.addTarget(self, action: action, for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.widthAnchor.constraint(equalToConstant: 46).isActive = true
        b.heightAnchor.constraint(equalToConstant: 46).isActive = true
        return b
    }

    private func buildControls() {
        for bar in [topBar, bottomBar] {
            bar.backgroundColor = UIColor(white: 0, alpha: 0.55)
            bar.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(bar)
        }
        titleLabel.text = o.title
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        titleLabel.lineBreakMode = .byTruncatingTail
        let badge = UILabel()
        badge.text = " " + engineName() + " "
        badge.textColor = .black
        badge.backgroundColor = UIColor(red: 1, green: 0.62, blue: 0.18, alpha: 1)
        badge.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        badge.layer.cornerRadius = 5
        badge.clipsToBounds = true
        let close = button("xmark", #selector(closeTap))
        let audio = button("speaker.wave.2", #selector(audioTap))
        let subs = button("captions.bubble", #selector(subsTap))
        let aspect = button("aspectratio", #selector(aspectTap))
        let speed = button("gauge", #selector(speedTap))
        let topStack = UIStackView(arrangedSubviews: [close, titleLabel, badge, speed, aspect, subs, audio])
        topStack.axis = .horizontal
        topStack.alignment = .center
        topStack.spacing = 4
        topStack.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(topStack)
        titleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        playButton.setImage(UIImage(systemName: "pause.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        playButton.tintColor = .white
        playButton.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        playButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        let back = button("gobackward.10", #selector(backTap))
        let fwd = button("goforward.10", #selector(fwdTap))
        for l in [timeLabel, lengthLabel] {
            l.textColor = .white
            l.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
            l.text = "0:00"
        }
        slider.minimumTrackTintColor = UIColor(red: 1, green: 0.55, blue: 0.1, alpha: 1)
        slider.addTarget(self, action: #selector(seekStart), for: .touchDown)
        slider.addTarget(self, action: #selector(seekEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        var items: [UIView] = [back, playButton, fwd, timeLabel, slider, lengthLabel]
        if o.hasNext { items.append(button("forward.end.fill", #selector(nextTap))) }
        let bottomStack = UIStackView(arrangedSubviews: items)
        bottomStack.axis = .horizontal
        bottomStack.alignment = .center
        bottomStack.spacing = 6
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(bottomStack)
        // left to right like a timeline, whatever the phone's language
        topStack.semanticContentAttribute = .forceLeftToRight
        bottomStack.semanticContentAttribute = .forceLeftToRight

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: g.topAnchor, constant: 54),
            topStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            topStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            topStack.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -4),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.topAnchor.constraint(equalTo: g.bottomAnchor, constant: -58),
            bottomStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            bottomStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            bottomStack.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 6)
        ])
    }

    private func setControls(_ on: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.topBar.alpha = on ? 1 : 0
            self.bottomBar.alpha = on ? 1 : 0
        }
        if on { hideAt = Date().addingTimeInterval(4) }
    }

    @objc private func toggleControls() { setControls(topBar.alpha < 0.5) }

    @objc private func doubleTap(_ g: UITapGestureRecognizer) {
        let x = g.location(in: videoView).x
        jump(x < videoView.bounds.width / 2 ? -10 : 10)
        setControls(true)
    }

    // ---- state ----
    private func fmt(_ s: Double) -> String {
        let t = Int(max(0, s.isFinite ? s : 0))
        let h = t / 3600, m = (t / 60) % 60, x = t % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, x) : String(format: "%d:%02d", m, x)
    }

    private func tick() {
        if !failure.isEmpty || finished { return }
        pump()
        let err = engineError()
        if !err.isEmpty { fail(err); return }
        if !started && !userPaused && Date() > deadline { fail("لم يبدأ خلال 30 ثانية"); return }
        let t = currentTime(), len = duration()
        if t > 0 { lastPos = t }
        if len > 0 { lastDur = len }
        let playing = isPlaying(), busy = isBusy()
        let now = Date()
        if playing, !userPaused, !seeking, let previous = lastClock, t > previous + 0.1 { clockAdvanced = true }
        if lastClock == nil || abs(t - (lastClock ?? t)) >= 0.1 || userPaused || seeking || !playing {
            lastClock = t
            lastAdvance = now
        }
        if playing { started = true; noteLabel.text = "" }
        if busy || !started { spinner.startAnimating() } else { spinner.stopAnimating() }
        let ended = hasEnded()
        let canRecover = started && (o.reconnect || !o.live) && !seeking && !userPaused && !ended && now > graceUntil
        let refillWindow = max(o.live ? 8.0 : 12.0, o.buffer.refill + 4)
        if canRecover && busy {
            if busySince == nil { busySince = now }
            if let b = busySince, now.timeIntervalSince(b) > refillWindow { recoverStall(); return }
        } else {
            busySince = nil
            if canRecover && playing && clockAdvanced && now.timeIntervalSince(lastAdvance) > refillWindow { recoverStall(); return }
        }
        if started && ended && now > graceUntil {
            if o.live && o.reconnect && !userPaused { recoverStall(); return }
            streamEnded = true
            if o.hasNext { wantNext = true }
            finish()
            return
        }
        if !seeking && len > 0 { slider.value = Float(t / len) }
        slider.isEnabled = len > 0
        timeLabel.text = fmt(t)
        lengthLabel.text = len > 0 ? fmt(len) : "مباشر"
        let sym = playing ? "pause.fill" : "play.fill"
        playButton.setImage(UIImage(systemName: sym, withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        if playing && topBar.alpha > 0.5 && Date() > hideAt { setControls(false) }
    }

    /// reopen the stream: from the same second (a film) or at the live edge (a channel)
    private func recoverStall() {
        let now = Date()
        busySince = nil
        lastAdvance = now
        lastClock = nil
        clockAdvanced = false
        stalls = stalls.filter { now.timeIntervalSince($0) < 120 } + [now]
        if stalls.count >= 3 { fail("تقطيع متكرر"); return }
        recoveryCount = min(2, recoveryCount + 1)
        let at = currentTime()
        noteLabel.text = "أعيد الاتصال…"
        graceUntil = now.addingTimeInterval(12)
        stopPlayback()
        o.start = o.live ? 0 : max(0, (at > 0 ? at : lastPos) - 2)
        if let u = o.mediaURL { startPlayback(u) }
    }

    /// the engine couldn't play it: close at once and let the app try the next engine
    func fail(_ why: String) {
        if !failure.isEmpty || finished { return }
        failure = why
        spinner.stopAnimating()
        noteLabel.text = engineName() + ": " + why
        DispatchQueue.main.asyncAfter(deadline: .now() + (started ? 2.5 : 0.8)) { [weak self] in self?.finish() }
    }

    // ---- actions ----
    @objc private func playTap() {
        userPaused = !userPaused && (isPlaying() || isBusy())
        setPaused(userPaused)
        if !userPaused && !started { deadline = Date().addingTimeInterval(30) }
        busySince = nil
        lastAdvance = Date()
        setControls(true)
    }
    @objc private func backTap() { jump(-10); setControls(true) }
    @objc private func fwdTap() { jump(10); setControls(true) }
    @objc private func nextTap() { wantNext = true; finish() }
    @objc private func closeTap() { finish() }
    @objc private func seekStart() { seeking = true; hideAt = Date().addingTimeInterval(8) }
    @objc private func seekEnd() {
        seek(toFraction: Double(slider.value))
        seeking = false
        setControls(true)
    }

    private func applyFill() {
        let vs = videoSize()
        guard fill, vs.width > 0, vs.height > 0, videoView.bounds.width > 0, videoView.bounds.height > 0 else {
            videoView.transform = .identity
            return
        }
        let sx = videoView.bounds.width / vs.width, sy = videoView.bounds.height / vs.height
        let s = max(sx, sy) / min(sx, sy)
        videoView.transform = CGAffineTransform(scaleX: s, y: s)
    }

    @objc private func aspectTap() {
        fill.toggle()
        UIView.animate(withDuration: 0.25) { self.applyFill() }
        setControls(true)
    }

    @objc private func speedTap() {
        let a = UIAlertController(title: "السرعة", message: nil, preferredStyle: .actionSheet)
        for r: Float in [0.75, 1, 1.25, 1.5, 2] {
            a.addAction(UIAlertAction(title: (r == rate ? "✓ " : "") + String(format: "%g×", r), style: .default) { _ in
                self.rate = r
                self.setRate(r)
            })
        }
        show(a)
    }

    @objc private func audioTap() { pick("الصوت", audioTracks(), current: currentAudio()) { self.setAudio($0) } }
    @objc private func subsTap() { pick("الترجمة", subtitleTracks(), current: currentSubtitle()) { self.setSubtitle($0) } }

    private func show(_ a: UIAlertController) {
        a.addAction(UIAlertAction(title: "إلغاء", style: .cancel, handler: nil))
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true, completion: nil)
        hideAt = Date().addingTimeInterval(8)
    }

    private func pick(_ title: String, _ tracks: [(String, Int)], current: Int, _ set: @escaping (Int) -> Void) {
        let a = UIAlertController(title: title, message: tracks.isEmpty ? "لا توجد مسارات" : nil, preferredStyle: .actionSheet)
        for (name, id) in tracks {
            a.addAction(UIAlertAction(title: (id == current ? "✓ " : "") + name, style: .default) { _ in set(id) })
        }
        show(a)
    }

    func finish() {
        if finished { return }
        finished = true
        timer?.invalidate()
        timer = nil
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        stopPlayback()
        dismiss(animated: true) { self.done(answer) }
    }
}
