import Foundation
import Darwin

/// «التخزين حتى نهاية الفيلم»: the film is fetched from the server into a file on the phone — ahead of the player and
/// on to the very end — while every player reads it from the app's own address on the phone (LocalServer:
/// http://127.0.0.1:<port>/v/<id>/<gen>/f.<ext>). Seeking into what is already there is instant, a dropped connection
/// goes on from the first missing byte, a paused film keeps filling, and a film opened again starts from what is
/// already stored. Movies and episodes only (a live channel has no end).
///
/// One download at a time (IPTV accounts often allow one connection). All state lives behind one lock (`cond`):
/// the downloads report on their own queue, the local server's threads wait on `cond` for the bytes they need.

/// Bytes [a, b) of the film.
struct Span {
    var a: Int64
    var b: Int64
}

/// What is on the phone: sorted, merged spans.
struct ByteRanges {
    private(set) var list: [Span] = []

    var bytes: Int64 {
        var n: Int64 = 0
        for s in list { n += s.b - s.a }
        return n
    }

    mutating func add(_ a: Int64, _ b: Int64) {
        if b <= a { return }
        var na = a, nb = b
        var out: [Span] = []
        out.reserveCapacity(list.count + 1)
        var placed = false
        for s in list {
            if s.b < na {
                out.append(s)
            } else if s.a > nb {
                if !placed { out.append(Span(a: na, b: nb)); placed = true }
                out.append(s)
            } else {
                na = min(na, s.a)
                nb = max(nb, s.b)
            }
        }
        if !placed { out.append(Span(a: na, b: nb)) }
        list = out
    }

    mutating func remove(_ a: Int64, _ b: Int64) {
        if b <= a { return }
        var out: [Span] = []
        for s in list {
            if s.b <= a || s.a >= b { out.append(s); continue }
            if s.a < a { out.append(Span(a: s.a, b: a)) }
            if s.b > b { out.append(Span(a: b, b: s.b)) }
        }
        list = out
    }

    /// The first byte at or after x that is not on the phone (x itself when x is missing).
    func end(from x: Int64) -> Int64 {
        var lo = 0, hi = list.count - 1, hit = -1
        while lo <= hi {
            let m = (lo + hi) / 2
            if list[m].a <= x { hit = m; lo = m + 1 } else { hi = m - 1 }
        }
        if hit >= 0 && list[hit].b > x { return list[hit].b }
        return x
    }

    func has(_ x: Int64) -> Bool { end(from: x) > x }

    /// Where the next stored part after x starts (Int64.max when there is none).
    func nextStart(after x: Int64) -> Int64 {
        for s in list where s.a > x { return s.a }
        return Int64.max
    }
}

/// One connection to the film's server, bringing [pos, limit).
final class CacheWorker {
    let entry: CacheEntry
    var task: URLSessionDataTask?
    let start: Int64
    var pos: Int64
    var limit: Int64
    let extra: Bool
    let viaFinal: Bool
    var stopped = false
    let born = Date()

    init(entry: CacheEntry, start: Int64, limit: Int64, extra: Bool, viaFinal: Bool) {
        self.entry = entry
        self.start = start
        self.pos = start
        self.limit = limit
        self.extra = extra
        self.viaFinal = viaFinal
    }
}

/// One film on the phone: its file, what of it is there, and the connections filling it.
final class CacheEntry {
    let id: String
    let key: String
    let file: String
    let meta: String
    var url = ""
    var finalURL = ""
    var ua = ""
    var ext = "mkv"
    var total: Int64 = -1
    var have = ByteRanges()
    var gen = 0
    var active = false
    /// stopped because the player went quiet: it starts again by itself when the player asks
    var idleStop = false
    /// where the player reads (the downloads go on from here to the end, then fill what is left before it)
    var focus: Int64 = 0
    /// a player waits for this byte now
    var needAt: Int64 = -1
    var lastTouch = Date()
    var used = Date()
    var lastByte = Date()
    /// the server refuses the link: the app is asked for a fresh one
    var dead = false
    var error = ""
    var noRange = false
    var conns = 1
    var soloHost = false
    var extraAt = Date.distantPast
    var workers: [Int: CacheWorker] = [:]
    var fails = 0
    var retryAt = Date.distantPast
    var fd: Int32 = -1
    var dirty = false
    var savedAt = Date.distantPast
    var waiting = 0
    var readers = 0
    var starve = 0.0
    var pos = 0.0
    var dur = 0.0
    /// the phone is almost full: only a window around the playing position is kept
    var window = false
    private var buckets = [Int64](repeating: 0, count: 20)   // bytes per quarter second, the last 5 seconds
    private var slotAt = 0

    init(id: String, key: String) {
        self.id = id
        self.key = key
        file = (StreamCache.dir as NSString).appendingPathComponent(id + ".data")
        meta = (StreamCache.dir as NSString).appendingPathComponent(id + ".json")
    }

    var complete: Bool { total > 0 && have.end(from: 0) >= total }
    /// bytes per second of the film itself (when the player told its length)
    var mediaRate: Double { total > 0 && dur > 30 ? Double(total) / dur : 0 }

    private func advance() -> Int {
        let slot = Int(ProcessInfo.processInfo.systemUptime * 4)
        if slotAt == 0 || slot - slotAt >= buckets.count {
            for i in 0..<buckets.count { buckets[i] = 0 }
        } else if slot > slotAt {
            var s = slotAt + 1
            while s <= slot { buckets[s % buckets.count] = 0; s += 1 }
        }
        if slot > slotAt { slotAt = slot }
        return slotAt
    }

    func count(_ n: Int64) {
        let s = advance()
        buckets[s % buckets.count] += n
        lastByte = Date()
    }

    /// bytes per second over the last 5 seconds
    func speedNow() -> Double {
        _ = advance()
        var n: Int64 = 0
        for b in buckets { n += b }
        return Double(n) / 5.0
    }
}

/// What a player shows about the film's copy on the phone.
struct CacheStatus {
    var total: Int64
    var have: Int64
    var speed: Double
    var done: Bool
    var dead: Bool
    var active: Bool
    var ahead: Int64
    var spans: [[Double]]
    var conns: Int
    var waiting: Bool
    var quiet: Double
    var error: String

    var percent: Int { total > 0 ? Int(Double(have) * 100 / Double(total)) : 0 }

    var text: String {
        if done { return "✓ الفيلم كله على الجهاز" }
        if dead { return "⚠︎ انتهت صلاحية الرابط — جاري طلب رابط جديد…" }
        let sp = speed >= 1_048_576 ? String(format: "%.1f MB/s", speed / 1_048_576) : String(format: "%.0f KB/s", speed / 1024)
        var t = "⬇ مخزّن \(percent)٪ · " + sp
        if conns > 1 { t += " · ×\(conns)" }
        if !active { t = "مخزّن \(percent)٪ · التنزيل متوقف" }
        else if speed < 1 && quiet > 6 { t = "مخزّن \(percent)٪ · " + (error.isEmpty ? "بانتظار الخادم…" : error) }
        return t
    }
}

final class StreamCache: NSObject, URLSessionDataDelegate {
    static let shared = StreamCache()
    static let dir: String = {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].path
        return (base as NSString).appendingPathComponent("SahraBuffer")
    }()

    struct Ticket {
        let id: String
        let gen: Int
        let url: String
    }

    /// room kept free for the phone itself
    private let reserve: Int64 = 1_500_000_000
    /// what each connection brings when there are several
    private let stripe: Int64 = 8 * 1024 * 1024
    let cond = NSCondition()
    private var entries: [String: CacheEntry] = [:]
    private var byTask: [Int: CacheWorker] = [:]
    private var current = ""
    private var session: URLSession!
    private let dq = OperationQueue()
    private var timer: DispatchSourceTimer?
    private var lastDisk = Date.distantPast

    override init() {
        super.init()
        try? FileManager.default.createDirectory(atPath: StreamCache.dir, withIntermediateDirectories: true, attributes: nil)
        dq.maxConcurrentOperationCount = 1
        dq.name = "sahra.cache"
        let c = URLSessionConfiguration.default
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.urlCache = nil
        c.timeoutIntervalForRequest = 20
        c.timeoutIntervalForResource = 7 * 24 * 3600
        c.httpMaximumConnectionsPerHost = 4
        c.allowsCellularAccess = true
        session = URLSession(configuration: c, delegate: self, delegateQueue: dq)
        let t = DispatchSource.makeTimerSource(queue: DispatchQueue.global(qos: .utility))
        t.schedule(deadline: .now() + 1, repeating: 1)
        t.setEventHandler { [weak self] in self?.tick() }
        t.resume()
        timer = t
        DispatchQueue.global(qos: .utility).async { [weak self] in self?.prune() }
    }

    // MARK: - what the app calls

    /// Starts (or goes on with) the film's copy and gives the address the players open. nil → play the link itself.
    func openFilm(url: String, ua: String, key: String, ext: String) -> Ticket? {
        guard let u = Net.makeURL(url), let sch = u.scheme?.lowercased(), sch == "http" || sch == "https" else { return nil }
        let port = LocalServer.shared.ensure()
        if port <= 0 { return nil }
        let k = key.isEmpty ? (url.components(separatedBy: "?").first ?? url) : key
        let id = StreamCache.keyID(k)
        let x = StreamCache.safeExt(ext, url)
        let solo = StreamCache.isSolo(u.host ?? "")
        cond.lock()
        // one film at a time: the others stop (their bytes stay for later)
        for (oid, o) in entries where oid != id && o.active { stopLocked(o, idle: false) }
        let e: CacheEntry
        if let old = entries[id] { e = old } else { e = loadLocked(id: id, key: k); entries[id] = e }
        if e.fd < 0 { e.fd = Darwin.open(e.file, O_RDWR | O_CREAT, 0o644) }
        if e.fd < 0 { cond.unlock(); return nil }
        if e.url != url { e.url = url; e.finalURL = "" }
        e.ua = ua
        e.ext = x
        e.dead = false
        e.error = ""
        e.fails = 0
        e.retryAt = .distantPast
        e.gen += 1
        e.active = true
        e.idleStop = false
        e.needAt = -1
        e.lastTouch = Date()
        e.used = Date()
        e.soloHost = solo
        e.conns = 1
        e.starve = 0
        current = id
        planLocked(e)
        let t = Ticket(id: id, gen: e.gen, url: "http://127.0.0.1:\(port)/v/\(id)/\(e.gen)/f.\(x)")
        cond.unlock()
        DispatchQueue.global(qos: .utility).async { [weak self] in self?.makeRoom(for: id) }
        return t
    }

    /// A fresh link for the same film (the old one expired): the download goes on with it.
    func relink(key: String, url: String) {
        if url.isEmpty || key.isEmpty { return }
        let id = StreamCache.keyID(key)
        cond.lock()
        if let e = entries[id] {
            e.url = url
            e.finalURL = ""
            e.dead = false
            e.error = ""
            e.fails = 0
            e.retryAt = .distantPast
            if id == current && !e.active { e.active = true; e.idleStop = false }
            planLocked(e)
            cond.broadcast()
        }
        cond.unlock()
    }

    /// The player closed: the download stops (what is stored stays for next time).
    func closeFilm(_ id: String, gen: Int) {
        cond.lock()
        if let e = entries[id], gen < 0 || gen == e.gen { stopLocked(e, idle: false) }
        cond.unlock()
        saveAll()
    }

    /// Something else plays (a live channel, an outside player): its connection must not be taken.
    func stopAll() {
        cond.lock()
        for (_, e) in entries where e.active { stopLocked(e, idle: false) }
        current = ""
        cond.unlock()
        saveAll()
    }

    /// The player is still there (it says so every second or two), and where it is.
    func touch(_ id: String, gen: Int, pos: Double, dur: Double) {
        _ = LocalServer.shared.ensure()
        cond.lock()
        if let e = entries[id] {
            e.lastTouch = Date()
            if pos >= 0 { e.pos = pos }
            if dur > 0 { e.dur = dur }
            if !e.active && e.idleStop && id == current && (gen < 0 || gen == e.gen) {
                e.active = true
                e.idleStop = false
                planLocked(e)
            }
        }
        cond.unlock()
    }

    func isDead(_ id: String) -> Bool {
        cond.lock(); defer { cond.unlock() }
        return entries[id]?.dead ?? false
    }

    func status(_ id: String) -> CacheStatus? {
        cond.lock(); defer { cond.unlock() }
        guard let e = entries[id] else { return nil }
        let total = e.total
        var spans: [[Double]] = []
        if total > 0 {
            // tiny holes are not worth a gap on a phone-sized bar
            let gap = max(Int64(1), total / 500)
            var cur: Span?
            for s in e.have.list {
                if var c = cur, s.a - c.b <= gap {
                    c.b = max(c.b, s.b)
                    cur = c
                } else {
                    if let c = cur { spans.append([Double(c.a) / Double(total), Double(c.b) / Double(total)]) }
                    cur = s
                }
            }
            if let c = cur { spans.append([Double(c.a) / Double(total), Double(c.b) / Double(total)]) }
            if spans.count > 80 { spans = Array(spans.prefix(80)) }
        }
        return CacheStatus(total: total, have: e.have.bytes, speed: e.speedNow(), done: e.complete, dead: e.dead, active: e.active,
                           ahead: e.have.end(from: e.focus) - e.focus, spans: spans,
                           conns: e.workers.values.filter { !$0.stopped }.count, waiting: e.waiting > 0,
                           quiet: Date().timeIntervalSince(e.lastByte), error: e.error)
    }

    func infoJSON(_ id: String) -> String {
        guard let s = status(id) else { return "{\"ok\":false}" }
        let d: [String: Any] = ["ok": true, "total": s.total, "have": s.have, "pct": s.total > 0 ? Double(s.have) / Double(s.total) : 0,
                                "speed": Int(s.speed), "done": s.done, "dead": s.dead, "active": s.active, "ahead": s.ahead,
                                "r": s.spans, "conns": s.conns, "waiting": s.waiting, "quiet": Int(s.quiet), "err": s.error, "text": s.text]
        guard let data = try? JSONSerialization.data(withJSONObject: d, options: []), let str = String(data: data, encoding: .utf8) else { return "{\"ok\":false}" }
        return str
    }

    /// {bytes, films, free}: what the copies take on the phone
    func usageJSON() -> String {
        var bytes: Int64 = 0, n = 0
        let fm = FileManager.default
        for f in (try? fm.contentsOfDirectory(atPath: StreamCache.dir)) ?? [] where f.hasSuffix(".data") {
            n += 1
            let u = URL(fileURLWithPath: (StreamCache.dir as NSString).appendingPathComponent(f))
            if let v = try? u.resourceValues(forKeys: [.totalFileAllocatedSizeKey]), let s = v.totalFileAllocatedSize { bytes += Int64(s) }
        }
        return "{\"bytes\":\(bytes),\"films\":\(n),\"free\":\(StreamCache.freeSpace())}"
    }

    /// Deletes every stored copy except the film playing now.
    func clear() {
        var ids: [String] = []
        cond.lock()
        for (id, e) in entries where !(id == current && (e.active || e.readers > 0)) { ids.append(id) }
        cond.unlock()
        var keep = ""
        cond.lock()
        if let e = entries[current], e.active || e.readers > 0 { keep = current }
        cond.unlock()
        for id in ids { removeEntry(id) }
        for f in (try? FileManager.default.contentsOfDirectory(atPath: StreamCache.dir)) ?? [] {
            if !keep.isEmpty && f.hasPrefix(keep + ".") { continue }
            let id = (f as NSString).deletingPathExtension
            cond.lock()
            let known = entries[id] != nil
            cond.unlock()
            if !known { try? FileManager.default.removeItem(atPath: (StreamCache.dir as NSString).appendingPathComponent(f)) }
        }
    }

    func saveAll() {
        var list: [CacheEntry] = []
        cond.lock()
        for (_, e) in entries where e.dirty { list.append(e) }
        cond.unlock()
        for e in list { saveMeta(e) }
    }

    // MARK: - the local server's side

    /// Answers one request of the local server, on that connection's own thread.
    func serve(_ c: Int32, id: String, head: Bool, range: String?, kind: String) {
        cond.lock()
        guard let e = entries[id] else {
            cond.unlock()
            LocalServer.reply(c, 404, "Not Found")
            return
        }
        e.readers += 1
        // the film's size comes with the server's first answer
        let until = Date().addingTimeInterval(20)
        while e.total < 0 && !e.dead && Date() < until {
            if !e.active {
                if e.idleStop && e.id == current { e.active = true; e.idleStop = false } else { break }
            }
            if e.workers.isEmpty { planLocked(e) }
            _ = cond.wait(until: Date().addingTimeInterval(0.5))
        }
        let total = e.total, ext = kind.isEmpty ? e.ext : kind, fd = e.fd, dead = e.dead
        cond.unlock()
        defer {
            cond.lock()
            e.readers -= 1
            cond.unlock()
        }
        if total < 0 {
            // a server that never tells the size: the film is streamed from the start as it comes, without a length
            if !dead && (range == nil || LocalServer.range(range, Int64.max)?.a == 0) {
                if LocalServer.head(c, 200, ["Content-Type": LocalServer.mime(ext)]) && !head { streamUnsized(c, e, fd) }
                return
            }
            LocalServer.reply(c, dead ? 502 : 503, dead ? "Link expired" : "Not ready")
            return
        }
        guard let r = LocalServer.range(range, total) else {
            LocalServer.reply(c, 416, "Range Not Satisfiable", extra: ["Content-Range": "bytes */\(total)"])
            return
        }
        var hdr: [String: String] = ["Content-Type": LocalServer.mime(ext), "Accept-Ranges": "bytes", "Content-Length": String(r.b - r.a + 1)]
        let partial = range != nil
        if partial { hdr["Content-Range"] = "bytes \(r.a)-\(r.b)/\(total)" }
        if !LocalServer.head(c, partial ? 206 : 200, hdr) || head { return }
        var off = r.a
        let end = r.b + 1
        var quiet = Date()
        let chunk: Int64 = 512 * 1024
        var buf = [UInt8](repeating: 0, count: Int(chunk))
        while off < end {
            cond.lock()
            let avail = e.have.end(from: off)
            if avail > off {
                e.focus = off
                cond.unlock()
                let n = Int(min(avail, end, off + chunk) - off)
                let got = buf.withUnsafeMutableBytes { p -> Int in pread(fd, p.baseAddress, n, off_t(off)) }
                if got <= 0 { return }
                if !LocalServer.sendAll(c, buf, got) { return }
                off += Int64(got)
                quiet = Date()
                continue
            }
            // not on the phone yet: tell the downloads where the player waits, then wait for it
            if e.dead || (!e.active && !(e.idleStop && e.id == current)) {
                cond.unlock()
                return
            }
            if !e.active { e.active = true; e.idleStop = false }
            e.focus = off
            e.needAt = off
            e.waiting += 1
            planLocked(e)
            _ = cond.wait(until: Date().addingTimeInterval(1))
            e.waiting -= 1
            cond.unlock()
            if Date().timeIntervalSince(quiet) > 75 || LocalServer.peerGone(c) { return }
        }
    }

    /// the bytes from the start of a film of unknown size, as they arrive, until its end is known and sent
    private func streamUnsized(_ c: Int32, _ e: CacheEntry, _ fd: Int32) {
        var off: Int64 = 0
        var quiet = Date()
        var buf = [UInt8](repeating: 0, count: 512 * 1024)
        while true {
            cond.lock()
            let avail = e.have.end(from: off)
            let total = e.total
            if avail > off {
                e.focus = off
                cond.unlock()
                let n = Int(min(avail - off, Int64(buf.count)))
                let got = buf.withUnsafeMutableBytes { p -> Int in pread(fd, p.baseAddress, n, off_t(off)) }
                if got <= 0 || !LocalServer.sendAll(c, buf, got) { return }
                off += Int64(got)
                quiet = Date()
                continue
            }
            if (total >= 0 && off >= total) || e.dead || !e.active {
                cond.unlock()
                return
            }
            e.needAt = off
            e.waiting += 1
            planLocked(e)
            _ = cond.wait(until: Date().addingTimeInterval(1))
            e.waiting -= 1
            cond.unlock()
            if Date().timeIntervalSince(quiet) > 75 || LocalServer.peerGone(c) { return }
        }
    }

    // MARK: - planning the connections (always under the lock)

    private func live(_ e: CacheEntry) -> [CacheWorker] { e.workers.values.filter { !$0.stopped } }

    private func planLocked(_ e: CacheEntry) {
        guard e.active, !e.dead, e.fd >= 0 else { return }
        if e.needAt >= 0 && e.have.has(e.needAt) { e.needAt = -1 }
        if e.complete || Date() < e.retryAt { return }
        let want = e.noRange || e.total < 0 ? 1 : max(1, e.conns)
        // 1) a player waits for a byte that no connection is bringing: that comes first
        if e.needAt >= 0 && !e.noRange && e.total >= 0 && !covers(live(e), e.needAt) {
            var n = live(e).count
            if n >= want, let v = victim(live(e), e.needAt) { stopWorker(v); n -= 1 }
            if n < want { spawn(e, at: e.needAt) }
        }
        // 2) the free connections go on from the playing position to the end, then fill what is left before it
        var rounds = 0
        while rounds < 4 {
            rounds += 1
            let cur = live(e)
            if cur.count >= want { break }
            if want > 1 { for w in cur where w.limit - w.pos > stripe { w.limit = w.pos + stripe } }
            guard let s = nextStart(e, cur) else { break }
            spawn(e, at: s)
        }
    }

    /// a connection already on its way to x
    private func covers(_ ws: [CacheWorker], _ x: Int64) -> Bool {
        ws.contains { $0.pos <= x && x < $0.limit && x - $0.pos < 4 * 1024 * 1024 }
    }

    /// the connection to give up for x: the one behind it first, then the one furthest ahead
    private func victim(_ ws: [CacheWorker], _ x: Int64) -> CacheWorker? {
        func score(_ w: CacheWorker) -> Int64 { w.pos < x ? (Int64(1) << 50) + (x - w.pos) : w.pos - x }
        return ws.max { score($0) < score($1) }
    }

    private func stopWorker(_ w: CacheWorker) {
        w.stopped = true
        w.task?.cancel()
    }

    private func nextStart(_ e: CacheEntry, _ cur: [CacheWorker]) -> Int64? {
        if e.noRange { return cur.isEmpty ? 0 : nil }
        if e.total < 0 { return cur.isEmpty ? e.have.end(from: e.needAt >= 0 ? e.needAt : e.focus) : nil }
        var x = skip(e, cur, e.have.end(from: e.focus))
        if x >= e.total {
            if e.window { return nil }
            x = skip(e, cur, e.have.end(from: 0))
            return x < e.total ? x : nil
        }
        if e.window && x - e.focus > 256 * 1024 * 1024 { return nil }
        return x
    }

    /// x moved past the bytes on the phone and the parts other connections are bringing
    private func skip(_ e: CacheEntry, _ cur: [CacheWorker], _ x0: Int64) -> Int64 {
        var x = x0
        var moved = true
        var n = 0
        while moved && n < 64 {
            moved = false
            n += 1
            for w in cur where w.pos <= x && x < w.limit {
                x = w.limit == Int64.max ? Int64.max : e.have.end(from: w.limit)
                moved = true
            }
        }
        return x
    }

    private func spawn(_ e: CacheEntry, at s: Int64) {
        let cur = live(e)
        // a connection that was going to bring s now ends just before it
        for w in cur where w.pos <= s && s < w.limit {
            w.limit = s
            if w.pos >= w.limit { stopWorker(w) }
        }
        var lim = e.have.nextStart(after: s)
        for w in cur where w.pos > s && w.pos < lim { lim = w.pos }
        if e.total > 0 { lim = min(lim, e.total) }
        if !e.noRange && e.conns > 1 && s < Int64.max - stripe { lim = min(lim, s + stripe) }
        let start = e.noRange ? 0 : s
        if e.noRange { lim = e.total > 0 ? e.total : Int64.max }
        if lim <= start { return }
        let useFinal = !e.finalURL.isEmpty
        guard let u = Net.makeURL(useFinal ? e.finalURL : e.url) else {
            e.dead = true
            e.error = "رابط غير صالح"
            return
        }
        var req = URLRequest(url: u)
        req.timeoutInterval = 20
        let open = lim == Int64.max || (e.total > 0 && lim >= e.total)
        req.setValue(open ? "bytes=\(start)-" : "bytes=\(start)-\(lim - 1)", forHTTPHeaderField: "Range")
        if !e.ua.isEmpty { req.setValue(e.ua, forHTTPHeaderField: "User-Agent") }
        req.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        let extra = !cur.filter { !$0.stopped }.isEmpty
        let w = CacheWorker(entry: e, start: start, limit: lim, extra: extra, viaFinal: useFinal)
        let t = session.dataTask(with: req)
        w.task = t
        byTask[t.taskIdentifier] = w
        e.workers[t.taskIdentifier] = w
        if extra { e.extraAt = Date() }
        t.resume()
    }

    private func stopLocked(_ e: CacheEntry, idle: Bool) {
        e.active = false
        e.idleStop = idle
        e.needAt = -1
        for (_, w) in e.workers { stopWorker(w) }
        cond.broadcast()
    }

    /// another file behind the same name (its size changed): what was stored is not this film
    private func resetLocked(_ e: CacheEntry, keep: CacheWorker?) {
        for (_, w) in e.workers where w !== keep { stopWorker(w) }
        if e.fd >= 0 { _ = ftruncate(e.fd, 0) }
        e.have = ByteRanges()
        e.total = -1
        e.dirty = true
    }

    /// this server takes one connection only (remembered for next time)
    private func soloLocked(_ e: CacheEntry) {
        e.conns = 1
        let ws = live(e)
        if ws.count > 1 {
            let keep = ws.min { abs($0.pos - e.focus) < abs($1.pos - e.focus) }
            for w in ws where w !== keep { stopWorker(w) }
        }
        if !e.soloHost {
            e.soloHost = true
            if let h = Net.makeURL(e.url)?.host { StreamCache.addSolo(h) }
        }
    }

    private func refusedLocked(_ e: CacheEntry, _ w: CacheWorker, _ code: Int) {
        // the server's own address for the file (after its redirect) expired: back to the link itself
        if w.viaFinal { e.finalURL = ""; return }
        // a second connection refused: one connection for this server
        if w.extra || Date().timeIntervalSince(e.extraAt) < 8 { soloLocked(e); return }
        e.fails += 1
        e.retryAt = Date().addingTimeInterval(min(8, 0.6 * Double(e.fails)))
        e.error = "الخادم رفض (HTTP \(code))"
        if ([401, 403, 404, 410, 451].contains(code) && e.fails >= 2) || e.fails >= 8 { e.dead = true }
    }

    // MARK: - the downloads (on the session's queue)

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        cond.lock()
        guard let w = byTask[dataTask.taskIdentifier], !w.stopped else {
            cond.unlock()
            completionHandler(.cancel)
            return
        }
        let e = w.entry
        let h = response as? HTTPURLResponse
        let code = h?.statusCode ?? 200
        let len = response.expectedContentLength
        var ok = false
        if code == 206 {
            let cr = StreamCache.header(h, "Content-Range")
            if cr.isEmpty {
                ok = true
                if e.total < 0 && w.limit == Int64.max && len > 0 { e.total = w.start + len }
            } else if let r = StreamCache.parseContentRange(cr), r.start == w.start {
                if r.total > 0 {
                    if e.total > 0 && e.total != r.total { resetLocked(e, keep: w) }
                    e.total = r.total
                }
                ok = true
            } else {
                e.noRange = true
                e.conns = 1
                e.fails += 1
                e.retryAt = Date().addingTimeInterval(1)
            }
        } else if code == 200 {
            if w.start == 0 {
                if len > 0 {
                    if e.total > 0 && e.total != len { resetLocked(e, keep: w) }
                    e.total = len
                }
                // (many servers answer «bytes=0-» with the whole file but still serve ranges further on)
                if StreamCache.header(h, "Accept-Ranges").lowercased() == "none" {
                    e.noRange = true
                    e.conns = 1
                    w.limit = e.total > 0 ? e.total : Int64.max
                }
                ok = true
            } else {
                // the whole file whatever was asked: this server has no ranges → one connection from the start
                e.noRange = true
                e.conns = 1
            }
        } else if code == 416 {
            if e.total < 0 || w.start < e.total { e.fails += 1; e.retryAt = Date().addingTimeInterval(2) }
        } else {
            refusedLocked(e, w, code)
        }
        if ok {
            if !w.viaFinal, let fu = response.url?.absoluteString, !fu.isEmpty, fu != e.url { e.finalURL = fu }
            if e.error.hasPrefix("الخادم") { e.error = "" }
            cond.unlock()
            completionHandler(.allow)
        } else {
            w.stopped = true
            cond.unlock()
            completionHandler(.cancel)
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        cond.lock()
        guard let w = byTask[dataTask.taskIdentifier], !w.stopped else { cond.unlock(); return }
        let e = w.entry
        let off = w.pos, lim = w.limit, fd = e.fd
        cond.unlock()
        var n = Int64(data.count)
        if off + n > lim { n = max(0, lim - off) }
        var wrote: Int64 = 0
        if n > 0 && fd >= 0 {
            wrote = data.withUnsafeBytes { (p: UnsafeRawBufferPointer) -> Int64 in
                guard let base = p.baseAddress else { return 0 }
                var done: Int64 = 0
                while done < n {
                    let r = pwrite(fd, base + Int(done), Int(n - done), off_t(off + done))
                    if r <= 0 { break }
                    done += Int64(r)
                }
                return done
            }
        }
        cond.lock()
        if !w.stopped && w.pos == off {
            if wrote > 0 {
                w.pos = off + wrote
                e.have.add(off, off + wrote)
                e.dirty = true
                e.count(wrote)
                if w.pos - w.start > 262_144 && e.fails > 0 { e.fails = 0; e.error = "" }
            }
            if wrote < n {
                // the phone is full: keep a window around the playing position only
                e.window = true
                e.error = "مساحة الجهاز ممتلئة"
                stopWorker(w)
            } else if w.pos >= w.limit || (e.total > 0 && w.pos >= e.total) || (!e.noRange && e.have.has(w.pos)) {
                stopWorker(w)
            }
            cond.broadcast()
        }
        cond.unlock()
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        cond.lock()
        guard let w = byTask.removeValue(forKey: task.taskIdentifier) else { cond.unlock(); return }
        let e = w.entry
        e.workers.removeValue(forKey: task.taskIdentifier)
        if !w.stopped {
            let now = Date()
            if error != nil {
                // a second connection that never worked, or that cut the first one: one connection only
                if w.extra && w.pos == w.start && now.timeIntervalSince(w.born) < 10 { soloLocked(e) }
                else if !w.extra && now.timeIntervalSince(e.extraAt) < 8 { soloLocked(e) }
                e.fails += 1
                e.retryAt = now.addingTimeInterval(e.fails <= 1 ? 0.2 : min(8, 0.7 * Double(e.fails)))
                if e.fails >= 3 { e.error = "انقطع الاتصال — إعادة المحاولة…" }
            } else if e.total < 0 && w.limit == Int64.max {
                e.total = w.pos   // the end of the file, now known
            } else if w.pos < min(w.limit, e.total > 0 ? e.total : Int64.max) {
                e.fails += 1   // the server closed early
                e.retryAt = now.addingTimeInterval(min(6, 0.5 * Double(e.fails)))
            }
        }
        planLocked(e)
        cond.broadcast()
        cond.unlock()
    }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        // many IPTV servers have broken certificates (like the rest of the app)
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }

    // MARK: - every second

    private func tick() {
        var save: [CacheEntry] = []
        let now = Date()
        cond.lock()
        for (_, e) in entries {
            if e.active && now.timeIntervalSince(e.lastTouch) > 25 {
                // the player went quiet (closed without telling, or the app slept): stop until it asks again
                stopLocked(e, idle: true)
            }
            if e.active {
                if e.waiting > 0 { e.starve += 1 } else { e.starve = max(0, e.starve - 0.34) }
                escalateLocked(e, now)
                planLocked(e)
            }
            if e.dirty && (now.timeIntervalSince(e.savedAt) > 8 || !e.active) { save.append(e) }
        }
        let disk = now.timeIntervalSince(lastDisk) > 10
        if disk { lastDisk = now }
        let cur = current
        cond.unlock()
        for e in save { saveMeta(e) }
        if disk && !cur.isEmpty { diskCheck(cur) }
    }

    /// more connections when one is not enough and the server allows it (at most 3)
    private func escalateLocked(_ e: CacheEntry, _ now: Date) {
        guard !e.noRange, e.total > 0, !e.soloHost, e.conns < 3, !e.dead, !e.complete else { return }
        guard now.timeIntervalSince(e.extraAt) > 12 else { return }
        let ws = live(e)
        guard !ws.isEmpty, ws.allSatisfy({ now.timeIntervalSince($0.born) > 4 }) else { return }
        let mr = e.mediaRate
        let ahead = Double(e.have.end(from: e.focus) - e.focus)
        let slow = mr > 0 && e.speedNow() < mr * 1.25 && ahead < mr * 90
        if e.starve >= 3 || slow {
            e.conns += 1
            e.starve = 0
            e.extraAt = now
        }
    }

    private func diskCheck(_ id: String) {
        makeRoom(for: id)
        let free = StreamCache.freeSpace()
        if free <= 0 { return }
        cond.lock()
        if let e = entries[id], e.active {
            if free < reserve {
                e.window = true
                punchLocked(e, before: e.focus - 96 * 1024 * 1024)
            } else if free > reserve + 1_000_000_000 && e.window {
                e.window = false
                if e.error == "مساحة الجهاز ممتلئة" { e.error = "" }
                planLocked(e)
            }
        }
        cond.unlock()
    }

    private struct PunchHole {
        var flags: UInt32
        var reserved: UInt32
        var offset: Int64
        var length: Int64
    }

    /// gives the watched part far behind the player back to the phone (F_PUNCHHOLE, APFS)
    private func punchLocked(_ e: CacheEntry, before b: Int64) {
        guard e.fd >= 0, b > 0 else { return }
        let blk: Int64 = 1 << 20
        for s in e.have.list where s.a < b {
            let a = (s.a + blk - 1) / blk * blk
            let z = min(s.b, b) / blk * blk
            if z <= a { continue }
            var ph = PunchHole(flags: 0, reserved: 0, offset: a, length: z - a)
            let r = withUnsafeMutablePointer(to: &ph) { p -> Int32 in fcntl(e.fd, 99, UnsafeMutableRawPointer(p)) }
            if r == 0 {
                e.have.remove(a, z)
                e.dirty = true
            }
        }
    }

    // MARK: - files

    private func loadLocked(id: String, key: String) -> CacheEntry {
        let e = CacheEntry(id: id, key: key)
        let fm = FileManager.default
        if let data = fm.contents(atPath: e.meta),
           let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any],
           (d["key"] as? String) == key, fm.fileExists(atPath: e.file) {
            let size = ((try? fm.attributesOfItem(atPath: e.file))?[.size] as? NSNumber)?.int64Value ?? 0
            e.total = (d["total"] as? NSNumber)?.int64Value ?? -1
            e.url = (d["url"] as? String) ?? ""
            for r in (d["ranges"] as? [[NSNumber]]) ?? [] where r.count == 2 {
                let a = r[0].int64Value, b = min(r[1].int64Value, size)
                if b > a { e.have.add(a, b) }
            }
        } else {
            try? fm.removeItem(atPath: e.file)
            try? fm.removeItem(atPath: e.meta)
        }
        return e
    }

    private func saveMeta(_ e: CacheEntry) {
        cond.lock()
        let d: [String: Any] = ["key": e.key, "url": e.url, "ext": e.ext, "total": e.total,
                                "ranges": e.have.list.map { [NSNumber(value: $0.a), NSNumber(value: $0.b)] },
                                "used": e.used.timeIntervalSince1970]
        e.dirty = false
        e.savedAt = Date()
        let path = e.meta
        cond.unlock()
        if let data = try? JSONSerialization.data(withJSONObject: d, options: []) {
            try? data.write(to: URL(fileURLWithPath: path), options: .atomic)
        }
    }

    private func removeEntry(_ id: String) {
        cond.lock()
        if let e = entries[id] {
            if e.readers > 0 || !e.workers.isEmpty || (e.active && id == current) { cond.unlock(); return }
            for (_, w) in e.workers { stopWorker(w) }
            if e.fd >= 0 { Darwin.close(e.fd); e.fd = -1 }
            entries.removeValue(forKey: id)
        }
        cond.unlock()
        let fm = FileManager.default
        try? fm.removeItem(atPath: (StreamCache.dir as NSString).appendingPathComponent(id + ".data"))
        try? fm.removeItem(atPath: (StreamCache.dir as NSString).appendingPathComponent(id + ".json"))
    }

    /// the films stored before, oldest first: (id, last used)
    private func stored() -> [(String, Double)] {
        var out: [(String, Double)] = []
        let fm = FileManager.default
        for f in (try? fm.contentsOfDirectory(atPath: StreamCache.dir)) ?? [] where f.hasSuffix(".data") {
            let id = (f as NSString).deletingPathExtension
            var used = 0.0
            let mp = (StreamCache.dir as NSString).appendingPathComponent(id + ".json")
            if let data = fm.contents(atPath: mp),
               let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any] {
                used = (d["used"] as? NSNumber)?.doubleValue ?? 0
            }
            out.append((id, used))
        }
        return out.sorted { $0.1 < $1.1 }
    }

    /// room for the rest of this film: the oldest other films go first
    private func makeRoom(for id: String) {
        cond.lock()
        let need: Int64
        if let e = entries[id], e.total > 0 { need = max(0, e.total - e.have.bytes) } else { need = 0 }
        cond.unlock()
        var free = StreamCache.freeSpace()
        if free <= 0 || free >= need + reserve { return }
        for (oid, _) in stored() where oid != id {
            removeEntry(oid)
            free = StreamCache.freeSpace()
            if free >= need + reserve { break }
        }
    }

    /// at launch: films not opened for 5 days, and all but the last 4, are deleted
    private func prune() {
        let list = stored()
        let old = Date().timeIntervalSince1970 - 5 * 24 * 3600
        for (i, item) in list.enumerated() where item.1 < old || i < list.count - 4 { removeEntry(item.0) }
    }

    // MARK: - small helpers

    static func freeSpace() -> Int64 {
        let u = URL(fileURLWithPath: StreamCache.dir)
        if let v = try? u.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let n = v.volumeAvailableCapacityForImportantUsage { return n }
        return 0
    }

    static func keyID(_ s: String) -> String {
        var h: UInt64 = 0xcbf2_9ce4_8422_2325
        for b in s.utf8 { h ^= UInt64(b); h = h &* 0x0000_0100_0000_01b3 }
        return String(h, radix: 16)
    }

    static func safeExt(_ ext: String, _ url: String) -> String {
        var x = ext.lowercased()
        if x.isEmpty, let u = Net.makeURL(url) { x = u.pathExtension.lowercased() }
        let ok = ["mkv", "mp4", "m4v", "mov", "avi", "ts", "webm", "mpg", "mpeg", "wmv", "flv", "m2ts"]
        return ok.contains(x) ? x : "mkv"
    }

    static func header(_ h: HTTPURLResponse?, _ name: String) -> String {
        guard let h = h else { return "" }
        for (k, v) in h.allHeaderFields {
            if let ks = k as? String, ks.caseInsensitiveCompare(name) == .orderedSame { return "\(v)" }
        }
        return ""
    }

    /// "bytes a-b/total" → (a, total); total -1 when the server writes "*"
    static func parseContentRange(_ s: String) -> (start: Int64, total: Int64)? {
        let t = s.trimmingCharacters(in: .whitespaces).lowercased()
        guard t.hasPrefix("bytes") else { return nil }
        let body = t.dropFirst(5).trimmingCharacters(in: .whitespaces)
        let parts = body.split(separator: "/", maxSplits: 1).map(String.init)
        guard parts.count == 2, let dash = parts[0].firstIndex(of: "-"), let a = Int64(parts[0][..<dash]) else { return nil }
        return (a, Int64(parts[1]) ?? -1)
    }

    private static let soloKey = "sahra.cache.solo"
    static func isSolo(_ host: String) -> Bool {
        (UserDefaults.standard.stringArray(forKey: soloKey) ?? []).contains(host.lowercased())
    }
    static func addSolo(_ host: String) {
        var a = UserDefaults.standard.stringArray(forKey: soloKey) ?? []
        let h = host.lowercased()
        if a.contains(h) { return }
        a.append(h)
        if a.count > 200 { a.removeFirst(a.count - 200) }
        UserDefaults.standard.set(a, forKey: soloKey)
    }
}
