#if SAHRA_KS
import UIKit
import KSPlayer

/// KSPlayer: an FFmpeg player (KSMEPlayer) with Metal drawing and its own full controls — audio and
/// subtitle tracks, speed, picture-in-picture, HDR. Good for MKV, HEVC and live TS.
final class KSEngineController: UIViewController, LiveSubtitleTarget {
    private let o: EngineOpts
    // 3.27: 🔒 lock + «تخطي المقدمة» / «الحلقة التالية»
    private lazy var extras = PlayerExtras(o)
    private var partEnded = false
    private let done: (String) -> Void
    var relink: (() -> Void)?
    private let cacheBadge = CacheBadge()
    private var playerView: IOSVideoPlayerView?
    private var overlay: SubtitleOverlay?
    private var watchdog: Timer?
    private let deadline = Date().addingTimeInterval(30)
    private var firstTime: Double = -1
    private var started = false
    private var finished = false
    private var wantNext = false
    private var streamEnded = false
    private var lastPos: Double = 0
    private var lastDur: Double = 0
    private var failure = ""

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    /// the screen stays awake while the film plays
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !finished { UIApplication.shared.isIdleTimerDisabled = true }
        extras.front()
    }

    /// Arabic subtitles found (or translated) while the film plays
    func loadLiveSubtitles(_ srt: String, label: String) {
        guard let ov = SubtitleOverlay(srt: srt) else { return }
        overlay?.label.removeFromSuperview()
        overlay = ov
        ov.attach(to: view)
        extras.front()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        guard let u = o.mediaURL else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.fail("رابط غير صالح") }
            return
        }
        // FFmpeg first (AVPlayer is its own engine in the app)
        KSOptions.firstPlayerType = KSMEPlayer.self
        KSOptions.secondPlayerType = KSMEPlayer.self
        let options = KSOptions()
        if !o.ua.isEmpty { options.appendHeader(["User-Agent": o.ua]) }
        if o.start > 1 { options.startPlayTime = o.start }
        // a few seconds in hand before the picture starts, and a deep buffer behind it: fewer stalls
        // (reading the phone's copy of a film: the real buffer is on the phone, so it starts and seeks sooner)
        options.preferredForwardBufferDuration = o.live ? 8 : (o.cacheId.isEmpty ? 10 : 4)
        options.maxBufferDuration = o.live ? 30 : 120

        let pv = IOSVideoPlayerView()
        pv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pv)
        NSLayoutConstraint.activate([
            pv.topAnchor.constraint(equalTo: view.topAnchor),
            pv.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            pv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pv.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        pv.backBlock = { [weak self] in self?.finish() }
        pv.playTimeDidChange = { [weak self] (current: TimeInterval, total: TimeInterval) in
            self?.progress(current, total)
        }
        playerView = pv

        if let ov = SubtitleOverlay(srt: o.subs) {
            overlay = ov
            ov.attach(to: view)
        }
        if !o.cacheId.isEmpty { cacheBadge.attach(to: view, top: 14) }
        // a close button of our own too, whatever KSPlayer shows in this orientation
        let close = UIButton(type: .system)
        close.setImage(UIImage(systemName: "xmark.circle.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold)), for: .normal)
        close.tintColor = UIColor(white: 1, alpha: 0.75)
        close.addTarget(self, action: #selector(closeTap), for: .touchUpInside)
        close.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(close)
        NSLayoutConstraint.activate([
            close.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            close.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 56),
            close.widthAnchor.constraint(equalToConstant: 44),
            close.heightAnchor.constraint(equalToConstant: 44)
        ])

        extras.jump = { [weak self] s in
            guard let self = self, let pv = self.playerView else { return }
            pv.seek(time: max(0, self.lastPos + s)) { _ in }
        }
        extras.next = { [weak self] in
            guard let self = self else { return }
            self.wantNext = true
            self.streamEnded = true
            self.finish()
        }
        extras.attach(to: view, actionBottom: 110)
        LiveSubs.target = self
        let definition = KSPlayerResourceDefinition(url: u, definition: o.title.isEmpty ? "KSPlayer" : o.title, options: options)
        pv.set(resource: KSPlayerResource(name: o.title, definitions: [definition]))
        watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.watch() }
    }

    private func progress(_ current: Double, _ total: Double) {
        guard current.isFinite else { return }
        if firstTime < 0 { firstTime = current } else if abs(current - firstTime) > 0.3 { started = true }
        if started { lastPos = current }
        if total.isFinite && total > 0 { lastDur = total }
        overlay?.show(at: current)
        if started && o.hasNext && total > 60 && current >= total - 1 {
            streamEnded = true
            wantNext = true
            finish()
        }
    }

    private func watch() {
        extras.tick(pos: lastPos, dur: lastDur, started: started)
        extras.front()
        if o.until > 0 && lastPos >= o.until && !partEnded {
            partEnded = true
            playerView?.pause()
        }
        let cs = cacheBadge.tick(o, pos: lastPos, dur: lastDur, relink: relink)
        if !started && Date() > deadline {
            // reading the phone's copy of a slow server: not a failure while the bytes keep coming (up to 90 s)
            let flowing = cs.map { $0.quiet < 8 && !$0.dead } ?? false
            if !flowing || Date() > deadline.addingTimeInterval(60) { fail("لم يبدأ خلال 30 ثانية") }
        }
    }

    @objc private func closeTap() { finish() }

    private func fail(_ why: String) {
        if finished || !failure.isEmpty { return }
        failure = why
        finish()
    }

    private func finish() {
        if finished { return }
        finished = true
        watchdog?.invalidate()
        watchdog = nil
        UIApplication.shared.isIdleTimerDisabled = false
        playerView?.pause()
        playerView?.removeFromSuperview()
        playerView = nil
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        if presentingViewController != nil && !isBeingDismissed {
            dismiss(animated: true) { self.done(answer) }
        } else {
            done(answer)
        }
    }
}
#endif
