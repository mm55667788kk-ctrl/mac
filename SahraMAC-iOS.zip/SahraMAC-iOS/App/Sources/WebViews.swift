import UIKit
import WebKit
import JavaScriptCore
import AVKit

/// Scriptable's WebView for the script: the page is served from the app's own address (sahra://app/…),
/// navigations are offered to the script's `shouldAllowRequest`, and the page can also talk through
/// `window.webkit.messageHandlers.sahra` (faster than the navigation trick Scriptable needs).
final class WebViews: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    weak var host: HostViewController?
    let scheme = SchemeHandler()
    private var views: [Int: WKWebView] = [:]
    private var objs: [Int: JSValue] = [:]
    private var pending: [Int: (ok: JSValue, fail: JSValue)] = [:]
    private var presented: [Int: JSValue] = [:]

    /// Runs before the page: tells it that it is inside the app (faster messages through
    /// window.webkit.messageHandlers.sahra). The page reaches video servers directly, like in Scriptable.
    static let inject = "window.SAHRA_APP = 1;"

    private func id(of wv: WKWebView) -> Int? {
        for (k, v) in views where v === wv { return k }
        return nil
    }

    func create(_ id: Int, _ obj: JSValue) {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(scheme, forURLScheme: SchemeHandler.scheme)
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.allowsPictureInPictureMediaPlayback = true
        cfg.allowsAirPlayForMediaPlayback = true
        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: WebViews.inject, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.add(WeakMessageHandler(self), name: "sahra")
        cfg.userContentController = ucc

        let frame = host?.view.bounds ?? UIScreen.main.bounds
        let wv = WKWebView(frame: frame, configuration: cfg)
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.scrollView.backgroundColor = .black
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        wv.scrollView.bounces = false
        wv.allowsBackForwardNavigationGestures = false
        if #available(iOS 16.4, *) { wv.isInspectable = true }
        views[id] = wv
        objs[id] = obj
        host?.attach(wv)
    }

    // ---- loading ----
    func loadFile(_ id: Int, _ path: String, _ ok: JSValue, _ fail: JSValue) {
        guard let wv = views[id] else { _ = fail.call(withArguments: ["no web view"]); return }
        var rel = path
        if rel.hasPrefix(Runtime.docs) { rel = String(rel.dropFirst(Runtime.docs.count)) }
        while rel.hasPrefix("/") { rel.removeFirst() }
        let enc = rel.split(separator: "/").map { part -> String in
            let s = String(part)
            return s.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? s
        }.joined(separator: "/")
        guard let url = URL(string: SchemeHandler.scheme + "://app/" + enc) else {
            _ = fail.call(withArguments: ["bad path"])
            return
        }
        pending[id] = (ok: ok, fail: fail)
        wv.load(URLRequest(url: url))
    }

    func loadURL(_ id: Int, _ s: String, _ ok: JSValue, _ fail: JSValue) {
        guard let wv = views[id], let url = Net.makeURL(s) else { _ = fail.call(withArguments: ["bad url"]); return }
        pending[id] = (ok: ok, fail: fail)
        wv.load(URLRequest(url: url))
    }

    func loadHTML(_ id: Int, _ html: String, _ base: String, _ ok: JSValue, _ fail: JSValue) {
        guard let wv = views[id] else { _ = fail.call(withArguments: ["no web view"]); return }
        pending[id] = (ok: ok, fail: fail)
        wv.loadHTMLString(html, baseURL: base.isEmpty ? nil : Net.makeURL(base))
    }

    func present(_ id: Int, _ done: JSValue) {
        guard let wv = views[id] else { return }
        presented[id] = done
        host?.reveal(wv)
    }

    func eval(_ id: Int, _ js: String, _ cb: JSValue) {
        guard let wv = views[id] else { _ = cb.call(withArguments: ["no web view", NSNull()]); return }
        wv.evaluateJavaScript(js) { result, error in
            if let e = error {
                _ = cb.call(withArguments: [e.localizedDescription, NSNull()])
            } else {
                let r: Any = result ?? NSNull()
                _ = cb.call(withArguments: [NSNull(), r])
            }
        }
    }

    /// An answer the script just wrote for the page: run it in the page right away.
    func pushAnswer(_ js: String) {
        for (_, wv) in views {
            wv.evaluateJavaScript("if (window.bridge) {" + js + "}", completionHandler: nil)
        }
    }

    // ---- the script decides about navigations (that is how the page talks in Scriptable) ----
    private func allow(_ obj: JSValue, _ url: String, _ method: String) -> Bool {
        guard let fn = obj.forProperty("shouldAllowRequest"), !fn.isUndefined, !fn.isNull else { return true }
        let req: [String: Any] = ["url": url, "method": method]
        if let r = fn.call(withArguments: [req]), r.isBoolean { return r.toBool() }
        return true
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        let url = navigationAction.request.url
        if let i = id(of: webView), let obj = objs[i] {
            if !allow(obj, url?.absoluteString ?? "", navigationAction.request.httpMethod ?? "GET") {
                decisionHandler(.cancel)
                return
            }
        }
        // other apps (VLC, Infuse, …)
        if let u = url, let sch = u.scheme?.lowercased(),
           !["sahra", "http", "https", "about", "blob", "data", "file"].contains(sch) {
            UIApplication.shared.open(u, options: [:], completionHandler: nil)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let s = message.body as? String, let wv = message.webView, let i = id(of: wv), let obj = objs[i] else { return }
        _ = allow(obj, s, "GET")
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard let i = id(of: webView), let p = pending.removeValue(forKey: i) else { return }
        _ = p.ok.call(withArguments: [])
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        failLoad(webView, error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        failLoad(webView, error)
    }

    private func failLoad(_ wv: WKWebView, _ error: Error) {
        let ns = error as NSError
        if ns.domain == NSURLErrorDomain && ns.code == NSURLErrorCancelled { return }
        if ns.domain == "WebKitErrorDomain" && ns.code == 102 { return }   // stopped by a policy decision (the bridge)
        guard let i = id(of: wv), let p = pending.removeValue(forKey: i) else { return }
        _ = p.fail.call(withArguments: [error.localizedDescription])
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        // the system closed the page's process (usually: out of memory). The script rebuilds the page with fresh
        // data and carries on with what was playing; if it does not take it, the page is simply reloaded.
        if let i = id(of: webView), let obj = objs[i], !allow(obj, "alsahra-died:", "GET") { return }
        webView.reload()
    }

    /// Tells the pages the system is short of memory (the player frees the video it has already shown).
    func memoryWarning() {
        for (_, wv) in views {
            wv.evaluateJavaScript("window.__memWarn && window.__memWarn()", completionHandler: nil)
        }
    }

    // ---- links that want a new window, and alert / confirm ----
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = navigationAction.request.url { UIApplication.shared.open(u, options: [:], completionHandler: nil) }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard let host = host else { completionHandler(); return }
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "حسناً", style: .default) { _ in completionHandler() })
        (host.presentedViewController ?? host).present(a, animated: true, completion: nil)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard let host = host else { completionHandler(false); return }
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "إلغاء", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "موافق", style: .default) { _ in completionHandler(true) })
        (host.presentedViewController ?? host).present(a, animated: true, completion: nil)
    }
}

/// WKUserContentController keeps its handlers alive; this keeps the cycle out.
final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

/// sahra://app/<path> → a file in the app's Documents folder (the page, the answers, test files);
/// sahra://app/__proxy?u=<url> → the app fetches that address and streams it back to the page.
final class SchemeHandler: NSObject, WKURLSchemeHandler, URLSessionDataDelegate {
    static let scheme = "sahra"
    private var session: URLSession!
    private var byTask: [Int: WKURLSchemeTask] = [:]
    private var byScheme: [ObjectIdentifier: URLSessionDataTask] = [:]

    /// Flow control for the page's long downloads (movies, live streams). WebKit gives a custom-scheme task no
    /// back-pressure: a page that stops reading (buffer full, paused) is still sent the whole stream at full
    /// network speed, it piles up in the web process, and after a few minutes the system kills that process.
    /// The page reports what it has read (sahra://app/__ack?s=<id>&n=<bytes>); the download is suspended while
    /// too much is unread and resumed when the page catches up.
    private final class Flow {
        let sid: String
        var sent = 0
        var acked = 0
        var suspended = false
        weak var task: URLSessionDataTask?
        init(sid: String) { self.sid = sid }
    }
    private var flows: [Int: Flow] = [:]          // URLSession task id → flow
    private var flowBySid: [String: Int] = [:]    // page's id → URLSession task id
    private let flowHigh = 10 * 1024 * 1024
    private let flowLow = 4 * 1024 * 1024

    private final class LocalRead {
        let handle: FileHandle
        var remaining: Int

        init(_ handle: FileHandle, count: Int) {
            self.handle = handle
            remaining = count
        }

        deinit { try? handle.close() }
    }

    private let diskQueue = DispatchQueue(label: "app.sahra.media.read", qos: .userInitiated)
    private var localReads: [ObjectIdentifier: LocalRead] = [:]

    override init() {
        super.init()
        let c = URLSessionConfiguration.default
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.urlCache = nil
        c.timeoutIntervalForRequest = 30
        c.httpMaximumConnectionsPerHost = 8
        session = URLSession(configuration: c, delegate: self, delegateQueue: OperationQueue.main)
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        if url.path == "/__proxy" { proxy(urlSchemeTask, url) }
        else if url.path == "/__ack" { ack(urlSchemeTask, url) }
        else { serveFile(urlSchemeTask, url) }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        let key = ObjectIdentifier(urlSchemeTask as AnyObject)
        localReads.removeValue(forKey: key)
        if let t = byScheme.removeValue(forKey: key) {
            byTask.removeValue(forKey: t.taskIdentifier)
            dropFlow(t.taskIdentifier)
            t.cancel()
        }
    }

    // ---- files ----
    /// Serve the exact byte range WebKit requested, including probes and seeks in downloaded movies.
    private func serveFile(_ task: WKURLSchemeTask, _ url: URL) {
        let rel = url.path
        let path = (Runtime.docs as NSString).appendingPathComponent(rel)
        var isDirectory: ObjCBool = false
        let attrs = try? FileManager.default.attributesOfItem(atPath: path)
        guard !rel.contains(".."),
              FileManager.default.fileExists(atPath: path, isDirectory: &isDirectory), !isDirectory.boolValue,
              let size = (attrs?[.size] as? NSNumber)?.intValue, size >= 0 else {
            localResponse(task, url, 404, ["Content-Length": "0", "Cache-Control": "no-store"])
            return
        }
        var headers = ["Content-Type": SchemeHandler.mime(path), "Cache-Control": "no-store",
                       "Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*"]
        var start = 0, count = size, status = 200
        if let requested = task.request.value(forHTTPHeaderField: "Range") {
            guard let range = SchemeHandler.parseRange(requested, size) else {
                headers["Content-Range"] = "bytes */\(size)"
                headers["Content-Length"] = "0"
                localResponse(task, url, 416, headers)
                return
            }
            start = range.lowerBound
            count = range.count
            status = 206
            headers["Content-Range"] = "bytes \(start)-\(range.upperBound)/\(size)"
        }
        headers["Content-Length"] = String(count)
        if task.request.httpMethod == "HEAD" || count == 0 {
            localResponse(task, url, status, headers)
            return
        }
        guard let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers),
              let file = FileHandle(forReadingAtPath: path) else {
            task.didFailWithError(URLError(.cannotOpenFile))
            return
        }
        do { try file.seek(toOffset: UInt64(start)) }
        catch {
            try? file.close()
            task.didFailWithError(error)
            return
        }
        let key = ObjectIdentifier(task as AnyObject)
        let read = LocalRead(file, count: count)
        localReads[key] = read
        task.didReceive(response)
        readLocalChunk(task, key: key, read: read)
    }

    private func localResponse(_ task: WKURLSchemeTask, _ url: URL, _ status: Int, _ headers: [String: String]) {
        guard let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) else {
            task.didFailWithError(URLError(.cannotParseResponse))
            return
        }
        task.didReceive(response)
        task.didFinish()
    }

    private func readLocalChunk(_ task: WKURLSchemeTask, key: ObjectIdentifier, read: LocalRead) {
        guard localReads[key] === read else { return }
        let count = min(read.remaining, 256 * 1024)
        diskQueue.async {
            let part = try? read.handle.read(upToCount: count)
            DispatchQueue.main.async {
                // A seek, Back, or an episode change can cancel a pending read.
                guard self.localReads[key] === read else { return }
                guard let data = part, !data.isEmpty else {
                    self.localReads.removeValue(forKey: key)
                    task.didFailWithError(URLError(.cannotDecodeRawData))
                    return
                }
                read.remaining -= data.count
                task.didReceive(data)
                if read.remaining > 0 {
                    self.readLocalChunk(task, key: key, read: read)
                } else if self.localReads.removeValue(forKey: key) === read {
                    task.didFinish()
                }
            }
        }
    }

    static func parseRange(_ header: String, _ size: Int) -> ClosedRange<Int>? {
        let h = header.trimmingCharacters(in: .whitespacesAndNewlines)
        guard size > 0, h.lowercased().hasPrefix("bytes=") else { return nil }
        let parts = h.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        if parts[0].isEmpty {
            guard let suffix = Int(parts[1]), suffix > 0 else { return nil }
            return max(0, size - suffix)...(size - 1)
        }
        guard let start = Int(parts[0]), start >= 0, start < size else { return nil }
        if parts[1].isEmpty { return start...(size - 1) }
        guard let end = Int(parts[1]), end >= start else { return nil }
        return start...min(end, size - 1)
    }

    static func mime(_ p: String) -> String {
        switch (p as NSString).pathExtension.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js": return "application/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json"
        case "mp4", "m4v": return "video/mp4"
        case "mov": return "video/quicktime"
        case "avi": return "video/x-msvideo"
        case "mkv": return "video/x-matroska"
        case "webm": return "video/webm"
        case "m4s": return "video/iso.segment"
        case "m3u8": return "application/vnd.apple.mpegurl"
        case "ts": return "video/mp2t"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "svg": return "image/svg+xml"
        default: return "application/octet-stream"
        }
    }

    // ---- the page's requests to other servers ----
    private func proxy(_ task: WKURLSchemeTask, _ url: URL) {
        guard let comps = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let target = comps.queryItems?.first(where: { $0.name == "u" })?.value,
              let turl = Net.makeURL(target) else {
            task.didFailWithError(URLError(.badURL))
            return
        }
        if task.request.httpMethod == "OPTIONS" {
            let headers = ["Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "*",
                           "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS", "Content-Length": "0"]
            if let r = HTTPURLResponse(url: url, statusCode: 204, httpVersion: "HTTP/1.1", headerFields: headers) {
                task.didReceive(r)
                task.didFinish()
            }
            return
        }
        var req = URLRequest(url: turl)
        req.httpMethod = task.request.httpMethod ?? "GET"
        for (k, v) in task.request.allHTTPHeaderFields ?? [:] {
            let l = k.lowercased()
            if l == "origin" || l == "referer" || l == "host" || l == "accept-encoding" { continue }
            req.setValue(v, forHTTPHeaderField: k)
        }
        // the page asks to be introduced as a set-top box (many IPTV servers only answer those)
        if let ua = comps.queryItems?.first(where: { $0.name == "ua" })?.value, !ua.isEmpty {
            req.setValue(ua, forHTTPHeaderField: "User-Agent")
        }
        let t = session.dataTask(with: req)
        byTask[t.taskIdentifier] = task
        byScheme[ObjectIdentifier(task as AnyObject)] = t
        if let sid = comps.queryItems?.first(where: { $0.name == "sid" })?.value, !sid.isEmpty {
            let f = Flow(sid: sid)
            f.task = t
            flows[t.taskIdentifier] = f
            flowBySid[sid] = t.taskIdentifier
        }
        t.resume()
    }

    private func dropFlow(_ taskId: Int) {
        if let f = flows.removeValue(forKey: taskId) { flowBySid.removeValue(forKey: f.sid) }
    }

    /// The page says how many bytes of a download it has read so far.
    private func ack(_ task: WKURLSchemeTask, _ url: URL) {
        let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let sid = items.first(where: { $0.name == "s" })?.value ?? ""
        let n = Int(items.first(where: { $0.name == "n" })?.value ?? "") ?? 0
        if let tid = flowBySid[sid], let f = flows[tid] {
            if n > f.acked { f.acked = n }
            if f.suspended && f.sent - f.acked < flowLow {
                f.suspended = false
                f.task?.resume()
            }
        }
        let headers = ["Access-Control-Allow-Origin": "*", "Cache-Control": "no-store", "Content-Length": "0"]
        if let r = HTTPURLResponse(url: url, statusCode: 204, httpVersion: "HTTP/1.1", headerFields: headers) {
            task.didReceive(r)
            task.didFinish()
        } else {
            task.didFailWithError(URLError(.badURL))
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let task = byTask[dataTask.taskIdentifier], let url = task.request.url else {
            completionHandler(.cancel)
            return
        }
        var status = 200
        var headers: [String: String] = [:]
        if let h = response as? HTTPURLResponse {
            status = h.statusCode
            for (k, v) in h.allHeaderFields { headers[(k.base as? String) ?? "\(k)"] = "\(v)" }
        }
        // URLSession already unpacked a compressed body: its length no longer matches
        if headers.keys.contains(where: { $0.lowercased() == "content-encoding" }) {
            headers = headers.filter { $0.key.lowercased() != "content-encoding" && $0.key.lowercased() != "content-length" }
        }
        headers = headers.filter { !$0.key.lowercased().hasPrefix("access-control-") && $0.key.lowercased() != "set-cookie" }
        headers["Access-Control-Allow-Origin"] = "*"
        headers["Access-Control-Expose-Headers"] = "*"
        headers["Cache-Control"] = "no-store"
        // where the server really answered from (after redirects): hls.js resolves the playlist's pieces against it
        if let fu = response.url?.absoluteString { headers["X-Sahra-URL"] = fu }
        guard let r = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) else {
            completionHandler(.cancel)
            return
        }
        task.didReceive(r)
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        let tid = dataTask.taskIdentifier
        byTask[tid]?.didReceive(data)
        if let f = flows[tid] {
            f.sent += data.count
            if !f.suspended && f.sent - f.acked > flowHigh {
                f.suspended = true
                dataTask.suspend()
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        dropFlow(task.taskIdentifier)
        guard let st = byTask.removeValue(forKey: task.taskIdentifier) else { return }
        byScheme.removeValue(forKey: ObjectIdentifier(st as AnyObject))
        if let e = error { st.didFailWithError(e) } else { st.didFinish() }
    }

    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        if challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
           let trust = challenge.protectionSpace.serverTrust {
            completionHandler(.useCredential, URLCredential(trust: trust))
        } else {
            completionHandler(.performDefaultHandling, nil)
        }
    }
}

/// «مشغّل النظام»: Apple's own player (MP4 / HLS, picture-in-picture, AirPlay).
enum NativePlayer {
    static func present(_ s: String, from host: UIViewController?) {
        guard let host = host, let url = Net.makeURL(s) else { return }
        let item = AVPlayerItem(url: url)
        // a longer buffer ahead (30 s) and waiting it out instead of stuttering on slow IPTV servers
        item.preferredForwardBufferDuration = 30
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = true
        player.allowsExternalPlayback = true
        let vc = AVPlayerViewController()
        vc.player = player
        vc.allowsPictureInPicturePlayback = true
        vc.canStartPictureInPictureAutomaticallyFromInline = true
        vc.updatesNowPlayingInfoCenter = true
        var top: UIViewController = host
        while let p = top.presentedViewController { top = p }
        top.present(vc, animated: true) { player.play() }
    }
}
