import UIKit
import AVFoundation

// سهرة MAC — the app runs the same script that runs in Scriptable, inside its own small runtime
// (JavaScriptCore + WKWebView), so the interface, the portal client and the players are identical.
@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        // sound keeps going with the screen locked or in picture-in-picture; with «التشغيل مع التطبيقات الأخرى»
        // (on by default) a clip in YouTube / TikTok plays together with ours instead of stopping it
        MPVGuard.atLaunch()
        AudioMix.apply()
        NotificationCenter.default.addObserver(self, selector: #selector(audioInterrupted(_:)),
                                               name: AVAudioSession.interruptionNotification, object: nil)

        let host = HostViewController()
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = .black
        w.rootViewController = host
        w.makeKeyAndVisible()
        window = w
        return true
    }

    /// iOS wakes the app when a download that went on in the background has finished
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        Downloader.shared.bgCompletion = completionHandler
    }

    /// Back from the background: the local server's socket may have been taken while the app slept.
    func applicationWillEnterForeground(_ application: UIApplication) {
        _ = LocalServer.shared.ensure()
        MPVGuard.resume()
    }

    /// What of each film is on the phone is written down before the app sleeps.
    func applicationDidEnterBackground(_ application: UIApplication) {
        StreamCache.shared.saveAll()
        MPVGuard.suspend()
    }

    /// the web pages' players may change the sound settings: ours are put back
    func applicationDidBecomeActive(_ application: UIApplication) {
        AudioMix.apply()
    }

    /// a call (or an app that does not share the sound) took it: the players pause, and go on when it comes back
    @objc private func audioInterrupted(_ n: Notification) {
        guard let raw = n.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        DispatchQueue.main.async {
            if type == .began {
                NotificationCenter.default.post(name: .sahraAudioBegan, object: nil)
                return
            }
            let opts = (n.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt).map { AVAudioSession.InterruptionOptions(rawValue: $0) } ?? []
            AudioMix.apply()
            if opts.contains(.shouldResume) || AudioMix.on {
                NotificationCenter.default.post(name: .sahraAudioEnded, object: nil)
                Runtime.shared.web.resumeAfterInterruption()
            }
        }
    }

    /// The system is short of memory: the page frees the video it has already shown, so it is not the one closed.
    func applicationDidReceiveMemoryWarning(_ application: UIApplication) {
        Runtime.shared.web.memoryWarning()
    }
}
