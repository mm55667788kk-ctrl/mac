import UIKit
import AVFoundation

// «السهرة ماك» 3.27: what every player shares — the sound alongside other apps, subtitles that arrive while a film
// plays, mpv's crash guard, and the 🔒 lock + «تخطي المقدمة» over players whose controls are not ours.

// MARK: - the sound alongside other apps

/// «التشغيل مع التطبيقات الأخرى»: with it on, a clip started in YouTube, TikTok… plays together with ours instead of
/// stopping it (the cost: no buttons on the lock screen, iOS keeps those for the app that plays alone).
enum AudioMix {
    static let key = "sahra.audio.mix"

    static var on: Bool { (UserDefaults.standard.object(forKey: key) as? Bool) ?? true }

    static func apply() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .moviePlayback, options: on ? [.mixWithOthers] : [])
        try? s.setActive(true)
    }

    static func set(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: key)
        apply()
    }
}

/// a phone call or another app took the sound for a moment: the players go on when it gives it back
extension Notification.Name {
    static let sahraAudioBegan = Notification.Name("sahra.audio.began")
    static let sahraAudioEnded = Notification.Name("sahra.audio.ended")
}

// MARK: - subtitles that arrive while the film plays

/// A player that can take subtitles at any moment (the Arabic ones found on the internet, or translated).
protocol LiveSubtitleTarget: AnyObject {
    func loadLiveSubtitles(_ srt: String, label: String)
}

enum LiveSubs {
    /// the player on screen now
    static weak var target: LiveSubtitleTarget?
    private static var seq = 0

    static func push(_ srt: String, label: String) {
        guard !srt.isEmpty else { return }
        target?.loadLiveSubtitles(srt, label: label)
    }

    /// a new file each time (VLC and mpv open a file; the same name could be the old one still cached)
    static func file(_ srt: String) -> URL? {
        seq += 1
        let f = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("sahra-live-\(seq).srt")
        return (try? srt.write(to: f, atomically: true, encoding: .utf8)) != nil ? f : nil
    }
}

// MARK: - mpv's crash guard

/// If the app closes while mpv plays (a crash), the next launch knows it: mpv is put aside for this build and the app
/// goes on with VLC / the other engines instead of closing again. A new build tries mpv again.
enum MPVGuard {
    private static let runningKey = "sahra.mpv.running"
    private static let brokenKey = "sahra.mpv.broken"
    private static let noteKey = "sahra.mpv.note"
    private static var active = 0

    static var build: String { (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "?" }

    /// mpv crashed the app in this build
    static var broken: Bool { UserDefaults.standard.string(forKey: brokenKey) == build }

    /// at launch: a mark left behind means the app died while mpv was playing
    static func atLaunch() {
        let d = UserDefaults.standard
        if d.bool(forKey: runningKey) {
            d.set(build, forKey: brokenKey)
            d.set("mpv أغلق التطبيق في المرة السابقة — أوقفناه في هذه النسخة وصار التشغيل بـ VLC والمحركات الأخرى", forKey: noteKey)
        }
        d.set(false, forKey: runningKey)
    }

    /// a message for the interface, once
    static func takeNote() -> String {
        let d = UserDefaults.standard
        let n = d.string(forKey: noteKey) ?? ""
        if !n.isEmpty { d.removeObject(forKey: noteKey) }
        return n
    }

    static func begin() {
        active += 1
        mark(true)
    }

    static func end() {
        active = max(0, active - 1)
        if active == 0 { mark(false) }
    }

    /// the app sleeps: iOS may close it then, that is not a crash
    static func suspend() { if active > 0 { mark(false) } }
    static func resume() { if active > 0 { mark(true) } }

    private static func mark(_ on: Bool) {
        UserDefaults.standard.set(on, forKey: runningKey)
        UserDefaults.standard.synchronize()
    }
}

// MARK: - 🔒 lock + «تخطي المقدمة» / «الحلقة التالية» over AVPlayer and KSPlayer

/// The same lock and pills as our own player, laid over a player that draws its own controls.
/// A tap anywhere shows the lock button for a moment; locked, a clear sheet takes every touch until «فتح القفل».
final class PlayerExtras: NSObject, UIGestureRecognizerDelegate {
    var jump: ((Double) -> Void)?
    var next: (() -> Void)?
    /// 3.29: the player's second right now (for landing exactly on the intro's end)
    var position: (() -> Double)?
    /// the player's controller: while locked it allows only the side the screen is on now
    weak var owner: UIViewController?
    private(set) var hold: UIInterfaceOrientationMask?
    private let o: EngineOpts
    private weak var host: UIView?
    private let lockButton = UIButton(type: .system)
    private let unlockButton = UIButton(type: .system)
    private let blocker = UIView()
    private let actionButton = UIButton(type: .system)
    private(set) var locked = false
    private var lockUntil = Date.distantPast
    private var unlockUntil = Date.distantPast
    private var actionKind = ""
    private var nextHidden = false
    private var controlsAt = Date()
    // 3.29: the real intro (and recap, and end credits)
    private let intro: IntroLogic
    private var lastPos = 0.0
    private var flashUntil = Date.distantPast
    private var flashText = ""

    init(_ o: EngineOpts) {
        self.o = o
        self.intro = IntroLogic(o)
        super.init()
        intro.onLearn = { [weak self] _ in
            self?.flashText = "✓ حفظنا نهاية المقدمة للحلقات الجاية"
            self?.flashUntil = Date().addingTimeInterval(3)
        }
    }

    func attach(to v: UIView, actionBottom: CGFloat = 96) {
        host = v
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapped))
        tap.cancelsTouchesInView = false
        tap.delegate = self
        v.addGestureRecognizer(tap)

        blocker.backgroundColor = UIColor(white: 0, alpha: 0.001)
        blocker.isHidden = true
        blocker.translatesAutoresizingMaskIntoConstraints = false
        blocker.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(blockerTap)))
        v.addSubview(blocker)

        lockButton.setImage(UIImage(systemName: "lock.open.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 18, weight: .bold)), for: .normal)
        lockButton.tintColor = .white
        lockButton.backgroundColor = UIColor(white: 0, alpha: 0.5)
        lockButton.layer.cornerRadius = 22
        lockButton.alpha = 0
        lockButton.addTarget(self, action: #selector(lockTap), for: .touchUpInside)
        lockButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(lockButton)

        unlockButton.setImage(UIImage(systemName: "lock.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 20, weight: .bold)), for: .normal)
        unlockButton.setTitle("  اضغط لفتح القفل", for: .normal)
        unlockButton.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        unlockButton.tintColor = .white
        unlockButton.backgroundColor = UIColor(white: 0, alpha: 0.65)
        unlockButton.layer.cornerRadius = 24
        unlockButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 18, bottom: 0, right: 18)
        unlockButton.alpha = 0
        unlockButton.isHidden = true
        unlockButton.addTarget(self, action: #selector(unlockTap), for: .touchUpInside)
        unlockButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(unlockButton)

        actionButton.setTitleColor(.black, for: .normal)
        actionButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .heavy)
        actionButton.backgroundColor = UIColor(white: 1, alpha: 0.95)
        actionButton.layer.cornerRadius = 10
        actionButton.layer.shadowColor = UIColor.black.cgColor
        actionButton.layer.shadowOpacity = 0.45
        actionButton.layer.shadowRadius = 8
        actionButton.layer.shadowOffset = CGSize(width: 0, height: 3)
        actionButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        actionButton.alpha = 0
        actionButton.addTarget(self, action: #selector(actionTap), for: .touchUpInside)
        actionButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(actionButton)

        let g = v.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            blocker.topAnchor.constraint(equalTo: v.topAnchor),
            blocker.bottomAnchor.constraint(equalTo: v.bottomAnchor),
            blocker.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            blocker.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            lockButton.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 14),
            lockButton.centerYAnchor.constraint(equalTo: v.centerYAnchor),
            lockButton.widthAnchor.constraint(equalToConstant: 44),
            lockButton.heightAnchor.constraint(equalToConstant: 44),
            unlockButton.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            unlockButton.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -40),
            unlockButton.heightAnchor.constraint(equalToConstant: 48),
            actionButton.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            actionButton.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -actionBottom),
            actionButton.heightAnchor.constraint(equalToConstant: 42)
        ])
        showLock()
    }

    func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }

    /// our buttons stay above the player's own views (it may add its controls after us)
    func front() {
        guard let v = host else { return }
        v.bringSubviewToFront(actionButton)
        v.bringSubviewToFront(blocker)
        v.bringSubviewToFront(lockButton)
        v.bringSubviewToFront(unlockButton)
    }

    @objc private func tapped() {
        if locked { return }
        controlsAt = Date()
        showLock()
    }

    private func showLock() {
        lockUntil = Date().addingTimeInterval(3.5)
        front()
        UIView.animate(withDuration: 0.2) { self.lockButton.alpha = 1 }
    }

    @objc private func lockTap() {
        locked = true
        hold = Orientation.current(host)
        if let vc = owner { Orientation.refresh(vc) }
        blocker.isHidden = false
        setAction("", "")
        UIView.animate(withDuration: 0.2) { self.lockButton.alpha = 0 }
        flashUnlock()
    }

    @objc private func blockerTap() { flashUnlock() }

    private func flashUnlock() {
        unlockButton.isHidden = false
        front()
        UIView.animate(withDuration: 0.2) { self.unlockButton.alpha = 1 }
        unlockUntil = Date().addingTimeInterval(2.5)
    }

    @objc private func unlockTap() {
        locked = false
        hold = nil
        if let vc = owner { Orientation.refresh(vc) }
        blocker.isHidden = true
        unlockButton.alpha = 0
        unlockButton.isHidden = true
        showLock()
    }

    private func setAction(_ kind: String, _ text: String) {
        if kind.isEmpty {
            if !actionKind.isEmpty {
                actionKind = ""
                UIView.animate(withDuration: 0.2) { self.actionButton.alpha = 0 }
            }
            return
        }
        if actionButton.title(for: .normal) != text {
            UIView.performWithoutAnimation {
                self.actionButton.setTitle(text, for: .normal)
                self.actionButton.layoutIfNeeded()
            }
        }
        if actionKind != kind {
            actionKind = kind
            front()
            UIView.animate(withDuration: 0.2) { self.actionButton.alpha = 1 }
        }
    }

    @objc private func actionTap() {
        let k = actionKind
        if k == "next" {
            setAction("", "")
            nextHidden = true
            next?()
            return
        }
        if k.isEmpty || k == "flash" { return }
        setAction("", "")
        let t = position?() ?? lastPos
        if let to = intro.tap(k, t: t) { jump?(to - t) }
    }

    /// once a second: the pill, and the buttons fading away
    func tick(pos t: Double, dur len: Double, started: Bool) {
        let now = Date()
        if !locked && lockButton.alpha > 0.5 && now > lockUntil {
            UIView.animate(withDuration: 0.3) { self.lockButton.alpha = 0 }
        }
        if locked && unlockButton.alpha > 0.5 && now > unlockUntil {
            UIView.animate(withDuration: 0.3, animations: { self.unlockButton.alpha = 0 }, completion: { _ in
                if self.unlockButton.alpha < 0.05 { self.unlockButton.isHidden = true }
            })
        }
        guard !o.live, !locked, started, t > 0 else { setAction("", ""); return }
        lastPos = t
        if now < flashUntil {
            setAction("flash", flashText)
            return
        }
        let p = intro.pill(t: t, len: len, hasNext: o.hasNext && !nextHidden, autoNext: true, controls: now.timeIntervalSince(controlsAt) < 4)
        setAction(p.0, p.1)
    }
}

// MARK: - 3.28: full screen of the web player, and the 🔒 lock holding the screen's turn

/// The web player has no screen of its own: its «تكبير» fills the app's page and turns the phone sideways (like
/// YouTube), so the lock, «تخطي المقدمة» and the subtitles stay (iOS's own full screen has none of them).
/// While a player is locked the screen also stops turning (a phone on a bed or in a hand that tilts).
enum Orientation {
    static let prefix = "sahra-orient:"

    /// the side the screen is on now, as the only one allowed
    static func current(_ v: UIView?) -> UIInterfaceOrientationMask {
        switch v?.window?.windowScene?.interfaceOrientation ?? .portrait {
        case .landscapeLeft: return .landscapeLeft
        case .landscapeRight: return .landscapeRight
        case .portraitUpsideDown: return .portraitUpsideDown
        default: return .portrait
        }
    }

    /// the controller's allowed sides changed (locked / unlocked)
    static func refresh(_ vc: UIViewController) {
        if #available(iOS 16.0, *) { vc.setNeedsUpdateOfSupportedInterfaceOrientations() }
        else { UIViewController.attemptRotationToDeviceOrientation() }
    }

    /// turns the screen (phones only: an iPad is held however its owner likes)
    static func turn(_ mask: UIInterfaceOrientationMask, host: UIViewController) {
        guard UIDevice.current.userInterfaceIdiom == .phone else { return }
        if #available(iOS 16.0, *) {
            guard let scene = host.view.window?.windowScene else { return }
            host.setNeedsUpdateOfSupportedInterfaceOrientations()
            scene.requestGeometryUpdate(.iOS(interfaceOrientations: mask)) { _ in }
        } else {
            let o: UIInterfaceOrientation = mask == .portrait ? .portrait : .landscapeRight
            UIDevice.current.setValue(o.rawValue, forKey: "orientation")
            UIViewController.attemptRotationToDeviceOrientation()
        }
    }

    /// from the page: "fs1,landscape" · "hold" · "free,fs0,portrait" …
    static func web(_ text: String) {
        DispatchQueue.main.async {
            guard let host = Runtime.shared.host else { return }
            for cmd in text.split(separator: ",") {
                switch cmd {
                case "fs1": host.immersive = true
                case "fs0": host.immersive = false
                case "hold": host.holdMask = current(host.view); refresh(host)
                case "free": host.holdMask = nil; refresh(host)
                // not while one of the players with a screen of its own is up (it turns by itself)
                case "landscape": if host.holdMask == nil && host.presentedViewController == nil { turn(.landscape, host: host) }
                case "portrait": if host.holdMask == nil && host.presentedViewController == nil { turn(.portrait, host: host) }
                default: break
                }
            }
        }
    }
}

// MARK: - 3.29: «تخطي المقدمة» الحقيقي

/// Where the intro (and the recap, and the end credits) really are: the file's chapters, the end the viewer showed
/// for this series, or TheIntroDB (timestamps per episode). A series whose intro isn't known yet: the pill guesses,
/// then asks «هنا تنتهي المقدمة؟» once — and when the viewer jumps over the intro by themselves (dragging, double
/// taps), where they land is kept. Every next episode then skips to that exact second (the app keeps it: `learned`).
final class IntroLogic {
    private(set) var s = -1.0, e = -1.0, rs = -1.0, re = -1.0, cs = -1.0
    private(set) var src = ""
    let learnable: Bool
    private var skipped = false, recapSkipped = false
    private var seen: Date?
    private var guessUntil = Date.distantPast
    private var lastT = -1.0, lastAt = Date.distantPast, steady = 0
    private var quietUntil = Date().addingTimeInterval(5)
    private var sessFrom = -1.0, sessTo = -1.0, sessAt = Date.distantPast
    private var fixUntil = Date.distantPast, fixS = 0.0, fixing = false
    /// a new end was kept (the player tells the viewer)
    var onLearn: ((Double) -> Void)?

    /// the end the viewer showed in this player — the app keeps it when the player closes
    static var learned: (s: Double, e: Double)?
    /// the player on screen: what the app finds after it opened reaches it here
    static weak var current: IntroLogic?

    init(_ o: EngineOpts) {
        learnable = o.ilearn
        apply(o.intro)
        IntroLogic.current = self
    }

    var known: Bool { e > 0 }
    var end: Double { e }

    private static let rank: [String: Int] = ["ch": 3, "me": 2, "db": 1]

    func apply(_ d: [String: Any]?, src forced: String? = nil) {
        guard let d = d else { return }
        func num(_ k: String) -> Double {
            if let v = d[k] as? Double { return v }
            if let n = d[k] as? NSNumber { return n.doubleValue }
            return -1
        }
        let sr = forced ?? (d["src"] as? String) ?? "db"
        let ns = num("s"), ne = num("e")
        if ne > 0 && ne > ns && (IntroLogic.rank[sr] ?? 0) >= (IntroLogic.rank[src] ?? 0) {
            s = max(0, ns)
            e = ne
            src = sr
        }
        if num("re") > 0 && (sr == "ch" || re <= 0) {
            rs = max(0, num("rs"))
            re = num("re")
        }
        if num("cs") > 0 && (sr == "ch" || cs <= 0) { cs = num("cs") }
    }

    private static let chIntro = #"^(intro(duction)?|opening( credits| theme| song| titles?)?|op\s*\d*|main titles?|title sequence|مقدمة|المقدمة|شارة( البداية)?|الشارة|تتر( البداية)?|générique( de début)?)$"#
    private static let chRecap = #"^(recap|previously( on.*)?|ملخص.*|سابقا.*|سابقاً.*)$"#
    private static let chCredits = #"^(credits|end(ing)?( credits| theme| song)?|ed\s*\d*|outro|closing credits|النهاية|شارة النهاية|تتر النهاية|générique de fin)$"#
    private static func match(_ text: String, _ pattern: String) -> Bool {
        text.range(of: pattern, options: [.regularExpression, .caseInsensitive]) != nil
    }

    /// the file's chapters (start, title): «Intro / Opening / مقدمة», «Recap / ملخص», «Credits / النهاية»
    func applyChapters(_ list: [(t: Double, name: String)]) {
        guard !list.isEmpty else { return }
        var d: [String: Any] = [:]
        for (i, c) in list.enumerated() {
            let n = c.name.trimmingCharacters(in: .whitespacesAndNewlines)
            let next = i + 1 < list.count ? list[i + 1].t : -1
            if d["e"] == nil && next > c.t && c.t < 1200 && IntroLogic.match(n, IntroLogic.chIntro) {
                d["s"] = c.t
                d["e"] = next
            } else if d["re"] == nil && next > c.t && c.t < 900 && IntroLogic.match(n, IntroLogic.chRecap) {
                d["rs"] = c.t
                d["re"] = next
            } else if d["cs"] == nil && c.t > 300 && IntroLogic.match(n, IntroLogic.chCredits) {
                d["cs"] = c.t
            }
        }
        if !d.isEmpty { apply(d, src: "ch") }
    }

    /// our own seeks (the pill, a resume, a reopen) are not the viewer's
    func ownSeek() {
        quietUntil = Date().addingTimeInterval(2.5)
        lastT = -1
        steady = 0
        sessFrom = -1
    }

    /// what the pill shows at second t: (key, text) — key "" = no pill
    func pill(t: Double, len: Double, hasNext: Bool, autoNext: Bool, controls: Bool) -> (String, String) {
        observe(t)
        let now = Date()
        guard len > 120 else { return ("", "") }
        let left = len - t
        if hasNext && left > 0.5 && (left <= 30 || (cs > 0 && t >= cs && cs < len - 5)) {
            return ("next", left <= 30 && autoNext ? "الحلقة التالية خلال \(Int(left.rounded(.up)))  ▶" : "الحلقة التالية  ▶")
        }
        if now < guessUntil { return ("save", "✓ هنا تنتهي المقدمة؟ احفظ") }
        if re > 0 && !recapSkipped && t >= rs - 0.5 && t < re - 2 { return ("recap", "تخطي الملخص  ⏭") }
        if e > 0 {
            // known: the pill for the whole intro, and it lands on its exact end
            if !skipped && t >= max(0, s - 1) && t < e - 2 { return ("intro", "تخطي المقدمة  ⏭") }
            return ("", "")
        }
        // a series whose intro isn't known yet: its first minutes (30 s alone, then with the controls)
        if learnable && !skipped && t < 300 && len > 600 {
            if seen == nil { seen = now }
            if now.timeIntervalSince(seen ?? now) < 30 || controls { return ("intro", "تخطي المقدمة  ⏭") }
        }
        return ("", "")
    }

    /// the pill was tapped at second t: where to go (nil = stay)
    func tap(_ key: String, t: Double) -> Double? {
        switch key {
        case "recap":
            recapSkipped = true
            ownSeek()
            return re
        case "intro":
            skipped = true
            ownSeek()
            if e > 0 {
                fixS = s
                fixUntil = src == "me" ? Date().addingTimeInterval(25) : .distantPast
                return e
            }
            // the first time in this series: a guess, then «هنا تنتهي المقدمة؟» (fix it by dragging, then save)
            fixS = t < 8 ? 0 : t
            guessUntil = Date().addingTimeInterval(12)
            fixUntil = Date().addingTimeInterval(25)
            return t + 85
        case "save":
            learn(fixS, t)
            return nil
        default:
            return nil
        }
    }

    /// «تخطي المقدمة» from the menu (known intros only)
    func skipNow() -> Double? {
        guard e > 0 else { return nil }
        skipped = true
        ownSeek()
        return e
    }

    /// «هنا تنتهي المقدمة» from the menu
    func markEnd(_ t: Double) { learn(s >= 0 && s < t - 10 ? s : 0, t) }

    private func learn(_ a0: Double, _ b0: Double) {
        let a = max(0, a0.rounded()), b = b0.rounded()
        guard b > a + 10, b <= 1800 else { return }
        s = a
        e = b
        src = "me"
        skipped = true
        fixUntil = .distantPast
        fixing = false
        guessUntil = .distantPast
        IntroLogic.learned = (a, b)
        onLearn?(b)
    }

    /// where the viewer jumps in the first minutes = the intro's end; after we skipped: their correction
    private func observe(_ t: Double) {
        let now = Date(), last = lastT, dt = now.timeIntervalSince(lastAt)
        lastT = t
        lastAt = now
        guard learnable, src.isEmpty || src == "me", last >= 0, now > quietUntil, dt < 3 else {
            finalize(now)
            return
        }
        let d = t - last
        if d > 6 || d < -6 {
            if now < fixUntil {
                fixing = true
                sessTo = t
                sessAt = now
            } else if d > 6 {
                if sessFrom < 0 && last < 600 && steady >= 2 { sessFrom = last }
                if sessFrom >= 0 {
                    sessTo = t
                    sessAt = now
                }
            } else {
                sessFrom = -1   // went back: not an intro skip
            }
            steady = 0
        } else if d > 0.05 {
            steady += 1
        }
        finalize(now)
    }

    private func finalize(_ now: Date) {
        if fixing && now.timeIntervalSince(sessAt) > 8 {
            fixing = false
            fixUntil = .distantPast
            if sessTo > fixS + 10 && sessTo < 900 { learn(fixS, sessTo) }
            return
        }
        if sessFrom >= 0 && !fixing && now.timeIntervalSince(sessAt) > 10 {
            let a = sessFrom, b = sessTo
            sessFrom = -1
            if b - a >= 20 && b - a <= 400 && b < 900 { learn(a < 8 ? 0 : a, b) }
        }
    }
}

/// what the app finds once the player is already up (TheIntroDB answers after the start)
enum LiveIntro {
    static func push(_ json: String) {
        guard let data = json.data(using: .utf8),
              let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any] else { return }
        DispatchQueue.main.async { IntroLogic.current?.apply(d) }
    }
}
