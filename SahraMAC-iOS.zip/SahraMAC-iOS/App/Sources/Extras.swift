import UIKit
import AVFoundation

// «السهرة ماك» 3.27: what every player shares — the sound alongside other apps, subtitles that arrive while a film
// plays, mpv's crash guard, and the 🔒 lock + «تخطي المقدمة» over players whose controls are not ours.

// MARK: - the sound alongside other apps

/// «التشغيل مع التطبيقات الأخرى»: with it on, a clip started in YouTube, TikTok… plays together with ours instead of
/// stopping it (the cost: no buttons on the lock screen, iOS keeps those for the app that plays alone).
enum AudioMix {
    static let key = "sahra.audio.mix"

    static var on: Bool { (UserDefaults.standard.object(forKey: key) as? Bool) ?? true }

    static func apply() {
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .moviePlayback, options: on ? [.mixWithOthers] : [])
        try? s.setActive(true)
    }

    static func set(_ value: Bool) {
        UserDefaults.standard.set(value, forKey: key)
        apply()
    }
}

/// a phone call or another app took the sound for a moment: the players go on when it gives it back
extension Notification.Name {
    static let sahraAudioBegan = Notification.Name("sahra.audio.began")
    static let sahraAudioEnded = Notification.Name("sahra.audio.ended")
}

// MARK: - subtitles that arrive while the film plays

/// A player that can take subtitles at any moment (the Arabic ones found on the internet, or translated).
protocol LiveSubtitleTarget: AnyObject {
    func loadLiveSubtitles(_ srt: String, label: String)
}

enum LiveSubs {
    /// the player on screen now
    static weak var target: LiveSubtitleTarget?
    private static var seq = 0

    static func push(_ srt: String, label: String) {
        guard !srt.isEmpty else { return }
        target?.loadLiveSubtitles(srt, label: label)
    }

    /// a new file each time (VLC and mpv open a file; the same name could be the old one still cached)
    static func file(_ srt: String) -> URL? {
        seq += 1
        let f = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("sahra-live-\(seq).srt")
        return (try? srt.write(to: f, atomically: true, encoding: .utf8)) != nil ? f : nil
    }
}

// MARK: - mpv's crash guard

/// If the app closes while mpv plays (a crash), the next launch knows it: mpv is put aside for this build and the app
/// goes on with VLC / the other engines instead of closing again. A new build tries mpv again.
enum MPVGuard {
    private static let runningKey = "sahra.mpv.running"
    private static let brokenKey = "sahra.mpv.broken"
    private static let noteKey = "sahra.mpv.note"
    private static var active = 0

    static var build: String { (Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String) ?? "?" }

    /// mpv crashed the app in this build
    static var broken: Bool { UserDefaults.standard.string(forKey: brokenKey) == build }

    /// at launch: a mark left behind means the app died while mpv was playing
    static func atLaunch() {
        let d = UserDefaults.standard
        if d.bool(forKey: runningKey) {
            d.set(build, forKey: brokenKey)
            d.set("mpv أغلق التطبيق في المرة السابقة — أوقفناه في هذه النسخة وصار التشغيل بـ VLC والمحركات الأخرى", forKey: noteKey)
        }
        d.set(false, forKey: runningKey)
    }

    /// a message for the interface, once
    static func takeNote() -> String {
        let d = UserDefaults.standard
        let n = d.string(forKey: noteKey) ?? ""
        if !n.isEmpty { d.removeObject(forKey: noteKey) }
        return n
    }

    static func begin() {
        active += 1
        mark(true)
    }

    static func end() {
        active = max(0, active - 1)
        if active == 0 { mark(false) }
    }

    /// the app sleeps: iOS may close it then, that is not a crash
    static func suspend() { if active > 0 { mark(false) } }
    static func resume() { if active > 0 { mark(true) } }

    private static func mark(_ on: Bool) {
        UserDefaults.standard.set(on, forKey: runningKey)
        UserDefaults.standard.synchronize()
    }
}

// MARK: - 🔒 lock + «تخطي المقدمة» / «الحلقة التالية» over AVPlayer and KSPlayer

/// The same lock and pills as our own player, laid over a player that draws its own controls.
/// A tap anywhere shows the lock button for a moment; locked, a clear sheet takes every touch until «فتح القفل».
final class PlayerExtras: NSObject, UIGestureRecognizerDelegate {
    var jump: ((Double) -> Void)?
    var next: (() -> Void)?
    private let o: EngineOpts
    private weak var host: UIView?
    private let lockButton = UIButton(type: .system)
    private let unlockButton = UIButton(type: .system)
    private let blocker = UIView()
    private let actionButton = UIButton(type: .system)
    private(set) var locked = false
    private var lockUntil = Date.distantPast
    private var unlockUntil = Date.distantPast
    private var actionKind = ""
    private var introSkipped = false
    private var introSeen: Date?
    private var nextHidden = false
    private var controlsAt = Date()

    init(_ o: EngineOpts) {
        self.o = o
        super.init()
    }

    func attach(to v: UIView, actionBottom: CGFloat = 96) {
        host = v
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapped))
        tap.cancelsTouchesInView = false
        tap.delegate = self
        v.addGestureRecognizer(tap)

        blocker.backgroundColor = UIColor(white: 0, alpha: 0.001)
        blocker.isHidden = true
        blocker.translatesAutoresizingMaskIntoConstraints = false
        blocker.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(blockerTap)))
        v.addSubview(blocker)

        lockButton.setImage(UIImage(systemName: "lock.open.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 18, weight: .bold)), for: .normal)
        lockButton.tintColor = .white
        lockButton.backgroundColor = UIColor(white: 0, alpha: 0.5)
        lockButton.layer.cornerRadius = 22
        lockButton.alpha = 0
        lockButton.addTarget(self, action: #selector(lockTap), for: .touchUpInside)
        lockButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(lockButton)

        unlockButton.setImage(UIImage(systemName: "lock.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 20, weight: .bold)), for: .normal)
        unlockButton.setTitle("  اضغط لفتح القفل", for: .normal)
        unlockButton.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .bold)
        unlockButton.tintColor = .white
        unlockButton.backgroundColor = UIColor(white: 0, alpha: 0.65)
        unlockButton.layer.cornerRadius = 24
        unlockButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 18, bottom: 0, right: 18)
        unlockButton.alpha = 0
        unlockButton.isHidden = true
        unlockButton.addTarget(self, action: #selector(unlockTap), for: .touchUpInside)
        unlockButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(unlockButton)

        actionButton.setTitleColor(.black, for: .normal)
        actionButton.titleLabel?.font = UIFont.systemFont(ofSize: 15, weight: .heavy)
        actionButton.backgroundColor = UIColor(white: 1, alpha: 0.95)
        actionButton.layer.cornerRadius = 10
        actionButton.layer.shadowColor = UIColor.black.cgColor
        actionButton.layer.shadowOpacity = 0.45
        actionButton.layer.shadowRadius = 8
        actionButton.layer.shadowOffset = CGSize(width: 0, height: 3)
        actionButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        actionButton.alpha = 0
        actionButton.addTarget(self, action: #selector(actionTap), for: .touchUpInside)
        actionButton.translatesAutoresizingMaskIntoConstraints = false
        v.addSubview(actionButton)

        let g = v.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            blocker.topAnchor.constraint(equalTo: v.topAnchor),
            blocker.bottomAnchor.constraint(equalTo: v.bottomAnchor),
            blocker.leadingAnchor.constraint(equalTo: v.leadingAnchor),
            blocker.trailingAnchor.constraint(equalTo: v.trailingAnchor),
            lockButton.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 14),
            lockButton.centerYAnchor.constraint(equalTo: v.centerYAnchor),
            lockButton.widthAnchor.constraint(equalToConstant: 44),
            lockButton.heightAnchor.constraint(equalToConstant: 44),
            unlockButton.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            unlockButton.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -40),
            unlockButton.heightAnchor.constraint(equalToConstant: 48),
            actionButton.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            actionButton.bottomAnchor.constraint(equalTo: g.bottomAnchor, constant: -actionBottom),
            actionButton.heightAnchor.constraint(equalToConstant: 42)
        ])
        showLock()
    }

    func gestureRecognizer(_ g: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool { true }

    /// our buttons stay above the player's own views (it may add its controls after us)
    func front() {
        guard let v = host else { return }
        v.bringSubviewToFront(actionButton)
        v.bringSubviewToFront(blocker)
        v.bringSubviewToFront(lockButton)
        v.bringSubviewToFront(unlockButton)
    }

    @objc private func tapped() {
        if locked { return }
        controlsAt = Date()
        showLock()
    }

    private func showLock() {
        lockUntil = Date().addingTimeInterval(3.5)
        front()
        UIView.animate(withDuration: 0.2) { self.lockButton.alpha = 1 }
    }

    @objc private func lockTap() {
        locked = true
        blocker.isHidden = false
        setAction("", "")
        UIView.animate(withDuration: 0.2) { self.lockButton.alpha = 0 }
        flashUnlock()
    }

    @objc private func blockerTap() { flashUnlock() }

    private func flashUnlock() {
        unlockButton.isHidden = false
        front()
        UIView.animate(withDuration: 0.2) { self.unlockButton.alpha = 1 }
        unlockUntil = Date().addingTimeInterval(2.5)
    }

    @objc private func unlockTap() {
        locked = false
        blocker.isHidden = true
        unlockButton.alpha = 0
        unlockButton.isHidden = true
        showLock()
    }

    private func setAction(_ kind: String, _ text: String) {
        if kind.isEmpty {
            if !actionKind.isEmpty {
                actionKind = ""
                UIView.animate(withDuration: 0.2) { self.actionButton.alpha = 0 }
            }
            return
        }
        if actionButton.title(for: .normal) != text {
            UIView.performWithoutAnimation {
                self.actionButton.setTitle(text, for: .normal)
                self.actionButton.layoutIfNeeded()
            }
        }
        if actionKind != kind {
            actionKind = kind
            front()
            UIView.animate(withDuration: 0.2) { self.actionButton.alpha = 1 }
        }
    }

    @objc private func actionTap() {
        if actionKind == "intro" {
            introSkipped = true
            setAction("", "")
            jump?(85)
        } else if actionKind == "next" {
            setAction("", "")
            nextHidden = true
            next?()
        }
    }

    /// once a second: the pill, and the buttons fading away
    func tick(pos t: Double, dur len: Double, started: Bool) {
        let now = Date()
        if !locked && lockButton.alpha > 0.5 && now > lockUntil {
            UIView.animate(withDuration: 0.3) { self.lockButton.alpha = 0 }
        }
        if locked && unlockButton.alpha > 0.5 && now > unlockUntil {
            UIView.animate(withDuration: 0.3, animations: { self.unlockButton.alpha = 0 }, completion: { _ in
                if self.unlockButton.alpha < 0.05 { self.unlockButton.isHidden = true }
            })
        }
        guard !o.live, !locked, started, len > 300, t > 0 else { setAction("", ""); return }
        if o.hasNext && !nextHidden && len - t <= 30 && len - t > 0.5 {
            setAction("next", "الحلقة التالية خلال \(Int((len - t).rounded(.up)))  ▶")
            return
        }
        if o.ep && !introSkipped && t >= 8 && t < 420 && t + 85 < len - 60 {
            if introSeen == nil { introSeen = now }
            if now.timeIntervalSince(introSeen ?? now) < 20 || now.timeIntervalSince(controlsAt) < 4 {
                setAction("intro", "تخطي المقدمة  ⏭")
                return
            }
        }
        setAction("", "")
    }
}
