import UIKit
import AVKit

/// The native engines this build carries. AVPlayer is always there; VLCKit, MPVKit and KSPlayer only
/// when build-ipa.sh could build them in (it says which at the end of the GitHub Actions log).
enum NativeEngines {
    static var available: [String] {
        var a: [String] = []
        #if SAHRA_KS
        a.append("ks")
        #endif
        #if SAHRA_MPV
        // 3.27: mpv that closed the app once in this build is put aside (VLC and the others carry on)
        if !MPVGuard.broken { a.append("mpv") }
        #endif
        #if SAHRA_VLC
        // VLCKit is linked weakly: the "lite" IPA leaves its framework out and the app still opens
        if vlcPresent { a.append("vlc") }
        #endif
        a.append("avplayer")
        return a
    }

    /// true when MobileVLCKit.framework actually loaded (it is missing from SahraMAC-lite.ipa)
    static var vlcPresent: Bool { NSClassFromString("VLCMediaPlayer") != nil }

    static func present(_ engine: String, json: String, from host: UIViewController?, relink: (() -> Void)? = nil,
                        done: @escaping (String) -> Void) {
        guard let host = host, var o = EngineOpts.parse(json) else {
            done(engineAnswer(pos: 0, dur: 0, next: false, error: "bad", started: false))
            return
        }
        // a film plays from its copy on the phone, fetched to the end ahead of the engine (StreamCache);
        // a live channel takes the connection, so any film download stops
        if o.live {
            StreamCache.shared.stopAll()
        } else if o.cache, let t = StreamCache.shared.openFilm(url: o.url, ua: o.ua, key: o.ckey, ext: o.ext, fresh: o.fresh) {
            o.remote = o.url
            o.url = t.url
            o.cacheId = t.id
            o.cacheGen = t.gen
        }
        let cid = o.cacheId, cgen = o.cacheGen
        // when the engine closes the download stops; a link the server refused is told to the app (it gets a fresh one)
        let finish: (String) -> Void = { answer in
            var a = answer
            if !cid.isEmpty {
                let dead = StreamCache.shared.isDead(cid)
                StreamCache.shared.closeFilm(cid, gen: cgen)
                if dead && a.hasSuffix("}") { a = String(a.dropLast()) + ",\"relink\":true}" }
            }
            done(a)
        }
        var vc: UIViewController?
        if engine == "avplayer" {
            let c = AVEngineController(o, done: finish)
            c.relink = relink
            vc = c
        }
        #if SAHRA_VLC
        if engine == "vlc" && vlcPresent {
            let c = VLCEngineController(o, done: finish)
            c.relink = relink
            vc = c
        }
        #endif
        #if SAHRA_MPV
        if engine == "mpv" && !MPVGuard.broken {
            let c = MPVEngineController(o, done: finish)
            c.relink = relink
            vc = c
        }
        #endif
        #if SAHRA_KS
        if engine == "ks" {
            let c = KSEngineController(o, done: finish)
            c.relink = relink
            vc = c
        }
        #endif
        guard let player = vc else {
            finish(engineAnswer(pos: 0, dur: 0, next: false, error: "missing", started: false))
            return
        }
        var top: UIViewController = host
        while let p = top.presentedViewController { top = p }
        top.present(player, animated: true, completion: nil)
    }
}

/// A small line over a player that has no bar of ours (AVPlayer, KSPlayer): how much of the film is on the phone.
final class CacheBadge {
    let label = UILabel()
    private var relinkAt = Date.distantPast

    init() {
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 11.5, weight: .semibold)
        label.backgroundColor = UIColor(white: 0, alpha: 0.5)
        label.layer.cornerRadius = 8
        label.clipsToBounds = true
        label.textAlignment = .center
        label.isUserInteractionEnabled = false
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    func attach(to v: UIView, top: CGFloat = 8) {
        v.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: v.centerXAnchor),
            label.topAnchor.constraint(equalTo: v.safeAreaLayoutGuide.topAnchor, constant: top),
            label.heightAnchor.constraint(equalToConstant: 22),
            label.widthAnchor.constraint(lessThanOrEqualTo: v.widthAnchor, constant: -24)
        ])
    }

    /// tells the phone's copy the player is still here, shows how far it got, asks for a new link if the old one died
    @discardableResult
    func tick(_ o: EngineOpts, pos: Double, dur: Double, relink: (() -> Void)?) -> CacheStatus? {
        guard !o.cacheId.isEmpty else { return nil }
        StreamCache.shared.touch(o.cacheId, gen: o.cacheGen, pos: pos, dur: dur)
        guard let s = StreamCache.shared.status(o.cacheId) else { return nil }
        label.text = "  " + s.text + "  "
        if s.dead && Date().timeIntervalSince(relinkAt) > 8, let r = relink {
            relinkAt = Date()
            r()
        }
        return s
    }
}

/// The app's own subtitles (found on the internet, or translated) drawn over a player that can't
/// load an SRT file itself.
final class SubtitleOverlay {
    private struct Cue { let a: Double; let b: Double; let text: String }
    private var cues: [Cue] = []
    private var shown = -2
    let label = UILabel()

    init?(srt: String) {
        if srt.isEmpty { return nil }
        let blocks = srt.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n\n")
        for b in blocks {
            let lines = b.components(separatedBy: "\n")
            guard let i = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let parts = lines[i].components(separatedBy: "-->")
            guard parts.count == 2, let a = SubtitleOverlay.time(parts[0]), let z = SubtitleOverlay.time(parts[1]) else { continue }
            var text = lines[(i + 1)...].joined(separator: "\n")
            text = text.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            text = text.replacingOccurrences(of: "\\{[^}]*\\}", with: "", options: .regularExpression)
            text = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { cues.append(Cue(a: a, b: z, text: text)) }
        }
        if cues.isEmpty { return nil }
        cues.sort { $0.a < $1.a }
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: UIDevice.current.userInterfaceIdiom == .pad ? 30 : 21, weight: .bold)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.shadowColor = UIColor(white: 0, alpha: 0.95)
        label.shadowOffset = CGSize(width: 1.5, height: 1.5)
        label.isUserInteractionEnabled = false
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    private static func time(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? ""
        let p = t.replacingOccurrences(of: ",", with: ".").components(separatedBy: ":")
        guard p.count >= 2 else { return nil }
        var v = 0.0
        for x in p {
            guard let n = Double(x) else { return nil }
            v = v * 60 + n
        }
        return v
    }

    func attach(to v: UIView) {
        v.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            label.bottomAnchor.constraint(equalTo: v.safeAreaLayoutGuide.bottomAnchor, constant: -64)
        ])
    }

    func show(at t: Double) {
        var lo = 0, hi = cues.count - 1, hit = -1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if cues[mid].a <= t { hit = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        let now = hit >= 0 && t <= cues[hit].b ? hit : -1
        if now == shown { return }
        shown = now
        label.text = now >= 0 ? cues[now].text : nil
    }
}

/// AVPlayer (AVFoundation): Apple's own player — the lightest on the battery, the phone's video chip,
/// picture-in-picture and AirPlay. Best with MP4/MOV and HLS (m3u8); MKV and raw TS go to the others.
final class AVEngineController: AVPlayerViewController, AVPlayerViewControllerDelegate, LiveSubtitleTarget {
    private let o: EngineOpts
    // 3.27: 🔒 lock + «تخطي المقدمة» / «الحلقة التالية» over Apple's player
    private lazy var extras = PlayerExtras(o)
    private var wasPlaying = false
    private var partEnded = false
    private let done: (String) -> Void
    var relink: (() -> Void)?
    private let cacheBadge = CacheBadge()
    private var observations: [NSKeyValueObservation] = []
    private var notes: [NSObjectProtocol] = []
    private var timeToken: Any?
    private var watchdog: Timer?
    private var overlay: SubtitleOverlay?
    private let deadline = Date().addingTimeInterval(25)
    private var started = false
    private var finished = false
    private var wantNext = false
    private var streamEnded = false
    private var seekedStart = false
    private var lastPos: Double = 0
    private var lastDur: Double = 0
    private var failure = ""
    private var waitSince: Date?
    private var stalls: [Date] = []

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        extras.front()
    }

    /// Arabic subtitles found (or translated) while the film plays
    func loadLiveSubtitles(_ srt: String, label: String) {
        guard let ov = SubtitleOverlay(srt: srt), let host = contentOverlayView else { return }
        overlay?.label.removeFromSuperview()
        overlay = ov
        ov.attach(to: host)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
        LiveSubs.target = self
        view.backgroundColor = .black
        guard let u = o.mediaURL else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.fail("رابط غير صالح") }
            return
        }
        var options: [String: Any] = [:]
        if !o.ua.isEmpty { options["AVURLAssetHTTPHeaderFieldsKey"] = ["User-Agent": o.ua] }
        let item = AVPlayerItem(asset: AVURLAsset(url: u, options: options))
        item.preferredForwardBufferDuration = o.live ? 8 : 30
        if o.live {
            // a channel keeps its distance from the live edge and keeps loading while paused
            item.automaticallyPreservesTimeOffsetFromLive = true
            item.canUseNetworkResourcesForLiveStreamingWhilePaused = true
        }
        let p = AVPlayer(playerItem: item)
        p.automaticallyWaitsToMinimizeStalling = true
        p.allowsExternalPlayback = true
        player = p
        allowsPictureInPicturePlayback = true
        updatesNowPlayingInfoCenter = true
        if #available(iOS 14.2, *) { canStartPictureInPictureAutomaticallyFromInline = true }

        observations.append(item.observe(\.status, options: [.new]) { [weak self] it, _ in
            DispatchQueue.main.async { self?.status(it) }
        })
        timeToken = p.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self] t in
            self?.progress(t.seconds)
        }
        notes.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.streamEnded = true
            if self.o.hasNext { self.wantNext = true }
            self.finish()
        })
        notes.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] n in
            let e = n.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error
            self?.fail(e?.localizedDescription ?? "انقطع التشغيل")
        })
        if let ov = SubtitleOverlay(srt: o.subs), let host = contentOverlayView {
            overlay = ov
            ov.attach(to: host)
        }
        if !o.cacheId.isEmpty, let host = contentOverlayView { cacheBadge.attach(to: host) }
        extras.jump = { [weak self] s in
            guard let p = self?.player else { return }
            let t = p.currentTime().seconds
            if t.isFinite { p.seek(to: CMTime(seconds: t + s, preferredTimescale: 600)) }
        }
        extras.next = { [weak self] in
            guard let self = self else { return }
            self.wantNext = true
            self.finish()
        }
        extras.attach(to: view)
        notes.append(NotificationCenter.default.addObserver(forName: .sahraAudioBegan, object: nil, queue: .main) { [weak self] _ in
            self?.wasPlaying = self?.player?.timeControlStatus != .paused
        })
        notes.append(NotificationCenter.default.addObserver(forName: .sahraAudioEnded, object: nil, queue: .main) { [weak self] _ in
            if self?.wasPlaying == true { self?.player?.play() }
        })
        p.play()
        watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.watch() }
    }

    private func status(_ item: AVPlayerItem) {
        switch item.status {
        case .readyToPlay:
            if o.start > 1 && !seekedStart {
                seekedStart = true
                player?.seek(to: CMTime(seconds: o.start, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: CMTime(seconds: 2, preferredTimescale: 600))
            }
        case .failed:
            fail(item.error?.localizedDescription ?? "AVPlayer لم يفتح هذا الرابط")
        default:
            break
        }
    }

    private func progress(_ t: Double) {
        guard t.isFinite else { return }
        if player?.timeControlStatus == .playing && t > 0.2 { started = true }
        if started { lastPos = t }
        if let d = player?.currentItem?.duration.seconds, d.isFinite, d > 0 { lastDur = d }
        overlay?.show(at: t)
    }

    private func watch() {
        extras.tick(pos: lastPos, dur: lastDur, started: started)
        extras.front()
        // a downloaded part: it ends where the download ends
        if o.until > 0 && lastPos >= o.until && !partEnded {
            partEnded = true
            player?.pause()
        }
        let cs = cacheBadge.tick(o, pos: lastPos, dur: lastDur, relink: relink)
        if !started && Date() > deadline {
            // reading the phone's copy of a slow server: not a failure while the bytes keep coming (up to 85 s)
            let flowing = cs.map { $0.quiet < 8 && !$0.dead } ?? false
            if !flowing || Date() > deadline.addingTimeInterval(60) { fail("لم يبدأ خلال 25 ثانية"); return }
        }
        // stuck on «loading»: nudge it (a channel jumps to the live edge); stuck again and again → next engine
        guard started, let p = player, p.timeControlStatus == .waitingToPlayAtSpecifiedRate else { waitSince = nil; return }
        guard let w = waitSince else { waitSince = Date(); return }
        if Date().timeIntervalSince(w) < (o.live ? 6 : 10) { return }
        // waiting for the phone's copy (the bytes are still on their way): nudging would not bring them sooner
        if let s = cs, !s.done, s.ahead < 4 * 1024 * 1024 {
            if s.waiting && s.quiet > 150 && !s.dead { fail("لا تصل بيانات من الخادم") }
            return
        }
        waitSince = nil
        let now = Date()
        stalls = stalls.filter { now.timeIntervalSince($0) < 120 } + [now]
        if stalls.count >= 3 { fail("تقطيع متكرر"); return }
        if o.live, let r = p.currentItem?.seekableTimeRanges.last?.timeRangeValue {
            let edge = CMTimeGetSeconds(CMTimeRangeGetEnd(r)) - 8
            if edge.isFinite && edge > 0 { p.seek(to: CMTime(seconds: edge, preferredTimescale: 600)) }
        } else {
            p.seek(to: p.currentTime())
        }
        p.playImmediately(atRate: 1)
    }

    private func fail(_ why: String) {
        if finished || !failure.isEmpty { return }
        failure = why
        finish()
    }

    private func finish() {
        if finished { return }
        finished = true
        watchdog?.invalidate()
        watchdog = nil
        if let t = timeToken { player?.removeTimeObserver(t) }
        timeToken = nil
        observations.removeAll()
        for n in notes { NotificationCenter.default.removeObserver(n) }
        notes.removeAll()
        player?.pause()
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        if presentingViewController != nil && !isBeingDismissed {
            dismiss(animated: true) { self.done(answer) }
        } else {
            done(answer)
        }
        player = nil
    }

    // the viewer closed it with the player's own ✕
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || presentingViewController == nil { finish() }
    }

    // picture-in-picture keeps this screen (and its answer to the app) alive
    func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool { false }
}
