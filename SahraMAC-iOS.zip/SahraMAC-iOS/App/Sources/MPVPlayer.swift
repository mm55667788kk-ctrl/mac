#if SAHRA_MPV
import UIKit
import Libmpv

/// MoltenVK sometimes asks for a 1×1 drawable while settling; ignoring that keeps the picture.
final class MPVMetalLayer: CAMetalLayer {
    override var drawableSize: CGSize {
        get { super.drawableSize }
        set { if Int(newValue.width) > 1 && Int(newValue.height) > 1 { super.drawableSize = newValue } }
    }
}

/// libmpv (MPVKit): mpv's player — FFmpeg demuxers and decoders, VideoToolbox hardware decoding,
/// libplacebo drawing over Metal (MoltenVK), libass subtitles. Takes almost anything: MKV, TS, HEVC, AV1, DTS…
final class MPVEngineController: EngineController {
    private var mpv: OpaquePointer?
    private let metal = MPVMetalLayer()
    private var loaded = false
    private var ended = false
    private var failed = ""

    override func engineName() -> String { "mpv" }

    private func opt(_ name: String, _ value: String) {
        guard let m = mpv else { return }
        _ = mpv_set_option_string(m, name, value)
    }

    private func prop(_ name: String, _ value: String) {
        guard let m = mpv else { return }
        _ = mpv_set_property_string(m, name, value)
    }

    private func command(_ args: [String]) {
        guard let m = mpv else { return }
        var cargs: [UnsafePointer<CChar>?] = args.map { UnsafePointer(strdup($0)) }
        cargs.append(nil)
        defer { for p in cargs { if let p = p { free(UnsafeMutablePointer(mutating: p)) } } }
        _ = mpv_command(m, &cargs)
    }

    private func double(_ name: String) -> Double {
        guard let m = mpv else { return 0 }
        var v: Double = 0
        return mpv_get_property(m, name, MPV_FORMAT_DOUBLE, &v) >= 0 && v.isFinite ? v : 0
    }

    private func int(_ name: String) -> Int {
        guard let m = mpv else { return 0 }
        var v: Int64 = 0
        return mpv_get_property(m, name, MPV_FORMAT_INT64, &v) >= 0 ? Int(v) : 0
    }

    private func flag(_ name: String) -> Bool {
        guard let m = mpv else { return false }
        var v: Int32 = 0
        return mpv_get_property(m, name, MPV_FORMAT_FLAG, &v) >= 0 && v != 0
    }

    private func string(_ name: String) -> String {
        guard let m = mpv, let c = mpv_get_property_string(m, name) else { return "" }
        defer { mpv_free(c) }
        return String(cString: c)
    }

    override func startPlayback(_ u: URL) {
        loaded = false
        ended = false
        failed = ""
        metal.frame = videoView.bounds
        metal.contentsScale = UIScreen.main.nativeScale
        metal.framebufferOnly = true
        metal.backgroundColor = UIColor.black.cgColor
        if metal.superlayer !== videoView.layer { videoView.layer.addSublayer(metal) }
        guard let m = mpv_create() else { failed = "لم يبدأ mpv"; return }
        mpv = m
        // drawing: libplacebo over Vulkan→Metal, decoding on the phone's video chip
        opt("vo", "gpu-next")
        opt("gpu-api", "vulkan")
        opt("gpu-context", "moltenvk")
        opt("hwdec", "videotoolbox")
        opt("hwdec-codecs", "all")
        // smooth on a phone: timing follows the sound, late frames are dropped instead of freezing the picture
        opt("video-sync", "audio")
        opt("framedrop", "vo")
        opt("vd-lavc-threads", "0")
        opt("video-rotate", "no")
        opt("ytdl", "no")
        opt("input-default-bindings", "no")
        opt("terminal", "no")
        // a deep buffer and reconnecting: IPTV servers drop and stall
        opt("cache", "yes")
        opt("demuxer-max-bytes", "150MiB")
        opt("demuxer-max-back-bytes", "50MiB")
        opt("demuxer-readahead-secs", o.live ? "20" : "60")
        // after a stall, wait for a few seconds of picture instead of stuttering frame by frame
        let prefill = recoveryCount > 0 || o.buffer == .high || o.buffer == .max
        opt("cache-pause-initial", prefill ? "yes" : "no")
        opt("cache-pause-wait", String(o.buffer.refill + Double(recoveryCount)))
        opt("network-timeout", "25")
        opt("cache-pause", "yes")
        opt("cache-secs", o.live ? "20" : "60")
        if o.live {
            // broken packets in a live channel are skipped, not waited on
            opt("demuxer-lavf-o", "fflags=+discardcorrupt+genpts")
        }
        opt("stream-lavf-o", "reconnect=1,reconnect_streamed=1,reconnect_on_network_error=1,reconnect_delay_max=6")
        opt("slang", "ar,ara,arabic")
        opt("subs-fallback", "yes")
        opt("sub-font-size", "46")
        if !o.ua.isEmpty { opt("user-agent", o.ua) }
        if o.start > 1 { opt("start", String(Int(o.start))) }
        // the layer itself is mpv's "window"
        var layer = metal
        _ = mpv_set_option(m, "wid", MPV_FORMAT_INT64, &layer)
        if mpv_initialize(m) < 0 { failed = "تعذّر تهيئة mpv"; return }
        command(["loadfile", u.absoluteString])
    }

    override func layoutVideo() {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        metal.frame = videoView.bounds
        CATransaction.commit()
    }

    override func pump() {
        guard let m = mpv else { return }
        while let ev = mpv_wait_event(m, 0) {
            let e = ev.pointee
            if e.event_id == MPV_EVENT_NONE { break }
            if e.event_id == MPV_EVENT_FILE_LOADED {
                loaded = true
                if let f = o.subtitleFile() { command(["sub-add", f.path, "select", "عربي"]) }
            } else if e.event_id == MPV_EVENT_END_FILE, let d = e.data {
                let end = d.assumingMemoryBound(to: mpv_event_end_file.self).pointee
                if end.reason == MPV_END_FILE_REASON_ERROR {
                    failed = String(cString: mpv_error_string(end.error))
                    if failed.isEmpty { failed = "تعذّر فتح الرابط" }
                } else if end.reason == MPV_END_FILE_REASON_EOF {
                    ended = true
                }
            } else if e.event_id == MPV_EVENT_SHUTDOWN {
                ended = true
            }
        }
    }

    override func stopPlayback() {
        guard let m = mpv else { return }
        command(["stop"])
        mpv = nil
        loaded = false
        mpv_terminate_destroy(m)
    }

    override func engineError() -> String { failed }
    override func isPlaying() -> Bool { loaded && !flag("pause") && !flag("core-idle") }
    override func isBusy() -> Bool { !loaded || flag("paused-for-cache") || flag("seeking") }
    override func hasEnded() -> Bool { ended }
    override func currentTime() -> Double { double("time-pos") }
    override func duration() -> Double { double("duration") }
    override func setPaused(_ paused: Bool) { prop("pause", paused ? "yes" : "no") }
    override func seek(toFraction f: Double) { command(["seek", String(format: "%.3f", f * 100), "absolute-percent"]) }
    override func jump(_ seconds: Double) { command(["seek", String(Int(seconds)), "relative"]) }
    override func setRate(_ r: Float) { prop("speed", String(format: "%.2f", r)) }
    override func videoSize() -> CGSize { CGSize(width: int("dwidth"), height: int("dheight")) }

    private func tracks(_ type: String) -> [(String, Int)] {
        var out: [(String, Int)] = []
        let n = int("track-list/count")
        for i in 0..<max(0, n) where string("track-list/\(i)/type") == type {
            let id = int("track-list/\(i)/id")
            let title = string("track-list/\(i)/title"), lang = string("track-list/\(i)/lang")
            let codec = string("track-list/\(i)/codec")
            var name = [title, lang].filter { !$0.isEmpty }.joined(separator: " · ")
            if name.isEmpty { name = "#\(id)" }
            if !codec.isEmpty { name += " (" + codec + ")" }
            out.append((name, id))
        }
        return out
    }

    override func audioTracks() -> [(String, Int)] { tracks("audio") }
    override func currentAudio() -> Int { Int(string("aid")) ?? -1 }
    override func setAudio(_ id: Int) { prop("aid", String(id)) }
    override func subtitleTracks() -> [(String, Int)] { [("بدون ترجمة", -1)] + tracks("sub") }
    override func currentSubtitle() -> Int { Int(string("sid")) ?? -1 }
    override func setSubtitle(_ id: Int) { prop("sid", id < 0 ? "no" : String(id)) }
}
#endif
