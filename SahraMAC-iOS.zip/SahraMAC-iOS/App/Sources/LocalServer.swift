import Foundation
import Darwin

/// A very small HTTP server on 127.0.0.1 — the phone itself, never the network. Every player (the page's own
/// engines, iOS, VLC, mpv, KSPlayer) opens http://127.0.0.1:<port>/v/<id>/<gen>/f.<ext> and gets the film from
/// StreamCache, with byte ranges for seeking. One thread per connection: a connection waiting for bytes that are
/// still on their way just sleeps; a player that stops reading (paused, buffer full) simply holds the sending.
final class LocalServer {
    static let shared = LocalServer()
    private let lock = NSLock()
    private var sock: Int32 = -1
    private var port = 0
    private var lastPort: UInt16 = 0

    /// The port, starting the server when needed (0 when it could not start).
    func ensure() -> Int {
        lock.lock()
        defer { lock.unlock() }
        if sock >= 0 && port > 0 { return port }
        startLocked()
        return port
    }

    private func startLocked() {
        let s = socket(AF_INET, SOCK_STREAM, 0)
        if s < 0 { return }
        var one: Int32 = 1
        _ = setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, socklen_t(MemoryLayout<Int32>.size))
        _ = setsockopt(s, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
        var bound = false
        // the same port as before when possible: a player that is open keeps its address after the app slept
        for p in [lastPort, UInt16(0)] {
            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = p.bigEndian
            addr.sin_addr = in_addr(s_addr: UInt32(0x7f00_0001).bigEndian)
            let r = withUnsafePointer(to: &addr) { ptr -> Int32 in
                ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa -> Int32 in
                    Darwin.bind(s, sa, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
            if r == 0 { bound = true; break }
        }
        if !bound || Darwin.listen(s, 64) != 0 {
            Darwin.close(s)
            return
        }
        var out = sockaddr_in()
        var len = socklen_t(MemoryLayout<sockaddr_in>.size)
        _ = withUnsafeMutablePointer(to: &out) { ptr -> Int32 in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa -> Int32 in getsockname(s, sa, &len) }
        }
        let p = Int(UInt16(bigEndian: out.sin_port))
        if p <= 0 {
            Darwin.close(s)
            return
        }
        sock = s
        port = p
        lastPort = UInt16(p)
        let t = Thread { [weak self] in self?.acceptLoop(s) }
        t.name = "sahra.local"
        t.start()
    }

    private func acceptLoop(_ s: Int32) {
        while true {
            let c = Darwin.accept(s, nil, nil)
            if c < 0 {
                let err = errno
                if err == EINTR || err == ECONNABORTED { continue }
                break
            }
            var one: Int32 = 1
            _ = setsockopt(c, SOL_SOCKET, SO_NOSIGPIPE, &one, socklen_t(MemoryLayout<Int32>.size))
            let t = Thread { LocalServer.handle(c) }
            t.name = "sahra.local.conn"
            t.start()
        }
        // the socket broke (iOS may take it while the app sleeps): the next ensure() opens it again on the same port
        lock.lock()
        if sock == s {
            Darwin.close(s)
            sock = -1
            port = 0
        }
        lock.unlock()
    }

    private struct Request {
        let method: String
        let path: String
        let headers: [String: String]
    }

    private static func handle(_ c: Int32) {
        defer { Darwin.close(c) }
        var tv = timeval(tv_sec: 15, tv_usec: 0)
        _ = setsockopt(c, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
        guard let req = readRequest(c) else { return }
        if req.method == "OPTIONS" {
            reply(c, 204, "", extra: ["Access-Control-Allow-Methods": "GET, HEAD, OPTIONS", "Access-Control-Allow-Headers": "*"])
            return
        }
        let parts = req.path.split(separator: "/").map(String.init)
        guard parts.count >= 2, parts[0] == "v", req.method == "GET" || req.method == "HEAD" else {
            reply(c, 404, "Not Found")
            return
        }
        // the name's extension says what the file is (f.mp4 when the page found MP4 inside a link without one)
        let name = parts.count >= 4 ? (parts[3] as NSString).pathExtension.lowercased() : ""
        StreamCache.shared.serve(c, id: parts[1], head: req.method == "HEAD", range: req.headers["range"], kind: name)
    }

    private static func readRequest(_ c: Int32) -> Request? {
        var data = [UInt8]()
        var tmp = [UInt8](repeating: 0, count: 4096)
        while data.count < 65536 {
            let n = tmp.withUnsafeMutableBytes { p -> Int in Darwin.recv(c, p.baseAddress, 4096, 0) }
            if n <= 0 { return nil }
            data.append(contentsOf: tmp[0..<n])
            guard let end = headerEnd(data) else { continue }
            let text = String(decoding: data[0..<end], as: UTF8.self)
            var lines = text.components(separatedBy: "\r\n")
            if lines.isEmpty { return nil }
            let first = lines.removeFirst().split(separator: " ").map(String.init)
            if first.count < 2 { return nil }
            var h: [String: String] = [:]
            for l in lines {
                guard let i = l.firstIndex(of: ":") else { continue }
                let k = l[..<i].trimmingCharacters(in: .whitespaces).lowercased()
                h[k] = l[l.index(after: i)...].trimmingCharacters(in: .whitespaces)
            }
            let path = first[1].components(separatedBy: "?").first ?? first[1]
            return Request(method: first[0].uppercased(), path: path, headers: h)
        }
        return nil
    }

    private static func headerEnd(_ d: [UInt8]) -> Int? {
        if d.count < 4 { return nil }
        var i = 0
        while i <= d.count - 4 {
            if d[i] == 13 && d[i + 1] == 10 && d[i + 2] == 13 && d[i + 3] == 10 { return i }
            i += 1
        }
        return nil
    }

    // MARK: - answers

    /// "bytes=a-b" → the bytes a…b (both included); no header → the whole file
    static func range(_ h: String?, _ total: Int64) -> Span? {
        if total <= 0 { return nil }
        guard let raw = h?.lowercased().trimmingCharacters(in: .whitespaces), raw.hasPrefix("bytes=") else {
            return Span(a: 0, b: total - 1)
        }
        let spec = raw.dropFirst(6).split(separator: ",").first.map(String.init) ?? ""
        let p = spec.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespaces) }
        if p.count != 2 { return nil }
        if p[0].isEmpty {
            guard let n = Int64(p[1]), n > 0 else { return nil }
            return Span(a: max(0, total - n), b: total - 1)
        }
        guard let a = Int64(p[0]), a >= 0, a < total else { return nil }
        let b = Int64(p[1]).map { min($0, total - 1) } ?? (total - 1)
        return b >= a ? Span(a: a, b: b) : nil
    }

    static func mime(_ ext: String) -> String {
        switch ext {
        case "mp4", "m4v": return "video/mp4"
        case "mov": return "video/quicktime"
        case "mkv": return "video/x-matroska"
        case "webm": return "video/webm"
        case "ts", "m2ts": return "video/mp2t"
        case "avi": return "video/x-msvideo"
        case "mpg", "mpeg": return "video/mpeg"
        default: return "application/octet-stream"
        }
    }

    private static func reason(_ code: Int) -> String {
        switch code {
        case 200: return "OK"
        case 204: return "No Content"
        case 206: return "Partial Content"
        case 404: return "Not Found"
        case 416: return "Range Not Satisfiable"
        case 502: return "Bad Gateway"
        case 503: return "Service Unavailable"
        default: return "Status"
        }
    }

    /// the status line and headers (every answer closes its connection: simple and fine on the phone itself)
    static func head(_ c: Int32, _ code: Int, _ h: [String: String]) -> Bool {
        var all = h
        all["Access-Control-Allow-Origin"] = "*"
        all["Access-Control-Expose-Headers"] = "*"
        all["Cache-Control"] = "no-store"
        all["Connection"] = "close"
        var s = "HTTP/1.1 \(code) \(reason(code))\r\n"
        for (k, v) in all { s += k + ": " + v + "\r\n" }
        s += "\r\n"
        let b = Array(s.utf8)
        return sendAll(c, b, b.count)
    }

    static func reply(_ c: Int32, _ code: Int, _ text: String, extra: [String: String] = [:]) {
        var h = extra
        let body = Array(text.utf8)
        h["Content-Type"] = "text/plain"
        h["Content-Length"] = String(body.count)
        if head(c, code, h) && !body.isEmpty { _ = sendAll(c, body, body.count) }
    }

    static func sendAll(_ c: Int32, _ b: [UInt8], _ n: Int) -> Bool {
        var sent = 0
        while sent < n {
            let r = b.withUnsafeBytes { p -> Int in
                guard let base = p.baseAddress else { return -1 }
                return Darwin.send(c, base + sent, n - sent, 0)
            }
            if r < 0 && errno == EINTR { continue }
            if r <= 0 { return false }
            sent += r
        }
        return true
    }

    /// the player went away (closed its connection) while we were waiting for bytes
    static func peerGone(_ c: Int32) -> Bool {
        var p = pollfd(fd: c, events: Int16(POLLIN), revents: 0)
        let r = poll(&p, 1, 0)
        if r < 0 { return true }
        if r == 0 { return false }
        if (Int32(p.revents) & (POLLHUP | POLLERR)) != 0 { return true }
        var x: UInt8 = 0
        let n = Darwin.recv(c, &x, 1, MSG_PEEK | MSG_DONTWAIT)
        return n == 0
    }
}
