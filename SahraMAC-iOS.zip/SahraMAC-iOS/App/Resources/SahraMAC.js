// Variables used by Scriptable.
// These must be at the top of the file. Do not edit.
// icon-color: red; icon-glyph: moon;

/*
 ╔════════════════════════════════════════════════════════════╗
 ║   السهرة ماك — مشغل MAC / Stalker Portal                    ║
 ║   لتطبيق Scriptable على iPhone و iPad                       ║
 ╚════════════════════════════════════════════════════════════╝

  طريقة الاستخدام:
   1) شغّل السكربت من تطبيق Scriptable.
   2) أضف رابط البوابة (مثال: http://example.com:8080/c/) وعنوان الـ MAC.
   3) استمتع بالبث المباشر والأفلام والمسلسلات.

  المزايا:
   • بث مباشر مع دليل البرامج (الآن / التالي) وتنقل بين القنوات
   • أفلام ومسلسلات (مواسم + حلقات) مع بحث وتحميل تدريجي
   • العربي أولاً: الأقسام العربية والمترجمة تظهر في المقدمة تلقائياً
   • مفضلة + آخر المشاهدات لكل بوابة
   • تشغيل داخلي (HLS) أو عبر VLC / Infuse / nPlayer + نسخ الرابط
   • أكثر من بوابة، إعادة مصادقة تلقائية عند انتهاء التوكن
   • ودجت للشاشة الرئيسية يعرض حالة الاشتراك وتاريخ الانتهاء
   • 100 ثيم + 100 حركة انتقال مع معاينة فورية
   • ترجمة تلقائية للقصص ودليل البرامج والعناوين (10 لغات)
   • فتح فوري: القنوات المحفوظة تظهر مباشرة والاتصال يتم في الخلفية

  ملاحظة: كل البيانات تُحفظ محلياً على جهازك فقط.
*/

const APP_VERSION = "3.19.0";
const APP_NAME = "السهرة ماك";
// داخل تطبيق الآيفون (IPA): الواجهة على عنوان التطبيق نفسه (sahra://app) والتطبيق يجلب أي رابط بنفسه
// → لا حماية CORS، فلا نقل للصفحة إلى خادم البث ولا لمعة ولا تجارب
const IN_APP = typeof __sahraApp !== "undefined" && !!__sahraApp;
const APP_PX = IN_APP ? String(__sahraApp.px || "sahra://app/__proxy") : "";
const APP_PX_JS = IN_APP ? "(function(){if(window.__pxOn)return;window.__pxOn=1;var PX=" + JSON.stringify(APP_PX + "?u=") + ";" +
  "function px(u){u=String(u);return /^https?:\\/\\//i.test(u)?PX+encodeURIComponent(u):u}window.__px=px;" +
  "var F=window.fetch;if(F)window.fetch=function(i,o){try{if(typeof i==='string')i=px(i);else if(typeof URL!=='undefined'&&i instanceof URL)i=px(i.href);else if(i&&i.url&&/^https?:/i.test(i.url))i=new Request(px(i.url),i)}catch(e){}return F.call(this,i,o)};" +
  // تحميل بتحكم بالتدفق: الصفحة تُبلغ التطبيق بما قرأته (sahra://app/__ack) فيوقف التنزيل عندما يمتلئ المخزن
  // (WebKit لا يضغط على التنزيل الأصلي، فكان الفيلم يتراكم في ذاكرة الصفحة حتى يقتلها النظام بعد دقائق)
  "window.__fcFetch=function(i,o){var u=px(i);if(u===String(i)||!F)return(F||window.fetch).call(window,i,o);var sid=Math.random().toString(36).slice(2)+Date.now().toString(36);" +
  "u+='&sid='+sid;var AK=PX.replace('__proxy?u=','__ack?s=')+sid+'&n=',last=0;" +
  "return F.call(window,u,o).then(function(r){r.sahraAck=function(n,force){if(force||n-last>=262144){last=n;try{F.call(window,AK+n,{cache:'no-store'}).catch(function(){})}catch(e){}}};return r})};" +
  "var X=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(){var a=[].slice.call(arguments);a[1]=px(a[1]);return X.apply(this,a)}})();" : "";
const STB_UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3";
const STB_XUA = "Model: MAG250; Link: WiFi";
const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 ساعات لكاش القنوات
const BIG_CHANNELS = 7000;             // أكثر من هذا → تحميل حسب القسم لحماية الذاكرة
const BIG_BYTES = 2.5 * 1024 * 1024;

// بوابتك الجاهزة — تُضاف تلقائياً مرة واحدة (تقدر تحذفها أو تعدّلها من شاشة البوابات)
const PRESET = { name: "6kcast", url: "http://cf.6kcast.online:80/c/", mac: "00:1A:79:6E:F8:08" };

let TZ = "Europe/London";
try { TZ = Intl.DateTimeFormat().resolvedOptions().timeZone || TZ; } catch (e) {}

/* ───────────────────────── التخزين المحلي ───────────────────────── */
const FM = FileManager.local();
const ROOT = FM.joinPath(FM.documentsDirectory(), "MacIPTV");
if (!FM.fileExists(ROOT)) FM.createDirectory(ROOT, true);
const fp = n => FM.joinPath(ROOT, n);

// أين وصلت المشاهدة: الموضع (للمتابعة وخط التقدم) + ما شوهد كاملاً (علامة ✓)
function posPut(u, k, t, d, end) {
  u.pos = u.pos || {}; u.done = u.done || {};
  t = +t || 0; d = +d || 0;
  if (end || (d && t > d - Math.max(30, d * 0.05))) { delete u.pos[k]; u.done[k] = Date.now(); }
  else if (t < 20) delete u.pos[k];
  else u.pos[k] = { t: Math.round(t), d: Math.round(d), ts: Date.now() };
  const ks = Object.keys(u.pos);
  if (ks.length > 300) ks.sort((a, b) => u.pos[a].ts - u.pos[b].ts).slice(0, ks.length - 300).forEach(z => delete u.pos[z]);
  const kd = Object.keys(u.done);
  if (kd.length > 1500) kd.sort((a, b) => u.done[a] - u.done[b]).slice(0, kd.length - 1500).forEach(z => delete u.done[z]);
}
function loadJSON(name, def) {
  try { const p = fp(name); if (FM.fileExists(p)) return JSON.parse(FM.readString(p)); }
  catch (e) { console.warn("read " + name + ": " + e); }
  return def;
}
function saveJSON(name, val) {
  try { FM.writeString(fp(name), JSON.stringify(val)); }
  catch (e) { console.error("write " + name + ": " + e); }
}

const DEF_SETTINGS = { player: "internal", catAr: true, trTitles: "smart", pmode: "auto", vmode: "auto", inApp: true, buf: "normal", fit: "contain", subSize: "m", subPos: "low", audio: "ar", autoNext: true, resume: true, subTr: true, arabic: "first", theme: 0, anim: 1, motion: true, tr: true, trLang: "ar", accel: "balanced", autoRe: true, stats: true, sameOrigin: false, lite: false, tmdbKey: "" };
const DB = loadJSON("db.json", {});
DB.portals = Array.isArray(DB.portals) ? DB.portals : [];
DB.settings = Object.assign({}, DEF_SETTINGS, DB.settings || {});
DB.user = DB.user || {};
const saveDB = () => saveJSON("db.json", DB);
// في تطبيق الآيفون لا يُغلق المتصفح أبداً (present لا ينتهي) → لا نعتبر كل فتح جديد «إغلاقاً مفاجئاً»
let NOWPLAY = null, DIED = [], PDIED = false;   // آخر مادة تُشغَّل + أوقات إغلاق النظام للصفحة
const CRASHED = !IN_APP && DB.session === "open";
// 3.3: التحويل التلقائي لعنوان خادم البث صار اختيارياً (كان سبب الشاشة السوداء)
if ((DB.mig || 0) < 33) { DB.settings.sameOrigin = false; DB.mig = 33; }
// 3.7: المشغلات القديمة داخل الصفحة استُبدلت بمحركات داخل مشغل السهرة
if ((DB.mig || 0) < 37) { if (!["auto", "own", "mts", "hls", "native"].includes(DB.settings.pmode)) DB.settings.pmode = "auto"; if (!["auto", "mkv", "native", "mts"].includes(DB.settings.vmode)) DB.settings.vmode = "auto"; DB.mig = 37; }
// 3.8: «مسرّعات التشغيل» صارت «التخزين المؤقت»
if ((DB.mig || 0) < 38) { DB.settings.buf = ({ fast: "low", balanced: "normal", stable: "high" })[DB.settings.accel] || DB.settings.buf || "normal"; DB.mig = 38; }
// 3.9.1: الوصف والعناوين وأسماء الأقسام بالعربي
if ((DB.mig || 0) < 39) { DB.settings.tr = true; DB.settings.trLang = DB.settings.trLang || "ar"; DB.settings.catAr = true; DB.mig = 39; saveDB(); }
// سجل الأحداث: يُحفظ على الجهاز ويظهر في تقرير الإغلاق المفاجئ
const PREV_LOG = CRASHED ? loadJSON("crumbs.json", []) : [];
const LOG = [];
let logDirty = false, logFlushed = 0;
function crumb(t, now) {
  const d = new Date();
  LOG.push(("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2) + ":" + ("0" + d.getSeconds()).slice(-2) + " " + String(t).slice(0, 160));
  if (LOG.length > 160) LOG.splice(0, LOG.length - 160);
  logDirty = true;
  if (now) flushLog();
}
function flushLog() { if (!logDirty) return; logDirty = false; logFlushed = Date.now(); saveJSON("crumbs.json", LOG); }
function devInfo() { try { return Device.model() + " · iOS " + Device.systemVersion(); } catch (e) { return "?"; } }

/* ───────────────────────── أدوات مساعدة ───────────────────────── */
const sleep = ms => new Promise(r => { const t = new Timer(); t.timeInterval = ms; t.repeats = false; t.schedule(r); });

const MAC_OUIS = ["001A79", "1027BE", "001EB8", "00A1F9", "A0BB3E", "D4CFF9", "001D9F", "ECB5D7", "000B78", "0030F1"];
function pickMacHex(hex) {
  while (hex.length > 12 && MAC_OUIS.indexOf(hex.slice(0, 6)) >= 0 && hex.slice(0, 6) === hex.slice(6, 12)) hex = hex.slice(6);
  if (hex.length <= 12) return hex;
  let best = -1;
  for (let i = 0; i + 12 <= hex.length; i++) if (MAC_OUIS.indexOf(hex.substr(i, 6)) >= 0) best = i;
  return best >= 0 ? hex.substr(best, 12) : hex.slice(-12);
}
function normMac(m) {
  const hex = pickMacHex(String(m || "").toUpperCase().replace(/[^0-9A-F]/g, ""));
  return hex.length === 12 ? hex.match(/.{2}/g).join(":") : null;
}
function firstOk(ps) {
  return new Promise((res, rej) => {
    let fails = 0, lastErr = null;
    if (!ps.length) return rej(new Error("no candidates"));
    ps.forEach(p => p.then(res, e => { lastErr = e; if (++fails === ps.length) rej(lastErr); }));
  });
}
async function mapLimit(arr, n, fn) {
  const out = new Array(arr.length);
  let i = 0;
  const worker = async () => { while (i < arr.length) { const k = i++; try { out[k] = await fn(arr[k], k); } catch (e) { out[k] = null; } } };
  await Promise.all(Array.from({ length: Math.min(n, arr.length) }, worker));
  return out;
}
function normUrl(u) {
  u = String(u || "").trim().replace(/\s+/g, "");
  if (!u) return null;
  if (!/^https?:\/\//i.test(u)) u = "http://" + u;
  return u;
}
function parseUrl(u) {
  const m = String(u || "").match(/^(https?:\/\/[^\/?#]+)(\/[^?#]*)?/i);
  return m ? { origin: m[1], path: m[2] || "/" } : null;
}
const hostOf = u => { const p = parseUrl(u); return p ? p.origin.replace(/^https?:\/\//i, "") : "Portal"; };
function randHex(n) { let s = ""; for (let i = 0; i < n; i++) s += "0123456789ABCDEF"[Math.floor(Math.random() * 16)]; return s; }
function qs(o) { return Object.keys(o).map(k => k + "=" + encodeURIComponent(o[k] == null ? "" : o[k])).join("&"); }
// "ffmpeg http://..." → "http://..."
const cleanCmd = c => String(c || "").trim().replace(/^\S+\s+(?=[a-z][a-z0-9+.-]*:\/\/)/i, "").trim();
// رابط وهمي يحتاج create_link (مثل http://localhost/ch/123_)
const PLACEHOLDER_RE = /\/\/(localhost|127\.0\.0\.1)(\/|$)|\/ch\/\d+_?$/i;
const isUrl = u => /^[a-z][a-z0-9+.-]*:\/\//i.test(u || "");

// تحويل روابط TS إلى HLS ليعمل المشغل الداخلي في iOS
function toHLS(u) {
  if (/[?&]extension=ts\b/i.test(u)) return u.replace(/([?&]extension=)ts\b/i, "$1m3u8");
  // روابط Xtream: http://host/user/pass/123  →  http://host/live/user/pass/123.m3u8
  const m = u.match(/^(https?:\/\/[^\/]+)\/(?:live\/)?([^\/?#]+)\/([^\/?#]+)\/(\d+)(?:\.ts)?(\?[^#]*)?$/i);
  if (m && !/^(movie|series|play)$/i.test(m[2])) return m[1] + "/live/" + m[2] + "/" + m[3] + "/" + m[4] + ".m3u8" + (m[5] || "");
  if (/\.ts(\?|$)/i.test(u)) return u.replace(/\.ts(\?|$)/i, ".m3u8$1");
  return u;
}

// رابط مكسور: عنوان الخادم مكرر داخل المسار (مثل /user/pass/c:8080/user/pass/123)
function badLink(u) {
  const m = String(u || "").match(/^[a-z][a-z0-9+.-]*:\/\/[^\/]+(\/[^?#]*)?/i);
  if (!m) return true;
  const p = m[1] || "";
  return /:\d{2,5}\//.test(p) || /[a-z]+:\/\//i.test(p) || /\/\//.test(p);
}
function repairLink(u) {
  const m = String(u || "").match(/^([a-z][a-z0-9+.-]*:\/\/[^\/]+)\/([^?#]*)(\?[^#]*)?/i);
  if (!m) return null;
  const segs = m[2].split("/").filter(Boolean);
  if (segs.length < 3) return null;
  const head = /^(live|movie|series)$/i.test(segs[0]) ? segs.slice(0, 3) : segs.slice(0, 2);
  const last = segs[segs.length - 1];
  if (head.some(x => /:/.test(x)) || /:/.test(last)) return null;
  return m[1] + "/" + head.concat(last).join("/") + (m[3] || "");
}
// مثل أجهزة MAG: إذا كانت القناة تحمل رابطاً جاهزاً يُشغَّل مباشرة، وإلا نطلب رابطاً من البوابة
async function resolveLink(s, o, pick) {
  // حلقات Ministra ذات المستويات الثلاثة: الملف الفعلي داخل الحلقة
  if (/^ep:\[/.test(o.cmd || "")) o = Object.assign({}, o, { cmd: await s.episodeCmd(o.cmd) });
  const direct = cleanCmd(o.cmd);
  const hasDirect = isUrl(direct) && !PLACEHOLDER_RE.test(direct) && !badLink(direct);
  const forceLink = String(o.tmp) === "1" || String(o.lb) === "1";
  const order = hasDirect ? (forceLink ? ["link", "direct"] : ["direct", "link"]) : ["link"];
  const want = order[Math.min(pick || 0, order.length - 1)];
  let r;
  if (want === "direct") r = { url: direct, src: "direct" };
  else {
    const link = await s.createLink(o.kind === "itv" ? "itv" : "vod", o.cmd, o.series);
    if (!badLink(link)) r = { url: link, src: "link" };
    else {
      const fixed = repairLink(link);
      if (fixed) r = { url: fixed, src: "repaired" };
      else if (hasDirect) r = { url: direct, src: "direct" };
      else r = { url: link, src: "broken" };
    }
  }
  r.n = order.length;
  return r;
}

/* MD5 / SHA-256 (لتوليد Serial و Device ID مثل أجهزة MAG) */
function md5(s) {
  const add = (x, y) => (x + y) | 0;
  const cmn = (q, a, b, x, s2, t) => { a = add(add(a, q), add(x, t)); return add((a << s2) | (a >>> (32 - s2)), b); };
  const ff = (a, b, c, d, x, s2, t) => cmn((b & c) | (~b & d), a, b, x, s2, t);
  const gg = (a, b, c, d, x, s2, t) => cmn((b & d) | (c & ~d), a, b, x, s2, t);
  const hh = (a, b, c, d, x, s2, t) => cmn(b ^ c ^ d, a, b, x, s2, t);
  const ii = (a, b, c, d, x, s2, t) => cmn(c ^ (b | ~d), a, b, x, s2, t);
  function cycle(x, k) {
    let a = x[0], b = x[1], c = x[2], d = x[3];
    a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586); c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426); c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417); c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101); c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
    a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632); c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083); c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690); c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784); c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
    a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463); c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353); c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222); c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835); c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
    a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415); c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606); c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744); c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379); c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
    x[0] = add(a, x[0]); x[1] = add(b, x[1]); x[2] = add(c, x[2]); x[3] = add(d, x[3]);
  }
  const blk = t => { const r = []; for (let i = 0; i < 64; i += 4) r[i >> 2] = t.charCodeAt(i) + (t.charCodeAt(i + 1) << 8) + (t.charCodeAt(i + 2) << 16) + (t.charCodeAt(i + 3) << 24); return r; };
  const n = s.length, st = [1732584193, -271733879, -1732584194, 271733878];
  let i;
  for (i = 64; i <= n; i += 64) cycle(st, blk(s.substring(i - 64, i)));
  s = s.substring(i - 64);
  const tail = new Array(16).fill(0);
  for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
  tail[i >> 2] |= 0x80 << ((i % 4) << 3);
  if (i > 55) { cycle(st, tail); for (let j = 0; j < 16; j++) tail[j] = 0; }
  tail[14] = n * 8;
  cycle(st, tail);
  const hx = "0123456789abcdef";
  let out = "";
  for (const v of st) for (let j = 0; j < 4; j++) out += hx[(v >> (j * 8 + 4)) & 15] + hx[(v >> (j * 8)) & 15];
  return out;
}

function sha256(ascii) {
  const rr = (v, a) => (v >>> a) | (v << (32 - a));
  const maxWord = Math.pow(2, 32);
  const words = [], bitLen = ascii.length * 8;
  let hash = [], k = [], pc = 0;
  const comp = {};
  for (let cand = 2; pc < 64; cand++) {
    if (!comp[cand]) {
      for (let i = 0; i < 313; i += cand) comp[i] = cand;
      hash[pc] = (Math.pow(cand, .5) * maxWord) | 0;
      k[pc++] = (Math.pow(cand, 1 / 3) * maxWord) | 0;
    }
  }
  hash = hash.slice(0, 8);
  ascii += "\x80";
  while (ascii.length % 64 - 56) ascii += "\x00";
  for (let i = 0; i < ascii.length; i++) words[i >> 2] |= ascii.charCodeAt(i) << ((3 - i) % 4) * 8;
  words[words.length] = (bitLen / maxWord) | 0;
  words[words.length] = bitLen;
  for (let j = 0; j < words.length;) {
    const w = words.slice(j, j += 16), old = hash;
    hash = hash.slice(0, 8);
    for (let i = 0; i < 64; i++) {
      const w15 = w[i - 15], w2 = w[i - 2], a = hash[0], e = hash[4];
      const t1 = hash[7] + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & hash[5]) ^ (~e & hash[6])) + k[i] +
        (w[i] = i < 16 ? w[i] : (w[i - 16] + (rr(w15, 7) ^ rr(w15, 18) ^ (w15 >>> 3)) + w[i - 7] + (rr(w2, 17) ^ rr(w2, 19) ^ (w2 >>> 10))) | 0);
      const t2 = (rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & hash[1]) ^ (a & hash[2]) ^ (hash[1] & hash[2]));
      hash = [(t1 + t2) | 0].concat(hash);
      hash[4] = (hash[4] + t1) | 0;
    }
    for (let i = 0; i < 8; i++) hash[i] = (hash[i] + old[i]) | 0;
  }
  let out = "";
  for (let i = 0; i < 8; i++) for (let j = 3; j + 1; j--) { const b = (hash[i] >> (j * 8)) & 255; out += (b < 16 ? "0" : "") + b.toString(16); }
  return out;
}

/* ───────────────────────── عميل بوابة Stalker ───────────────────────── */
class Stalker {
  constructor(p) {
    this.p = p;
    this.mac = normMac(p.mac);
    const u = parseUrl(normUrl(p.url));
    if (!u || !this.mac) throw new Error("بيانات البوابة غير صحيحة");
    this.origin = u.origin;
    let path = u.path.replace(/\/+$/, "");
    this.explicit = /\.php$/i.test(path) ? path : null;
    path = path.replace(/\/(index\.html?|portal\.php|load\.php)$/i, "").replace(/\/server$/i, "").replace(/\/c$/i, "");
    this.prefix = path; // "" أو "/stalker_portal" ...
    const c = [];
    if (this.explicit) c.push(this.explicit);
    if (p.api) c.push(p.api);
    if (this.prefix) c.push(this.prefix + "/server/load.php", this.prefix + "/portal.php");
    c.push("/portal.php", "/server/load.php", "/stalker_portal/server/load.php");
    this.cands = c.filter((x, i) => c.indexOf(x) === i);
    this.api = null;
    this.token = null;
    this.profile = null;
    this.sn = (p.sn || "").trim() || md5(this.mac).toUpperCase().slice(0, 13);
    this.id1 = (p.id1 || "").trim() || sha256(this.mac).toUpperCase();
    this.id2 = (p.id2 || "").trim() || this.id1;
    this.sig = (p.sig || "").trim() || sha256(this.sn + this.mac).toUpperCase();
  }

  referer() {
    const base = this.api && /stalker_portal/.test(this.api) ? "/stalker_portal" : this.prefix;
    return this.origin + (base || "") + "/c/";
  }

  headers(auth) {
    const h = {
      "User-Agent": STB_UA,
      "X-User-Agent": STB_XUA,
      "Accept": "*/*",
      "Referer": this.referer(),
      "Cookie": "mac=" + encodeURIComponent(this.mac) + "; stb_lang=en; timezone=" + encodeURIComponent(TZ)
    };
    if (auth && this.token) h["Authorization"] = "Bearer " + this.token;
    return h;
  }

  async http(url, auth, timeout) {
    const r = new Request(url);
    r.method = "GET";
    r.headers = this.headers(auth);
    r.timeoutInterval = timeout || 20;
    r.allowInsecureRequest = true;
    const text = await r.loadString();
    return { text: text || "", status: (r.response && r.response.statusCode) || 0 };
  }

  parse(text) {
    if (!text) return null;
    try { return JSON.parse(text); } catch (e) {}
    const i = text.indexOf("{");
    if (i >= 0) { try { return JSON.parse(text.slice(i)); } catch (e) {} }
    return null;
  }

  async handshake(api, to) {
    const base = this.origin + api + "?";
    const r1 = await this.http(base + qs({ type: "stb", action: "handshake", token: "", prehash: "", JsHttpRequest: "1-xml" }), false, to || 10);
    const j1 = this.parse(r1.text);
    if (j1 && j1.js && j1.js.token) return j1.js.token;
    if (!j1 || !j1.js) return null;
    // بعض البوابات تتطلب توكن من العميل
    const tok = randHex(32);
    const r2 = await this.http(base + qs({ type: "stb", action: "handshake", token: tok, prehash: "", JsHttpRequest: "1-xml" }), false, to || 10);
    const j2 = this.parse(r2.text);
    if (j2 && j2.js) return j2.js.token || tok;
    return null;
  }

  async auth() {
    this.token = null;
    let win = null, last = "";
    const tryOne = (api, to) => this.handshake(api, to).then(t => { if (!t) throw new Error("no token"); return { api, t }; });
    // 1) آخر مسار ناجح أولاً (أسرع)  2) وإلا جرّب كل المسارات بالتوازي وخذ أسرعها
    if (this.p.api && this.cands[0] === this.p.api) {
      try { win = await tryOne(this.p.api, 9); } catch (e) { last = String((e && e.message) || e); }
    }
    if (!win) {
      try { win = await firstOk(this.cands.map(a => tryOne(a, 10))); }
      catch (e) { if (e && e.message && e.message !== "no token") last = e.message; }
    }
    if (!win) throw new Error("تعذّر الاتصال بالبوابة — تأكد من الرابط واتصال الإنترنت" + (last ? "\n(" + last + ")" : ""));
    this.api = win.api; this.token = win.t; this.p.api = win.api;
    this.profile = await this.getProfile();
    return true;
  }

  reauth() {
    if (!this._auth) {
      const done = () => { this._auth = null; };
      this._auth = this.auth().then(v => { done(); return v; }, e => { done(); throw e; });
    }
    return this._auth;
  }

  async getProfile() {
    const metrics = JSON.stringify({ mac: this.mac, sn: this.sn, type: "STB", model: "MAG250", uid: this.id1, random: randHex(40).toLowerCase() });
    const j = await this.call({
      type: "stb", action: "get_profile", hd: 1,
      ver: "ImageDescription: 0.2.18-r23-250; ImageDate: Fri Jan 15 15:20:44 EET 2016; PORTAL version: 5.6.1; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c",
      num_banks: 2, sn: this.sn, stb_type: "MAG250", client_type: "STB", image_version: 218, video_out: "hdmi",
      device_id: this.id1, device_id2: this.id2, signature: this.sig, auth_second_step: 1, hw_version: "1.7-BD-00",
      not_valid_token: 0, metrics, timestamp: Math.floor(Date.now() / 1000), api_signature: 262, prehash: ""
    }, false);
    return (j && j.js && typeof j.js === "object") ? j.js : {};
  }

  async call(params, retry = true, timeout = 25) {
    if (!this.token) await this.reauth();
    const url = this.origin + this.api + "?" + qs(params) + "&JsHttpRequest=1-xml";
    let res;
    try { res = await this.http(url, true, timeout); }
    catch (e) {
      if (retry) { await this.reauth(); return this.call(params, false, timeout); }
      throw new Error("خطأ في الشبكة: " + ((e && e.message) || e));
    }
    const j = this.parse(res.text);
    const authFail = res.status === 401 || res.status === 403 || (!j && /authori[sz]ation failed|access denied|unauthori[sz]ed/i.test(res.text));
    if (authFail && retry) { await this.reauth(); return this.call(params, false, timeout); }
    if (!j) throw new Error(authFail ? "رفضت البوابة الاتصال — الـ MAC غير مفعّل أو الاشتراك منتهي" : "رد غير صالح من البوابة (HTTP " + res.status + ")");
    return j;
  }

  abs(u) {
    u = String(u || "").trim();
    if (!u) return "";
    if (/^https?:\/\//i.test(u)) return u;
    if (u.startsWith("//")) return "http:" + u;
    if (u.startsWith("/")) return this.origin + u;
    if (/\.(png|jpe?g|gif|webp|svg)$/i.test(u)) return this.origin + (this.prefix || "/stalker_portal") + "/misc/logos/320/" + u;
    return "";
  }

  async account() {
    let info = {};
    try { const j = await this.call({ type: "account_info", action: "get_main_info" }); if (j && j.js && typeof j.js === "object") info = j.js; } catch (e) {}
    const p = this.profile || {};
    const exp = info.end_date || info.phone || info.expire_billing_date || p.expire_billing_date || p.end_date || "";
    return {
      expiry: String(exp || "").trim(),
      tariff: String(info.tariff_plan || p.tariff_plan || "").trim(),
      status: p.status != null ? String(p.status) : "",
      blocked: String(p.blocked || "") === "1",
      mac: this.mac
    };
  }

  /* ── البث المباشر ── */
  async liveGenres() {
    const j = await this.call({ type: "itv", action: "get_genres" });
    const a = Array.isArray(j.js) ? j.js : [];
    return a.map(x => ({ id: String(x.id), title: String(x.title || x.alias || x.id).trim() }));
  }
  async allChannels() {
    const j = await this.call({ type: "itv", action: "get_all_channels" }, true, 90);
    const d = j && j.js && (Array.isArray(j.js.data) ? j.js.data : (Array.isArray(j.js) ? j.js : null));
    return d;
  }
  async channelsPage(genre, page) {
    const j = await this.call({ type: "itv", action: "get_ordered_list", genre, force_ch_link_check: "", fav: 0, sortby: "number", hd: 0, p: page });
    const js = (j && j.js) || {};
    const data = Array.isArray(js.data) ? js.data : [];
    const total = +js.total_items || data.length, per = +js.max_page_items || data.length || 14;
    return { items: data, pages: Math.max(1, Math.ceil(total / per)), total };
  }
  slimCh(c) {
    const cmd = c.cmd || (Array.isArray(c.cmds) && c.cmds[0] && c.cmds[0].url) || "";
    const o = { id: String(c.id), name: String(c.name || "").trim(), num: +c.number || 0, cmd, logo: this.abs(c.logo), g: String(c.tv_genre_id || "") };
    if (c.use_http_tmp_link != null) o.tmp = String(c.use_http_tmp_link);
    if (c.use_load_balancing != null) o.lb = String(c.use_load_balancing);
    return o;
  }
  async epg(chId) {
    let a = [];
    try {
      const j = await this.call({ type: "itv", action: "get_short_epg", ch_id: chId, size: 10 });
      a = Array.isArray(j.js) ? j.js : ((j.js && j.js.data) || []);
    } catch (e) {}
    if (!a.length) {
      try {
        const d = new Date(), z = n => (n < 10 ? "0" : "") + n;
        const j = await this.call({ type: "epg", action: "get_simple_data_table", ch_id: chId, date: d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate()), p: 0 });
        a = (j.js && Array.isArray(j.js.data)) ? j.js.data : [];
      } catch (e) {}
    }
    const ts = v => { const t = Date.parse(String(v || "").replace(" ", "T")); return isNaN(t) ? 0 : Math.floor(t / 1000); };
    return a.map(e => ({
      name: String(e.name || "").trim(), start: +e.start_timestamp || ts(e.time), end: +e.stop_timestamp || ts(e.time_to),
      t1: e.t_time || "", t2: e.t_time_to || "", desc: String(e.descr || "").trim()
    }));
  }

  /* ── رابط التشغيل ── */
  async createLink(type, cmd, series) {
    let url = "", err = null;
    try {
      const j = await this.call({ type, action: "create_link", cmd, series: series || "", forced_storage: "undefined", disable_ad: 0, download: 0, force_ch_link_check: 0 });
      const js = j && j.js;
      if (js && js.error) err = js.error;
      url = cleanCmd(js && typeof js === "object" ? js.cmd : js);
    } catch (e) { err = e.message; }
    if (!isUrl(url)) {
      const raw = cleanCmd(cmd);
      if (isUrl(raw) && !PLACEHOLDER_RE.test(raw)) url = raw;
    }
    if (!isUrl(url)) {
      const map = { nothing_to_play: "لا يوجد بث متاح لهذه المادة", limit: "تجاوزت الحد المسموح من الاتصالات المتزامنة", link_fault: "تعذّر إنشاء الرابط", nginx_auth_error: "رفض الخادم الرابط" };
      throw new Error(map[err] || (err ? "تعذّر التشغيل: " + err : "تعذّر إنشاء رابط التشغيل"));
    }
    return url;
  }

  /* ── الأفلام والمسلسلات ── */
  async categories(type) {
    const j = await this.call({ type, action: "get_categories" });
    const a = Array.isArray(j.js) ? j.js : [];
    return a.map(x => ({ id: String(x.id), title: String(x.title || x.alias || x.id).trim() }));
  }
  slimVod(m, type) {
    const series = Array.isArray(m.series) ? m.series : [];
    const rating = String(m.rating_imdb || m.rating_kinopoisk || "").trim();
    return {
      id: String(m.id), type,
      name: String(m.name || m.o_name || "").trim(), oname: String(m.o_name || "").trim(),
      poster: this.abs(m.screenshot_uri || m.pic || m.cover_big || m.logo),
      cmd: m.cmd || "", year: String(m.year || "").trim(), rating: /^[0-9.]+$/.test(rating) && +rating > 0 ? rating : "",
      genres: String(m.genres_str || "").trim(), desc: String(m.description || "").trim(),
      time: String(m.time || "").trim(), director: String(m.director || "").trim(), actors: String(m.actors || "").trim(),
      series, isSeries: type === "series" || String(m.is_series) === "1" || series.length > 0
    };
  }
  async items(type, cat, page, search) {
    const p = { type, action: "get_ordered_list", category: cat || "*", movie_id: 0, season_id: 0, episode_id: 0, fav: 0, sortby: "added", hd: 0, p: page || 1 };
    if (search) p.search = search;
    const j = await this.call(p);
    const js = (j && j.js) || {};
    const data = (Array.isArray(js.data) ? js.data : []).map(m => this.slimVod(m, type));
    const total = +js.total_items || data.length, per = +js.max_page_items || data.length || 14;
    return { items: data, page: page || 1, pages: Math.max(1, Math.ceil(total / per)), total };
  }
  async listAll(params, max) {
    let all = [];
    for (let p = 1; p <= (max || 10); p++) {
      const j = await this.call(Object.assign({}, params, { p }));
      const js = (j && j.js) || {};
      const d = Array.isArray(js.data) ? js.data : [];
      all = all.concat(d);
      const total = +js.total_items || 0;
      if (!d.length || all.length >= total) break;
    }
    return all;
  }
  async seasons(type, movieId) {
    const a = await this.listAll({ type, action: "get_ordered_list", movie_id: movieId, season_id: 0, episode_id: 0 });
    return a.map((s, i) => ({ id: String(s.id), name: String(s.name || ("الموسم " + (i + 1))).trim(), cmd: s.cmd || "", eps: Array.isArray(s.series) ? s.series : [] }));
  }
  async episodes(type, movieId, seasonId) {
    const a = await this.listAll({ type, action: "get_ordered_list", movie_id: movieId, season_id: seasonId, episode_id: 0 }, 20);
    return a.map((e, i) => ({ id: String(e.id), name: String(e.name || "").trim(), cmd: e.cmd || ("ep:" + JSON.stringify([type, movieId, seasonId, String(e.id)])), num: +e.series_number || +e.episode_number || (i + 1) }));
  }
  async episodeCmd(mk) {
    this.epc = this.epc || {};
    if (this.epc[mk]) return this.epc[mk];
    let q = []; try { q = JSON.parse(mk.slice(3)); } catch (e) {}
    const j = await this.call({ type: q[0] || "vod", action: "get_ordered_list", movie_id: q[1], season_id: q[2], episode_id: q[3], p: 1 });
    const d = (j && j.js && Array.isArray(j.js.data)) ? j.js.data : [];
    const f = d.find(x => x && x.cmd);
    if (!f) throw new Error("لا يوجد ملف لهذه الحلقة");
    return (this.epc[mk] = f.cmd);
  }
}

/* ───────────────────────── الجسر بين الواجهة و Scriptable ───────────────────────── */
let ST = null, STP = null, PENDING = null;
let MEM = freshMem();
const MTC = {};   // ذاكرة جدول المباريات
function freshMem() { return { liveRaw: null, genres: null, genre: {}, cats: {} }; }
let TRC = null;
const trCache = () => TRC || (TRC = loadJSON("tr.json", {}));
const activePortal = () => DB.portals.find(p => p.id === DB.activeId) || null;
function userData(id) {
  const u = DB.user[id] || (DB.user[id] = {});
  u.favs = Object.assign({ itv: [], vod: [], series: [] }, u.favs || {});
  u.recent = Array.isArray(u.recent) ? u.recent : [];
  return u;
}
const pub = p => ({ id: p.id, name: p.name, url: p.url, mac: p.mac, sn: p.sn || "", id1: p.id1 || "", id2: p.id2 || "", sig: p.sig || "" });
async function needST() {
  if (STP) return STP;
  if (!ST) {
    const p = activePortal();
    if (!p) throw new Error("لا توجد بوابة نشطة");
    ST = new Stalker(p);
    await ST.auth();
  }
  return ST;
}

const PLAYERS = {
  vlc: u => "vlc-x-callback://x-callback-url/stream?url=" + encodeURIComponent(u),
  infuse: u => "infuse://x-callback-url/play?url=" + encodeURIComponent(u),
  nplayer: u => "nplayer-" + u,
  safari: u => u
};

/* ═════════ الممثلون: صورهم وأعمالهم ═════════
 * الأسماء من البوابة (حقل actors). الصور والأعمال من TMDB إذا أضاف المستخدم مفتاحه المجاني،
 * وإلا من ويكيبيديا وويكي بيانات (مجانية بلا إعداد). أعمالهم تُطابَق مع الاشتراك فتُشغَّل مباشرة. */
const WIKI_UA = "AlsahraMac/" + APP_VERSION + " (iPhone; personal IPTV player)";
const TMDB_IMG = "https://image.tmdb.org/t/p/";
const normP = t => normK(String(t || "").replace(/ـ/g, ""));
const isArS = s => /[؀-ۿ]/.test(String(s || ""));
const stripParen = s => String(s || "").replace(/\s*[\(（\[].*?[\)）\]]\s*/g, " ").trim();
const ACTOR_RE = /ممثل|ممثلة|فنان|فنانة|مغن|مغنية|كوميدي|مذيع|actor|actress|comedian|singer|presenter|entertainer|performer/i;
const NOT_ACTOR_RE = /لاعب|كرة|سياسي|رجل أعمال|footballer|politician|player|wrestler|businessman|scientist/i;
const WORK_RE = /مسلسل|فيلم|برنامج|دراما|television|tv series|film|movie|sitcom|drama|telenovela|series|miniseries/i;
let PPL = null;
function pplDB() {
  if (!PPL) { PPL = loadJSON("people.json", {}) || {}; PPL.n = PPL.n || {}; PPL.c = PPL.c || {}; PPL.w = PPL.w || {}; }
  return PPL;
}
function pruneOld(o, max) { const k = Object.keys(o); if (k.length > max) k.sort((a, b) => (o[b].t || 0) - (o[a].t || 0)).slice(max).forEach(x => delete o[x]); }
function pplSave() { const d = pplDB(); pruneOld(d.n, 800); pruneOld(d.c, 300); pruneOld(d.w, 150); saveJSON("people.json", d); }
const freshE = (e, okDays, missDays) => !!e && Date.now() - (e.t || 0) < 864e5 * (e.img || e.ok ? okDays : missDays);
async function webJSON(url, headers, timeout) {
  const r = new Request(url);
  r.headers = Object.assign({ "User-Agent": WIKI_UA, "Accept": "application/json" }, headers || {});
  r.timeoutInterval = timeout || 12;
  r.allowInsecureRequest = true;
  const t = await r.loadString();
  const st = (r.response && r.response.statusCode) || 0;
  if (st >= 400) throw new Error("HTTP " + st);
  return JSON.parse(t);
}
const tmdbKey = () => String((DB.settings || {}).tmdbKey || "").trim();
async function tmdb(path, params) {
  const k = tmdbKey();
  if (!k) throw new Error("no key");
  const bearer = /^eyJ/.test(k), q = Object.assign({ language: "ar-SA" }, params || {});
  if (!bearer) q.api_key = k;
  const qs = Object.keys(q).map(x => x + "=" + encodeURIComponent(q[x])).join("&");
  return webJSON("https://api.themoviedb.org/3" + path + "?" + qs, bearer ? { Authorization: "Bearer " + k } : null, 12);
}
async function wpSearch(lang, q, n) {
  const u = "https://" + lang + ".wikipedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrsearch=" + encodeURIComponent(q) +
    "&gsrlimit=" + (n || 4) + "&gsrnamespace=0&prop=pageimages%7Cpageprops%7Cdescription&piprop=thumbnail&pithumbsize=300&ppprop=wikibase_item&redirects=1";
  const j = await webJSON(u);
  return ((j && j.query && j.query.pages) || []).slice().sort((a, b) => (a.index || 0) - (b.index || 0));
}
async function sparql(q) {
  const j = await webJSON("https://query.wikidata.org/sparql?format=json&query=" + encodeURIComponent(q), { Accept: "application/sparql-results+json" }, 20);
  return (j && j.results && j.results.bindings) || [];
}
const sv = (r, k) => (r && r[k] && r[k].value) || "";
const commonsImg = (u, w) => u ? String(u).replace(/^http:/, "https:") + "?width=" + (w || 300) : "";
// هل هذا العنوان هو اسم الممثل؟ 3 = نفس الاسم، 2 = قريب منه، 0 = لا
function nameMatch(title, name) {
  const t = normP(stripParen(title)), n = normP(name);
  if (!t || !n) return 0;
  if (t === n) return 3;
  if (t.includes(n) || (n.length > 6 && n.includes(t))) return 2;
  const tt = normT(stripParen(title)).split(" ").map(normP), nt = normT(name).split(" ").map(normP).filter(x => x.length > 1);
  return nt.length >= 2 && nt.every(x => tt.includes(x)) ? 2 : 0;
}
// صيغ الكلمة العربية كما قد تكون مكتوبة في البوابة (البحث فيها حرفي)
function arVariants(q) {
  const plain = String(q).replace(/[أإآٱ]/g, "ا").replace(/ة(?=\s|$)/g, "ه").replace(/[\u064B-\u065F\u0670]/g, "");
  const hamza = (ch) => plain.split(" ").map(w => /^الا/.test(w) ? "ال" + ch + w.slice(3) : /^ا/.test(w) && !/^ال/.test(w) && w.length > 2 ? ch + w.slice(1) : w).join(" ");
  const ta = x => x.replace(/ه(?=\s|$)/g, "ة");
  const ya = x => x.replace(/ي(?=\s|$)/g, "ى");
  return [plain, ta(plain), ta(hamza("أ")), ta(hamza("إ")), ya(ta(plain))].filter((x, i, a) => a.indexOf(x) === i && x !== q).slice(0, 4);
}
// أطول كلمة بدون «ال» والهمزة في أولها والتاء/الياء في آخرها: «الازرق» → «زرق»
function arStem(q) {
  const w = String(q).split(/\s+/).map(x => x.replace(/^(و|ف|ب)?ال/, "").replace(/^[اأإآ]/, "").replace(/[ةهىي]$/, "")).filter(x => x.length >= 3 && /[\u0600-\u06FF]/.test(x));
  return w.sort((a, b) => b.length - a.length)[0] || "";
}
// محتوى عربي: اسم عربي، أو «AR | …»، أو «عربي / مدبلج»
const isArItem = it => /[\u0600-\u06FF]/.test(String(it.name || "")) || /^\s*(ar|arb|ara|arabic|ksa|sa|eg|egy|syr|sy|leb|lb|kw|gcc|mena|khaleeji)\b\s*[:|\-–]/i.test(String(it.name || "")) || /\b(arabic|arab)\b|عربي|مدبلج|خليجي|مصري|سوري/i.test(String(it.name || "") + " " + String(it.genres || ""));
// اسم العمل في البوابة بدون الرموز («AR |» والجودة والسنة)
function cleanWork(n) {
  return String(n || "")
    .replace(/^\s*[A-Z]{2,4}\s*[|:\-–]\s*/, "").replace(/^\s*[؀-ۿ]{2,8}\s*\|\s*/, "")
    .replace(/[\[\(（]?\b(19|20)\d{2}\b[\]\)）]?/g, " ")
    .replace(/\b(4K|8K|UHD|FHD|HD|SD|HEVC|H\.?26[45]|1080p|720p|2160p|MULTI|VIP|NEW|DUB|SUB|BLURAY|WEB-?DL|DOLBY|ATMOS)\b/gi, " ")
    .replace(/\bS\d{1,2}(E\d{1,3})?\b/gi, " ").replace(/(مدبلج|مترجم|حصري|جديد|كامل)/g, " ")
    .replace(/[|•·★⭐]+/g, " ").replace(/\s+/g, " ").trim();
}
// هل اسم المادة في البوابة هو هذا العمل؟ (3 = نفس الاسم، 2 = نفس الاسم + رقم الجزء)
function workHit(itemName, title) {
  const a = normT(cleanWork(itemName)), b = normT(cleanWork(stripParen(title)));
  if (!a || !b || b.replace(/\s/g, "").length < 2) return 0;
  if (normP(a) === normP(b)) return 3;
  if (a.startsWith(b + " ") && /^\d{1,2}$/.test(a.slice(b.length + 1).trim())) return 2;
  return 0;
}
async function personWiki(name) {
  for (const lang of isArS(name) ? ["ar"] : ["en", "ar"]) {
    let pages;
    try { pages = await wpSearch(lang, name, 4); } catch (e) { if (lang === "ar" || !isArS(name)) throw e; continue; }
    let best = null, bs = 0;
    for (const p of pages) {
      const m = nameMatch(p.title, name), d = p.description || "", act = ACTOR_RE.test(d);
      if (!act && NOT_ACTOR_RE.test(d)) continue;
      const sc = m === 3 ? (act ? 5 : 3) : m === 2 && act ? 4 : 0;
      if (sc > bs) { bs = sc; best = p; }
    }
    if (best) return { img: (best.thumbnail && best.thumbnail.source) || "", wd: (best.pageprops && best.pageprops.wikibase_item) || "", desc: best.description || "", g: /ممثلة|فنانة|مغنية|مذيعة|actress/i.test(best.description || "") ? "f" : "" };
  }
  return null;
}
async function personTMDB(name) {
  const j = await tmdb("/search/person", { query: name, include_adult: "false" });
  const rs = (j && j.results) || [];
  const r = rs.find(x => x.known_for_department === "Acting" && nameMatch(x.name, name)) || rs.find(x => x.known_for_department === "Acting") || rs[0];
  return r ? { img: r.profile_path ? TMDB_IMG + "w185" + r.profile_path : "", tm: r.id, desc: "", g: r.gender === 1 ? "f" : r.gender === 2 ? "m" : "" } : null;
}
async function worksTMDB(id) {
  const j = await tmdb("/person/" + id + "/combined_credits", {});
  const seen = new Set();
  return ((j && j.cast) || [])
    .filter(c => !(c.genre_ids || []).some(g => g === 10767 || g === 10763) && !/^(himself|herself|self|نفسه|نفسها)\b/i.test(String(c.character || "").trim()))
    .map(c => ({ t: String(c.title || c.name || "").trim(), ot: String(c.original_title || c.original_name || "").trim(), y: String(c.release_date || c.first_air_date || "").slice(0, 4), s: c.media_type === "tv" ? 1 : 0, p: c.poster_path ? TMDB_IMG + "w185" + c.poster_path : "", pop: +c.popularity || 0 }))
    .filter(w => w.t && !seen.has(w.s + normP(w.t)) && seen.add(w.s + normP(w.t)))
    .sort((a, b) => (b.y || "0").localeCompare(a.y || "0") || b.pop - a.pop);
}
async function worksWiki(qid) {
  if (!/^Q\d+$/.test(qid || "")) return [];
  const rows = await sparql("SELECT ?w ?ar ?en (MIN(?yy) AS ?y) (MAX(?tv0) AS ?tv) (SAMPLE(?im) AS ?img) WHERE { ?w wdt:P161 wd:" + qid + " . " +
    "OPTIONAL { ?w rdfs:label ?ar . FILTER(LANG(?ar) = \"ar\") } OPTIONAL { ?w rdfs:label ?en . FILTER(LANG(?en) = \"en\") } " +
    "OPTIONAL { ?w wdt:P577|wdt:P580 ?d . BIND(YEAR(?d) AS ?yy) } " +
    "OPTIONAL { ?w wdt:P31 ?t . BIND(IF(?t IN (wd:Q5398426, wd:Q1259759, wd:Q526877, wd:Q63952888, wd:Q117467246, wd:Q15416), 1, 0) AS ?tv0) } " +
    "OPTIONAL { ?w wdt:P3383|wdt:P18 ?im } } GROUP BY ?w ?ar ?en LIMIT 400");
  const seen = new Set();
  return rows.map(r => ({ t: sv(r, "ar") || sv(r, "en"), ot: sv(r, "en"), y: String(sv(r, "y")).slice(0, 4), s: sv(r, "tv") === "1" ? 1 : 0, p: commonsImg(sv(r, "img"), 185) }))
    .filter(w => w.t && !/^Q\d+$/.test(w.t) && !seen.has(normP(w.t)) && seen.add(normP(w.t)))
    .sort((a, b) => (b.y || "0").localeCompare(a.y || "0"));
}
async function castWiki(title, year, series) {
  const t = cleanWork(title), lang = isArS(t) ? "ar" : "en";
  if (!t) return [];
  const pages = await wpSearch(lang, t + (lang === "ar" ? (series ? " مسلسل" : " فيلم") : (series ? " TV series" : " film")), 5);
  const y = String(year || "").slice(0, 4);
  const best = pages.filter(p => WORK_RE.test(p.description || "") && workHit(stripParen(p.title), t))
    .sort((a, b) => (y && String(b.description || "").includes(y) ? 1 : 0) - (y && String(a.description || "").includes(y) ? 1 : 0))[0];
  const qid = best && best.pageprops && best.pageprops.wikibase_item;
  if (!/^Q\d+$/.test(qid || "")) return [];
  const rows = await sparql("SELECT ?p ?ar ?en (SAMPLE(?im) AS ?img) WHERE { wd:" + qid + " wdt:P161 ?p . " +
    "OPTIONAL { ?p rdfs:label ?ar . FILTER(LANG(?ar) = \"ar\") } OPTIONAL { ?p rdfs:label ?en . FILTER(LANG(?en) = \"en\") } " +
    "OPTIONAL { ?p wdt:P18 ?im } } GROUP BY ?p ?ar ?en LIMIT 30");
  return rows.map(r => ({ n: sv(r, lang) || sv(r, "ar") || sv(r, "en"), img: commonsImg(sv(r, "img"), 300), wd: sv(r, "p").split("/").pop() })).filter(x => x.n && !/^Q\d+$/.test(x.n)).slice(0, 16);
}
async function castTMDB(title, oname, year, series) {
  const y = String(year || "").slice(0, 4);
  for (const kind of series ? ["tv", "movie"] : ["movie", "tv"]) {
    for (const q of [cleanWork(title), cleanWork(oname)].filter((x, i, a) => x && a.indexOf(x) === i)) {
      const p = { query: q };
      if (/^\d{4}$/.test(y)) p[kind === "tv" ? "first_air_date_year" : "year"] = y;
      let r = ((await tmdb("/search/" + kind, p)).results || [])[0];
      if (!r && p.query && y) r = ((await tmdb("/search/" + kind, { query: q })).results || [])[0];
      if (!r) continue;
      const c = await tmdb("/" + kind + "/" + r.id + (kind === "tv" ? "/aggregate_credits" : "/credits"), {});
      return ((c && c.cast) || []).slice(0, 16).map(x => ({ n: x.name, img: x.profile_path ? TMDB_IMG + "w185" + x.profile_path : "", tm: x.id }));
    }
  }
  return [];
}
const pplKey = n => (tmdbKey() ? "t:" : "w:") + normP(n);

const H = {
  async init() {
    return { portals: DB.portals.map(pub), activeId: DB.activeId || null, settings: DB.settings, version: APP_VERSION };
  },

  async savePortal({ portal }) {
    const url = normUrl(portal.url), mac = normMac(portal.mac);
    if (!url || !parseUrl(url)) throw new Error("رابط البوابة غير صحيح");
    if (!mac) throw new Error("عنوان MAC غير صحيح — 12 خانة مثل 00:1A:79:12:34:56");
    const t = v => String(v || "").trim();
    const clean = { id: portal.id || ("p" + Date.now().toString(36)), name: t(portal.name) || hostOf(url), url, mac, sn: t(portal.sn), id1: t(portal.id1), id2: t(portal.id2), sig: t(portal.sig) };
    const i = DB.portals.findIndex(p => p.id === clean.id);
    if (i >= 0) { if (DB.portals[i].url === url) clean.api = DB.portals[i].api; DB.portals[i] = clean; }
    else DB.portals.push(clean);
    try { FM.remove(fp("live_" + clean.id + ".json")); } catch (e) {}
    saveDB();
    return { portals: DB.portals.map(pub), id: clean.id };
  },

  async deletePortal({ id }) {
    DB.portals = DB.portals.filter(p => p.id !== id);
    delete DB.user[id];
    try { const f = fp("live_" + id + ".json"); if (FM.fileExists(f)) FM.remove(f); } catch (e) {}
    if (DB.activeId === id) { DB.activeId = null; ST = null; MEM = freshMem(); }
    saveDB();
    return { portals: DB.portals.map(pub), activeId: DB.activeId || null };
  },

  async connect({ id }) {
    const p = DB.portals.find(x => x.id === id);
    if (!p) throw new Error("البوابة غير موجودة");
    const run = (async () => {
      const s = new Stalker(p);
      await s.auth();
      const genres = await s.liveGenres().catch(() => null);
      if ((!genres || !genres.length) && String(s.profile && s.profile.status) === "1")
        throw new Error("رفضت البوابة هذا الـ MAC — غير مفعّل أو الاشتراك منتهي");
      return { s, genres };
    })();
    STP = run.then(x => x.s);
    STP.catch(() => {});
    try {
      const { s, genres } = await run;
      ST = s; MEM = freshMem(); MEM.genres = genres;
      DB.activeId = id; p.api = s.api; saveDB();
      setTimeout(() => { try { if (ST === s) liveIndex(s, false); } catch (e) {} }, 4000);   // تسخين فهرس القنوات في الخلفية: البحث يصير فورياً
      const u = userData(id);
      return { portal: pub(p), genres: genres || [], favs: u.favs, recent: u.recent, pm: u.pm || {}, pos: u.pos || {}, done: u.done || {}, hasCache: FM.fileExists(fp("live_" + id + ".json")) };
    } finally { STP = null; }
  },

  async account() {
    const s = await needST();
    const a = await s.account();
    const p = activePortal();
    if (p) { p.account = a; saveDB(); }
    return a;
  },

  async liveQuick({ genre }) {
    const s = await needST();
    const pages = await Promise.all([1, 2, 3].map(n => s.channelsPage(genre, n).catch(() => ({ items: [] }))));
    const seen = {};
    return [].concat(...pages.map(x => x.items)).map(c => s.slimCh(c)).filter(c => c.name && !seen[c.id] && (seen[c.id] = 1));
  },

  async translate({ texts, to }) {
    to = to || "ar";
    const C = trCache();
    let dirty = false;
    const out = await mapLimit(texts || [], 4, async t => {
      t = String(t || "").trim();
      if (!t) return "";
      const k = to + ":" + md5(unescape(encodeURIComponent(t)));
      if (C[k]) return C[k];
      const r = new Request("https://translate.googleapis.com/translate_a/single?client=gtx&ie=UTF-8&oe=UTF-8&dt=t&sl=auto&tl=" + to + "&q=" + encodeURIComponent(t.slice(0, 4000)));
      r.timeoutInterval = 12;
      const j = JSON.parse(await r.loadString());
      if (j && j[2] === to) { C[k] = t; dirty = true; return t; }
      const res = ((j && j[0]) || []).map(x => (x && x[0]) || "").join("").trim();
      if (res) { C[k] = res; dirty = true; }
      return res || t;
    });
    if (dirty) {
      const keys = Object.keys(C);
      if (keys.length > 5000) keys.slice(0, 1500).forEach(k => delete C[k]);
      saveJSON("tr.json", C);
    }
    return out.map((x, i) => x == null ? String(texts[i] || "") : x);
  },

  // ترجمة سطور الترجمة دفعة واحدة (طلب واحد لكل ~25 سطراً) مع ذاكرة مؤقتة في الجلسة
  async trSubs({ texts, to }) {
    to = to || "ar";
    const C = MEM.subTr || (MEM.subTr = {});
    const src = (texts || []).map(t => String(t || "").replace(/\s*\n\s*/g, " ").trim());
    const out = src.map(t => (t ? C[to + "|" + t] : "") || null);
    const need = []; src.forEach((t, i) => { if (out[i] == null && t) need.push(i); });
    const chunks = []; let ch = [], len = 0;
    for (const i of need) { if (ch.length && (len + src[i].length > 1400 || ch.length >= 25)) { chunks.push(ch); ch = []; len = 0; } ch.push(i); len += src[i].length + 1; }
    if (ch.length) chunks.push(ch);
    await mapLimit(chunks, 2, async c => {
      const lines = c.map(i => src[i]);
      let parts = null;
      try {
        const r = new Request("https://translate.googleapis.com/translate_a/single?client=gtx&ie=UTF-8&oe=UTF-8&dt=t&sl=auto&tl=" + to + "&q=" + encodeURIComponent(lines.join("\n")));
        r.timeoutInterval = 15;
        const j = JSON.parse(await r.loadString());
        const full = ((j && j[0]) || []).map(x => (x && x[0]) || "").join("");
        parts = full.split("\n").map(x => x.trim());
        if (parts.length !== lines.length) parts = null;
      } catch (e) {}
      if (!parts) parts = await H.translate({ texts: lines, to });
      c.forEach((i, k) => { out[i] = parts[k] || src[i]; C[to + "|" + src[i]] = out[i]; });
    });
    const keys = Object.keys(C); if (keys.length > 6000) keys.slice(0, 2000).forEach(k => delete C[k]);
    return out.map((x, i) => x == null ? src[i] : x);
  },

  // ترجمة قوائم قصيرة (أسماء أقسام/عناوين) دفعة واحدة مع حفظ دائم في tr.json
  async trList({ texts, to }) {
    to = to || "ar";
    const C = trCache();
    const src = (texts || []).map(t => String(t || "").replace(/\s*\n\s*/g, " ").trim());
    const key = t => to + ":" + md5(unescape(encodeURIComponent(t)));
    const out = src.map(t => (t ? C[key(t)] : "") || (t ? null : ""));
    const need = [], seen = {};
    src.forEach((t, i) => { if (out[i] == null && !seen[t]) { seen[t] = 1; need.push(i); } });
    const chunks = []; let ch = [], len = 0;
    for (const i of need) { if (ch.length && (len + src[i].length > 1200 || ch.length >= 30)) { chunks.push(ch); ch = []; len = 0; } ch.push(i); len += src[i].length + 1; }
    if (ch.length) chunks.push(ch);
    let dirty = false;
    await mapLimit(chunks, 2, async c => {
      const lines = c.map(i => src[i]);
      let parts = null;
      try {
        const r = new Request("https://translate.googleapis.com/translate_a/single?client=gtx&ie=UTF-8&oe=UTF-8&dt=t&sl=auto&tl=" + to + "&q=" + encodeURIComponent(lines.join("\n")));
        r.timeoutInterval = 15;
        const j = JSON.parse(await r.loadString());
        const full = ((j && j[0]) || []).map(x => (x && x[0]) || "").join("");
        parts = full.split("\n").map(x => x.trim());
        if (parts.length !== lines.length) parts = null;
      } catch (e) {}
      let ok = true;
      if (!parts) { try { parts = await H.translate({ texts: lines, to }); } catch (e) { parts = lines; ok = false; } }
      c.forEach((i, k) => { const v = parts[k] || src[i]; if (ok) { C[key(src[i])] = v; dirty = true; } else out[i] = v; });
    });
    if (dirty) {
      const keys = Object.keys(C);
      if (keys.length > 8000) keys.slice(0, 2500).forEach(k => delete C[k]);
      saveJSON("tr.json", C);
    }
    return src.map((t, i) => out[i] != null ? out[i] : (t ? C[key(t)] || t : ""));
  },

  async liveInit({ force }) {
    const s = await needST();
    const p = activePortal(), key = "live_" + p.id + ".json";
    if (!force && MEM.liveRaw) return { __raw: MEM.liveRaw };
    if (!force) {
      try {
        const f = fp(key);
        if (FM.fileExists(f)) {
          const raw = FM.readString(f) || "";
          const ts = +((raw.match(/^\{"ts":(\d+)/) || [])[1] || 0);
          if (raw.length > BIG_BYTES) FM.remove(f);   // قائمة ضخمة قديمة → نستخدم التحميل حسب القسم
          else if (ts && Date.now() - ts < CACHE_TTL && /"data":\{/.test(raw.slice(0, 40))) { MEM.liveRaw = raw; return { __raw: raw }; }
        }
      } catch (e) {}
    }
    const genres = (!force && MEM.genres) || await s.liveGenres();
    let chans = null, total = 0;
    try { total = (await s.channelsPage("*", 1)).total || 0; } catch (e) {}
    crumb("channels total=" + total, true);
    MEM.liveTotal = total;
    if (total <= BIG_CHANNELS) {
      try { chans = await s.allChannels(); } catch (e) { console.warn("get_all_channels: " + e.message); }
    }
    let data = chans && chans.length
      ? { mode: "all", genres, channels: chans.map(c => s.slimCh(c)).filter(c => c.name) }
      : { mode: "paged", genres, channels: [] };
    chans = null;
    const raw = JSON.stringify({ ts: Date.now(), data });
    const paged = data.mode === "paged";
    data = null;
    MEM.liveRaw = raw; MEM.genre = {};
    if (!paged) { try { FM.writeString(fp(key), raw); } catch (e) {} }
    return { __raw: raw };
  },

  // ── البحث في كل القنوات (حتى لو القائمة ضخمة وتُحمّل قسماً قسماً)
  async liveSearch({ q, build, quick }) {
    const s = await needST();
    q = String(q || "").trim();
    if (quick) {   // فوري بلا شبكة: الفهرس إن وُجد (ذاكرة/ملف)، وإلا القنوات الرياضية + ما وصل من الفهرس حتى الآن
      const i0 = await liveIndex(s, false);
      const pool = i0 ? i0.items : [].concat(MEM.idxPart || [], (MEM.sports && MEM.sports.all) || []);
      const seenQ = {};
      return { items: q ? searchChannels(i0 ? pool : pool.filter(c => c && !seenQ[c.id] && (seenQ[c.id] = 1)), q, 300) : [], total: pool.length, ready: !!i0 };
    }
    const idx = await liveIndex(s, !!build);
    if (!q) return { items: [], total: idx ? idx.items.length : 0, ready: !!idx };
    if (idx) return { items: searchChannels(idx.items, q, 300), total: idx.items.length, ready: true };
    // الفهرس غير جاهز: نجرب بحث الخادم مباشرة
    return { items: await serverSearch(s, q), total: 0, ready: false };
  },

  async liveGenre({ genre, force }) {
    const s = await needST();
    if (!force && MEM.genre[genre]) return MEM.genre[genre];
    const first = await s.channelsPage(genre, 1);
    let items = first.items;
    const pages = Math.min(first.pages, 60);
    for (let p = 2; p <= pages; p += 6) {
      const batch = [];
      for (let k = p; k < p + 6 && k <= pages; k++) batch.push(s.channelsPage(genre, k).catch(() => ({ items: [] })));
      (await Promise.all(batch)).forEach(r => { items = items.concat(r.items); });
    }
    const seen = {};
    const out = items.map(c => s.slimCh(c)).filter(c => c.name && !seen[c.id] && (seen[c.id] = 1));
    MEM.genre[genre] = out;
    return out;
  },

  async epg({ id }) { const s = await needST(); return s.epg(id); },

  async play(o) {
    const s = await needST();
    const r = await resolveLink(s, o, o.pick);
    const raw = r.url;
    if (o.ext && o.ext !== "internal") {
      const mk = PLAYERS[o.ext] || PLAYERS.safari;
      Safari.open(mk(raw));
      return { url: raw, raw, src: r.src, n: r.n, opened: o.ext };
    }
    return { url: o.fmt === "hls" ? toHLS(raw) : raw, raw, src: r.src, n: r.n };
  },

  // مكتبات التشغيل الداخلي (mpegts.js لبث TS و hls.js لبث HLS) — تُحمّل مرة واحدة وتُحفظ على الجهاز
  async lib({ name }) {
    const L = name === "hls"
      ? { file: "hls-1.js", urls: ["https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js", "https://unpkg.com/hls.js@1/dist/hls.min.js"], sig: /Hls/ }
      : { file: "mpegts-1.8.0.js", urls: ["https://cdn.jsdelivr.net/npm/mpegts.js@1.8.0/dist/mpegts.js", "https://unpkg.com/mpegts.js@1.8.0/dist/mpegts.js", "https://cdn.jsdelivr.net/npm/mpegts.js/dist/mpegts.js"], sig: /mpegts/ };
    const f = fp(L.file);
    try { if (FM.fileExists(f)) { const c = FM.readString(f); if (c && c.length > 50000) return c; } } catch (e) {}
    for (const u of L.urls) {
      try {
        const r = new Request(u);
        r.timeoutInterval = 25;
        const src = await r.loadString();
        if (r.response && r.response.statusCode === 200 && src && src.length > 50000 && L.sig.test(src)) { FM.writeString(f, src); return src; }
      } catch (e) {}
    }
    throw new Error("تعذّر تحميل مكتبة التشغيل — تحقق من الإنترنت");
  },

  // فحص خادم البث: رمز الاستجابة، نوع المحتوى، إذن CORS، التحويل
  async probe({ ts, hls }) {
    const one = (u, method) => {
      const r = new Request(u);
      r.method = method; r.timeoutInterval = 8; r.allowInsecureRequest = true;
      r.headers = { "User-Agent": STB_UA };
      let redir = "";
      r.onRedirect = q => { redir = q.url; return q; };
      const run = (async () => {
        let body = "", err = "";
        try { if (method === "GET") body = String(await r.loadString() || "").slice(0, 70); else await r.load(); }
        catch (e) { err = String((e && e.message) || e); }
        const rs = r.response || {}, h = rs.headers || {};
        const hv = k => { for (const key in h) if (key.toLowerCase() === k) return String(h[key]); return ""; };
        return { status: rs.statusCode || 0, type: hv("content-type"), cors: hv("access-control-allow-origin"), redirect: redir || (rs.url && rs.url !== u ? rs.url : ""), body: body.replace(/\s+/g, " ").trim(), err };
      })();
      return Promise.race([run, sleep(9000).then(() => ({ status: 0, err: "timeout" }))]);
    };
    const out = {};
    if (ts) out.ts = await one(ts, "HEAD");
    if (hls) out.hls = await one(hls, "GET");
    return out;
  },

  // تشغيل الواجهة من نفس عنوان خادم البث لتجاوز حماية CORS في المتصفح
  async useOrigin({ origin, restore }) {
    if (IN_APP) throw new Error("unsupported");
    if (!/^https?:\/\/[^\/?#]+$/i.test(origin || "")) throw new Error("عنوان غير صالح");
    const p = activePortal();
    if (p && userData(p.id).noOrigin === origin) throw new Error("unsupported");
    PENDING = { origin, restore: restore || null };
    return true;
  },
  async reloadApp() { PENDING = { reload: true }; return true; },
  async log({ msg }) { crumb("UI " + msg); return true; },
  // ── المشغل داخل صفحة التطبيق (بعد نقل التطبيق إلى عنوان خادم البث)
  async streamInfo(o) {
    const it = { cmd: o.cmd, series: o.series || "", tmp: o.tmp, lb: o.lb };
    const R = await resolveStream(o.kind || "itv", it, { pick: o.pick || 0, resolve: !!o.resolve, key: o.key, startAt: o.startAt, noResume: !!o.noResume, own: o.own, force: o.force, here: IN_APP ? "" : o.here || "" });
    MEM.lastStream = { kind: o.kind, url: R.url, info: R.info, fmt: R.fmt };
    const cached = !!libCached("mpegts");
    if (!cached) libSoon("mpegts");
    return { url: R.url, origin: R.origin, fmt: R.fmt, hls: R.hls, opts: R.opts, mtsCached: cached };
  },
  async moveApp({ origin, restore }) {
    if (IN_APP) throw new Error("unsupported");
    if (!/^https?:\/\/[^\/?#]+$/i.test(origin || "")) throw new Error("عنوان غير صالح");
    PENDING = { move: { origin, restore: restore || null } };
    return true;
  },
  async playState({ kind, eng }) {
    const p = activePortal(); if (!p) return false;
    const u = userData(p.id), key = "fsp:0";
    let ch = false;
    if (!u.pm || u.pm[kind] !== key) { u.pm = Object.assign({}, u.pm || {}, { [kind]: key }); ch = true; }
    if ((eng === "own" || eng === "mts") && u.tsEng !== eng) { u.tsEng = eng; ch = true; }
    if (ch) saveDB();
    crumb("in-page playing " + kind + " " + (eng || ""));
    return true;
  },
  // ما يُشغَّل الآن (في الذاكرة فقط): إن أغلق النظام الصفحة أثناء التشغيل نكمله تلقائياً
  async nowPlaying(a) { NOWPLAY = a && a.on !== false && a.item ? { t: a.t, item: a.item, label: a.label || "", at: Date.now() } : null; return ""; },
  async savePos({ kind, key, t, d, end }) {
    const p = activePortal(); if (!p || !key || kind === "itv") return false;
    posPut(userData(p.id), kind + ":" + String(key).slice(0, 120), t, d, end);
    saveDB();
    return true;
  },
  // «شوهدت» يدوياً أو إلغاؤها
  async markSeen({ keys, on }) {
    const p = activePortal(); if (!p) return false;
    const u = userData(p.id); u.done = u.done || {}; u.pos = u.pos || {};
    (keys || []).slice(0, 300).forEach(k => { k = String(k).slice(0, 124); if (on) { u.done[k] = Date.now(); delete u.pos[k]; } else delete u.done[k]; });
    saveDB();
    return true;
  },
  async playReport({ kind, name, diag, info }) {
    const L = MEM.lastStream || {}, I = L.info;
    const lines = [APP_NAME + " v" + APP_VERSION + " — تقرير مشغل السهرة (داخل التطبيق)", devInfo(), "النوع: " + kind + " · الصيغة: " + (L.fmt || "?"), "المادة: " + (name || ""), "الرابط: " + maskU(L.url),
      "الخادم: " + (I ? "HEAD " + (I.status || "لا رد") + " · " + (I.type || "-") + (I.len ? " · " + Math.round(I.len / 1048576) + "MB" : "") + (I.redirected ? " · تحويل → " + maskU(I.final) : "") + (I.err ? " · " + I.err.slice(0, 60) : "") : "—"),
      info && Object.keys(info).length ? "الملف: " + Object.keys(info).map(k => k + "=" + info[k]).join(" · ") : ""].concat((diag || []).map(String)).filter(Boolean);
    try { Pasteboard.copy(lines.join("\n")); } catch (e) {}
    return true;
  },

  async playerOpen(o) {
    await needST();
    libSoon("mpegts");
    PENDING = { player: { items: o.items || [], index: o.index || 0, kind: o.kind || "itv", pick: o.pick || 0, cfg: o.cfg || {}, accent: o.accent || "", restore: o.restore || null, meta: o.meta || null, force: o.force || null, wait: !!o.afterFail, rc: 0 } };
    return true;
  },

  // ── جدول المباريات (بيانات 365Scores العامة بالعربي) ──
  async matches({ date, live, major, tz }) {
    tz = tz || "Asia/Riyadh";
    const key = [live ? "live" : date, major ? 1 : 0, tz].join("|"), now = Date.now();
    const c = MTC[key];
    if (c && now - c.at < (live ? 15000 : 40000)) return c.v;
    const q = "appTypeId=5&langId=27&timezoneName=" + encodeURIComponent(tz) + "&userCountryId=122&sports=1";
    let url;
    if (live) url = "https://webws.365scores.com/web/games/current/?" + q;
    else { const [y, m, d] = String(date || "").split("-"); url = "https://webws.365scores.com/web/games/allscores/?" + q + "&startDate=" + d + "/" + m + "/" + y + "&endDate=" + d + "/" + m + "/" + y + (major ? "&onlyMajorGames=true" : "") + "&withTop=true"; }
    let j;
    try {
      const r = new Request(url);
      r.headers = { "User-Agent": IOS_UA, "Accept": "application/json", "Accept-Language": "ar" };
      r.timeoutInterval = 15;
      j = JSON.parse(await r.loadString());
    } catch (e) {
      if (c) return c.v;
      throw new Error("تعذّر تحميل المباريات — تحقق من الإنترنت");
    }
    const countries = {}; (j.countries || []).forEach(x => { countries[x.id] = x.name; });
    const tm = x => ({ id: x.id, n: x.name || "", s: x.score == null ? -1 : x.score, iv: x.imageVersion || 1, w: !!x.isWinner });
    // الأسماء الإنجليزية (للبحث في دليل البرامج وأسماء القنوات)
    let en = {};
    try {
      const r2 = new Request(url.replace("langId=27", "langId=1"));
      r2.headers = { "User-Agent": IOS_UA, "Accept": "application/json" };
      r2.timeoutInterval = 12;
      ((JSON.parse(await r2.loadString()) || {}).games || []).forEach(g => { if (g && g.homeCompetitor) en[g.id] = [g.homeCompetitor.name || "", (g.awayCompetitor || {}).name || ""]; });
    } catch (e) {}
    let games = (j.games || []).filter(g => g && g.homeCompetitor && g.awayCompetitor).map(g => {
      const o = { id: g.id, cid: g.competitionId, t: g.startTime, sg: g.statusGroup, st: g.statusText || "", sst: g.shortStatusText || "",
        gt: g.gameTime, gtd: g.gameTimeDisplay || "", rn: g.roundName || "", cd: g.competitionDisplayName || "", tv: !!g.hasTVNetworks, h: tm(g.homeCompetitor), a: tm(g.awayCompetitor) };
      if (en[g.id]) { o.h.en = en[g.id][0]; o.a.en = en[g.id][1]; }
      return o;
    });
    if (live) games = games.filter(g => g.sg === 3);
    const used = {}; games.forEach(g => { used[g.cid] = 1; });
    const comps = (j.competitions || []).filter(x => used[x.id]).map(x => ({ id: x.id, n: x.name || "", c: countries[x.countryId] || "", cc: x.countryId, r: x.popularityRank || 0, iv: x.imageVersion || 1, intl: !!x.isInternational }));
    const v = { games, comps, at: now };
    MTC[key] = { at: now, v };
    return v;
  },
  // إعدادات خاصة بالبوابة يتعلمها التطبيق (مثل: هل يدعم الخادم HLS)
  async portalFlag({ k, v }) {
    const p = activePortal(); if (!p || !/^(hls|hls2|nts|swap)$/.test(k)) return false;
    if (k === "swap") { const o = {}; Object.keys(v && typeof v === "object" ? v : {}).slice(0, 60).forEach(x => { o[String(x).slice(0, 200)] = v[x] ? 1 : 0; }); userData(p.id).swap = o; saveDB(); crumb("portal swap " + JSON.stringify(o).slice(0, 120), true); return true; }
    userData(p.id)[k] = v ? 1 : 0; saveDB(); crumb("portal " + k + "=" + (v ? 1 : 0), true);
    return true;
  },
  // رابط HLS للبث المباشر عبر تحويل البوابة (بنفس ترويسات الجهاز) ليعمل بمشغل iOS بدون نقل التطبيق
  async hlsLink(o) {
    const s = await needST();
    let r;
    try { r = await resolveLink(s, Object.assign({}, o, { kind: "itv" }), o.pick || 0); } catch (e) { return { url: "" }; }
    const h = toHLS(r.url);
    if (!h || h === r.url || !/m3u8/i.test(h)) { crumb("hls link: no m3u8 form", true); return { url: "", bad: 1 }; }
    let info = null;
    try { info = await headInfo(h); } catch (e) {}
    crumb("hls link " + (info ? info.status + " " + (info.type || "-") + (info.redirected ? " → " + maskU(originOfUrl(info.final)) : "") : "no head"), true);
    if (info && (info.status === 403 || info.status === 404 || info.status === 401 || info.status === 410)) return { url: "", bad: 1 };
    return { url: info && info.redirected && info.final ? info.final : h };
  },
  async matchStop() { MEM.mcGen = (MEM.mcGen || 0) + 1; return true; },
  // ── القناة الناقلة لكل مباراة: من دليل البرامج (EPG) لقنوات الرياضة في اشتراكك + أسماء القنوات + بيانات 365
  async matchChannels({ games }) {
    // مباراة واحدة فتحها المستخدم: فوراً بدون انتظار دور قائمة المباريات
    if ((games || []).length <= 2) return await matchChannelsRun(games);
    // طلب واحد في كل مرة (كانت الطلبات المتزامنة تثقل الجوال)
    const prev = MEM.mcQ || Promise.resolve();
    let done;
    MEM.mcQ = new Promise(r => { done = r; });
    try { await prev; } catch (e) {}
    try { return await matchChannelsRun(games); } finally { done(); }
  },
  // التشكيلة (365Scores بالعربي): الأساسيون بمواقعهم في الملعب + البدلاء + المدرب
  async matchInfo({ id }) {
    const key = "info" + id, c = MTC[key];
    if (c && Date.now() - c.at < (c.v.live ? 60000 : 600000)) return c.v;
    let j;
    try {
      const r = new Request("https://webws.365scores.com/web/game/?appTypeId=5&langId=27&timezoneName=Asia%2FRiyadh&userCountryId=122&gameId=" + encodeURIComponent(id));
      r.headers = { "User-Agent": IOS_UA, "Accept": "application/json", "Accept-Language": "ar" };
      r.timeoutInterval = 15;
      j = JSON.parse(await r.loadString()) || {};
    } catch (e) { if (c) return c.v; throw new Error("تعذّر تحميل التشكيلة — تحقق من الإنترنت"); }
    const g = j.game || {}, M = {};
    (g.members || []).forEach(m => { if (m && m.id != null) M[m.id] = m; });
    const side = comp => {
      const L = comp && comp.lineups;
      if (!L || !Array.isArray(L.members) || !L.members.length) return null;
      const P = x => {
        const m = M[x.id] || {}, y = x.yardFormation || {}, pos = x.position || {}, f = x.formation || {};
        return { n: String(m.name || x.name || "").trim(), sn: String(m.shortName || m.name || "").trim(), num: m.jerseyNumber != null ? m.jerseyNumber : "", aid: m.athleteId || 0, iv: m.imageVersion || 1,
          pos: String(f.name || pos.name || "").trim(), line: +y.line || 0, fp: +y.fieldPosition || 0, fl: y.fieldLine != null ? +y.fieldLine : -1, fs: y.fieldSide != null ? +y.fieldSide : -1, r: x.ranking ? +x.ranking : 0 };
      };
      const st = x => +x.status || 0, txt = x => String(x.statusText || "");
      const coachOf = x => /coach|manag|مدرب/i.test(txt(x) + " " + ((x.position || {}).name || ""));
      const xi = L.members.filter(x => st(x) === 1 && !coachOf(x)).map(P);
      const subs = L.members.filter(x => st(x) === 2 && !coachOf(x)).map(P);
      const coach = L.members.filter(coachOf).map(P)[0] || null;
      return { formation: String(L.formation || ""), status: String(L.status || ""), pos: !!L.hasFieldPositions, xi, subs, coach: coach ? coach.n : "" };
    };
    const v = { live: g.statusGroup === 3, h: side(g.homeCompetitor), a: side(g.awayCompetitor) };
    MTC[key] = { at: Date.now(), v };
    return v;
  },
  // القناة التي اخترتها لشبكة ناقلة (مثل Jordan Sport) → تظهر مباشرة في كل مباراة تنقلها
  async netLearn({ net, ch, gid }) {
    const p = activePortal(); if (!p || (!net && !gid) || !ch || !ch.cmd) return false;
    const u = userData(p.id), v = { id: ch.id, name: ch.name, num: ch.num, cmd: ch.cmd, logo: ch.logo || "", g: ch.g, tmp: ch.tmp, lb: ch.lb, at: Date.now() };
    if (net) { u.net = u.net || {}; u.net[netKey(net)] = v; const ks = Object.keys(u.net); if (ks.length > 80) delete u.net[ks[0]]; }
    else { u.netg = u.netg || {}; u.netg[String(gid)] = v; const ks = Object.keys(u.netg); if (ks.length > 120) delete u.netg[ks[0]]; }
    saveDB();
    return true;
  },
  // أسماء الفريقين بالإنجليزية (للبحث عن قنوات المباراة في الاشتراك)
  async matchEn({ id }) {
    if (MTC["en" + id]) return MTC["en" + id];
    try {
      const r = new Request("https://webws.365scores.com/web/game/?appTypeId=5&langId=1&timezoneName=Asia%2FRiyadh&userCountryId=122&gameId=" + encodeURIComponent(id));
      r.headers = { "User-Agent": IOS_UA, "Accept": "application/json" };
      r.timeoutInterval = 12;
      const g = (JSON.parse(await r.loadString()) || {}).game || {};
      const v = { h: (g.homeCompetitor || {}).name || "", a: (g.awayCompetitor || {}).name || "", venue: ((g.venue || {}).name) || "" };
      MTC["en" + id] = v;
      return v;
    } catch (e) { return { h: "", a: "" }; }
  },

  async ytSearch({ q }) {
    const r = new Request("https://www.youtube.com/results?search_query=" + encodeURIComponent(q || "") + "&hl=ar&gl=SA");
    r.headers = { "User-Agent": YT_UA, "Accept-Language": "ar,en;q=0.8" };
    r.timeoutInterval = 15;
    const html = await r.loadString();
    const m = html.match(/var ytInitialData\s*=\s*(\{[\s\S]*?\});\s*<\/script>/) || html.match(/ytInitialData"\]\s*=\s*(\{[\s\S]*?\});/);
    if (!m) throw new Error("تعذّر جلب نتائج يوتيوب — حاول مرة أخرى");
    const vr = [];
    ytCollect(JSON.parse(m[1]), vr, 0);
    const seen = {};
    return vr.filter(v => !seen[v.videoId] && (seen[v.videoId] = 1)).slice(0, 40).map(v => {
      const live = JSON.stringify(v.badges || v.thumbnailOverlays || "").indexOf("LIVE") >= 0 && !v.lengthText;
      return { id: v.videoId, title: ytText(v.title), ch: ytText(v.ownerText || v.longBylineText || v.shortBylineText), len: v.lengthText ? ytText(v.lengthText) : "", views: ytText(v.shortViewCountText || v.viewCountText), ago: ytText(v.publishedTimeText), live, thumb: "https://i.ytimg.com/vi/" + v.videoId + "/mqdefault.jpg" };
    });
  },
  async ytPlay({ id, restore }) {
    if (!/^[\w-]{6,20}$/.test(id || "")) throw new Error("رابط فيديو غير صالح");
    PENDING = { yt: id, restore: restore || null };
    return true;
  },

  async copyText({ text }) { Pasteboard.copy(String(text || "")); return true; },

  async copyLink(o) {
    const s = await needST();
    const r = await resolveLink(s, o, o.pick);
    Pasteboard.copy(r.url);
    return { url: r.url };
  },

  async vodCats({ type, force }) {
    const s = await needST();
    if (!force && MEM.cats[type]) return MEM.cats[type];
    const c = await s.categories(type);
    MEM.cats[type] = c;
    return c;
  },
  async vodList({ type, cat, page, q }) {
    const s = await needST();
    return s.items(type, q ? "*" : cat, page || 1, q || "");
  },
  // بحث أذكى: صيغ الكتابة العربية (أ/ا، ة/ه، ى/ي)، جذر الكلمة، والترجمة عربي ↔ إنجليزي — والمحتوى العربي أولاً
  // بحث على مرحلتين: fast = الاسم وصيغ كتابته فقط (فوري)، وبعده الكامل = + الترجمة (لا تؤخر أول النتائج)
  async vodSearch({ type, q, fast }) {
    const s = await needST();
    q = String(q || "").replace(/\s+/g, " ").trim();
    if (!q) return { items: [], page: 1, pages: 1, total: 0 };
    const key = type + ":" + normK(q);
    MEM.vsc = MEM.vsc || {};
    const cf = MEM.vsc[key + "~f"], cu = MEM.vsc[key + "!"];
    if (!fast && cu && Date.now() - cu.at < 300000) return cu.v;
    if (fast && (cu || cf) && Date.now() - (cu || cf).at < 300000) return Object.assign({}, (cu || cf).v, { partial: !cu });
    const ar = isArS(q), nq = normT(q);
    const FS = MEM.vsF || (MEM.vsF = {});
    const st = FS[key] || (FS[key] = { found: new Map(), done: new Set() });
    const qs = new Map();
    const addQ = (x, w) => { x = String(x || "").replace(/\s+/g, " ").trim(); if (x.replace(/\s/g, "").length >= 2 && !qs.has(x)) qs.set(x, w); };
    addQ(q, 3);
    if (ar) { arVariants(q).forEach(v => addQ(v, 3)); const sm = arStem(q); if (sm) addQ(sm, 1); }
    else { const w = q.split(" ").filter(x => x.length >= 4).sort((a, b) => b.length - a.length)[0]; if (w && w !== q) addQ(w, 1); }
    const runQs = list => mapLimit(list.filter(x => !st.done.has(x)), 3, async x => {
      st.done.add(x);
      const maxP = qs.get(x) === 1 ? 3 : 2;
      for (let pg = 1; pg <= maxP; pg++) {
        let r; try { r = await s.items(type, "*", pg, x); } catch (e) { break; }
        (r.items || []).forEach(it => { if (it && it.id != null && !st.found.has(String(it.id))) st.found.set(String(it.id), it); });
        if (pg >= r.pages) break;
      }
    });
    // الترجمة تبدأ بالتوازي مع البحث العادي (مرة واحدة لكل كلمة بحث، محفوظة)
    const trP = fast ? null : Promise.race([H.translate({ texts: [q], to: ar ? "en" : "ar" }), sleep(4500).then(() => [""])]).then(r => String((r || [])[0] || "").trim()).catch(() => "");
    await runQs([...qs.keys()].slice(0, 5));
    let tq = trP ? await trP : "";
    if (tq && normT(tq) !== nq) { addQ(tq, 2); await runQs([tq]); } else tq = "";
    const ntq = normT(tq), words = nq.split(" ").filter(w => w.length > 1), twords = ntq.split(" ").filter(w => w.length > 2);
    const hit = (t, x) => !t || !x ? 0 : t === x ? 100 : t.startsWith(x) ? 72 : t.includes(x) ? 52 : 0;
    const allIn = (ws, t) => ws.length > 1 && !!t && ws.every(w => t.includes(w));
    const score = it => {
      const nm = normT(cleanWork(it.name)), on = normT(it.oname || "");
      let sc = Math.max(hit(nm, nq), hit(on, nq));
      if (!sc && ntq) sc = Math.max(hit(nm, ntq), hit(on, ntq)) * 0.85;
      if (!sc && (allIn(words, nm) || allIn(words, on))) sc = 34;
      if (!sc && (allIn(twords, nm) || allIn(twords, on))) sc = 28;
      if (!sc) return 0;   // نتائج «الجذر» التي لا تحتوي كلماتك لا تظهر
      if (isArItem(it)) sc += 24;
      return sc;
    };
    const items = [...st.found.values()].map(it => ({ it, sc: score(it) })).filter(x => x.sc > 0)
      .sort((a, b) => b.sc - a.sc || String(b.it.year || "").localeCompare(String(a.it.year || ""))).map(x => x.it).slice(0, 160);
    const v = { items, page: 1, pages: 1, total: items.length, tq, ar: items.filter(isArItem).length };
    MEM.vsc[key + (fast ? "~f" : "!")] = { at: Date.now(), v };
    const ks = Object.keys(MEM.vsc); if (ks.length > 80) delete MEM.vsc[ks[0]];
    const fk = Object.keys(FS); if (fk.length > 40) delete FS[fk[0]];
    crumb("vod search " + (fast ? "fast " : "") + type + " «" + q.slice(0, 30) + "» q=" + qs.size + " found=" + st.found.size + " shown=" + items.length + (tq ? " tr=" + tq.slice(0, 30) : ""), true);
    return fast ? Object.assign({}, v, { partial: true }) : v;
  },
  async seasons({ type, id }) { const s = await needST(); return s.seasons(type, id); },
  async episodes({ type, id, season }) { const s = await needST(); return s.episodes(type, id, season); },

  async saveUser({ favs, recent, pm }) {
    if (!DB.activeId) return false;
    const u = userData(DB.activeId);
    if (pm) u.pm = Object.assign({}, u.pm || {}, pm);
    if (favs) u.favs = favs;
    if (recent) u.recent = recent.slice(0, 40);
    saveDB();
    return true;
  },
  async setSettings({ settings }) {
    DB.settings = Object.assign({}, DB.settings, settings || {});
    // إعادة تفعيل "التشغيل من خادم البث" تسمح بالمحاولة من جديد
    if (settings && settings.sameOrigin === true) { const p = activePortal(); if (p) delete userData(p.id).noOrigin; }
    saveDB();
    return DB.settings;
  },
  async clearCache() {
    for (const p of DB.portals) { try { const f = fp("live_" + p.id + ".json"); if (FM.fileExists(f)) FM.remove(f); } catch (e) {} }
    try { if (FM.fileExists(fp("tr.json"))) FM.remove(fp("tr.json")); } catch (e) {}
    TRC = null;
    MEM = freshMem();
    return true;
  },
  // ── الممثلون: صورهم (دفعة واحدة) ثم صفحة الممثل مع أعماله الموجودة في الاشتراك
  async people({ names }) {
    const d = pplDB(), useTM = !!tmdbKey();
    const list = (Array.isArray(names) ? names : []).map(x => String(x || "").trim()).filter(Boolean).slice(0, 16);
    const out = await mapLimit(list, 4, async n => {
      const k = pplKey(n);
      let e = d.n[k];
      if (!freshE(e, 60, 7)) {
        let r;
        try {
          r = useTM ? await personTMDB(n) : await personWiki(n);
          if (useTM && (!r || !r.img)) { const w = await personWiki(n).catch(() => null); if (w) r = Object.assign({}, w, r ? { tm: r.tm } : {}); }
        } catch (x) { return { n, k, img: (e && e.img) || "" }; }   // لا إنترنت: لا نحفظ «لا توجد صورة»
        e = d.n[k] = Object.assign({ t: Date.now(), name: n }, r || { img: "" });
      }
      return { n, k, img: e.img || "", desc: e.desc || "" };
    });
    pplSave();
    return { list: out.filter(Boolean) };
  },
  // طاقم العمل عندما لا تعطيه البوابة
  async castOf({ name, oname, year, series }) {
    const d = pplDB(), useTM = !!tmdbKey();
    const key = (useTM ? "t:" : "w:") + normP(cleanWork(name)) + ":" + String(year || "").slice(0, 4) + (series ? ":s" : "");
    let e = d.c[key];
    if (!freshE(e, 30, 3)) {
      let list;
      try { list = useTM ? await castTMDB(name, oname, year, series) : await castWiki(name, year, series); } catch (x) { return { list: (e && e.list) || [] }; }
      e = d.c[key] = { t: Date.now(), ok: list.length ? 1 : 0, list };
      list.forEach(p => { const k = pplKey(p.n); if (!freshE(d.n[k], 60, 7) || !d.n[k].img) d.n[k] = { t: Date.now(), name: p.n, img: p.img || "", tm: p.tm, wd: p.wd, desc: "" }; });
      pplSave();
    }
    return { list: (e.list || []).map(p => ({ n: p.n, img: p.img || "", k: pplKey(p.n) })) };
  },
  async person({ n, k }) {
    const d = pplDB(), name = String(n || "").trim();
    if (!name) throw new Error("اسم غير صالح");
    k = k || pplKey(name);
    if (!d.n[k]) { try { await H.people({ names: [name] }); } catch (x) {} }
    const e = d.n[k] || d.n[pplKey(name)] || {};
    // 1) أعماله من TMDB أو ويكي بيانات (محفوظة أسبوعاً)
    const wk = e.tm ? "t" + e.tm : e.wd ? "w" + e.wd : "";
    let works = [];
    if (wk) {
      const c = d.w[wk];
      if (c && Date.now() - c.t < 7 * 864e5) works = c.list || [];
      else {
        try { works = e.tm ? await worksTMDB(e.tm) : await worksWiki(e.wd); d.w[wk] = { t: Date.now(), list: works }; }
        catch (x) { works = (c && c.list) || []; }
      }
    }
    // 2) الموجود منها في الاشتراك
    const s = await needST();
    const found = [], seen = new Set(), got = new Set();
    const add = (it, w) => { if (!it || seen.has(it.type + ":" + it.id)) return; seen.add(it.type + ":" + it.id); if (w) got.add(normP(w.t)); found.push({ item: it, w: w ? w.t : "" }); };
    const types = ["vod", "series"];
    // أ) بحث البوابة باسم الممثل (بعض البوابات تبحث في طاقم العمل أيضاً)
    await mapLimit(types, 2, async type => {
      let r; try { r = await s.items(type, "*", 1, name); } catch (x) { return; }
      (r.items || []).forEach(it => {
        const w = works.find(x => workHit(it.name, x.t) || (x.ot && workHit(it.name, x.ot)));
        if (w || (it.actors && normP(it.actors).includes(normP(name)))) add(it, w);
      });
    });
    // ب) كل عمل باسمه (العربي ثم الأصلي) — الأحدث أولاً
    await mapLimit(works.slice(0, 14), 3, async w => {
      if (got.has(normP(w.t))) return;
      const qs = [w.t, w.ot].map(cleanWork).filter((x, i, a) => x && x.replace(/\s/g, "").length >= 2 && a.indexOf(x) === i);
      for (const q of qs) {
        for (const type of w.s ? ["series", "vod"] : ["vod", "series"]) {
          let r; try { r = await s.items(type, "*", 1, q); } catch (x) { continue; }
          const hits = (r.items || []).filter(it => workHit(it.name, q) || (it.oname && workHit(it.oname, q))).slice(0, 3);
          hits.forEach(it => add(it, w));
          if (hits.length) return;
        }
      }
    });
    pplSave();
    found.sort((a, b) => String(b.item.year || "").localeCompare(String(a.item.year || "")));
    return { n: name, img: e.img || "", desc: e.desc || "", g: e.g || "", src: e.tm ? "tmdb" : e.wd ? "wiki" : "", found: found.slice(0, 60),
      works: works.slice(0, 40).map(w => Object.assign({}, w, { has: got.has(normP(w.t)) ? 1 : 0 })) };
  },
  async open({ url }) { Safari.open(url); return true; }
};

/* ───────────────────────── يوتيوب (تخطي الإعلانات تلقائياً) ───────────────────────── */
const YT_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15";
const ytText = x => !x ? "" : (x.simpleText || (Array.isArray(x.runs) ? x.runs.map(r => r.text).join("") : "")).trim();
function ytCollect(node, out, depth) {
  if (!node || typeof node !== "object" || depth > 40 || out.length >= 60) return;
  if (Array.isArray(node)) { for (const n of node) ytCollect(n, out, depth + 1); return; }
  if (node.videoRenderer && node.videoRenderer.videoId) out.push(node.videoRenderer);
  for (const k in node) if (k !== "videoRenderer") ytCollect(node[k], out, depth + 1);
}
// يُحقن في صفحة يوتيوب: يتخطى الإعلانات ويخفيها + زر رجوع للسهرة
const YT_JS = `(function () {
  if (window.__alsahraYT) return 0;
  window.__alsahraYT = 1;
  var css = document.createElement("style");
  css.textContent = "ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytm-ad-slot-renderer,ytm-display-ad-renderer,ytm-mealbar-promo-renderer,ytm-banner-promo-renderer,ytm-statement-banner-renderer,ytm-paid-content-overlay-renderer,.ytp-ad-overlay-container,.ytp-ad-image-overlay,.ad-container,#player-ads,.masthead-ad,ytm-promoted-sparkles-text-search-renderer{display:none!important}" +
    "#alsahra-back{position:fixed;z-index:2147483647;top:calc(env(safe-area-inset-top) + 6px);left:50%;transform:translateX(-50%);background:rgba(10,10,10,.88);color:#fff;font:700 14px -apple-system,system-ui;padding:9px 16px;border-radius:999px;border:1px solid rgba(255,255,255,.18);box-shadow:0 6px 20px rgba(0,0,0,.4);direction:rtl}" +
    "#alsahra-badge{position:fixed;z-index:2147483646;bottom:calc(env(safe-area-inset-bottom) + 70px);left:50%;transform:translateX(-50%);background:#16a34a;color:#fff;font:700 12px -apple-system,system-ui;padding:6px 12px;border-radius:999px;opacity:0;transition:opacity .3s;pointer-events:none;direction:rtl}";
  (document.head || document.documentElement).appendChild(css);
  var back = document.createElement("div");
  back.id = "alsahra-back"; back.textContent = "‹ رجوع إلى السهرة";
  back.onclick = function () { window.__alsahraBack = 1; back.textContent = "جاري الرجوع…"; };
  var badge = document.createElement("div");
  badge.id = "alsahra-badge"; badge.textContent = "⚡ تم تخطي إعلان";
  var mount = function () { if (document.body && !document.getElementById("alsahra-back")) { document.body.appendChild(back); document.body.appendChild(badge); } };
  mount();
  var skipped = 0, inAd = false;
  setInterval(function () {
    mount();
    var p = document.querySelector(".html5-video-player");
    var v = document.querySelector("video");
    var ad = !!(p && (p.classList.contains("ad-showing") || p.classList.contains("ad-interrupting")));
    if (v && ad) {
      if (!inAd) { inAd = true; v.__alsMuted = v.muted; }
      v.muted = true;
      try { if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.3) v.currentTime = v.duration - 0.1; } catch (e) {}
      try { v.playbackRate = 16; } catch (e) {}
    } else if (v && inAd) {
      inAd = false; v.muted = !!v.__alsMuted; try { v.playbackRate = 1; } catch (e) {}
      skipped++; badge.textContent = "⚡ تم تخطي " + (skipped > 1 ? skipped + " إعلانات" : "إعلان");
      badge.style.opacity = 1; setTimeout(function () { badge.style.opacity = 0; }, 1800);
    }
    var b = document.querySelectorAll(".ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button");
    for (var i = 0; i < b.length; i++) try { b[i].click(); } catch (e) {}
  }, 300);
  return 1;
})()`;

/* ───────────────────────── مشغل السهرة (ملء الشاشة على عنوان خادم البث) ───────────────────────── */
// تعمل داخل صفحة على خادم البث نفسه → طلب TS من نفس العنوان → لا حجب CORS
function alsahraPlayerMain() {
  if (window.__alsahraP) return 1;
  if (!window.AlsahraBox) return 0;
  var P = window.__alsahraP = { q: [], o: {} };
  P.take = function () { return P.q.length ? JSON.stringify(P.q.splice(0)) : ""; };
  function send(o) { P.q.push(o); }
  try { window.stop(); } catch (e) {}
  var css = "*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}" +
    "html,body{height:100%;background:#0b0b10;color:#fff;font-family:-apple-system,system-ui,sans-serif;-webkit-user-select:none;user-select:none}" +
    ":root{--a:#e50914}#pg{position:fixed;inset:0;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#0b0b10;padding-bottom:calc(env(safe-area-inset-bottom) + 28px)}" +
    "#pg button{font:inherit;color:#fff;border:0;background:rgba(255,255,255,.12);height:44px;padding:0 13px;border-radius:14px;font-weight:700;font-size:14px;white-space:nowrap;flex:none}" +
    "#pg button:active{transform:scale(.96)}#pg button:disabled{opacity:.35}" +
    // الرأس يبدأ تحت شريط Scriptable العلوي (إغلاق/مشاركة) حتى لا يختفي زر الرجوع خلفه
    "#hd{display:flex;align-items:center;gap:10px;padding:calc(env(safe-area-inset-top) + 60px) 14px 2px}#hd button{height:40px}" +
    "#tt{flex:1;min-width:0}#tt b{display:block;font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#tt small{display:block;font-size:12px;color:#aaa;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
    "#sb::after{content:attr(data-e);color:#777}" +
    "#boxw{position:sticky;top:0;z-index:5;margin:8px 12px;aspect-ratio:16/9;border-radius:18px;overflow:hidden;background:#000;box-shadow:0 12px 30px rgba(0,0,0,.55)}" +
    "#info{padding:4px 14px}" +
    "#acts{display:flex;gap:8px;margin:4px 0 12px}#acts button{flex:1;min-width:0}#vlc{background:#f97316!important}.single #pv,.single #nx{display:none}" +
    "#desc{font-size:13.5px;color:#b9b9c2;line-height:1.85;margin-bottom:12px;display:none}" +
    "#lt{font-weight:800;font-size:16px;margin:6px 2px 10px;display:none}" +
    ".it{display:flex;align-items:center;gap:12px;padding:9px;border-radius:14px;background:rgba(255,255,255,.05);margin-bottom:8px}" +
    ".it.on{background:rgba(255,255,255,.1);box-shadow:inset 0 0 0 2px var(--a)}" +
    ".it .n{flex:none;width:46px;height:46px;border-radius:12px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;overflow:hidden;color:#ddd}.it .n img{width:100%;height:100%;object-fit:contain}" +
    ".it .x{flex:1;min-width:0}.it b{display:block;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.it small{display:block;font-size:12px;color:#999;margin-top:2px}" +
    ".it.on .n{background:var(--a);color:#fff}" +
    "@media (orientation:landscape) and (max-height:540px){#hd,#info,#setw{display:none}#pg{overflow:hidden;padding:0}#boxw{position:fixed;inset:0;margin:0;border-radius:0;aspect-ratio:auto;z-index:20}}";
  document.documentElement.innerHTML = "<head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover'><meta name='color-scheme' content='dark'><style>" + css + "</style></head><body dir='rtl'>" +
    "<div id='pg'><div id='hd'><button id='bk'>‹ رجوع</button><div id='tt'><b id='nm'></b><small id='sb'></small></div></div><div id='boxw'></div><div id='setw'></div>" +
    "<div id='info'><div id='acts'><button id='pv'>‹ السابق</button><button id='nx'>التالي ›</button><button id='vlc'>VLC</button></div><div id='desc' dir='auto'></div><div id='lt'></div><div id='list'></div></div></div></body>";
  var $ = function (id) { return document.getElementById(id); };
  var B = window.AlsahraBox.create($("boxw"), { send: send, setsHost: $("setw"), info: function (t) { $("sb").setAttribute("data-e", t ? ($("sb").textContent ? " · " : "") + t : ""); } });
  // معرّفات العناصر داخل الصندوق (لهذه الصفحة فقط)
  Array.prototype.forEach.call(document.querySelectorAll("#boxw [data-e], #setw [data-e]"), function (e) { e.id = e.getAttribute("data-e"); });
  Object.defineProperty(P, "state", { get: function () { return B.state; } });
  Object.defineProperty(P, "diag", { get: function () { return B.diag; } });
  P.err = B.err; P.busy = B.busy; P.toast = B.toast; P.trRes = B.trRes;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  $("bk").onclick = function () { B.pos(); B.destroy(); send({ c: "back" }); };
  $("vlc").onclick = function () { B.pos(); send({ c: "vlc" }); };
  $("nx").onclick = function () { B.pos(); send({ c: "next" }); };
  $("pv").onclick = function () { B.pos(); send({ c: "prev" }); };
  $("list").addEventListener("click", function (e) { var it = e.target.closest && e.target.closest(".it"); if (!it) return; var i = +it.getAttribute("data-i"); if (i === P.index) return; B.pos(); send({ c: "goto", i: i }); });
  function renderList(items, meta, vod) {
    P.items = items || [];
    $("lt").style.display = P.items.length > 1 ? "block" : "none";
    $("lt").textContent = vod ? ("الحلقات" + (meta && meta.season ? " — " + meta.season : "")) : "القنوات";
    $("desc").textContent = meta && meta.desc ? meta.desc : "";
    $("desc").style.display = meta && meta.desc ? "block" : "none";
    $("list").innerHTML = P.items.length > 1 ? P.items.map(function (x, i) {
      var badge = !vod && x.l ? "<img src='" + esc(x.l) + "' loading='lazy' onerror='this.remove()'>" : esc(vod ? (i + 1) : (x.u || i + 1));
      return "<div class='it' data-i='" + i + "'><div class='n'>" + badge + "</div><div class='x'><b dir='auto'>" + esc(vod ? (x.s || x.n) : x.n) + "</b>" + (!vod && x.u ? "<small>#" + esc(x.u) + "</small>" : "") + "</div></div>";
    }).join("") : "";
  }
  function markList(i) {
    P.index = i;
    var els = $("list").querySelectorAll(".it");
    for (var k = 0; k < els.length; k++) els[k].classList.toggle("on", k === i);
    var on = els[i];
    if (on && P.items.length > 1) { var y = on.offsetTop - $("boxw").offsetHeight - 70; if (Math.abs($("pg").scrollTop - y) > 300) $("pg").scrollTop = Math.max(0, y); }
  }
  P.play = function (url, title, sub, cfg, hls, accent, o) {
    o = o || {};
    var vod = (o.kind || "itv") !== "itv";
    if (accent) document.documentElement.style.setProperty("--a", accent);
    $("pg").className = vod && !o.eps ? "single" : "";
    $("pv").textContent = vod ? "⏮ السابقة" : "‹ السابق"; $("nx").textContent = vod ? "التالية ⏭" : "التالي ›";
    $("pv").disabled = !!(o.eps && !o.eps.prev); $("nx").disabled = !!(o.eps && !o.eps.next);
    if (o.list) renderList(o.list, o.meta, vod);
    if (o.index != null) markList(o.index);
    $("nm").textContent = title || ""; $("sb").textContent = sub || ""; $("sb").setAttribute("data-e", "");
    return B.play(url, title, sub, hls, accent, o);
  };
  return 1;
}

/* ───────── مشغل MKV: يحوّل ملفات MKV إلى MP4 مجزأ أثناء التحميل ويشغلها داخل الصفحة ─────────
   يعمل داخل صفحة مشغل السهرة (على عنوان خادم البث نفسه) بلا مكتبات خارجية.
   فيديو: H.264 / HEVC — صوت: AAC / AC-3 / E-AC-3 / MP3 — ترجمة: SRT / ASS — يفضّل الصوت والترجمة العربية. */
function alsahraMkvMain() {
  if (window.AlsahraMKV && window.AlsahraTS) return 1;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const te = s => { const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i) & 255; return o; };
  const cat = a => { let n = 0; for (const x of a) n += x.length; const o = new Uint8Array(n); let p = 0; for (const x of a) { o.set(x, p); p += x.length; } return o; };
  const B = a => a instanceof Uint8Array ? a : new Uint8Array(a);
  const u16 = n => [(n >>> 8) & 255, n & 255];
  const u32 = n => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
  const u64 = n => { const hi = Math.floor(n / 4294967296); return u32(hi).concat(u32(n - hi * 4294967296)); };
  const Z = n => new Uint8Array(n);
  function box(t, ...ps) {
    const parts = ps.map(B); let n = 8; for (const p of parts) n += p.length;
    const o = new Uint8Array(n); o.set(u32(n), 0); o.set(te(t), 4);
    let q = 8; for (const p of parts) { o.set(p, q); q += p.length; }
    return o;
  }
  const fbox = (t, v, f, ...ps) => box(t, [v, (f >>> 16) & 255, (f >>> 8) & 255, f & 255], ...ps);
  const MATRIX = [].concat(u32(0x10000), u32(0), u32(0), u32(0), u32(0x10000), u32(0), u32(0), u32(0), u32(0x40000000));

  /* ── MP4 ── */
  function initSeg(t) {
    const v = t.kind === "v";
    const mvhd = fbox("mvhd", 0, 0, u32(0), u32(0), u32(1000), u32(0), u32(0x10000), u16(0x100), Z(10), MATRIX, Z(24), u32(2));
    const tkhd = fbox("tkhd", 0, 3, u32(0), u32(0), u32(1), u32(0), u32(0), Z(8), u16(0), u16(0), u16(v ? 0 : 0x100), u16(0), MATRIX, u32((t.w || 0) * 65536), u32((t.h || 0) * 65536));
    const mdhd = fbox("mdhd", 0, 0, u32(0), u32(0), u32(t.ts), u32(0), u16(0x55c4), u16(0));
    const hdlr = fbox("hdlr", 0, 0, u32(0), te(v ? "vide" : "soun"), Z(12), te(v ? "VideoHandler" : "SoundHandler"), [0]);
    const mh = v ? fbox("vmhd", 0, 1, Z(8)) : fbox("smhd", 0, 0, Z(4));
    const dinf = box("dinf", fbox("dref", 0, 0, u32(1), fbox("url ", 0, 1)));
    const stbl = box("stbl", fbox("stsd", 0, 0, u32(1), t.entry), fbox("stts", 0, 0, u32(0)), fbox("stsc", 0, 0, u32(0)), fbox("stsz", 0, 0, u32(0), u32(0)), fbox("stco", 0, 0, u32(0)));
    const trak = box("trak", tkhd, box("mdia", mdhd, hdlr, box("minf", mh, dinf, stbl)));
    const mvex = box("mvex", fbox("trex", 0, 0, u32(1), u32(1), u32(0), u32(0), u32(0)));
    return cat([box("ftyp", te("isom"), u32(512), te("isom"), te("iso6"), te("mp41")), box("moov", mvhd, trak, mvex)]);
  }
  function frag(seq, base, smp) {
    const n = smp.length, trunSize = 20 + n * 16, moofSize = 8 + 16 + 8 + 16 + 20 + trunSize;
    const tr = new Uint8Array(n * 16), dv = new DataView(tr.buffer);
    let total = 0;
    for (let i = 0; i < n; i++) {
      const s = smp[i];
      dv.setUint32(i * 16, s.dur >>> 0); dv.setUint32(i * 16 + 4, s.data.length); dv.setUint32(i * 16 + 8, s.flags); dv.setInt32(i * 16 + 12, s.cts | 0);
      total += s.data.length;
    }
    const moof = box("moof", fbox("mfhd", 0, 0, u32(seq)), box("traf", fbox("tfhd", 0, 0x20000, u32(1)), fbox("tfdt", 1, 0, u64(Math.max(0, base))), fbox("trun", 1, 0xF01, u32(n), u32(moofSize + 8), tr)));
    const out = new Uint8Array(moof.length + 8 + total);
    out.set(moof, 0); out.set(u32(8 + total), moof.length); out.set(te("mdat"), moof.length + 4);
    let q = moof.length + 8;
    for (const s of smp) { out.set(s.data, q); q += s.data.length; }
    return out;
  }
  const vEntry = (fc, w, h, cfg) => box(fc, Z(6), u16(1), Z(16), u16(w), u16(h), u32(0x480000), u32(0x480000), u32(0), u16(1), Z(32), u16(0x18), u16(0xffff), cfg);
  const aEntry = (fc, ch, sr, cfg) => box(fc, Z(6), u16(1), Z(8), u16(ch), u16(16), u16(0), u16(0), u32(sr < 65536 ? sr * 65536 : 0), cfg);
  function desc(tag, body) { const n = body.length; return cat([new Uint8Array([tag, 0x80 | ((n >> 21) & 0x7f), 0x80 | ((n >> 14) & 0x7f), 0x80 | ((n >> 7) & 0x7f), n & 0x7f]), body]); }
  function esds(oti, dsi) {
    const dcd = desc(4, cat([new Uint8Array([oti, 0x15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), dsi ? desc(5, dsi) : Z(0)]));
    return fbox("esds", 0, 0, desc(3, cat([new Uint8Array([0, 1, 0]), dcd, desc(6, new Uint8Array([2]))])));
  }
  const SRS = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
  function asc(aot, sr, ch) { let i = SRS.indexOf(sr); if (i < 0) i = 3; return new Uint8Array([(aot << 3) | (i >> 1), ((i & 1) << 7) | ((ch & 15) << 3)]); }
  function bits(f, start) { let bit = start; return n => { let v = 0; for (let i = 0; i < n; i++, bit++) v = (v * 2) + ((f[bit >> 3] >> (7 - (bit & 7))) & 1); return v; }; }
  function wbits(list) { // [[value, nbits], ...] → bytes
    const out = []; let cur = 0, nb = 0;
    for (const [v, n] of list) for (let i = n - 1; i >= 0; i--) { cur = (cur << 1) | ((v >> i) & 1); if (++nb === 8) { out.push(cur); cur = 0; nb = 0; } }
    if (nb) out.push(cur << (8 - nb));
    return out;
  }
  const chMode = ch => ch >= 6 ? [7, 1] : ch === 5 ? [7, 0] : ch === 4 ? [6, 0] : ch === 3 ? [3, 0] : ch === 1 ? [1, 0] : [2, 0];
  const fsc = sr => sr === 44100 ? 1 : sr === 32000 ? 2 : 0;
  function dac3(f, sr, ch) {
    if (f && f.length > 8 && f[0] === 0x0B && f[1] === 0x77) {
      const fscod = f[4] >> 6, frm = f[4] & 0x3f, bsid = f[5] >> 3, bsmod = f[5] & 7, rb = bits(f, 48);
      const acmod = rb(3);
      if ((acmod & 1) && acmod !== 1) rb(2);
      if (acmod & 4) rb(2);
      if (acmod === 2) rb(2);
      return box("dac3", wbits([[fscod, 2], [bsid, 5], [bsmod, 3], [acmod, 3], [rb(1), 1], [frm >> 1, 5], [0, 5]]));
    }
    const m = chMode(ch);
    return box("dac3", wbits([[fsc(sr), 2], [8, 5], [0, 3], [m[0], 3], [m[1], 1], [15, 5], [0, 5]]));
  }
  function dec3(f, sr, ch) {
    let fscod = fsc(sr), acmod = chMode(ch)[0], lfe = chMode(ch)[1], rate = 640, nb = 6;
    if (f && f.length > 8 && f[0] === 0x0B && f[1] === 0x77) {
      const rb = bits(f, 16);
      rb(2); rb(3); const frmsiz = rb(11); fscod = rb(2);
      let s = 48000, nbc = 3;
      if (fscod === 3) { s = [24000, 22050, 16000][rb(2)] || 24000; } else { nbc = rb(2); s = [48000, 44100, 32000][fscod]; }
      acmod = rb(3); lfe = rb(1);
      nb = [1, 2, 3, 6][nbc];
      rate = Math.round(((frmsiz + 1) * 16 * s) / (nb * 256) / 1000) || 640;
    }
    return { box: box("dec3", wbits([[rate, 13], [0, 3], [fscod, 2], [16, 5], [0, 1], [0, 1], [0, 3], [acmod, 3], [lfe, 1], [0, 3], [0, 4], [0, 1]])), fs: nb * 256 };
  }
  function hevcStr(c) {
    const sp = c[1] >> 6, tier = (c[1] >> 5) & 1, prof = c[1] & 31;
    let comp = ((c[2] << 24) | (c[3] << 16) | (c[4] << 8) | c[5]) >>> 0, rev = 0;
    for (let i = 0; i < 32; i++) { rev = ((rev << 1) | (comp & 1)) >>> 0; comp >>>= 1; }
    const cons = [c[6], c[7], c[8], c[9], c[10], c[11]];
    while (cons.length && !cons[cons.length - 1]) cons.pop();
    return ["", "A", "B", "C"][sp] + prof + "." + rev.toString(16) + "." + (tier ? "H" : "L") + c[12] + cons.map(b => "." + b.toString(16)).join("");
  }
  const hx = x => (x < 16 ? "0" : "") + x.toString(16);

  /* ── EBML ── */
  const vlen = b => b & 0x80 ? 1 : b & 0x40 ? 2 : b & 0x20 ? 3 : b & 0x10 ? 4 : b & 0x08 ? 5 : b & 0x04 ? 6 : b & 0x02 ? 7 : b & 0x01 ? 8 : 0;
  function hdr(d, p, end) {
    if (p >= end) return null;
    const il = vlen(d[p]); if (!il || il > 4) return { bad: 1 };
    if (p + il >= end) return null;
    const sl = vlen(d[p + il]); if (!sl) return { bad: 1 };
    if (p + il + sl > end) return null;
    let id = 0; for (let i = 0; i < il; i++) id = id * 256 + d[p + i];
    let sz = d[p + il] & (0xff >> sl), all = sz === (0xff >> sl);
    for (let i = 1; i < sl; i++) { const b = d[p + il + i]; sz = sz * 256 + b; if (b !== 255) all = false; }
    return { id, size: all ? -1 : sz, hl: il + sl };
  }
  function each(d, fn) { let p = 0; while (p < d.length) { const h = hdr(d, p, d.length); if (!h || h.bad || h.size < 0) break; const s = p + h.hl, e = Math.min(d.length, s + h.size); fn(h.id, d.subarray(s, e)); p = e; } }
  const uint = d => { let n = 0; for (let i = 0; i < d.length; i++) n = n * 256 + d[i]; return n; };
  const flt = d => { const dv = new DataView(d.buffer, d.byteOffset, d.length); return d.length === 4 ? dv.getFloat32(0) : d.length === 8 ? dv.getFloat64(0) : 0; };
  const str = d => { let s = ""; for (let i = 0; i < d.length && d[i]; i++) s += String.fromCharCode(d[i]); return s; };
  const utf8 = d => { try { return new TextDecoder("utf-8").decode(d); } catch (e) { return str(d); } };
  function parseTracks(d) {
    const out = [];
    each(d, (id, e) => {
      if (id !== 0xAE) return;
      const t = { num: 0, type: 0, codec: "", priv: null, lang: "eng", ietf: "", def: 1, forced: 0, name: "", w: 0, h: 0, sr: 0, ch: 2, strip: null, enc: false };
      each(e, (k, v) => {
        if (k === 0xD7) t.num = uint(v);
        else if (k === 0x83) t.type = uint(v);
        else if (k === 0x86) t.codec = str(v);
        else if (k === 0x63A2) t.priv = v.slice();
        else if (k === 0x22B59C) t.lang = str(v);
        else if (k === 0x22B59D) t.ietf = str(v);
        else if (k === 0x536E) t.name = utf8(v);
        else if (k === 0x88) t.def = uint(v);
        else if (k === 0x55AA) t.forced = uint(v);
        else if (k === 0xE0) each(v, (a, b) => { if (a === 0xB0) t.w = uint(b); else if (a === 0xBA) t.h = uint(b); });
        else if (k === 0xE1) each(v, (a, b) => { if (a === 0xB5) t.sr = flt(b); else if (a === 0x9F) t.ch = uint(b); });
        else if (k === 0x6D80) each(v, (a, b) => {
          if (a !== 0x6240) return;
          each(b, (c, x) => {
            if (c === 0x5034) { let algo = 0, set = null; each(x, (q, y) => { if (q === 0x4254) algo = uint(y); else if (q === 0x4255) set = y.slice(); }); if (algo === 3 && set) t.strip = set; else t.enc = true; }
            else if (c === 0x5035) t.enc = true;
          });
        });
      });
      out.push(t);
    });
    return out;
  }
  function parseBlock(d) {
    const tl = vlen(d[0]); if (!tl || d.length < tl + 3) return null;
    let track = d[0] & (0xff >> tl); for (let i = 1; i < tl; i++) track = track * 256 + d[i];
    let q = tl;
    const rel = ((d[q] << 8) | d[q + 1]) << 16 >> 16; q += 2;
    const flags = d[q++], lace = (flags >> 1) & 3;
    const frames = [];
    if (!lace) frames.push(d.subarray(q));
    else {
      const n = d[q++] + 1, sizes = [];
      if (lace === 1) { for (let i = 0; i < n - 1; i++) { let s = 0, b; do { b = d[q++]; s += b; } while (b === 255 && q < d.length); sizes.push(s); } }
      else if (lace === 3) {
        let l = vlen(d[q]), s = d[q] & (0xff >> l); for (let i = 1; i < l; i++) s = s * 256 + d[q + i]; q += l; sizes.push(s);
        for (let i = 1; i < n - 1; i++) { l = vlen(d[q]); let v = d[q] & (0xff >> l); for (let j = 1; j < l; j++) v = v * 256 + d[q + j]; q += l; s += v - (Math.pow(2, 7 * l - 1) - 1); sizes.push(s); }
      } else { const e = Math.floor((d.length - q) / n); for (let i = 0; i < n - 1; i++) sizes.push(e); }
      let used = 0; for (const s of sizes) used += s;
      sizes.push(d.length - q - used);
      for (const s of sizes) { if (s < 0 || q + s > d.length) return null; frames.push(d.subarray(q, q + s)); q += s; }
    }
    return { track, rel, key: !!(flags & 0x80), frames };
  }
  function parseCues(d, seg, scale) {
    const out = [];
    each(d, (k, v) => {
      if (k !== 0xBB) return;
      let t = -1, pos = -1;
      each(v, (a, b) => { if (a === 0xB3) t = uint(b); else if (a === 0xB7 && pos < 0) each(b, (c, x) => { if (c === 0xF1) pos = uint(x); }); });
      if (t >= 0 && pos >= 0) out.push({ t: t * scale / 1e6, pos: seg + pos });
    });
    out.sort((a, b) => a.t - b.t);
    return out;
  }
  // قارئ متدفق: يستقبل أجزاء الملف ويستخرج المسارات والإطارات
  function Demux(cb) {
    let buf = new Uint8Array(0), p = 0, abs = 0, skip = 0, resync = false, ctime = 0;
    const D = { scale: 1e6, seg: 0, segSize: -1 };
    D.reset = (at, rs) => { buf = new Uint8Array(0); p = 0; abs = at; skip = 0; resync = !!rs; };
    D.push = chunk => {
      const rest = buf.length - p;
      if (rest <= 0) { abs += buf.length; buf = chunk; }
      else { const n = new Uint8Array(rest + chunk.length); n.set(buf.subarray(p)); n.set(chunk, rest); abs += p; buf = n; }
      p = 0;
      parse();
    };
    function parse() {
      for (;;) {
        if (skip) { const k = Math.min(skip, buf.length - p); p += k; skip -= k; if (skip) return; }
        if (resync) {
          let i = p, found = -1, wait = false;
          for (; i + 4 <= buf.length; i++) {
            if (buf[i] !== 0x1F || buf[i + 1] !== 0x43 || buf[i + 2] !== 0xB6 || buf[i + 3] !== 0x75) continue;
            const h = hdr(buf, i, buf.length);
            if (!h || i + h.hl >= buf.length) { wait = true; break; }
            const c = buf[i + h.hl];
            if (!h.bad && (c === 0xE7 || c === 0xBF || c === 0xA7 || c === 0xAB)) { found = i; break; }
          }
          if (found < 0) { p = wait ? i : Math.max(p, buf.length - 3); return; }
          p = found; resync = false;
        }
        const h = hdr(buf, p, buf.length);
        if (!h) return;
        if (h.bad) { resync = true; p++; continue; }
        const id = h.id, start = p + h.hl, size = h.size, at = abs + p;
        if (id === 0x18538067) { D.seg = abs + start; D.segSize = size; p = start; continue; }
        if (id === 0x1F43B675) { p = start; cb.cluster(at); continue; }
        if (id === 0xE7 || id === 0xA3 || id === 0xA0 || id === 0x1549A966 || id === 0x1654AE6B || id === 0x114D9B74 || id === 0x1C53BB6B) {
          if (size < 0) { resync = true; p = start; continue; }
          if (size > 48 * 1048576) { skip = size; p = start; continue; }
          if (buf.length - start < size) return;
          const d = buf.subarray(start, start + size);
          p = start + size;
          handle(id, d);
          continue;
        }
        if (size < 0) { p = start; continue; }
        skip = size; p = start;
      }
    }
    function handle(id, d) {
      if (id === 0xE7) ctime = uint(d);
      else if (id === 0xA3) { const b = parseBlock(d); if (b) cb.block(b, (ctime + b.rel) * D.scale / 1e6, 0, b.key); }
      else if (id === 0xA0) {
        let blk = null, dur = 0, ref = false;
        each(d, (k, v) => { if (k === 0xA1) blk = v; else if (k === 0x9B) dur = uint(v); else if (k === 0xFB) ref = true; });
        if (blk) { const b = parseBlock(blk); if (b) cb.block(b, (ctime + b.rel) * D.scale / 1e6, dur * D.scale / 1e6, !ref); }
      }
      else if (id === 0x1549A966) { let dur = 0; each(d, (k, v) => { if (k === 0x2AD7B1) D.scale = uint(v) || 1e6; else if (k === 0x4489) dur = flt(v); }); cb.info(dur * D.scale / 1e6); }
      else if (id === 0x1654AE6B) cb.tracks(parseTracks(d));
      else if (id === 0x114D9B74) each(d, (k, v) => { if (k !== 0x4DBB) return; let sid = 0, pos = -1; each(v, (a, b) => { if (a === 0x53AB) sid = uint(b); else if (a === 0x53AC) pos = uint(b); }); if (sid === 0x1C53BB6B && pos >= 0) cb.cuesAt(D.seg + pos); });
      else if (id === 0x1C53BB6B) cb.cues(parseCues(d, D.seg, D.scale));
    }
    return D;
  }

  const isAr = t => /^(ara|ar)$/i.test(t.lang || "") || /^ar(\b|-)/i.test(t.ietf || "") || /arab|عرب/i.test(t.name || "");
  function videoSetup(t) {
    const p = t.priv;
    if (/^V_MPEG4\/ISO\/AVC/.test(t.codec) && p && p.length > 6) return { codec: "avc1." + hx(p[1]) + hx(p[2]) + hx(p[3]), name: "H.264", entry: vEntry("avc1", t.w, t.h, box("avcC", p)) };
    if (/^V_MPEGH\/ISO\/HEVC/.test(t.codec) && p && p.length > 22) { const fc = p[22] ? "hvc1" : "hev1"; return { codec: fc + "." + hevcStr(p), name: "HEVC", entry: vEntry(fc, t.w, t.h, box("hvcC", p)) }; }
    return null;
  }
  function audioSetup(t) {
    const c = t.codec, sr = Math.round(t.sr || 48000), ch = t.ch || 2;
    if (/^A_AAC/.test(c)) {
      let a = t.priv && t.priv.length >= 2 ? t.priv : null;
      if (!a) a = asc(/MAIN/.test(c) ? 1 : /SSR/.test(c) ? 3 : /LTP/.test(c) ? 4 : 2, sr, ch);
      const aot = a[0] >> 3;
      return { codec: "mp4a.40." + (aot === 31 || !aot ? 2 : aot), name: "AAC", fs: 1024, sr, ch, aac: true, entry: () => aEntry("mp4a", ch, sr, esds(0x40, a)) };
    }
    if (c === "A_AC3") return { codec: "ac-3", name: "AC-3", fs: 1536, sr, ch, frame: true, entry: f => aEntry("ac-3", ch, sr, dac3(f, sr, ch)) };
    if (c === "A_EAC3") { const A = { codec: "ec-3", name: "E-AC-3", fs: 1536, sr, ch, frame: true }; A.entry = f => { const d = dec3(f, sr, ch); A.fs = d.fs; return aEntry("ec-3", ch, sr, d.box); }; return A; }
    if (c === "A_MPEG/L3") return { codec: "mp4a.6B", name: "MP3", fs: sr < 32000 ? 576 : 1152, sr, ch, entry: () => aEntry("mp4a", ch, sr, esds(0x6B, null)) };
    return null;
  }
  const NAMES = { A_DTS: "DTS", "A_TRUEHD": "TrueHD", A_FLAC: "FLAC", A_OPUS: "Opus", A_VORBIS: "Vorbis", "A_PCM/INT/LIT": "PCM", A_AC3: "AC-3", A_EAC3: "E-AC-3" };
  const LANGS = { ara: "العربية", ar: "العربية", eng: "English", en: "English", fre: "Français", fra: "Français", tur: "Türkçe", spa: "Español", ger: "Deutsch", deu: "Deutsch", hin: "हिन्दी", per: "فارسی", fas: "فارسی", urd: "اردو", ind: "Indonesia", und: "" };

  function start(v, url, o) {
    o = o || {};
    const MS = window.ManagedMediaSource || window.MediaSource;
    const mms = !!window.ManagedMediaSource && MS === window.ManagedMediaSource;
    const ctl = { info: { fmt: "MKV" }, subs: [], sub: -1, destroyed: false, log: [] };
    const L = m => { ctl.log.push(m); if (ctl.log.length > 30) ctl.log.shift(); };
    const fail = m => { if (ctl.destroyed || ctl.failed) return; ctl.failed = true; L("fail: " + m); stopAll(); o.onerror && o.onerror(m); };
    if (!MS) { setTimeout(() => fail("هذا الجهاز لا يدعم تشغيل MKV داخلياً (يحتاج iOS 17.1 أو أحدث)"), 0); return ctl; }
    const sup = m => { try { return MS.isTypeSupported(m); } catch (e) { return false; } };
    let ms = null, objUrl = "", msOpen = false, VT = null, AT = null, TT = {}, A = null, V = null;
    let tracks = null, duration = 0, total = 0, firstCluster = -1, cues = null, cuesAt = 0, cuesTried = false;
    let gen = 0, fetchCtl = null, started = false, eof = false, seekT = -1, seekByCue = false, seekTries = 0, seekPos = 0, seekWait = false, selfT = -1, selfUntil = 0, pend = [], pendBytes = 0;
    const setTime = t => { selfT = t; selfUntil = Date.now() + 1500; try { v.currentTime = t; } catch (e) {} };
    let vin = [], vsorted = [], vready = [], S = -1, vseq = 1, aseq = 1, ain = [], aNext = -1, lastDur = 3003, vFrags = 0, aInit = false, firstKeyMs = -1, lastKeyMs = -1, dropUntil = -1, hevc = false, rB = 0, rT = 0;
    const R = 16;
    const subKeys = new Set();

    function SBQ(kind) {
      const q = []; let sb = null, bytes = 0;
      const Q = {
        get bytes() { return bytes; }, get sb() { return sb; },
        attach(s) { sb = s; s.addEventListener("updateend", () => { Q.kick(); onUpdate(); }); s.addEventListener("error", () => fail("تعذّر فك " + (kind === "v" ? "الفيديو" : "الصوت"))); Q.kick(); },
        push(d, init) { q.push({ d, init }); bytes += d.length; Q.kick(); },
        remove(a, b) { if (b > a) { q.push({ rm: [a, b] }); Q.kick(); } },
        clear() { for (let i = q.length - 1; i >= 0; i--) if (q[i].d && !q[i].init) { bytes -= q[i].d.length; q.splice(i, 1); } },
        idle() { return !q.length && (!sb || !sb.updating); },
        kick() {
          if (!sb || ctl.destroyed || sb.updating || !q.length || !ms || ms.readyState === "closed") return;
          const op = q[0];
          try {
            if (op.rm) sb.remove(op.rm[0], op.rm[1]); else sb.appendBuffer(op.d);
            q.shift(); if (op.d) bytes -= op.d.length;
          } catch (e) {
            if (e.name === "QuotaExceededError") { evict(true); setTimeout(Q.kick, 500); }
            else if (op.rm) q.shift();
            else fail("خطأ في التشغيل: " + e.name);
          }
        }
      };
      return Q;
    }
    const vq = SBQ("v"), aq = SBQ("a");
    function buffered(sb) { try { return sb ? sb.buffered : null; } catch (e) { return null; } }
    function ahead() {
      const b = buffered(vq.sb); if (!b || !b.length) return 0;
      const t = v.currentTime;
      for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.6 && t <= b.end(i)) return b.end(i) - t;
      return 0;
    }
    ctl.ahead = () => ahead();
    function inBuf(t) { const b = buffered(vq.sb); if (!b) return false; for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.3 && t < b.end(i) - 0.2) return true; return false; }
    // معدل البيانات (بايت لكل ثانية) لتحديد حجم التخزين حسب جودة الفيلم (4K يحتاج حدوداً أصغر بالثواني)
    const rate = () => rT > 4 ? rB / rT : 0;
    const capSec = (bytes, lo, hi) => { const r = rate(); return r ? Math.max(lo, Math.min(hi, bytes / r)) : hi; };
    function evict(hard) {
      const t = v.currentTime, keep = hard ? 3 : capSec(mms ? 22e6 : 45e6, 5, 25);
      for (const Q of [vq, aq]) { const b = buffered(Q.sb); if (b && b.length && t - b.start(0) > keep + 2) Q.remove(b.start(0), t - keep); }
    }
    const MAXA = Math.round((+o.maxAhead || 75) * (mms ? 0.6 : 1));
    ctl.bytes = 0;
    ctl.trim = () => { try { evict(true); } catch (e) {} };   // تحذير ذاكرة من النظام: نفرّغ ما خلف موضع المشاهدة
    async function gate(g) {
      while (g === gen && !ctl.destroyed && !ctl.failed) {
        if (!V) { if (!tracks) return; await sleep(40); continue; }   // ننتظر تجهيز المشغل قبل قراءة المزيد
        const qb = vq.bytes + aq.bytes;
        if (!started) { if (qb < 24e6) return; }
        else if (qb < 8e6 && ahead() < capSec(mms ? 75e6 : 150e6, 10, MAXA) && !(mms && ms && ms.streaming === false && ahead() > 8)) return;
        await sleep(300);
      }
    }
    function stopAll() {
      gen++;
      try { fetchCtl && fetchCtl.abort(); } catch (e) {}
      clearInterval(ctl.evT); clearInterval(ctl.gapT);
    }
    ctl.destroy = () => {
      if (ctl.destroyed) return;
      stopAll(); ctl.destroyed = true;
      v.removeEventListener("seeking", onSeeking);
      try { v.removeAttribute("src"); v.load(); } catch (e) {}
      try { objUrl && URL.revokeObjectURL(objUrl); } catch (e) {}
      for (const s of ctl.subs) { try { s.track.mode = "disabled"; } catch (e) {} }
    };
    ctl.setSub = i => {
      ctl.sub = i;
      ctl.subs.forEach((s, k) => { try { s.track.mode = k === i ? "showing" : "disabled"; } catch (e) {} });
    };

    // ── الإعداد بعد قراءة المسارات
    function setup() {
      if (!tracks || !msOpen || V || ctl.failed) return;
      if (ms.readyState !== "open") { msOpen = false; ms.addEventListener("sourceopen", () => { msOpen = true; setup(); }, { once: true }); return; }
      const vids = tracks.filter(t => t.type === 1);
      VT = vids.find(t => !t.enc && videoSetup(t));
      if (!VT) {
        const c = vids[0] ? vids[0].codec.replace(/^V_/, "").replace(/\/.*$/, "") : "";
        return fail(vids.length ? "صيغة الفيديو (" + c + ") غير مدعومة داخلياً — افتحه في VLC" : "لا يوجد فيديو في هذا الملف");
      }
      V = videoSetup(VT); hevc = V.name === "HEVC";
      if (!sup('video/mp4; codecs="' + V.codec + '"')) return fail("هذا الجهاز لا يدعم فيديو " + V.name + " (" + V.codec + ") — افتحه في VLC");
      const auds = tracks.filter(t => t.type === 2);
      const cands = auds.map((t, i) => ({ t, i, a: !t.enc && audioSetup(t) })).filter(x => x.a && x.a.codec !== o.noAudio && sup('audio/mp4; codecs="' + x.a.codec + '"'));
      const arW = o.audioPref === "orig" ? 0 : 4;
      cands.sort((x, y) => ((isAr(y.t) ? arW : 0) + (y.t.def ? 2 : 0) - y.i * 0.01) - ((isAr(x.t) ? arW : 0) + (x.t.def ? 2 : 0) - x.i * 0.01));
      if (cands.length) { AT = cands[0].t; A = cands[0].a; ctl.aCodec = A.codec; }
      else if (auds.length && o.noAudio) ctl.info.note = "تعذّر فك صوت هذا الملف داخلياً فشُغّل بدون صوت — للصوت افتحه في VLC";
      else if (auds.length) ctl.info.note = "صوت " + (NAMES[auds[0].codec] || auds[0].codec.replace(/^A_/, "")) + " غير مدعوم داخلياً — للصوت افتحه في VLC";
      try {
        vq.attach(ms.addSourceBuffer('video/mp4; codecs="' + V.codec + '"'));
        if (A) aq.attach(ms.addSourceBuffer('audio/mp4; codecs="' + A.codec + '"'));
      } catch (e) { return fail("تعذّر تجهيز المشغل: " + (e.message || e.name)); }
      if (duration > 0) { try { ms.duration = duration / 1000; } catch (e) {} }
      vq.push(initSeg({ kind: "v", ts: 90000, w: VT.w, h: VT.h, entry: V.entry }), true);
      if (A && !A.frame) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry() }), true); aInit = true; }
      // الترجمة
      tracks.filter(t => t.type === 17 && /^S_TEXT\/(UTF8|ASS|SSA|WEBVTT)/.test(t.codec)).slice(0, 8).forEach(t => {
        try {
          const label = (t.name || LANGS[(t.lang || "").toLowerCase()] || t.lang || "ترجمة").slice(0, 24);
          const tt = v.addTextTrack("subtitles", label, t.ietf || t.lang || "");
          tt.mode = "disabled";
          TT[t.num] = { t, track: tt, ass: /ASS|SSA/.test(t.codec), idx: ctl.subs.length };
          ctl.subs.push({ label, lang: t.lang, ar: isAr(t), track: tt });
        } catch (e) {}
      });
      const ar = ctl.subs.findIndex(s => s.ar);
      if (ar >= 0) ctl.setSub(ar);
      ctl.info = Object.assign(ctl.info, { v: V.name, res: VT.w && VT.h ? VT.w + "×" + VT.h : "", a: A ? A.name + (AT.lang && AT.lang !== "und" ? " · " + (LANGS[AT.lang] || AT.lang) : "") : "", audios: auds.length });
      L("tracks: " + V.codec + " " + (A ? A.codec + " " + AT.lang : "no-audio") + " subs=" + ctl.subs.length);
      o.onstatus && o.onstatus(ctl.info);
      ctl.evT = setInterval(() => { if (!ctl.destroyed) evict(false); }, 4000);
      ctl.gapT = setInterval(gapJump, 500);
      const P0 = pend; pend = []; pendBytes = 0;
      if (o.start > 5 && !ctl.didStart) { ctl.didStart = true; doSeek(o.start); return; }
      for (const x of P0) { if (ctl.failed || gen !== x[4]) break; route(x[0], x[1], x[2], x[3]); }
    }

    // ── الفيديو: ترتيب أزمنة الفك (DTS) من أزمنة العرض، ثم مقاطع MP4
    function onVideo(ms_, data, key) {
      if (firstKeyMs < 0) { if (!key) return; firstKeyMs = lastKeyMs = ms_; if (landed(ms_)) return; }
      else if (key) lastKeyMs = ms_;
      else if (ms_ < lastKeyMs) {
        // HEVC (x265 open-GOP): إطارات RASL بعد إطار CRA تعتمد على ما قبله. عند البدء أو بعد القفز
        // لا يملك المفكّك ما قبله → نحذفها (لا تُعرض قبل موضع البدء أصلاً، والمعيار يمنع اعتماد غيرها عليها)
        ctl.openGop = true;
        if (hevc && (lastKeyMs === firstKeyMs || ms_ < dropUntil)) { ctl.lead = (ctl.lead || 0) + 1; return; }
      }
      if (VT.strip) data = cat([VT.strip, data]);
      const pts = Math.round(ms_ * 90);
      vin.push({ pts, data, key });
      let lo = 0, hi = vsorted.length; while (lo < hi) { const m = (lo + hi) >> 1; if (vsorted[m] < pts) lo = m + 1; else hi = m; } vsorted.splice(lo, 0, pts);
      while (vin.length > R) { const f = vin.shift(); f.dts = vsorted.shift(); vready.push(f); }
      flushVideo(false);
    }
    function flushVideo(force) {
      if (force) while (vin.length) { const f = vin.shift(); f.dts = vsorted.shift(); vready.push(f); }
      let k = -1;
      for (let i = vready.length - 1; i > 0; i--) if (vready[i].key) { k = i; break; }
      if (k < 0 && vready.length > 2 && vready[vready.length - 1].dts - vready[0].dts > 3 * 90000) k = vready.length - 1;
      if (force && vready.length) k = vready.length;
      if (k <= 0) return;
      const out = vready.splice(0, k), next = vready[0];
      if (S < 0) {
        S = 0; for (const f of out.concat(vready)) S = Math.max(S, f.dts - f.pts);
        const ds = out.concat(vready).map(f => f.dts).sort((a, b) => a - b), dd = [];
        for (let i = 1; i < ds.length; i++) if (ds[i] > ds[i - 1]) dd.push(ds[i] - ds[i - 1]);
        dd.sort((a, b) => a - b);
        S += 2 * (dd[dd.length >> 1] || 3750);   // هامش لإعادة الترتيب الأعمق في المشاهد اللاحقة
      }
      const smp = out.map((f, i) => {
        const nd = i + 1 < out.length ? out[i + 1].dts : next ? next.dts : f.dts + lastDur;
        const dur = Math.max(1, nd - f.dts); lastDur = dur;
        const c = f.pts + S - f.dts; if (c < 0) ctl.clamp = (ctl.clamp || 0) + 1;
        return { data: f.data, dur, flags: f.key ? 0x02000000 : 0x01010000, cts: Math.max(0, c) };
      });
      const fr = frag(vseq++, out[0].dts, smp);
      rB += fr.length; rT += smp.reduce((a, x) => a + x.dur, 0) / 90000;
      vq.push(fr);
      vFrags++;
      if (A && !aInit && vFrags >= 2) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry(null) }), true); aInit = true; }
      flushAudio(force);
    }
    // ── الصوت
    function onAudio(ms_, frames) {
      if (firstKeyMs < 0 && ain.length > 400) ain.shift();
      for (let j = 0; j < frames.length; j++) {
        let f = frames[j];
        if (AT.strip) f = cat([AT.strip, f]);
        if (A.aac && f.length > 7 && f[0] === 0xFF && (f[1] & 0xF6) === 0xF0) f = f.subarray((f[1] & 1) ? 7 : 9);
        if (A.frame && !aInit) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry(f) }), true); aInit = true; }
        ain.push({ t: ms_ * A.sr / 1000 + j * A.fs, data: f });
      }
      if (ain.length && (ain[ain.length - 1].t - ain[0].t) > A.sr * 2 && S >= 0) flushAudio(false);
    }
    function flushAudio() {
      if (!A || !aInit || S < 0 || !ain.length) return;
      if (firstKeyMs >= 0) { const lim = (firstKeyMs - 40) * A.sr / 1000; while (ain.length && ain[0].t < lim) ain.shift(); if (!ain.length) return; }
      let base = Math.round(ain[0].t + S * A.sr / 90000);
      if (aNext >= 0 && Math.abs(base - aNext) < A.fs * 1.5) base = aNext;
      const smp = ain.map(f => ({ data: f.data, dur: A.fs, flags: 0x02000000, cts: 0 }));
      aNext = base + smp.length * A.fs;
      const fa = frag(aseq++, base, smp); rB += fa.length;
      aq.push(fa);
      ain = [];
    }
    // ── الترجمة
    function onSub(t, ms_, dur, frames) {
      const T = TT[t.num]; if (!T) return;
      const key = t.num + ":" + Math.round(ms_);
      if (subKeys.has(key)) return; subKeys.add(key);
      let txt = utf8(frames[0] || new Uint8Array(0));
      if (T.ass) { const parts = txt.split(","); txt = parts.length > 8 ? parts.slice(8).join(",") : txt; txt = txt.replace(/\{[^}]*\}/g, ""); }
      txt = txt.replace(/\\N/gi, "\n").replace(/<[^>]+>/g, "").trim();
      if (!txt) return;
      const st = ms_ / 1000 + Math.max(0, S) / 90000, en = st + Math.max(0.6, (dur || 3500) / 1000);
      try { const C = window.VTTCue || window.TextTrackCue, cue = new C(st, en, txt); try { cue.snapToLines = true; cue.line = o.subLine != null ? o.subLine : -1; } catch (e) {} T.track.addCue(cue); } catch (e) {}
      o.onsub && o.onsub(T.idx, st, en, txt);
    }
    // ── بعد القفز: التأكد أننا وصلنا قرب الوقت المطلوب وإلا نصحّح الموضع
    function landed(ms_) {
      if (seekT < 0) return false;
      const diff = ms_ - seekT * 1000, span = ((dmx.segSize > 0 ? dmx.seg + dmx.segSize : total) || 0) - Math.max(0, firstCluster);
      if (!seekByCue && seekTries < 4 && duration > 0 && span > 0 && (diff > 2500 || diff < -25000)) {
        seekTries++;
        const shift = Math.floor(span * ((diff > 0 ? diff + 5000 : diff + 8000) / duration));
        const np = Math.max(Math.max(0, firstCluster), Math.min(seekPos - shift, (total || seekPos) - 65536));
        L("seek refine " + Math.round(diff / 1000) + "s → " + np);
        restartAt(np, true);
        return true;
      }
      const st = ms_ / 1000 + Math.max(0, S) / 90000, want = Math.max(st + 0.03, seekT);
      if (v.currentTime < want - 0.05 || v.currentTime > want + 4) setTime(want);
      seekT = -1; seekWait = false;
      return false;
    }
    const dmx = Demux({
      cluster(at) { if (firstCluster < 0) firstCluster = at; },
      info(d) { duration = d; },
      tracks(t) { if (!tracks) { tracks = t; setup(); } },
      cuesAt(p) { if (!cuesAt) cuesAt = p; },
      cues(c) { if (!cues && c.length) cues = c; },
      block(b, ms_, dur, key) {
        if (ctl.failed) return;
        // قبل جاهزية المشغل نحتفظ بكل الإطارات (مراجع لنفس البيانات، بلا نسخ) حتى لا تضيع ثوانٍ من الفيلم
        if (!V) { if (pendBytes < 96 * 1048576) { pend.push([b, ms_, dur, key, gen]); for (const f of b.frames) pendBytes += f.length; } return; }
        if (seekWait && seekT < 0) return;
        route(b, ms_, dur, key);
      }
    });
    function route(b, ms_, dur, key) {
      if (b.track === VT.num) onVideo(ms_, b.frames[0], key);
      else if (AT && b.track === AT.num) onAudio(ms_, b.frames);
      else if (TT[b.track]) onSub(TT[b.track].t, ms_, dur, b.frames);
    }

    function resetPipes() {
      vin = []; vsorted = []; vready = []; ain = []; aNext = -1; firstKeyMs = -1; lastKeyMs = -1; eof = false;
      vq.clear(); aq.clear();
    }
    function restartAt(pos, rs) {
      stopAllFetch();
      resetPipes();
      vq.remove(0, Infinity); if (A) aq.remove(0, Infinity);
      seekPos = pos;
      dmx.reset(pos, rs);
      const g = ++gen;
      pump(pos, g);
    }
    function stopAllFetch() { try { fetchCtl && fetchCtl.abort(); } catch (e) {} }
    async function loadCues(g) {
      try {
        const end = total ? Math.min(total - 1, cuesAt + 4 * 1048576 - 1) : cuesAt + 4 * 1048576 - 1;
        const r = await fetch(url, { headers: { Range: "bytes=" + cuesAt + "-" + end }, cache: "no-store" });
        if (g !== gen || r.status !== 206) return;
        const d = new Uint8Array(await r.arrayBuffer());
        const h = hdr(d, 0, d.length);
        if (h && !h.bad && h.id === 0x1C53BB6B && h.size > 0 && h.hl + h.size <= d.length) { const c = parseCues(d.subarray(h.hl, h.hl + h.size), dmx.seg, dmx.scale); if (c.length) cues = c; }
        L("cues: " + (cues ? cues.length : 0));
      } catch (e) { L("cues failed"); }
    }
    async function doSeek(t) {
      if (ctl.destroyed || ctl.failed || !V) return;
      const g = ++gen;
      stopAllFetch();
      seekWait = true; seekPend = false; seekT = -1; ctl.seeked = true;
      if (!cues && cuesAt && !cuesTried) { cuesTried = true; await sleep(150); await loadCues(g); if (g !== gen) return; }
      seekT = t; seekTries = 0; dropUntil = t * 1000;
      let pos;
      if (cues && cues.length) { let i = 0; while (i + 1 < cues.length && cues[i + 1].t <= t * 1000 + 300) i++; pos = cues[Math.max(0, i - (t * 1000 - cues[i].t < 1500 ? 1 : 0))].pos; seekByCue = true; }
      else {
        seekByCue = false;
        const fc = Math.max(0, firstCluster), endB = (dmx.segSize > 0 ? dmx.seg + dmx.segSize : total) || 0;
        pos = duration > 0 && endB > fc ? Math.max(fc, Math.floor(fc + (endB - fc) * (t * 1000 / duration) - 262144)) : fc;
      }
      L("seek " + Math.round(t) + "s → " + pos + (seekByCue ? " (cue)" : ""));
      restartAt(pos, true);
    }
    let seekTimer = 0, seekPend = false;
    function onSeeking() {
      if (ctl.destroyed || !V) return;
      if (Date.now() < selfUntil && Math.abs(v.currentTime - selfT) < 0.6) return;
      if (inBuf(v.currentTime)) return;
      seekPend = true;
      clearTimeout(seekTimer);
      seekTimer = setTimeout(() => { if (!inBuf(v.currentTime)) doSeek(v.currentTime); else seekPend = false; }, 280);
    }
    // قفز الفجوات الصغيرة (مثلاً عندما يبدأ الصوت بعد الصورة بجزء من الثانية بعد القفز)
    function gapJump() {
      if (ctl.destroyed || v.readyState >= 3 || seekWait || seekPend || (!started && !ctl.seeked)) return;
      let b; try { b = v.buffered; } catch (e) { return; }
      const t = v.currentTime;
      for (let i = 0; i < b.length; i++) {
        const s0 = b.start(i), e0 = b.end(i);
        if (t >= s0 - 0.01 && t < e0) return;
        if (s0 > t && s0 - t < 3.5) { setTime(s0 + 0.05); L("gap → " + s0.toFixed(2)); return; }
      }
    }
    function onUpdate() {
      if (ctl.destroyed) return;
      gapJump();
      const b = buffered(vq.sb);
      if (!started && !seekWait && b && b.length && (!A || (buffered(aq.sb) || { length: 0 }).length || vFrags > 3)) {
        started = true;
        if (!ctl.seeked && v.currentTime < b.start(0) - 0.05) setTime(b.start(0) + 0.02);
        L("ready " + b.start(0).toFixed(2));
        o.onready && o.onready(ctl.info);
      }
      if (eof && V && vFrags > 0 && vq.sb && vq.idle() && aq.idle() && ms.readyState === "open") { try { ms.endOfStream(); } catch (e) {} }
    }

    async function pump(from, g) {
      let tries = 0, discard = 0;
      while (g === gen && !ctl.destroyed) {
        const ac = new AbortController(); fetchCtl = ac;
        let res;
        try { res = await (window.__fcFetch || window.fetch.bind(window))(url, { headers: { Range: "bytes=" + from + "-" }, signal: ac.signal, cache: "no-store" }); }
        catch (e) {
          if (g !== gen) return;
          L("fetch error: " + (e.message || e));
          if (++tries > 3) return fail(from === 0 ? "تعذّر الاتصال بخادم الفيلم" : "انقطع الاتصال بخادم الفيلم");
          await sleep(900 * tries); continue;
        }
        if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
        if (res.status === 416) { eof = true; flushVideo(true); onUpdate(); return; }
        if (!res.ok) {
          L("HTTP " + res.status);
          if (++tries > 2 || res.status === 401 || res.status === 403 || res.status === 404) return fail("الخادم رفض تشغيل الفيلم (HTTP " + res.status + ")");
          await sleep(1200); continue;
        }
        const cr = res.headers.get("content-range") || "", cl = +res.headers.get("content-length") || 0;
        const m = cr.match(/\/(\d+)/);
        if (m) total = +m[1]; else if (res.status === 200 && cl) total = cl;
        discard = res.status === 200 && from > 0 ? from : 0;
        if (from === 0) ctl.info.size = total;
        const rd = res.body.getReader();
        let first = from === 0 && !tracks, rd0 = 0;
        try {
          for (;;) {
            await gate(g);
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            const { done, value } = await rd.read();
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            if (done) break;
            rd0 += value.length; if (res.sahraAck) res.sahraAck(rd0);   // نخبر التطبيق بما قرأناه: إن لم نقرأ يتوقف التنزيل بدل أن يمتلئ ذاكرة الصفحة
            let chunk = value;
            if (discard) { if (chunk.length <= discard) { discard -= chunk.length; continue; } chunk = chunk.subarray(discard); discard = 0; }
            if (first) {
              first = false;
              if (!(chunk[0] === 0x1A && chunk[1] === 0x45 && chunk[2] === 0xDF && chunk[3] === 0xA3)) {
                try { ac.abort(); } catch (e) {}
                const k = chunk.length > 8 && chunk[4] === 0x66 && chunk[5] === 0x74 && chunk[6] === 0x79 && chunk[7] === 0x70 ? "mp4" : chunk[0] === 0x47 ? "ts" : /^#EXTM3U/.test(str(chunk.subarray(0, 7))) ? "hls" : "other";
                L("not mkv: " + k);
                stopAll(); ctl.destroyed = true; v.removeEventListener("seeking", onSeeking);
                o.onformat && o.onformat(k);
                return;
              }
            }
            from += chunk.length; tries = 0; ctl.bytes += chunk.length;
            dmx.push(chunk);
            if (ctl.failed) return;
          }
        } catch (e) {
          if (g !== gen) return;
          L("read error at " + from + ": " + (e.message || e));
          if (++tries > 5) return fail("انقطع تحميل الفيلم");
          await sleep(700 * tries); continue;
        }
        if (total && from < total) { L("early end " + from + "/" + total); if (++tries > 5) return fail("انقطع تحميل الفيلم"); await sleep(600); continue; }
        eof = true; flushVideo(true); onUpdate();
        L("eof");
        return;
      }
    }

    v.addEventListener("seeking", onSeeking);
    try {
      ms = new MS();
      ms.addEventListener("sourceopen", () => { msOpen = true; setup(); }, { once: true });
      v.disableRemotePlayback = true;
      objUrl = URL.createObjectURL(ms);
      v.src = objUrl;
    } catch (e) { setTimeout(() => fail("تعذّر تجهيز المشغل: " + (e.message || e)), 0); return ctl; }
    pump(0, gen);
    return ctl;
  }

  /* ───────── محرك TS الخاص بالسهرة: بث مباشر MPEG-TS → MP4 مجزأ (بديل تلقائي لمكتبة mpegts.js) ───────── */
  function unesc(n) { const o = []; for (let i = 0; i < n.length; i++) { if (i >= 2 && n[i] === 3 && n[i - 1] === 0 && n[i - 2] === 0) continue; o.push(n[i]); } return new Uint8Array(o); }
  function spsSize(sps) {
    try {
      const d = unesc(sps); let bit = 8;
      const rb = n => { let v = 0; for (let i = 0; i < n; i++, bit++) v = v * 2 + ((d[bit >> 3] >> (7 - (bit & 7))) & 1); return v; };
      const ue = () => { let z = 0; while (!rb(1) && z < 32) z++; return (Math.pow(2, z) - 1) + (z ? rb(z) : 0); };
      const se = () => { const k = ue(); return k & 1 ? (k + 1) / 2 : -k / 2; };
      const prof = rb(8); rb(16); ue();
      let cf = 1;
      if ([100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135].indexOf(prof) >= 0) {
        cf = ue(); if (cf === 3) rb(1); ue(); ue(); rb(1);
        if (rb(1)) for (let i = 0; i < (cf !== 3 ? 8 : 12); i++) if (rb(1)) { let last = 8, next = 8; for (let j = 0; j < (i < 6 ? 16 : 64); j++) { if (next) next = (last + se() + 256) % 256; last = next || last; } }
      }
      ue(); const poc = ue();
      if (poc === 0) ue(); else if (poc === 1) { rb(1); se(); se(); const n = ue(); for (let i = 0; i < n; i++) se(); }
      ue(); rb(1);
      const w = ue() + 1, h = ue() + 1, fmo = rb(1);
      if (!fmo) rb(1); rb(1);
      let cl = 0, cr = 0, ct = 0, cb = 0;
      if (rb(1)) { cl = ue(); cr = ue(); ct = ue(); cb = ue(); }
      const cx = cf === 0 ? 1 : 2, cy = (cf === 1 ? 2 : 1) * (2 - fmo);
      return [w * 16 - (cl + cr) * cx, (2 - fmo) * h * 16 - (ct + cb) * cy];
    } catch (e) { return [0, 0]; }
  }
  function annexB(d) {
    const out = []; let i = 0, s = -1;
    while (i + 3 <= d.length) {
      if (d[i] === 0 && d[i + 1] === 0 && (d[i + 2] === 1 || (i + 3 < d.length && d[i + 2] === 0 && d[i + 3] === 1))) {
        const sc = d[i + 2] === 1 ? 3 : 4;
        if (s >= 0 && i > s) out.push(d.subarray(s, i));
        i += sc; s = i;
      } else i++;
    }
    if (s >= 0 && s < d.length) out.push(d.subarray(s));
    return out;
  }
  const rdTs = (d, i) => ((d[i] >> 1) & 7) * 1073741824 + ((((d[i + 1] << 8) | d[i + 2]) >> 1) * 32768) + (((d[i + 3] << 8) | d[i + 4]) >> 1);
  function startTS(v, url, o) {
    o = o || {};
    const live = o.live !== false;
    const MS = window.ManagedMediaSource || window.MediaSource;
    const mms = !!window.ManagedMediaSource && MS === window.ManagedMediaSource;
    const ctl = { info: { fmt: "TS" }, log: [], destroyed: false };
    const L = m => { ctl.log.push(m); if (ctl.log.length > 30) ctl.log.shift(); };
    const fail = m => { if (ctl.destroyed || ctl.failed) return; ctl.failed = true; L("fail: " + m); stop(); o.onerror && o.onerror(m); };
    if (!MS) { setTimeout(() => fail("هذا الجهاز لا يدعم التشغيل المتقدم (يحتاج iOS 17.1 أو أحدث)"), 0); return ctl; }
    const sup = m => { try { return MS.isTypeSupported(m); } catch (e) { return false; } };
    let ms = null, objUrl = "", fetchCtl = null, gen = 0, started = false;
    let pmt = -1, vPid = -1, aPid = -1, vType = "", aType = "", aLang = "", pes = {}, rest = null;
    let sps = null, pps = null, V = null, A = null, aBuf = null, vs = [], as = [], base = -1, shift = 0, lastV = -1, lastDur = 3600, vseq = 1, aseq = 1, aNext = -1, vInitKey = "";
    const Q = []; let vsb = null, asb = null, waitAudio = 0;
    function SB(sb) {
      const q = []; let bytes = 0;
      const S = { sb, q, get bytes() { return bytes; },
        push(d) { q.push(d); bytes += d.length; S.kick(); },
        rm(a, b) { if (b > a) { q.push({ rm: [a, b] }); S.kick(); } },
        kick() {
          if (ctl.destroyed || sb.updating || !q.length || ms.readyState === "closed") return;
          const x = q[0];
          try { if (x.rm) sb.remove(x.rm[0], x.rm[1]); else sb.appendBuffer(x); q.shift(); if (!x.rm) bytes -= x.length; }
          catch (e) { if (e.name === "QuotaExceededError") { evict(4); setTimeout(S.kick, 400); } else if (x.rm) q.shift(); else fail("خطأ في التشغيل: " + e.name); }
        } };
      sb.addEventListener("updateend", () => { S.kick(); onUpd(); });
      sb.addEventListener("error", () => fail("تعذّر فك البث"));
      return S;
    }
    function stop() { gen++; try { fetchCtl && fetchCtl.abort(); } catch (e) {} clearInterval(ctl.t); }
    ctl.destroy = () => { if (ctl.destroyed) return; stop(); ctl.destroyed = true; try { v.removeAttribute("src"); v.load(); } catch (e) {} try { objUrl && URL.revokeObjectURL(objUrl); } catch (e) {} };
    function evict(keep) { const t = v.currentTime; for (const S of [vsb, asb]) { if (!S) continue; try { const b = S.sb.buffered; if (b.length && t - b.start(0) > keep + 2) S.rm(b.start(0), t - keep); } catch (e) {} } }
    function onUpd() {
      if (ctl.destroyed) return;
      let b; try { b = v.buffered; } catch (e) { return; }
      if (!started && V && b.length) {
        if (b.end(b.length - 1) - b.start(0) < SB0) return;   // ننتظر حجم التخزين المؤقت المختار قبل البدء
        started = true; try { v.currentTime = b.start(0) + 0.05; } catch (e) {}
        L("ready " + b.start(0).toFixed(2)); o.onready && o.onready(ctl.info);
      }
    }
    const SB0 = Math.max(0, +o.startBuf || 0), LMAX = Math.max(4, +o.liveMax || 12), KEEP = +o.keep || (live ? 20 : 40), REBUF = !!o.rebuf;
    let rebuf = false;
    ctl.bytes = 0;
    ctl.trim = () => { try { evict(3); } catch (e) {} };
    ctl.ahead = () => { let b; try { b = v.buffered; } catch (e) { return 0; } const t = v.currentTime; for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.3 && t <= b.end(i)) return b.end(i) - t; return 0; };
    ctl.userPause = () => { rebuf = false; };
    function tick() {
      if (!started || ctl.destroyed) return;
      evict(KEEP);
      let b; try { b = v.buffered; } catch (e) { return; }
      if (!b.length) return;
      const t = v.currentTime, end = b.end(b.length - 1), ah = ctl.ahead();
      if (live && end - t > LMAX) { L("catch up " + (end - t).toFixed(1)); try { v.currentTime = end - Math.max(1.5, SB0 + 1); } catch (e) {} return; }
      // تخزين أكبر: عند نفاد المخزون نتوقف قليلاً حتى يمتلئ بدل التقطيع المتكرر
      if (REBUF && !rebuf && !v.paused && ah < 0.25 && v.readyState < 3) { rebuf = true; L("rebuffer"); try { v.pause(); } catch (e) {} o.onbuffer && o.onbuffer(true); }
      else if (rebuf && ah >= Math.max(1, SB0)) { rebuf = false; const p = v.play(); if (p && p.catch) p.catch(() => {}); o.onbuffer && o.onbuffer(false); }
      if (v.readyState < 3) for (let i = 0; i < b.length; i++) { if (t >= b.start(i) && t < b.end(i)) break; if (b.start(i) > t && b.start(i) - t < 4) { try { v.currentTime = b.start(i) + 0.05; } catch (e) {} break; } }
    }
    // ── المسارات: ننشئ مخازن الصورة والصوت معاً بعد وصول أول إطار مفتاحي وأول إطار صوت
    let aInfo = null, keySeen = false;
    function audioInfo(f) {
      if (aType === "aac") {
        const aot = (f[2] >> 6) + 1, si = (f[2] >> 2) & 15, ch = ((f[2] & 1) << 2) | (f[3] >> 6), sr = SRS[si] || 48000;
        return { codec: "mp4a.40." + aot, name: "AAC", sr, fs: 1024, entry: aEntry("mp4a", ch || 2, sr, esds(0x40, asc(aot, sr, ch || 2))) };
      }
      if (aType === "ac3") { const sr = [48000, 44100, 32000][f[4] >> 6] || 48000; return { codec: "ac-3", name: "AC-3", sr, fs: 1536, entry: aEntry("ac-3", 2, sr, dac3(f, sr, 2)) }; }
      if (aType === "eac3") { const d = dec3(f, 48000, 2); return { codec: "ec-3", name: "E-AC-3", sr: 48000, fs: d.fs, entry: aEntry("ec-3", 2, 48000, d.box) }; }
      return null;
    }
    const spsKey = () => Array.from(sps).join(",") + "|" + Array.from(pps).join(",");
    function vInit() {
      const wh = spsSize(sps);
      const avcC = cat([new Uint8Array([1, sps[1], sps[2], sps[3], 0xFF, 0xE1, sps.length >> 8, sps.length & 255]), sps, new Uint8Array([1, pps.length >> 8, pps.length & 255]), pps]);
      vInitKey = spsKey();
      return { wh, codec: "avc1." + hx(sps[1]) + hx(sps[2]) + hx(sps[3]), init: initSeg({ kind: "v", ts: 90000, w: wh[0], h: wh[1], entry: vEntry("avc1", wh[0], wh[1], box("avcC", avcC)) }) };
    }
    function trySetup() {
      if (V || ctl.failed || !keySeen || !sps || !pps || ms.readyState !== "open") return;
      const waited = vs.length > 1 ? vs[vs.length - 1].dts - vs[0].dts : 0;
      if (aPid >= 0 && !aInfo && waited < 180000) return;
      const x = vInit();
      if (!sup('video/mp4; codecs="' + x.codec + '"')) return fail("هذا الجهاز لا يدعم فيديو هذا البث (" + x.codec + ")");
      try { vsb = SB(ms.addSourceBuffer('video/mp4; codecs="' + x.codec + '"')); } catch (e) { return fail("تعذّر تجهيز المشغل: " + (e.message || e.name)); }
      if (aInfo) {
        if (sup('audio/mp4; codecs="' + aInfo.codec + '"')) { try { asb = SB(ms.addSourceBuffer('audio/mp4; codecs="' + aInfo.codec + '"')); A = aInfo; } catch (e) { asb = null; } }
        if (!A) ctl.info.note = "صوت " + aInfo.name + " غير مدعوم داخلياً — للصوت افتحه في VLC";
      }
      V = { codec: x.codec };
      vsb.push(x.init);
      if (A) asb.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry }));
      ctl.info.v = "H.264"; ctl.info.res = x.wh[0] + "×" + x.wh[1];
      if (A) ctl.info.a = A.name + (aLang && aLang !== "und" ? " · " + (LANGS[aLang] || aLang) : "");
      L("setup " + x.codec + " " + (A ? A.codec : "no-audio"));
      o.onstatus && o.onstatus(ctl.info);
      if (!A) as = [];
      flushV(false);
    }
    // ── الطوابع الزمنية: تسلسل مستمر حتى عند انقطاع البث أو التفاف العداد
    function outT(dts) {
      if (base < 0) base = dts;
      let t = dts - base + shift;
      if (lastV >= 0 && (t < lastV - 45000 || t > lastV + 900000)) { shift += lastV + lastDur - t; t = lastV + lastDur; L("discontinuity"); aNext = -1; }
      return t;
    }
    function onVideo(pts, dts, d) {
      const ns = annexB(d); let key = false, nsps = null, npps = null; const keep = [];
      for (const n of ns) { const t = n[0] & 0x1f; if (t === 7) nsps = n; else if (t === 8) npps = n; else if (t === 9 || t === 12) continue; else { if (t === 5) key = true; keep.push(n); } }
      if (nsps) sps = nsps.slice(); if (npps) pps = npps.slice();
      if (!keySeen) { if (!key || !sps || !pps) return; keySeen = true; }
      if (V && key && nsps && vInitKey !== spsKey()) { flushV(true); const x = vInit(); vsb.push(x.init); L("sps change " + x.wh.join("x")); }
      if (!keep.length) return;
      let n = 0; for (const x of keep) n += 4 + x.length;
      const out = new Uint8Array(n); let q = 0;
      for (const x of keep) { out.set(u32(x.length), q); out.set(x, q + 4); q += 4 + x.length; }
      if (dts == null) dts = pts;
      const t = outT(dts);
      vs.push({ dts: t, cts: Math.max(0, pts - dts), data: out, key });
      lastV = t;
      if (!V) { trySetup(); if (!V) { if (vs.length > 600) vs.shift(); return; } }
      if (key && vs.length > 1) flushV(false);
      else if (vs.length > 1 && vs[vs.length - 1].dts - vs[0].dts > (live ? 90000 : 180000)) flushV(false);
    }
    function flushV(all) {
      if (!V || vs.length < (all ? 1 : 2)) return;
      const k = all ? vs.length : vs.length - 1;
      const out = vs.splice(0, k), nx = vs[0];
      const smp = out.map((f, i) => { const nd = i + 1 < out.length ? out[i + 1].dts : nx ? nx.dts : f.dts + lastDur; const dur = Math.max(1, Math.min(nd - f.dts, 90000)); lastDur = dur; return { data: f.data, dur, flags: f.key ? 0x02000000 : 0x01010000, cts: f.cts }; });
      vsb.push(frag(vseq++, out[0].dts, smp));
      flushA();
    }
    function onAudio(pts, d) {
      if (rest) { d = cat([rest, d]); rest = null; }
      const fr = [];
      let i = 0;
      while (i + 7 < d.length) {
        if (aType === "aac") {
          if (d[i] !== 0xFF || (d[i + 1] & 0xF6) !== 0xF0) { i++; continue; }
          const len = ((d[i + 3] & 3) << 11) | (d[i + 4] << 3) | (d[i + 5] >> 5), hl = (d[i + 1] & 1) ? 7 : 9;
          if (len < hl) { i++; continue; }
          if (i + len > d.length) break;
          if (!aInfo) aInfo = audioInfo(d.subarray(i, i + 7));
          fr.push(d.subarray(i + hl, i + len)); i += len;
        } else {
          if (d[i] !== 0x0B || d[i + 1] !== 0x77) { i++; continue; }
          let len;
          if (aType === "ac3") { const fs = d[i + 4] >> 6, code = d[i + 4] & 63, kb = [32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640][code >> 1], sr = [48000, 44100, 32000][fs]; if (!kb || !sr) { i++; continue; } len = 2 * (Math.floor(96000 * kb / sr) + (sr === 44100 ? code & 1 : 0)); }
          else len = ((((d[i + 2] & 7) << 8) | d[i + 3]) + 1) * 2;
          if (i + len > d.length) break;
          if (!aInfo) aInfo = audioInfo(d.subarray(i, i + len));
          fr.push(d.subarray(i, i + len)); i += len;
        }
      }
      if (i < d.length) rest = d.slice(i, Math.min(d.length, i + 8192));
      const AI = A || aInfo;
      if (!AI || !fr.length || base < 0 || (V && !A)) return;
      const t0 = (pts - base + shift) * AI.sr / 90000;
      fr.forEach((f, j) => as.push({ t: t0 + j * AI.fs, data: f }));
      if (!V) { trySetup(); if (as.length > 2000) as.splice(0, as.length - 2000); return; }
      if (as.length && as[as.length - 1].t - as[0].t > A.sr) flushA();
    }
    function flushA() {
      if (!A || !asb || !as.length) return;
      let b0 = Math.round(as[0].t);
      if (aNext >= 0 && Math.abs(b0 - aNext) < A.fs * 2) b0 = aNext;
      if (b0 < 0) { as = []; return; }
      aNext = b0 + as.length * A.fs;
      asb.push(frag(aseq++, b0, as.map(f => ({ data: f.data, dur: A.fs, flags: 0x02000000, cts: 0 }))));
      as = [];
    }
    // ── قراءة الحزم
    function psi(p) { const ptr = p[0]; return p.subarray(1 + ptr); }
    function onPkt(d, o2) {
      const pusi = d[o2 + 1] & 0x40, pid = ((d[o2 + 1] & 0x1f) << 8) | d[o2 + 2], afc = (d[o2 + 3] >> 4) & 3;
      let s = o2 + 4;
      if (afc & 2) s += 1 + d[s];
      if (!(afc & 1) || s >= o2 + 188) return;
      const pl = d.subarray(s, o2 + 188);
      if (pid === 0) {
        if (!pusi || pmt >= 0) return;
        const t = psi(pl), sl = ((t[1] & 15) << 8) | t[2];
        for (let i = 8; i + 4 <= 3 + sl - 4; i += 4) { const pn = (t[i] << 8) | t[i + 1]; if (pn) { pmt = ((t[i + 2] & 0x1f) << 8) | t[i + 3]; break; } }
        return;
      }
      if (pid === pmt) {
        if (!pusi || vPid >= 0 || aPid >= 0) return;
        const t = psi(pl), sl = ((t[1] & 15) << 8) | t[2], pil = ((t[10] & 15) << 8) | t[11];
        let i = 12 + pil; const end = Math.min(t.length, 3 + sl - 4), auds = [];
        while (i + 5 <= end) {
          const st = t[i], ep = ((t[i + 1] & 0x1f) << 8) | t[i + 2], il = ((t[i + 3] & 15) << 8) | t[i + 4];
          let lang = "", ds = "";
          for (let j = i + 5; j + 2 <= i + 5 + il;) { const tag = t[j], ln = t[j + 1]; if (tag === 0x0A && ln >= 3) lang = String.fromCharCode(t[j + 2], t[j + 3], t[j + 4]); if (tag === 0x6A) ds = "ac3"; if (tag === 0x7A) ds = "eac3"; j += 2 + ln; }
          if (st === 0x1B && vPid < 0) { vPid = ep; vType = "h264"; }
          else if (st === 0x24 && vPid < 0) { vPid = ep; vType = "hevc"; }
          else if (st === 0x0F) auds.push({ pid: ep, type: "aac", lang });
          else if (st === 0x81 || (st === 0x06 && ds === "ac3")) auds.push({ pid: ep, type: "ac3", lang });
          else if (st === 0x87 || (st === 0x06 && ds === "eac3")) auds.push({ pid: ep, type: "eac3", lang });
          i += 5 + il;
        }
        const arW = o.audioPref === "orig" ? 0 : 2;
        auds.forEach((a, k) => { a.k = k; });
        auds.sort((x, y) => (/^ar/i.test(y.lang) ? arW : 0) + (y.type === "aac" ? 1 : 0) - y.k * 0.01 - ((/^ar/i.test(x.lang) ? arW : 0) + (x.type === "aac" ? 1 : 0) - x.k * 0.01));
        if (auds[0]) { aPid = auds[0].pid; aType = auds[0].type; aLang = auds[0].lang.toLowerCase(); }
        L("pmt v=" + vType + " a=" + aType + (aLang ? "/" + aLang : ""));
        if (vType === "hevc") return fail("بث HEVC — استخدم المحرك الأساسي أو VLC");
        if (vPid < 0) return fail("لا يوجد فيديو في هذا البث");
        return;
      }
      if (pid !== vPid && pid !== aPid) return;
      const st = pes[pid] || (pes[pid] = { parts: [], len: 0 });
      if (pusi) { if (st.len) endPes(pid, st); st.parts = [pl]; st.len = pl.length; }
      else if (st.len) { st.parts.push(pl); st.len += pl.length; }
    }
    function endPes(pid, st) {
      const d = st.parts.length === 1 ? st.parts[0] : cat(st.parts);
      st.parts = []; st.len = 0;
      if (d.length < 9 || d[0] !== 0 || d[1] !== 0 || d[2] !== 1) return;
      const fl = d[7], hl = d[8];
      const pts = fl & 0x80 ? rdTs(d, 9) : null, dts = fl & 0x40 ? rdTs(d, 14) : pts;
      const body = d.subarray(9 + hl);
      if (pid === vPid) { if (pts != null) onVideo(pts, dts, body); }
      else if (pts != null || rest) onAudio(pts != null ? pts : 0, body);
    }
    let carry = null;
    function feed(chunk) {
      let d = chunk;
      if (carry) { d = cat([carry, chunk]); carry = null; }
      let i = 0;
      while (i + 188 <= d.length) {
        if (d[i] !== 0x47) { i++; continue; }
        if (i + 188 < d.length && d[i + 188] !== 0x47) { i++; continue; }
        onPkt(d, i); if (ctl.failed) return;
        i += 188;
      }
      if (i < d.length) carry = d.slice(i);
    }
    async function pump(g) {
      let tries = 0, got = 0;
      while (g === gen && !ctl.destroyed) {
        const ac = new AbortController(); fetchCtl = ac;
        try {
          const r = await (window.__fcFetch || window.fetch.bind(window))(url, { signal: ac.signal, cache: "no-store" });
          if (g !== gen) { ac.abort(); return; }
          if (!r.ok) { if (++tries > 2) return fail("الخادم رفض البث (HTTP " + r.status + ")"); await sleep(1000); continue; }
          const rd = r.body.getReader(); let rd0 = 0;
          for (;;) {
            while (g === gen && ((vsb ? vsb.bytes : 0) + (asb ? asb.bytes : 0)) > 12e6) await sleep(200);
            const { done, value } = await rd.read();
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            if (done) break;
            rd0 += value.length; if (r.sahraAck) r.sahraAck(rd0);
            got += value.length; ctl.bytes += value.length; tries = 0; feed(value);
            if (ctl.failed) return;
          }
        } catch (e) { if (g !== gen) return; L("net: " + (e.message || e)); if (!got) return fail("NetworkError — " + (e.message || e)); }
        if (!live) { flushV(true); return; }
        if (++tries > 4) return fail("انقطع البث");
        L("reconnect " + tries); await sleep(500 * tries);
        carry = null; rest = null; pes = {};
      }
    }
    try {
      ms = new MS();
      ms.addEventListener("sourceopen", () => { pump(gen); }, { once: true });
      v.disableRemotePlayback = true;
      objUrl = URL.createObjectURL(ms);
      v.src = objUrl;
    } catch (e) { setTimeout(() => fail("تعذّر تجهيز المشغل: " + (e.message || e)), 0); return ctl; }
    ctl.t = setInterval(tick, 500);
    return ctl;
  }
  window.AlsahraTS = { play: startTS };
  window.AlsahraMKV = { play: start };
  return 1;
}

const MKV_JS = "(" + alsahraMkvMain.toString() + ")()";
/* ───────── صندوق مشغل السهرة: مكوّن واحد يعمل داخل صفحة التطبيق أو صفحة المشغل ─────────
   يشغّل: MKV (تحويل حي) · TS+ (محرك السهرة) · mpegts.js · HLS · مشغل iOS الأصلي
   مع: شريط تقديم، ±10، ترجمة + ترجمة تلقائية، إعدادات (تخزين مؤقت، محرك، مقاس، سرعة…)، تقرير. */
function alsahraBoxMain() {
  if (window.AlsahraBox) return 1;
  var CSS = ".epx{position:absolute;inset:0;color:#fff;font-family:-apple-system,system-ui,sans-serif;-webkit-user-select:none;user-select:none;direction:rtl;--a:#e50914}" +
    ".epx *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}" +
    ".epx button{font:inherit;color:#fff;border:0;background:rgba(255,255,255,.14);height:40px;padding:0 12px;border-radius:12px;font-weight:700;font-size:13.5px;white-space:nowrap;flex:none}" +
    ".epx button:active{transform:scale(.96)}" +
    ".ex-box{position:absolute;inset:0;background:#000;overflow:hidden}" +
    ".ex-box video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000}" +
    ".ex-box video::cue{font-size:15px;background:rgba(0,0,0,.6);font-family:-apple-system,sans-serif}" +
    ".ex-box video::-webkit-media-text-track-container{transition:transform .25s}.ex-box:not(.hid) video::-webkit-media-text-track-container{transform:translateY(-40px)}" +
    ".ex-box video::cue{line-height:1.45;text-shadow:0 1px 3px rgba(0,0,0,.9)}" +
    ".fs-s video::cue{font-size:12px}.fs-m video::cue{font-size:15px}.fs-l video::cue{font-size:19px}.fs-xl video::cue{font-size:24px}" +
    ".ex-ov{position:absolute;inset:0;z-index:3;display:flex;flex-direction:column;justify-content:space-between;background:linear-gradient(rgba(0,0,0,.45),rgba(0,0,0,0) 30%,rgba(0,0,0,0) 55%,rgba(0,0,0,.8));transition:opacity .25s}" +
    ".hid .ex-ov{opacity:0;pointer-events:none}" +
    ".ex-top{display:flex;align-items:center;gap:8px;padding:8px 10px;direction:ltr}.ex-top .sp{flex:1}" +
    ".ex-bd{font-size:11px;font-weight:800;padding:5px 10px;border-radius:99px;background:var(--a);white-space:nowrap;max-width:62%;overflow:hidden;text-overflow:ellipsis}" +
    ".ex-oc{display:flex;justify-content:center;align-items:center;gap:22px;direction:ltr}" +
    ".epx .ex-oc button{width:50px;height:50px;padding:0;border-radius:50%;background:rgba(0,0,0,.45);font-size:14px}.epx .ex-oc .pp{width:60px;height:60px;font-size:20px}" +
    ".ex-ob{padding:0 10px 8px}" +
    ".ex-seek{display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11.5px;font-weight:700;color:#ddd;font-variant-numeric:tabular-nums;direction:ltr}" +
    ".ex-rg{flex:1;-webkit-appearance:none;appearance:none;height:4px;border-radius:9px;background:linear-gradient(90deg,var(--a) var(--p,0%),rgba(255,255,255,.3) var(--p,0%));outline:0}" +
    ".ex-rg::-webkit-slider-thumb{-webkit-appearance:none;width:15px;height:15px;border-radius:50%;background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.5)}" +
    ".ex-row{display:flex;gap:8px;direction:ltr;justify-content:flex-end}.epx .ex-row button{height:32px;padding:0 10px;border-radius:10px;font-size:12.5px;background:rgba(0,0,0,.55)}" +
    ".epx .cc{display:none}.hascc .cc{display:inline-block}.epx .on.cc,.epx .on.gear{background:var(--a)}" +
    ".ex-mid{position:absolute;inset:0;z-index:4;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;text-align:center;padding:12px;pointer-events:none}" +
    ".ex-sp{width:40px;height:40px;border-radius:50%;border:3px solid rgba(255,255,255,.15);border-top-color:#fff;animation:exr .8s linear infinite}@keyframes exr{to{transform:rotate(360deg)}}" +
    ".ex-msg{font-size:14px;font-weight:700;color:#f2f2f2;max-width:92%;line-height:1.6;white-space:pre-line}" +
    ".ex-dt{font-size:10.5px;color:#9a9a9a;max-width:92%;line-height:1.5;direction:ltr;word-break:break-all;display:none;max-height:3em;overflow:hidden}.err .ex-dt{display:block}" +
    ".epx .ex-pl{pointer-events:auto;width:64px;height:64px;padding:0;border-radius:50%;background:var(--a);font-size:24px;display:none}" +
    ".ex-eb{pointer-events:auto;display:none;gap:7px;flex-wrap:wrap;justify-content:center}.epx .ex-eb button{height:34px;padding:0 11px;font-size:12.5px;border-radius:11px}" +
    ".err .ex-sp{display:none}.err .ex-eb{display:flex}.ok .ex-mid{display:none}.ok.buf .ex-mid{display:flex}.ok.buf .ex-msg{display:none}" +
    ".err .ex-ov,.load .ex-ov{background:none}.err .ex-oc,.load .ex-oc{visibility:hidden}" +
    ".epx .vlc{background:#f97316}" +
    ".live .ex-seek,.live .ex-oc,.live .cc{display:none}" +
    ".ex-note,.ex-toast{position:absolute;left:50%;transform:translateX(-50%);z-index:6;background:rgba(15,15,18,.93);border:1px solid rgba(255,255,255,.12);padding:7px 12px;border-radius:12px;font-size:12px;font-weight:600;width:max-content;max-width:90%;text-align:center;line-height:1.5;display:none}" +
    ".ex-note{top:44px}.ex-toast{bottom:52px}" +
    ".ex-rs{position:absolute;z-index:6;left:10px;bottom:48px;display:none}.epx .ex-rs button{height:32px;font-size:12px;background:rgba(20,20,24,.92);border:1px solid rgba(255,255,255,.18)}" +
    ".ex-menu{position:absolute;z-index:7;right:10px;bottom:46px;background:rgba(16,16,20,.97);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:5px;max-height:78%;overflow:auto;display:none;min-width:210px}" +
    ".epx .ex-menu button{display:flex;width:100%;justify-content:space-between;gap:12px;height:38px;background:transparent;font-size:13.5px;font-weight:600}.epx .ex-menu button.on{color:var(--a)}.epx .ex-menu button.on::after{content:'✓'}" +
    ".ex-sets{position:absolute;inset:0;z-index:8;background:rgba(10,10,14,.96);overflow-y:auto;-webkit-overflow-scrolling:touch;padding:10px 12px 14px;display:none}.ex-sets.on{display:block}" +
    ".ex-sets .hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}.ex-sets .hdr b{font-size:14px}.epx .ex-sets .hdr button{height:32px;padding:0 12px;font-size:12.5px}" +
    ".ex-sets h4{font-size:12.5px;color:#aaa;margin:10px 2px 6px;font-weight:700}" +
    ".ex-sg{display:flex;gap:6px;flex-wrap:wrap}.epx .ex-sg button{height:32px;padding:0 11px;border-radius:10px;font-size:12.5px;background:rgba(255,255,255,.08)}.epx .ex-sg button.on{background:var(--a)}" +
    ".ex-sg[data-k=rate] button{direction:ltr}.ex-sets small{display:block;color:#888;font-size:11px;margin:6px 2px 0;line-height:1.6}" +
    ".epx.epx-st{position:relative;inset:auto}.epx-st .ex-sets{position:static;inset:auto;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:16px;margin:10px 14px 4px;padding:12px 14px 14px;overflow:visible}";
  var BUF = {
    low: { start: 0.3, live: 6, keep: 10, vod: 30, rebuf: false, mts: { enableStashBuffer: false, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 3, liveBufferLatencyMinRemain: 0.5 } },
    normal: { start: 1.5, live: 12, keep: 20, vod: 60, rebuf: false, mts: { enableStashBuffer: true, stashInitialSize: 384 * 1024, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 8, liveBufferLatencyMinRemain: 2 } },
    high: { start: 4, live: 25, keep: 30, vod: 120, rebuf: true, mts: { enableStashBuffer: true, stashInitialSize: 2 * 1024 * 1024, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 20, liveBufferLatencyMinRemain: 5 } },
    max: { start: 8, live: 45, keep: 40, vod: 240, rebuf: true, mts: { enableStashBuffer: true, stashInitialSize: 4 * 1024 * 1024, liveBufferLatencyChasing: false } }
  };
  var BUFN = { low: "قليل", normal: "متوازن", high: "كبير", max: "كبير جداً" };
  var BUFD = { low: "بدء فوري وأقل تأخير — للنت القوي", normal: "توازن بين سرعة البدء والثبات", high: "يخزّن ~4 ثوانٍ قبل البدء ويتوقف قليلاً بدل التقطيع", max: "يخزّن ~8 ثوانٍ — للنت الضعيف جداً" };
  var ENGL = { live: [["auto", "تلقائي"], ["own", "السهرة TS+"], ["mts", "السهرة TS"], ["hls", "السهرة HLS"], ["native", "iOS الأصلي"]], vod: [["auto", "تلقائي"], ["mkv", "السهرة MKV"], ["native", "iOS الأصلي"], ["mts", "السهرة TS"]] };
  var NET = /NetworkError|Load failed|Failed to fetch|تعذّر الاتصال|انقطع الاتصال|لا استجابة/;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var fmtT = function (s) { s = Math.max(0, Math.floor(s || 0)); var h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60; return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (x < 10 ? "0" : "") + x; };

  function create(root, host) {
    if (!document.getElementById("epx-css")) { var st0 = document.createElement("style"); st0.id = "epx-css"; st0.textContent = CSS; (document.head || document.documentElement).appendChild(st0); }
    var P = { state: "init", mts: null, mkv: null, ts: null, diag: [], o: {}, kind: "itv", items: [] };
    // تحذير ذاكرة من النظام (يستدعيه التطبيق): نفرّغ مخزن الصورة المشاهَد خلف الموضع الحالي
    window.__memWarn = function () { try { if (P.mkv && P.mkv.trim) P.mkv.trim(); if (P.ts && P.ts.trim) P.ts.trim(); } catch (e) {} };
    var send = function (m) { try { host.send(m); } catch (e) {} };
    var D = function (m) { P.diag.push(new Date().toTimeString().slice(0, 8) + " " + m); if (P.diag.length > 40) P.diag.shift(); };
    root.innerHTML = "<div class='epx live' data-e='ap'><div class='ex-box load' data-e='box'><video data-e='v' playsinline webkit-playsinline></video>" +
      "<div class='ex-mid'><div class='ex-sp'></div><div class='ex-msg' data-e='msg'>جاري التجهيز…</div><div class='ex-dt' data-e='dt'></div><button class='ex-pl' data-e='pl'>▶</button>" +
      "<div class='ex-eb'><button data-e='er'>إعادة</button><button class='vlc' data-e='evlc'>VLC</button><button data-e='alt'>محرك آخر ▾</button><button data-e='rep'>نسخ التقرير</button></div></div>" +
      "<div class='ex-ov'><div class='ex-top'><span class='ex-bd' data-e='bd'>مشغل السهرة</span><span class='sp'></span></div>" +
      "<div class='ex-oc'><button data-e='b10'>↺10</button><button class='pp' data-e='pp'>❚❚</button><button data-e='f10'>10↻</button></div>" +
      "<div class='ex-ob'><div class='ex-seek'><span data-e='tc'>0:00</span><input class='ex-rg' data-e='rg' type='range' min='0' max='1000' value='0'><span data-e='td'>0:00</span></div>" +
      "<div class='ex-row'><button class='cc' data-e='cc'>الترجمة</button><button class='gear' data-e='gear' aria-label='الإعدادات'>⚙︎</button><button data-e='fs' aria-label='ملء الشاشة'>⛶</button></div></div></div>" +
      "<div class='ex-menu' data-e='menu'></div><div class='ex-note' data-e='note'></div><div class='ex-toast' data-e='toast'></div><div class='ex-rs' data-e='rs'><button data-e='rsb'>↺ من البداية</button></div>" +
      "<div class='ex-sets' data-e='sets'></div></div></div>";
    // العناصر تُحفظ مرة واحدة؛ وبعد إزالة الصندوق تبقى مراجع منفصلة فلا تحدث أخطاء من المؤقتات المتأخرة
    var EL = {};
    var $ = function (id) { return EL[id] || (EL[id] = root.querySelector("[data-e='" + id + "']") || document.createElement("div")); };
    ["ap", "box", "v", "msg", "dt", "pl", "bd", "rg", "menu", "note", "toast", "rs", "sets", "cc", "gear", "pp", "tc", "td"].forEach($);
    // لوحة الإعدادات تحت الصندوق إذا وفّرت الصفحة مكاناً لها (أوسع وأسهل من داخل الصورة)
    var stw = null;
    if (host.setsHost) { stw = document.createElement("div"); stw.className = "epx epx-st"; stw.appendChild($("sets")); host.setsHost.appendChild(stw); }
    var ap = $("ap"), box = $("box"), v = $("v"), msg = $("msg"), pl = $("pl"), bd = $("bd"), rg = $("rg");
    var hideT, dragging = false, posT = 0, toastT = 0, noteT = 0, dead = false;
    var isVod = function () { return P.kind && P.kind !== "itv"; };
    var info = function (t) { try { host.info && host.info(t); } catch (e) {} };
    function show() { box.classList.remove("hid"); clearTimeout(hideT); if (P.state === "playing" && !v.paused) hideT = setTimeout(function () { if (!dragging && $("menu").style.display !== "block" && !$("sets").classList.contains("on")) box.classList.add("hid"); }, 3500); }
    function setMsg(t, kind, d) { box.classList.remove("ok", "err", "buf", "load"); box.classList.add(kind || "load"); msg.textContent = t || ""; $("dt").textContent = d || ""; }
    function state(s, m, extra) { P.state = s; var o = { c: "state", s: s, m: m || "" }; for (var k in extra || {}) o[k] = extra[k]; send(o); }
    function toast(t, ms) { var e = $("toast"); e.textContent = t; e.style.display = "block"; clearTimeout(toastT); toastT = setTimeout(function () { e.style.display = "none"; }, ms || 2600); }
    function note(t) { var e = $("note"); e.textContent = t; e.style.display = "block"; clearTimeout(noteT); noteT = setTimeout(function () { e.style.display = "none"; }, 7000); }
    box.addEventListener("click", function (e) {
      if (e.target.closest && e.target.closest("button,input,.ex-menu,.ex-sets")) return;
      if ($("menu").style.display === "block") { $("menu").style.display = "none"; return; }
      if (box.classList.contains("hid")) show(); else if (P.state === "playing") box.classList.add("hid");
    });
    function sendPos() { if (isVod() && P.state === "playing" && isFinite(v.duration) && v.duration > 60) send({ c: "pos", t: Math.floor(v.currentTime), d: Math.floor(v.duration) }); }
    $("evlc").onclick = function () { sendPos(); send({ c: "vlc", t: Math.floor(v.currentTime || 0) }); };
    $("er").onclick = function () { setMsg("جاري إعادة المحاولة…"); send({ c: "retry", t: Math.floor(P.lastT || 0) }); };
    $("rep").onclick = function () { send({ c: "report", diag: P.diag.concat(P.mkvLog || []).slice(-50), info: P.info || {} }); };
    $("fs").onclick = function () { try { if (v.webkitEnterFullscreen) v.webkitEnterFullscreen(); else if (v.requestFullscreen) v.requestFullscreen(); } catch (e) {} };
    $("pp").onclick = function () { if (!v.paused && P.ts && P.ts.userPause) P.ts.userPause(); if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(onPlayErr); } else v.pause(); show(); };
    $("b10").onclick = function () { try { v.currentTime = Math.max(0, v.currentTime - 10); } catch (e) {} show(); };
    $("f10").onclick = function () { try { v.currentTime = Math.min((v.duration || 1e9) - 1, v.currentTime + 10); } catch (e) {} show(); };
    $("rsb").onclick = function () { $("rs").style.display = "none"; try { v.currentTime = 0; } catch (e) {} };
    rg.addEventListener("input", function () { dragging = true; var d = v.duration || 0; $("tc").textContent = fmtT(rg.value / 1000 * d); rg.style.setProperty("--p", rg.value / 10 + "%"); show(); });
    rg.addEventListener("change", function () { dragging = false; var d = v.duration || 0; if (d && isFinite(d)) { try { v.currentTime = rg.value / 1000 * d; } catch (e) {} } show(); });
    pl.onclick = function () { pl.style.display = "none"; setMsg("جاري التشغيل…"); var p = P.mts ? P.mts.play() : v.play(); if (p && p.catch) p.catch(function () {}); };
    $("alt").onclick = function () {
      var m = $("menu"), cur = P.o.force || "auto";
      m.innerHTML = ENGL[isVod() ? "vod" : "live"].map(function (e) { return "<button data-eng='" + e[0] + "' class='" + (e[0] === cur ? "on" : "") + "'><span>" + e[1] + "</span></button>"; }).join("");
      m.style.display = "block";
    };

    /* ── الترجمة: مسارات الملف + ترجمة تلقائية مع زر إيقاف ── */
    var S = { subs: [], sel: -1, auto: null, src: -1, q: [], seen: {}, pend: {}, id: 0, busy: 0, fail: 0, log: {}, init: false };
    function trName() { return (P.o.trLang || "ar") === "ar" ? "العربية" : String(P.o.trLang).toUpperCase(); }
    function collectSubs() {
      var arr = [];
      if (P.mkv && P.mkv.subs) P.mkv.subs.forEach(function (s, k) { arr.push({ label: s.label, ar: s.ar, lang: s.lang || "", track: s.track, src: "mkv", k: k }); });
      else for (var i = 0; i < v.textTracks.length; i++) {
        var t = v.textTracks[i];
        if (t === S.auto || t.__als || (t.kind !== "subtitles" && t.kind !== "captions")) continue;
        arr.push({ label: t.label || t.language || ("ترجمة " + (arr.length + 1)), ar: /^ar/i.test(t.language || "") || /عرب|arab/i.test(t.label || ""), lang: t.language || "", track: t, src: "native" });
      }
      S.subs = arr;
      ap.classList.toggle("hascc", arr.length > 0);
      return arr;
    }
    function source() {
      var i = -1;
      S.subs.forEach(function (s, k) { if (i < 0 && !s.ar && (/^en/i.test(s.lang) || /english|انجليز|إنجليز/i.test(s.label))) i = k; });
      if (i < 0) S.subs.forEach(function (s, k) { if (i < 0 && !s.ar) i = k; });
      return i;
    }
    function applySubs() {
      collectSubs();
      if (!S.subs.length || S.init) return;
      S.init = true;
      var ar = -1; S.subs.forEach(function (s, k) { if (ar < 0 && s.ar) ar = k; });
      var want = P.o.subOn === false ? -1 : ar >= 0 ? ar : (P.o.tr !== false && source() >= 0 ? -2 : -1);
      selectSub(want, false);
      if (want === -2) note("ترجمة تلقائية إلى " + trName() + " — اضغط «الترجمة» لإيقافها");
    }
    function selectSub(sel, user) {
      S.sel = sel;
      var src = sel === -2 ? source() : -1;
      S.subs.forEach(function (s, k) { try { s.track.mode = k === sel ? "showing" : (k === src && s.src === "native" ? "hidden" : "disabled"); } catch (e) {} });
      if (sel === -2) startAuto(src);
      if (S.auto) { try { S.auto.mode = sel === -2 ? "showing" : "disabled"; } catch (e) {} }
      $("cc").classList.toggle("on", sel !== -1);
      if (user) {
        send({ c: "subpref", on: sel !== -1 });
        toast(sel === -1 ? "تم إيقاف الترجمة" : sel === -2 ? "ترجمة تلقائية إلى " + trName() : "الترجمة: " + S.subs[sel].label, 1600);
      }
    }
    function startAuto(src) {
      if (src < 0) return;
      if (!S.auto) { S.auto = v.addTextTrack("subtitles", trName() + " · ترجمة تلقائية", P.o.trLang || "ar"); S.auto.__als = 1; }
      if (S.src === src) return;
      S.src = src; S.q = []; S.seen = {};
      clearAuto(false);
      var s = S.subs[src];
      if (s.src === "mkv") (S.log[s.k] || []).forEach(queueCue);
      else pollNative();
    }
    function clearAuto(off) {
      if (!S.auto) return;
      try { var m = S.auto.mode; S.auto.mode = "hidden"; var cs = S.auto.cues ? Array.prototype.slice.call(S.auto.cues) : []; cs.forEach(function (c) { S.auto.removeCue(c); }); S.auto.mode = off ? "disabled" : m; } catch (e) {}
    }
    function pollNative() {
      var s = S.subs[S.src]; if (!s || s.src !== "native" || S.sel !== -2) return;
      try { var cs = s.track.cues; if (cs) for (var i = 0; i < cs.length; i++) queueCue({ st: cs[i].startTime, en: cs[i].endTime, txt: cs[i].text }); } catch (e) {}
    }
    function queueCue(c) {
      var txt = String(c.txt || "").replace(/<[^>]+>/g, "").trim(); if (!txt) return;
      var key = Math.round(c.st * 10) + "|" + txt; if (S.seen[key]) return; S.seen[key] = 1;
      S.q.push({ st: c.st, en: c.en, txt: txt });
    }
    function flushTr() {
      if (S.sel !== -2 || !S.q.length || S.busy >= 2 || S.fail > 4) return;
      var t = v.currentTime || 0;
      S.q.sort(function (a, b) { return (a.en < t - 1 ? 1e9 : 0) + a.st - ((b.en < t - 1 ? 1e9 : 0) + b.st); });
      var batch = S.q.splice(0, 25), id = ++S.id;
      S.pend[id] = { b: batch, src: S.src }; S.busy++;
      send({ c: "tr", id: id, texts: batch.map(function (c) { return c.txt.replace(/\s*\n\s*/g, " "); }) });
    }
    function trRes(id, arr) {
      S.busy = Math.max(0, S.busy - 1);
      var p = S.pend[id]; delete S.pend[id];
      if (!p || p.src !== S.src || !S.auto) return 1;
      if (!arr) { S.fail++; p.b.forEach(function (c) { S.q.push(c); }); if (S.fail === 5) note("تعذّرت الترجمة التلقائية — تحقق من الإنترنت"); return 1; }
      S.fail = 0;
      var C = window.VTTCue || window.TextTrackCue;
      p.b.forEach(function (c, i) { try { var q = new C(c.st, c.en, arr[i] || c.txt); cueLine(q); S.auto.addCue(q); } catch (e) {} });
      flushTr();
      return 1;
    }
    var trT = setInterval(function () { if (S.sel === -2) { pollNative(); flushTr(); } }, 1200);
    $("cc").onclick = function () {
      var m = $("menu");
      if (m.style.display === "block") { m.style.display = "none"; return; }
      collectSubs();
      var opts = [{ s: -1, l: "إيقاف الترجمة" }];
      if (source() >= 0) opts.push({ s: -2, l: trName() + " — ترجمة تلقائية" });
      S.subs.forEach(function (x, k) { opts.push({ s: k, l: x.label }); });
      m.innerHTML = opts.map(function (o) { return "<button data-s='" + o.s + "' class='" + (o.s === S.sel ? "on" : "") + "'><span dir='auto'>" + esc(o.l) + "</span></button>"; }).join("");
      m.style.display = "block"; show();
    };
    $("menu").addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("button"); if (!b) return;
      $("menu").style.display = "none";
      var eng = b.getAttribute("data-eng");
      if (eng) { setMsg("جاري التشغيل بمحرك " + b.textContent + "…"); send({ c: "retry", force: eng, t: Math.floor(P.lastT || 0) }); return; }
      selectSub(+b.getAttribute("data-s"), true);
    });
    v.textTracks.addEventListener && v.textTracks.addEventListener("addtrack", function () { if (!P.mkv) { collectSubs(); if (!S.init) setTimeout(applySubs, 300); } });
    function resetSubs() {
      if (S.auto) clearAuto(true);
      S.subs = []; S.sel = -1; S.src = -1; S.q = []; S.seen = {}; S.pend = {}; S.busy = 0; S.fail = 0; S.log = {}; S.init = false;
      $("menu").style.display = "none"; $("cc").classList.remove("on"); ap.classList.remove("hascc");
    }

    /* ── إعدادات المشغل ── */
    var Pset = function () { return P.o.set || {}; };
    var bufOf = function () { return BUF[Pset().buf] || BUF.normal; };
    function setV(k, val) { P.o.set = Object.assign({}, Pset()); P.o.set[k] = val; send({ c: "set", key: k, val: val }); }
    // الترجمة في أسفل الصورة (السطر الأخير) — كانت تظهر في منتصف الشاشة خاصة بملء الشاشة
    function cueLine(q) { try { q.snapToLines = true; q.line = (Pset().subPos || "low") === "high" ? -3 : -1; } catch (e) {} }
    function relineCues() { try { for (var i = 0; i < v.textTracks.length; i++) { var cs = v.textTracks[i].cues; if (cs) for (var j = 0; j < cs.length; j++) cueLine(cs[j]); } } catch (e) {} }
    // ترجمات الملف نفسه (MP4/HLS) أيضاً تُنزل لأسفل الصورة
    function hookTrack(t) { if (!t || t.__ln) return; t.__ln = 1; try { t.addEventListener("cuechange", function () { var a = t.activeCues; if (a) for (var k = 0; k < a.length; k++) { var want = (Pset().subPos || "low") === "high" ? -3 : -1; if (a[k].line !== want) cueLine(a[k]); } }); } catch (e) {} }
    try { for (var ti = 0; ti < v.textTracks.length; ti++) hookTrack(v.textTracks[ti]); v.textTracks.addEventListener("addtrack", function (e) { hookTrack(e.track); }); } catch (e) {}
    function applyLook() {
      var st = Pset();
      v.style.objectFit = st.fit === "cover" ? "cover" : st.fit === "fill" ? "fill" : "contain";
      ap.classList.remove("fs-s", "fs-m", "fs-l", "fs-xl"); ap.classList.add("fs-" + (st.subSize || "m"));
    }
    function seg(key, cur, list) { return "<div class='ex-sg' data-k='" + key + "'>" + list.map(function (o) { return "<button data-v='" + o[0] + "' class='" + (String(o[0]) === String(cur) ? "on" : "") + "'>" + o[1] + "</button>"; }).join("") + "</div>"; }
    function renderSets() {
      var st = Pset(), vod = isVod();
      $("sets").innerHTML = "<div class='hdr'><b>إعدادات المشغل</b><button data-close='1'>تم</button></div>" +
        "<h4>نوع المشغل</h4>" + seg("eng", P.o.force || "auto", ENGL[vod ? "vod" : "live"]) +
        "<h4>التخزين المؤقت</h4>" + seg("buf", st.buf || "normal", [["low", BUFN.low], ["normal", BUFN.normal], ["high", BUFN.high], ["max", BUFN.max]]) + "<small>" + BUFD[st.buf || "normal"] + "</small>" +
        "<h4>مقاس الصورة</h4>" + seg("fit", st.fit || "contain", [["contain", "ملائم"], ["cover", "ملء (قص)"], ["fill", "تمديد"]]) +
        (vod ? "<h4>سرعة التشغيل</h4>" + seg("rate", P.rate || v.playbackRate || 1, [[0.75, "0.75×"], [1, "عادي"], [1.25, "1.25×"], [1.5, "1.5×"], [2, "2×"]]) : "") +
        "<h4>حجم الترجمة</h4>" + seg("subSize", st.subSize || "m", [["s", "صغير"], ["m", "متوسط"], ["l", "كبير"], ["xl", "كبير جداً"]]) +
        "<h4>موضع الترجمة</h4>" + seg("subPos", st.subPos || "low", [["low", "أسفل الشاشة"], ["high", "أعلى قليلاً"]]) +
        "<h4>الصوت المفضّل</h4>" + seg("audio", st.audio || "ar", [["ar", "العربي أولاً"], ["orig", "الأصلي"]]) +
        (vod ? "<h4>الحلقة التالية تلقائياً</h4>" + seg("autoNext", st.autoNext === false ? "0" : "1", [["1", "تشغيل"], ["0", "إيقاف"]]) : "") +
        "<h4>إظهار السرعة والمخزون</h4>" + seg("stats", st.stats === false ? "0" : "1", [["1", "تشغيل"], ["0", "إيقاف"]]);
    }
    function setsOpen(on) { $("sets").classList.toggle("on", on); $("gear").classList.toggle("on", on); if (on) { renderSets(); if (stw) { try { $("sets").scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch (e) {} } } show(); }
    $("gear").onclick = function () { setsOpen(!$("sets").classList.contains("on")); };
    $("sets").addEventListener("click", function (e) {
      if (e.target.closest && e.target.closest("[data-close]")) { setsOpen(false); return; }
      var b = e.target.closest && e.target.closest(".ex-sg button"); if (!b) return;
      var k = b.parentNode.getAttribute("data-k"), val = b.getAttribute("data-v");
      var reload = function (why) { toast(why, 1600); send({ c: "retry", t: Math.floor(P.lastT || v.currentTime || 0), force: P.o.force || "auto" }); };
      if (k === "eng") { setV(isVod() ? "vmode" : "pmode", val); toast("المحرك: " + b.textContent, 1500); send({ c: "retry", force: val, t: Math.floor(P.lastT || v.currentTime || 0) }); }
      else if (k === "buf") { setV("buf", val); renderSets(); reload("التخزين المؤقت: " + BUFN[val] + " — إعادة التحميل…"); return; }
      else if (k === "fit") { setV("fit", val); applyLook(); }
      else if (k === "rate") { P.rate = +val; try { v.playbackRate = +val; } catch (e) {} }
      else if (k === "subSize") { setV("subSize", val); applyLook(); }
      else if (k === "subPos") { setV("subPos", val); applyLook(); relineCues(); }
      else if (k === "audio") { setV("audio", val); renderSets(); if (P.mkv || P.ts) reload(val === "ar" ? "الصوت العربي أولاً — إعادة التحميل…" : "الصوت الأصلي — إعادة التحميل…"); return; }
      else if (k === "autoNext") setV("autoNext", val === "1");
      else if (k === "stats") setV("stats", val === "1");
      renderSets();
    });
    var lastB = 0, lastBt = 0;
    var stT = setInterval(function () {
      var E = P.ts || P.mkv; if (!E || P.state !== "playing" || Pset().stats === false) { lastB = 0; return; }
      var now = Date.now(), by = E.bytes || 0;
      if (by < lastB) lastB = 0;
      if (lastB && now > lastBt) {
        var kbs = (by - lastB) / 1024 / ((now - lastBt) / 1000), ah = E.ahead ? E.ahead() : 0;
        bd.textContent = (P.ts ? "السهرة TS+" : "MKV") + " · " + (kbs >= 1024 ? (kbs / 1024).toFixed(1) + " MB/s" : Math.round(kbs) + " KB/s") + " · " + ah.toFixed(0) + "ث";
      }
      lastB = by; lastBt = now;
    }, 2000);

    /* ── المحركات ── */
    function stop() {
      clearTimeout(P.wd); clearTimeout(P.st); clearTimeout(P.bk);
      if (P.mts) { try { P.mts.pause(); P.mts.unload(); P.mts.detachMediaElement(); P.mts.destroy(); } catch (e) {} P.mts = null; }
      if (P.mkv) { try { P.mkvLog = P.mkv.log.slice(); P.mkv.destroy(); } catch (e) {} P.mkv = null; }
      if (P.ts) { try { P.mkvLog = P.ts.log.slice(); P.ts.destroy(); } catch (e) {} P.ts = null; }
      resetSubs(); $("rs").style.display = "none";
      try { v.pause(); v.removeAttribute("src"); v.load(); } catch (e) {}
    }
    function fail(m) {
      m = String(m || "خطأ");
      D("fail: " + m);
      // الخادم رفض الرابط (404/403/410): نتذكره لنعطي رسالة واضحة بدل آخر خطأ من المحركات الاحتياطية
      var hs = /HTTP\s*\(?(403|404|410)|\b(403|404|410)\s+(Not Found|Forbidden|Gone)/i.exec(m);
      if (hs) P.httpErr = hs[1] || hs[2];
      // تجربة HLS (بدون نقل التطبيق) لم تنجح → نرجع للمحرك العادي
      if (P.o.trial && !P.played) { stop(); pl.style.display = "none"; P.o.trial = ""; P.state = "loading"; setMsg(isVod() ? "جاري تجهيز الفيديو…" : "جاري تشغيل البث…"); show(); state("trialfail", m); return; }
      if (P.state !== "playing" && NET.test(m) && P.o.rs && !P.o.resolved) { stop(); setMsg("جاري البحث عن مسار آخر للبث…"); state("netfail", m); return; }
      if (P.hls && !P.triedHls && !isVod()) { P.triedHls = 1; stop(); setMsg("جاري تجربة HLS…"); native(P.hls); return; }
      // فيلم/حلقة اشتغلت ثم توقفت بخطأ → استئناف تلقائي من نفس الموضع (رابط جديد) بدل رسالة فشل
      if (isVod() && P.played && !/لا يدعم|غير مدعوم|لا يشغلها/.test(m)) {
        var ac = (P.mkv && P.mkv.aCodec) || "", t = Math.floor(P.lastT || v.currentTime || 0);
        P.played = false; stop(); pl.style.display = "none";
        P.state = "loading"; setMsg("توقف التشغيل — جاري الاستئناف تلقائياً…"); show();
        send({ c: "recover", t: t, m: m, dec: /فك|decode/i.test(m) ? 1 : 0, ac: ac });
        return;
      }
      stop(); pl.style.display = "none";
      if (P.httpErr && !isVod()) m = "الخادم لا يبث هذه القناة الآن (HTTP " + P.httpErr + ") — جرّب لاحقاً أو قناة أخرى";
      setMsg(isVod() ? "تعذّر تشغيل الفيديو" : "تعذّر تشغيل البث", "err", m); state("error", m); show();
    }
    function onPlayErr(e) { if (e && e.name === "NotAllowedError") { clearTimeout(P.wd); setMsg(isVod() ? "الفيديو جاهز — اضغط للتشغيل" : "البث جاهز — اضغط للتشغيل"); pl.style.display = "block"; } }
    function tryPlay() { var p = v.play(); if (p && p.catch) p.catch(onPlayErr); }
    function wd(ms) { clearTimeout(P.wd); P.wd = setTimeout(function () { if (P.state !== "playing" && pl.style.display !== "block") fail("لا استجابة من الخادم"); }, ms); }
    function native(u) {
      bd.textContent = /m3u8/i.test(u) ? "HLS" : "iOS";
      if (isVod()) info(/m3u8/i.test(u) ? "HLS" : String(P.fmt === "auto" ? "" : P.fmt || "").toUpperCase());
      v.disableRemotePlayback = false; v.src = u; tryPlay(); wd(P.o.trial === "hls" || P.o.trial === "nts" ? 9000 : isVod() ? 20000 : 12000);
    }
    function ownTS(u, live) {
      if (!window.AlsahraTS) return native(u);
      P.triedOwn = 1;
      bd.textContent = "السهرة TS+";
      var B = bufOf();
      P.ts = window.AlsahraTS.play(v, u, {
        live: live, startBuf: B.start, liveMax: B.live, keep: B.keep, rebuf: B.rebuf, audioPref: Pset().audio || "ar",
        onbuffer: function (on) { box.classList.toggle("buf", !!on); },
        onerror: function (m) {
          var M = window.mpegts;
          if (!P.triedMts && !NET.test(m) && M && M.getFeatureList && M.getFeatureList().mseLivePlayback) { D("own engine: " + m + " → mpegts.js"); stop(); P.o.own = false; P.fb = 1; mtsPlay(u, live); }
          else fail(m);
        },
        onstatus: function (i) { P.info = i; D("ts+ " + [i.v, i.res, i.a, i.note].filter(Boolean).join(" | ")); if (i.note) note(i.note); },
        onready: function () { tryPlay(); }
      });
      wd(16000);
    }
    function mtsPlay(u, live) {
      var M = window.mpegts;
      if (P.o.force === "mts" && (!M || !M.getFeatureList)) return fail("تعذّر تحميل محرك السهرة TS — تحقق من الإنترنت");
      if (P.o.force !== "mts" && (P.o.own || !M || !M.getFeatureList || !M.getFeatureList().mseLivePlayback)) return window.AlsahraTS ? ownTS(u, live) : native(u);
      P.triedMts = 1;
      bd.textContent = "السهرة TS";
      try {
        v.disableRemotePlayback = true;
        var p = M.createPlayer({ type: "mpegts", isLive: live, url: u, cors: true }, Object.assign({ enableWorker: false, lazyLoad: false, autoCleanupSourceBuffer: true }, bufOf().mts));
        P.mts = p;
        p.on(M.Events.ERROR, function (t, d, i) {
          var m = t + " / " + d + (i && i.msg ? " — " + i.msg : "");
          if (P.state === "playing" && live) { setMsg("إعادة الاتصال…"); state("stall", m); send({ c: "reconnect" }); }
          else if (!P.triedOwn && window.AlsahraTS && !NET.test(m)) { D("mpegts: " + m + " → own engine"); stop(); ownTS(u, live); }
          else fail(m);
        });
        p.attachMediaElement(v); p.load();
        var pr = p.play(); if (pr && pr.catch) pr.catch(onPlayErr);
        wd(16000);
      } catch (e) { fail(String((e && e.message) || e)); }
    }
    function mkvPlay(u) {
      if (!window.AlsahraMKV) return native(u);
      bd.textContent = "السهرة MKV";
      P.mkv = window.AlsahraMKV.play(v, u, {
        start: P.o.start || 0, maxAhead: bufOf().vod, audioPref: Pset().audio || "ar", noAudio: P.o.noAud || "", subLine: (Pset().subPos || "low") === "high" ? -3 : -1,
        onerror: function (m) { fail(m); },
        onstatus: function (i) {
          P.info = i;
          bd.textContent = "MKV · " + i.v + (i.a ? " · " + String(i.a).split(" · ")[0] : "");
          info([i.v, i.res, i.a].filter(Boolean).join(" · "));
          D("mkv " + [i.v, i.res, i.a, i.note].filter(Boolean).join(" | "));
          if (i.note) note(i.note);
          applySubs();
        },
        onsub: function (k, st, en, txt) { (S.log[k] = S.log[k] || []).push({ st: st, en: en, txt: txt }); if (S.sel === -2 && S.subs[S.src] && S.subs[S.src].k === k) queueCue({ st: st, en: en, txt: txt }); },
        onready: function () { tryPlay(); },
        onformat: function (k) { D("format " + k); P.mkv = null; if (k === "ts") mtsPlay(u, false); else native(u); }
      });
      wd(30000);
    }
    v.addEventListener("loadedmetadata", function () {
      if (!P.mkv && P.o.start > 5 && isVod() && v.duration > P.o.start + 30) { try { v.currentTime = P.o.start; } catch (e) {} }
      if (!P.mkv && isVod()) setTimeout(applySubs, 800);
    });
    v.addEventListener("playing", function () {
      clearTimeout(P.wd); clearTimeout(P.st); pl.style.display = "none"; setMsg("", "ok"); P.played = true;
      if (P.mts && !P.triedOwn && window.AlsahraTS) { clearTimeout(P.bk); P.bk = setTimeout(function () { var mi = P.mts && P.mts.mediaInfo; if (P.mts && !v.videoWidth && mi && mi.hasVideo) { D("black picture → own engine"); var u = P.url; stop(); setMsg("جاري تجربة محرك آخر…"); P.state = "loading"; ownTS(u, !isVod()); } }, 5000); }
      if (P.state !== "playing") { state("playing", "", { fmt: P.fmt, eng: P.ts ? "own" : P.mts ? (P.fb ? "mts-fb" : "mts") : P.mkv ? "mkv" : "native" }); D("playing " + (v.videoWidth || 0) + "×" + (v.videoHeight || 0)); if (isVod() && P.o.start > 5) { $("rs").style.display = "block"; setTimeout(function () { $("rs").style.display = "none"; }, 8000); toast("استئناف من " + fmtT(P.o.start)); } }
      if (P.rate && isVod() && v.playbackRate !== P.rate) { try { v.playbackRate = P.rate; } catch (e) {} }
      $("pp").textContent = "❚❚"; show();
    });
    v.addEventListener("pause", function () { $("pp").textContent = "▶"; show(); sendPos(); });
    v.addEventListener("waiting", function () {
      if (P.state !== "playing") return;
      if (isVod()) { box.classList.add("buf"); return; }
      clearTimeout(P.st); P.st = setTimeout(function () { setMsg("إعادة الاتصال…"); state("stall"); send({ c: "reconnect" }); }, 15000);
    });
    v.addEventListener("timeupdate", function () {
      clearTimeout(P.st); box.classList.remove("buf");
      if (v.currentTime > 1) P.lastT = v.currentTime;
      if (isVod()) {
        var d = v.duration;
        if (d && isFinite(d)) { $("td").textContent = fmtT(d); if (!dragging) { var x = Math.round(v.currentTime / d * 1000); rg.value = x; rg.style.setProperty("--p", x / 10 + "%"); $("tc").textContent = fmtT(v.currentTime); } }
        if (Date.now() - posT > 15000) { posT = Date.now(); sendPos(); }
      }
    });
    v.addEventListener("ended", function () { if (isVod()) { send({ c: "pos", t: 0, d: Math.floor(v.duration || 0), end: 1 }); if (P.o.eps && Pset().autoNext !== false) { toast("الحلقة التالية…"); send({ c: "next", auto: 1 }); } else { $("pp").textContent = "▶"; show(); } } });
    v.addEventListener("error", function () {
      if (!v.getAttribute("src") || P.mts) return;
      if (P.ts) return fail("تعذّر فك البث");
      var e = v.error, c = e ? e.code : 0, m = e && e.message ? String(e.message).slice(0, 90) : "";
      if (P.mkv) return fail("تعذّر فك الفيديو" + (m ? " — " + m : ""));
      fail(c === 4 ? "صيغة هذا الملف لا يشغلها iOS — افتحه في VLC" + (m ? " (" + m + ")" : "") : c === 2 ? "انقطع الاتصال بالخادم" + (m ? " — " + m : "") : c === 3 ? "تعذّر فك الفيديو" + (m ? " — " + m : "") : "رمز " + c + (m ? " — " + m : ""));
    });

    var api = {
      get state() { return P.state; }, get lastT() { return P.lastT || 0; }, get video() { return v; },
      get diag() { return P.diag; }, get engine() { return P.ts ? "own" : P.mts ? "mts" : P.mkv ? "mkv" : v.getAttribute("src") ? "native" : ""; },
      busy: function (t) { stop(); P.state = "loading"; setMsg(t || "جاري المحاولة…"); show(); return 1; },
      toast: function (t) { toast(t); return 1; },
      note: function (t) { note(t); return 1; },
      err: function (m) { P.o.resolved = true; fail(m); return 1; },
      trRes: trRes,
      pos: sendPos,
      stop: function () { sendPos(); stop(); P.state = "stopped"; setMsg("", "load"); },
      destroy: function () { if (dead) return; dead = true; sendPos(); stop(); clearInterval(trT); clearInterval(stT); root.innerHTML = ""; if (stw && stw.parentNode) stw.parentNode.removeChild(stw); },
      play: function (url, title, sub, hls, accent, o) {
        stop();
        o = o || {};
        P.played = false; P.httpErr = "";
        P.o = o; P.kind = o.kind || "itv";
        // التجارب بدون نقل التطبيق لها مهلة قصيرة حتى لا ينتظر المستخدم
        clearTimeout(P.trT);
        if (o.trial) P.trT = setTimeout(function () { if (!P.played && P.o === o && o.trial) fail("trial timeout"); }, o.trial === "swap" ? 7000 : 9000);
        applyLook(); if ($("sets").classList.contains("on")) renderSets();
        P.url = url; P.hls = hls && hls !== url ? hls : ""; P.triedHls = 0; P.triedOwn = 0; P.triedMts = 0; P.fb = 0; P.state = "loading"; P.lastT = o.start || 0; P.info = null;
        if (accent) { ap.style.setProperty("--a", accent); if (stw) stw.style.setProperty("--a", accent); }
        ap.className = (isVod() ? "epx vod" : "epx live") + (" fs-" + (Pset().subSize || "m"));
        rg.value = 0; rg.style.setProperty("--p", "0%"); $("tc").textContent = "0:00"; $("td").textContent = "0:00";
        info("");
        setMsg(isVod() ? "جاري تجهيز الفيديو…" : "جاري تشغيل البث…"); pl.style.display = "none"; show();
        var f = o.fmt || (/m3u8/i.test(url) ? "hls" : /\.(mp4|m4v|mov)(\?|$)/i.test(url) ? "mp4" : /\.(mkv|webm)(\?|$)/i.test(url) ? "mkv" : isVod() ? "auto" : "ts");
        P.fmt = f;
        var F = o.force || "";
        D("play " + P.kind + " " + f + (F ? " force=" + F : "") + " @" + location.origin);
        if (F) { P.triedOwn = P.triedMts = P.triedHls = 1; }
        if (F === "own") ownTS(url, !isVod());
        else if (F === "mts") mtsPlay(url, !isVod());
        else if (F === "hls") native(P.hls || url);
        else if (F === "native") native(url);
        else if (F === "mkv") mkvPlay(url);
        else if (f === "hls" || f === "mp4" || f === "avi") native(url);
        else if (f === "mkv" || f === "auto") mkvPlay(url);
        else mtsPlay(url, !isVod());
        return 1;
      }
    };
    return api;
  }
  window.AlsahraBox = { create: create };
  return 1;
}

const BOX_JS = "(" + alsahraBoxMain.toString() + ")()";
const PLAYER_JS = "(" + alsahraPlayerMain.toString() + ")()";
// العنوان الأساسي (بدون المنفذ الافتراضي :80 / :443 حتى يطابق location.origin في الصفحة)
const originOfUrl = u => (String(u || "").match(/^[a-z][a-z0-9+.-]*:\/\/[^\/?#]+/i) || [""])[0].replace(/^(http:\/\/[^\/]+):80$/i, "$1").replace(/^(https:\/\/[^\/]+):443$/i, "$1");

const IOS_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148";
const hval = (h, k) => { for (const key in h || {}) if (key.toLowerCase() === k) return String(h[key]); return ""; };
function absUrl(loc, base) {
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(loc)) return loc;
  if (/^\/\//.test(loc)) return (String(base).match(/^[a-z]+:/i) || ["http:"])[0] + loc;
  if (loc[0] === "/") return originOfUrl(base) + loc;
  return String(base).replace(/[?#].*$/, "").replace(/[^\/]*$/, "") + loc;
}
const maskU = u => String(u || "")
  .replace(/([?&](?:mac|token|play_token|password|username|sn|stream_token|uid)=)[^&]+/gi, "$1***")
  .replace(/^([a-z]+:\/\/[^\/]+)\/([^?#]*)/i, (m, o, p) => {
    const parts = p.split("/"), cred = {};
    if (/^(live|movie|series|timeshift)$/i.test(parts[0]) && parts.length >= 4) { cred[1] = cred[2] = 1; }
    else if (parts.length >= 3 && /^\d+(\.\w+)?$/.test(parts[parts.length - 1])) { cred[0] = cred[1] = 1; }
    return o + "/" + parts.map((x, i) => cred[i] || (/^[A-Za-z0-9_-]{6,}$/.test(x) && !/^\d+$/.test(x) && !/^(series|movies?|live)$/i.test(x)) ? "***" : x).join("/");
  });
// طلب HEAD دون تتبع التحويل تلقائياً: يكشف العنوان النهائي ونوع الملف دون فتح البث
async function headInfo(u) {
  let cur = u;
  const out = { status: 0, type: "", len: 0, redirected: false, hops: [] };
  for (let i = 0; i < 5; i++) {
    const r = new Request(cur);
    r.method = "HEAD"; r.timeoutInterval = 6; r.allowInsecureRequest = true;
    r.headers = { "User-Agent": IOS_UA, "Accept": "*/*" };
    let loc = "";
    r.onRedirect = q => { loc = (q && q.url) || ""; return null; };
    let err = "";
    try { await Promise.race([r.load(), sleep(7000).then(() => { throw new Error("timeout"); })]); } catch (e) { err = String((e && e.message) || e); }
    const rs = r.response || {}, h = rs.headers || {};
    out.status = rs.statusCode || 0; out.type = hval(h, "content-type"); out.len = +hval(h, "content-length") || 0; out.err = err;
    if (!loc && out.status >= 300 && out.status < 400) loc = hval(h, "location");
    if (!loc) break;
    loc = absUrl(loc, cur);
    if (loc === cur) break;
    out.hops.push(loc); out.redirected = true; cur = loc;
  }
  out.final = cur;
  return out;
}
function detectFmt(url, ctype, kind) {
  const u = String(url || "").split(/[?#]/)[0].toLowerCase(), t = String(ctype || "").toLowerCase();
  if (/mpegurl/.test(t) || /\.m3u8$/.test(u)) return "hls";
  if (/matroska|webm/.test(t) || /\.(mkv|webm)$/.test(u)) return "mkv";
  if (/video\/mp4|quicktime|x-m4v/.test(t) || /\.(mp4|m4v|mov)$/.test(u)) return "mp4";
  if (/x-msvideo|\/avi/.test(t) || /\.avi$/.test(u)) return "avi";
  if (/mp2t/.test(t) || /\.ts$/.test(u)) return "ts";
  return kind === "itv" ? "ts" : "auto";
}
const posKey = (PL, it) => PL.kind + ":" + String(it.id || it.cmd || "").slice(0, 120);

// يحدد الرابط النهائي للتشغيل: إنشاء الرابط + كشف التحويل + نوع الملف + موضع الاستئناف + إعدادات المشغل
async function resolveStream(kind, it, o) {
  o = o || {};
  const vod = kind !== "itv";
  const lo = () => ({ kind, cmd: it.cmd, series: it.series || "", tmp: it.tmp, lb: it.lb });
  const r = await resolveLink(await needST(), lo(), o.pick || 0);
  let url = r.url, info = null;
  const p0 = activePortal(), ud = p0 ? userData(p0.id) : {}, o0 = originOfUrl(url);
  // الأفلام دائماً، والبث المباشر عند الحاجة: نكشف التحويل إلى خادم آخر قبل التشغيل
  const here = String(o.here || "").replace(/:(80|443)$/, "").toLowerCase();
  const willMove = /^https?:/.test(here) ? here !== String(o0 || "").replace(/:(80|443)$/, "").toLowerCase() : !!o.here;
  if (vod || o.resolve || (ud.redir && ud.redir[o0]) || willMove) {
    info = await headInfo(url);
    crumb("head " + info.status + " " + (info.type || "-") + (info.redirected ? " → " + maskU(originOfUrl(info.final)) : "") + (info.err ? " (" + info.err.slice(0, 40) + ")" : ""), true);
    if (info.redirected) {
      url = info.final;
      if (!vod && p0) { ud.redir = Object.assign({}, ud.redir || {}, { [o0]: 1 }); saveDB(); }
    } else if (r.src !== "direct" && /token|[?&](t|e|s|st|exp|hash)=/i.test(url)) {
      try { const r2 = await resolveLink(await needST(), lo(), o.pick || 0); if (r2 && r2.url) url = r2.url; } catch (e) {}
    }
  }
  const origin = originOfUrl(url);
  if (!origin) throw new Error("رابط غير صالح");
  const fmt = detectFmt(url, info && info.type, kind);
  const st = DB.settings || {};
  let start = 0;
  if (vod && st.resume !== false && o.key && !o.noResume) { const ps = (ud.pos || {})[kind + ":" + String(o.key).slice(0, 120)]; if (ps && ps.t > 20 && (!ps.d || ps.t < ps.d - Math.max(30, ps.d * 0.05))) start = ps.t; }
  if (o.startAt != null && o.startAt > 5) start = o.startAt;
  const opts = { kind, fmt, start, rs: !vod && !info, resolved: !!info, own: o.own != null ? !!o.own : ud.tsEng !== "mts",
    force: o.force || "", subOn: st.subOn !== false, tr: st.subTr !== false, trLang: st.trLang || "ar",
    set: { buf: st.buf || "normal", fit: st.fit || "contain", subSize: st.subSize || "m", subPos: st.subPos || "low", audio: st.audio || "ar", autoNext: st.autoNext !== false, stats: st.stats !== false } };
  return { url, origin, fmt, info, opts, hls: vod ? "" : toHLS(url) };
}

async function playerLoad(wv, PL, nav) {
  const it = PL.items[PL.index];
  if (!it) { PL.err = "لا توجد مادة للتشغيل"; return false; }
  const vod = PL.kind !== "itv";
  let R;
  try { R = await resolveStream(PL.kind, it, { pick: PL.pick || 0, resolve: PL.resolve, key: it.id || it.cmd, startAt: PL.startAt, own: PL.own, force: PL.force }); }
  catch (e) { PL.err = String((e && e.message) || e); return false; }
  PL.startAt = null;
  const url = R.url, origin = R.origin, fmt = R.fmt;
  PL.info = R.info;
  const porg = IN_APP ? "app" : origin;
  if (nav || porg !== PL.origin) {
    crumb("player open " + maskU(origin) + " fmt=" + fmt, true);
    if (IN_APP) await Promise.race([wv.loadFile(appFile("player.html", "<!DOCTYPE html><html><head><meta charset='utf-8'><script>" + APP_PX_JS + "</script></head><body style='background:#000'></body></html>")), sleep(10000)]);
    else await Promise.race([wv.loadURL(origin + "/alsahra-player-" + Date.now().toString(36) + ".html"), sleep(10000)]);
    let ok = 0;
    try { await wv.evaluateJavaScript(BOX_JS + "\n;0", false); ok = await wv.evaluateJavaScript(PLAYER_JS, false); } catch (e) {}
    if (!ok) { PL.err = "تعذّر تجهيز مشغل السهرة على هذا الخادم"; return false; }
    PL.origin = porg; PL.libs = {}; PL.listSent = false;
  }
  PL.libs = PL.libs || {};
  await injectLibs(wv, PL.libs, fmt, PL.force, "window.__alsahraP && __alsahraP.busy('جاري تحميل محرك السهرة TS…')");
  const sub = vod ? String(it.sub || "") : [it.num ? "#" + it.num : "", "بث مباشر"].filter(Boolean).join(" · ");
  const opts = Object.assign({}, R.opts, { eps: vod && PL.items.length > 1 ? { prev: PL.index > 0, next: PL.index < PL.items.length - 1 } : null, index: PL.index, noAud: PL.noAud || "" });
  if (!PL.listSent) { opts.list = PL.items.map(x => ({ n: x.name || "", s: x.sub || "", l: x.logo || "", u: x.num || "" })); opts.meta = PL.meta || null; }
  const args = [url, it.name || "", sub, {}, R.hls, PL.accent || "", opts].map(x => JSON.stringify(x)).join(",");
  let okp = 0;
  try { okp = await wv.evaluateJavaScript("window.__alsahraP ? __alsahraP.play(" + args + ") : 0", false); } catch (e) {}
  if (!okp) { PL.err = "صفحة المشغل لم تعمل"; return false; }
  PL.url = url; PL.fmt = fmt; PL.listSent = true;
  return true;
}
// المحركات داخل الصفحة: MKV و TS+ مدمجة دائماً، و mpegts.js احتياطية (لا ننتظر تحميلها إلا إذا اختارها المستخدم)
async function injectLibs(wv, libs, fmt, force, busyFn) {
  if (force === "mts" && !libs.mts && !libCached("mpegts")) {
    if (busyFn) { try { await wv.evaluateJavaScript(busyFn, false); } catch (e) {} }
    try { await H.lib({ name: "mpegts" }); } catch (e) { crumb("lib: " + e.message); }
  }
  if ((fmt === "ts" || fmt === "auto" || force === "mts") && !libs.mts) {
    const lib = libCached("mpegts");
    if (lib) { try { await wv.evaluateJavaScript(lib + "\n;0", false); libs.mts = 1; } catch (e) { crumb("lib inject failed"); } }
    else libSoon("mpegts");
  }
  if (!libs.mkv) { try { await wv.evaluateJavaScript("window.AlsahraMKV && window.AlsahraTS ? 1 : (" + MKV_JS + ")", false); libs.mkv = 1; } catch (e) { crumb("mkv inject failed"); } }
}
function libCached(name) {
  try { const f = fp(name === "hls" ? "hls-1.js" : "mpegts-1.8.0.js"); if (FM.fileExists(f)) { const c = FM.readString(f); if (c && c.length > 50000) return c; } } catch (e) {}
  return "";
}
let LIBP = {};
function libSoon(name) { if (!LIBP[name] && !libCached(name)) LIBP[name] = H.lib({ name }).catch(() => { LIBP[name] = null; }); }
async function playerErr(wv, PL) { try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.err(" + JSON.stringify(PL.err || "تعذّر التشغيل") + ")", false); } catch (e) {} }
async function playerCmd(wv, PL, m) {
  const it = () => PL.items[PL.index];
  if (m.c === "state") {
    crumb("player " + m.s + (m.m ? " " + String(m.m).slice(0, 80) : ""), m.s !== "stall");
    if (m.s === "playing") {
      PL.rc = 0; PL.resolveTried = false;
      const p = activePortal();
      if (p) {
        const u = userData(p.id), key = "fsp:" + (PL.pick || 0);
        let ch = false;
        if (!u.pm || u.pm[PL.kind] !== key) { u.pm = Object.assign({}, u.pm || {}, { [PL.kind]: key }); ch = true; }
        if ((m.eng === "own" || m.eng === "mts") && u.tsEng !== m.eng) { u.tsEng = m.eng; ch = true; }
        if (ch) saveDB();
      }
    }
    // البث رُفض من الصفحة: غالباً الخادم يحوّل إلى خادم آخر → نكشف التحويل ونفتح المشغل هناك
    if (m.s === "netfail") {
      if (PL.resolveTried) { PL.err = m.m || "تعذّر التشغيل"; await playerErr(wv, PL); return ""; }
      PL.resolveTried = true; PL.resolve = true;
      crumb("player net error → checking redirect", true);
      const ok = await playerLoad(wv, PL, false);
      PL.resolve = false;
      if (!ok) await playerErr(wv, PL);
    }
    return "";
  }
  if (m.c === "back") return "back";
  if (m.c === "tr") {
    let r = null;
    try { r = await H.trSubs({ texts: m.texts || [], to: (DB.settings && DB.settings.trLang) || "ar" }); } catch (e) { crumb("subs translate: " + e.message); }
    try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.trRes(" + (+m.id || 0) + "," + JSON.stringify(r) + ")", false); } catch (e) {}
    return "";
  }
  if (m.c === "set") {
    const OK = { buf: ["low", "normal", "high", "max"], fit: ["contain", "cover", "fill"], subSize: ["s", "m", "l", "xl"], subPos: ["low", "high"], audio: ["ar", "orig"], pmode: ["auto", "own", "mts", "hls", "native"], vmode: ["auto", "mkv", "native", "mts"] };
    if (OK[m.key] ? OK[m.key].includes(m.val) : (m.key === "autoNext" || m.key === "stats") && typeof m.val === "boolean") { DB.settings = Object.assign({}, DB.settings, { [m.key]: m.val }); saveDB(); }
    return "";
  }
  if (m.c === "subpref") { DB.settings = Object.assign({}, DB.settings, { subOn: !!m.on }); saveDB(); return ""; }
  if (m.c === "goto") {
    const j = +m.i;
    if (!(j >= 0 && j < PL.items.length) || j === PL.index) return "";
    PL.index = j; PL.rc = 0; PL.resolveTried = false;
    if (PL.restore && PL.restore.vodBack) PL.restore.ep = j;
    if (PL.restore && PL.restore.listOnly && PL.items[j]) PL.restore.lastId = PL.items[j].id;
    if (!(await playerLoad(wv, PL, false))) await playerErr(wv, PL);
    return "";
  }
  if (m.c === "pos") {
    const p = activePortal(), x = it();
    if (p && x && PL.kind !== "itv") {
      posPut(userData(p.id), posKey(PL, x), m.t, m.d, m.end);
      saveDB();
    }
    return "";
  }
  if (m.c === "report") {
    const x = it() || {}, I = PL.info;
    const lines = [APP_NAME + " v" + APP_VERSION + " — تقرير مشغل السهرة", devInfo(), "النوع: " + PL.kind + " · الصيغة: " + (PL.fmt || "?"), "المادة: " + (x.name || ""), "الرابط: " + maskU(PL.url),
      "الخادم: " + (I ? "HEAD " + (I.status || "لا رد") + " · " + (I.type || "-") + (I.len ? " · " + Math.round(I.len / 1048576) + "MB" : "") + (I.redirected ? " · تحويل → " + maskU(I.final) : "") + (I.err ? " · " + I.err.slice(0, 60) : "") : "—"),
      m.info && Object.keys(m.info).length ? "الملف: " + Object.keys(m.info).map(k => k + "=" + m.info[k]).join(" · ") : ""]
      .concat((m.diag || []).map(String)).filter(Boolean);
    try { Pasteboard.copy(lines.join("\n")); } catch (e) {}
    try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.toast('تم نسخ التقرير ✓ أرسله لنا')", false); } catch (e) {}
    return "";
  }
  if (m.c === "vlc") {
    try { const r = await resolveLink(await needST(), { kind: PL.kind, cmd: it().cmd, series: it().series || "", tmp: it().tmp, lb: it().lb }, PL.pick || 0); Safari.open(PLAYERS.vlc(r.url)); } catch (e) {}
    return "";
  }
  if (m.c === "next" || m.c === "prev") {
    const j = PL.index + (m.c === "next" ? 1 : -1);
    if (j < 0 || j >= PL.items.length) return "";
    PL.index = j; PL.rc = 0; PL.resolveTried = false;
    if (PL.restore && PL.restore.vodBack) PL.restore.ep = j;
    if (!(await playerLoad(wv, PL, false))) await playerErr(wv, PL);
    return "";
  }
  // فيلم توقف بخطأ بعد بدء المشاهدة → استئناف تلقائي برابط جديد (حتى 3 مرات لنفس الموضع)
  if (m.c === "recover") {
    const now = Date.now(), t = Math.max(0, +m.t || 0);
    if (!PL.vrAt || now - PL.vrAt > 120000 || Math.abs(t - (PL.vrT || 0)) > 90) PL.vr = 0;
    PL.vr = (PL.vr || 0) + 1; PL.vrAt = now; PL.vrT = t;
    if (PL.vr >= 2 && m.dec && /^(ac-3|ec-3)$/.test(m.ac || "")) PL.noAud = m.ac;
    crumb("player recover " + PL.vr + " @" + t + " " + String(m.m || "").slice(0, 60));
    if (PL.vr > 3) { try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.err(" + JSON.stringify(m.m || "تعذّر إكمال التشغيل") + ")", false); } catch (e) {} return ""; }
    PL.resolveTried = false; PL.resolve = true; PL.startAt = t + [0, 0, 4, 12][PL.vr];
    await sleep(500);
    if (!(await playerLoad(wv, PL, false))) await playerErr(wv, PL);
    PL.resolve = false;
    return "";
  }
  if (m.c === "reconnect" || m.c === "retry") {
    if (m.c === "reconnect" && (DB.settings.autoRe === false || ++PL.rc > 3)) { try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.err('انقطع البث')", false); } catch (e) {} return ""; }
    crumb("player " + m.c + " " + PL.rc);
    if (m.c === "retry") { PL.resolveTried = false; if (PL.kind !== "itv" && m.t > 5) PL.startAt = m.t; if (m.own != null) PL.own = !!m.own; if (m.force !== undefined) PL.force = m.force && m.force !== "auto" ? m.force : null; }
    await sleep(800);
    if (!(await playerLoad(wv, PL, false))) await playerErr(wv, PL);
  }
  return "";
}

/* ───────────────────────── فهرس البحث في كل القنوات ───────────────────────── */
// أسماء عربية شائعة ↔ كتابتها اللاتينية في أسماء القنوات
const CH_ALIAS = [[/بي\s*[اإأ]?ن\s*|بين\s*سبورت/g, "bein "], [/[اإأ]م\s*بي\s*سي/g, "mbc"], [/[اإأ]س\s*[اإأ]س\s*سي/g, "ssc"], [/سبورت(س)?/g, "sport"], [/روتانا/g, "rotana"], [/(ال)?جزيره/g, "jazeera"], [/(ال)?عربيه/g, "arabiya"], [/دبي/g, "dubai"], [/[اإأ]بو\s*ظبي/g, "abu dhabi"], [/(ال)?كاس/g, "kass"], [/شاهد/g, "shahid"], [/نتفليكس/g, "netflix"], [/سينما/g, "cinema"], [/[اإأ]كشن/g, "action"], [/دراما/g, "drama"], [/كرتون/g, "cartoon"], [/سبيستون/g, "spacetoon"], [/ناشيونال|ناشونال/g, "national"], [/جيو\s*غرافيك|جيوجرافيك/g, "geographic"], [/[اإأ]وربت/g, "orbit"], [/ثمانيه/g, "thmanyah"], [/ديسكفري|ديسكوفري/g, "discovery"], [/ماجد/g, "majid"], [/نايل|النيل/g, "nile"], [/سكاي/g, "sky"], [/نيوز/g, "news"], [/[اإأ]ون\s*تايم/g, "on time"], [/ستارز/g, "starz"], [/فوكس/g, "fox"], [/[اإأ]وه\s*[اإأ]س\s*[اإأ]ن|[اإأ]و\s*[اإأ]س\s*[اإأ]ن/g, "osn"], [/هيستوري/g, "history"], [/بي\s*بي\s*سي/g, "bbc"], [/سي\s*[اإأ]ن\s*[اإأ]ن/g, "cnn"]];
const chNorm = t => normT(t);
function chQueries(q) {
  const n = chNorm(q), out = [n];
  let a = n; CH_ALIAS.forEach(([re, v]) => { a = a.replace(re, v + " "); });
  a = a.replace(/\s+/g, " ").trim();
  if (a && a !== n) out.push(a);
  return out.filter(Boolean);
}
// يطابق: الاسم يحتوي العبارة (بمسافات أو بدونها) أو كل كلماتها، أو رقم القناة
function searchChannels(items, q, max) {
  const qs = chQueries(q), num = /^\d+$/.test(q.trim()) ? +q.trim() : 0;
  const hit = [];
  for (const c of items) {
    if (num && c.num === num) { hit.push([0, c]); continue; }
    const nn = c.nn || (c.nn = chNorm(c.name)), nk = c.nk || (c.nk = nn.replace(/\s+/g, ""));
    let best = 9;
    for (const x of qs) {
      const xk = x.replace(/\s+/g, "");
      if (!xk) continue;
      if (nn.startsWith(x) || nk.startsWith(xk)) best = Math.min(best, 1);
      else if (nk.includes(xk)) best = Math.min(best, 2);
      else if (x.split(" ").every(w => w && nk.includes(w))) best = Math.min(best, 3);
    }
    if (best < 9) hit.push([best, c]);
  }
  hit.sort((a, b) => a[0] - b[0] || (a[1].num || 99999) - (b[1].num || 99999));
  return hit.slice(0, max || 300).map(x => { const c = Object.assign({}, x[1]); delete c.nn; delete c.nk; return c; });
}
// فهرس خفيف لكل القنوات (اسم/رقم/قسم/رابط) — يُبنى مرة ويُحفظ 24 ساعة
async function liveIndex(s, build) {
  const p = activePortal(); if (!p) return null;
  const now = Date.now(), key = "idx_" + p.id + ".json", DAY = 24 * 3600e3, WEEK = 7 * DAY;
  const refresh = () => { if (!MEM.idxP) { MEM.idxP = buildIndex(s, key).finally(() => { MEM.idxP = null; }); MEM.idxP.catch(() => {}); } };
  if (MEM.liveIdx && now - MEM.liveIdx.at < DAY) return MEM.liveIdx;
  // القائمة كاملة موجودة أصلاً
  try {
    const d = MEM.liveRaw ? (JSON.parse(MEM.liveRaw).data || {}) : null;
    if (d && d.mode === "all" && d.channels && d.channels.length) { MEM.liveIdx = { at: now, items: d.channels, src: "all" }; return MEM.liveIdx; }
  } catch (e) {}
  let old = MEM.liveIdx || null;
  try {
    const f = fp(key);
    if (!old && FM.fileExists(f)) {
      const j = JSON.parse(FM.readString(f) || "{}");
      if (j && j.at && now - j.at < WEEK && Array.isArray(j.items) && j.items.length) old = { at: j.at, items: j.items.map(a => ({ id: a[0], name: a[1], num: a[2], g: a[3], cmd: a[4], logo: a[5] || "", tmp: a[6], lb: a[7] })), src: "file" };
    }
  } catch (e) {}
  if (old) {
    MEM.liveIdx = old;
    if (now - old.at >= DAY) refresh();   // أقدم من يوم: نستخدمها فوراً ونجدّدها في الخلفية (لا انتظار)
    return old;
  }
  if (!build) { refresh(); return null; }
  refresh();
  try { return await MEM.idxP; } catch (e) { return null; }
}
async function buildIndex(s, key) {
  const t0 = Date.now();
  let items = null;
  const total = MEM.liveTotal || 0;
  MEM.idxPart = [];   // ما وصل حتى الآن — يستخدمه البحث الفوري قبل اكتمال الفهرس
  // حتى 25 ألف قناة: طلب واحد ثم نحتفظ بالحقول الضرورية فقط
  if (!total || total <= 25000) {
    try { const a = await s.allChannels(); if (a && a.length) items = a.map(c => s.slimCh(c)).filter(c => c.name); } catch (e) { crumb("index all: " + String(e && e.message || e).slice(0, 60)); }
  }
  // غير ذلك: نمر على الأقسام (الأقسام الرياضية/العربية أولاً، وصفحات كل قسم دفعة واحدة)
  if (!items) {
    const genres = (MEM.genres || await s.liveGenres()).filter(g => g.id !== "*");
    const gs = g => (SPORT_RE.test(g.title) ? 2 : 0) + (chLang("", g.title) === "ar" ? 1 : 0);
    genres.sort((a, b) => gs(b) - gs(a));
    const seen = {}; items = [];
    await mapLimit(genres, 4, async g => {
      try {
        const first = await s.channelsPage(g.id, 1); let list = first.items;
        const pages = Math.min(first.pages, 40);
        for (let k = 2; k <= pages; k += 4) {
          const batch = [];
          for (let j = k; j < k + 4 && j <= pages; j++) batch.push(s.channelsPage(g.id, j).catch(() => ({ items: [] })));
          (await Promise.all(batch)).forEach(r => { list = list.concat(r.items || []); });
        }
        list.forEach(c => { const o = s.slimCh(c); if (o.name && !seen[o.id]) { seen[o.id] = 1; items.push(o); MEM.idxPart.push(o); } });
      } catch (e) {}
    });
  }
  const idx = { at: Date.now(), items, src: "built" };
  MEM.liveIdx = idx; MEM.idxPart = null;
  try { FM.writeString(fp(key), JSON.stringify({ at: idx.at, items: items.map(c => [c.id, c.name, c.num, c.g, c.cmd, c.logo || "", c.tmp, c.lb]) })); } catch (e) {}
  crumb("search index " + items.length + " ch in " + Math.round((Date.now() - t0) / 1000) + "s", true);
  return idx;
}
// بحث الخادم (بعض البوابات تدعمه) — نتحقق أن النتائج فعلاً مطابقة
async function serverSearch(s, q) {
  try {
    const j = await s.call({ type: "itv", action: "get_ordered_list", genre: "*", search: q, fav: 0, sortby: "number", hd: 0, p: 1 });
    const js = (j && j.js) || {}, data = Array.isArray(js.data) ? js.data : [];
    const tot = +js.total_items || data.length;
    if (MEM.liveTotal && tot >= MEM.liveTotal) return [];
    const items = data.map(c => s.slimCh(c)).filter(c => c.name);
    const ok = searchChannels(items, q, 300);
    return ok.length >= Math.ceil(items.length * 0.6) ? ok : [];
  } catch (e) { return []; }
}

/* ───────────────────────── القنوات الرياضية والقناة الناقلة ───────────────────────── */
async function matchChannelsRun(games) {
  const s = await needST();
  liveIndex(s, false).catch(() => {});   // الفهرس يُبنى بالتوازي من أول لحظة (لا ننتظره إلا عند الحاجة)
  const sp = await sportsChannels(s);
  const t0 = Date.now();
  games = (games || []).slice(0, 60);
  const E = MEM.sEpg || (MEM.sEpg = {});
  const gen = MEM.mcGen || 0;
  const inflight = MEM.epgIn || (MEM.epgIn = {});   // نفس الدليل لا يُطلب مرتين لو اشتغل بحثان معاً
  const epgOf = (k, chId) => {
    if (inflight[k]) return inflight[k];
    if (Date.now() - t0 > 25000 || (MEM.mcGen || 0) !== gen) return Promise.resolve();
    return inflight[k] = (async () => {
      let list = [];
      try { list = await s.epg(chId); } catch (e) {}
      E[k] = { at: Date.now(), list: (list || []).filter(e => e && e.name).map(e => ({ n: normT(e.name + " " + (e.desc || "").slice(0, 160)), s: e.start, e: e.end, t: e.name })) };
    })().finally(() => { delete inflight[k]; });
  };
  const fresh = k => E[k] && Date.now() - E[k].at < 20 * 60000;
  // 1) القنوات الناقلة من 365Scores أولاً (طلب خفيف لكل مباراة) — غالباً تكفي ولا نحتاج دليل البرامج
  const tvn = {};
  await mapLimit(games.filter(g => g.tv && (g.sg === 3 || g.sg === 2)).slice(0, 30), 6, async g => { tvn[g.id] = await tvNetworks365(g.id); });
  const mine0 = netMine(), mineG0 = netMineG();
  const sureIn = (g, items, tok) => {
    const nm = tvn[g.id] || [];
    if (!nm.length) return !!mineG0[String(g.id)];
    return nm.some(x => { const q = normK(x); return !!mine0[netKey(x)] || netFind(items, x).length > 0 || (tok && q.length >= 3 && items.some(ch => hasTok(ch.nk, q))); });
  };
  let unsure = games.filter(g => !sureIn(g, sp.all, true));   // لا قناة مؤكدة في القنوات الرياضية
  if (unsure.some(g => (tvn[g.id] || []).length)) {
    // قد تكون القناة في قسم آخر: نبحث في فهرس كل القنوات (في الذاكرة، أسرع بكثير من دليل البرامج)
    const idx = await Promise.race([liveIndex(s, true).catch(() => null), sleep(6000).then(() => null)]);
    const pool = (idx && idx.items) || MEM.idxPart || null;
    if (pool) unsure = unsure.filter(g => !sureIn(g, pool, false));
  }
  // دليل البرامج لكل مجموعة قنوات رياضية (نسخة واحدة لكل اسم: HD/FHD/4K تشترك في نفس الدليل)
  if (unsure.length) await mapLimit(sp.groups.filter(g => !fresh(g.k)).slice(0, 100), 8, g => epgOf(g.k, g.rep.id));
  // قنوات بلد كل بطولة (مرة لكل بلد)
  const byCy = {};
  const cys = {}; unsure.forEach(g => { if (g.cy && !g.intl && (g.sg === 3 || g.sg === 2)) cys[g.cy] = g.cc || 0; });
  if (Object.keys(cys).length) {
    const idx = await Promise.race([liveIndex(s, true).catch(() => null), sleep(7000).then(() => null)]);
    const pool = (idx && idx.items) || MEM.idxPart || null;
    if (pool) Object.keys(cys).forEach(cy => { byCy[cy] = countryChannels(pool, cy, cys[cy]); });
    const need = []; Object.keys(byCy).forEach(cy => byCy[cy].forEach(c => { if (!fresh("c" + c.id)) need.push(c); }));
    await mapLimit(need.slice(0, 40), 8, c => epgOf("c" + c.id, c.id));
  }
  const out = {};
  for (const g of games) {
    const k = Date.parse(g.t) / 1000 || 0;
    const H = teamToks(g.h), A = teamToks(g.a);
    const best = [], seen = {}, add = (ch, why, prog) => { if (!ch || seen[ch.id] || best.length >= 14) return; seen[ch.id] = 1; best.push(Object.assign({}, ch, { why, prog: prog || "" })); };
    // 3) القنوات الناقلة حسب 365Scores: أولاً القناة التي اخترتها أنت لهذه الشبكة، ثم القنوات الرياضية، ثم كل القنوات
    const names = tvn[g.id] || [];
    const mine = netMine();
    names.forEach(nm => { const c = mine[netKey(nm)]; if (c) add(c, "mine"); });
    if (!names.length) { const c = netMineG()[String(g.id)]; if (c) add(c, "mine"); }
    names.forEach(nm => { const q = normK(nm); if (q.length < 3) return; sp.all.forEach(ch => { if (hasTok(ch.nk, q)) add(ch, "365"); }); });
    names.forEach(nm => netFind(sp.all, nm).forEach(ch => add(ch, "365")));
    let idxWait = false;
    if (names.length && !best.some(x => (x.why === "365" || x.why === "mine") && arExact(x))) {   // لا نسخة «AR» بعد → نبحث في كل الأقسام
      // الفهرس نفسه الذي يستخدمه البحث (يُبنى مرة في اليوم) — لا ننتظر أكثر من 15 ثانية، والبناء يكمل في الخلفية
      const idx = await Promise.race([liveIndex(s, true).catch(() => null), sleep(6000).then(() => null)]);
      const pool = (idx && idx.items) || MEM.idxPart || null;   // حتى لو لم يكتمل الفهرس نبحث فيما وصل منه
      if (pool) names.forEach(nm => netFind(pool, nm).forEach(ch => add(ch, "365")));
      if (!idx) idxWait = !!MEM.idxP;   // الفهرس ما زال يُبنى → الواجهة تعيد السؤال بعد قليل
    }
    // 1) دليل البرامج: عنوان البرنامج فيه الفريقين ووقته يغطي المباراة
    if (H.length && A.length) for (const gr of sp.groups) {
      const ep = E[gr.k]; if (!ep) continue;
      const hit = ep.list.find(e => (!k || !e.s || (e.s < k + 150 * 60 && (e.e || e.s + 7200) > k - 45 * 60)) && H.some(w => e.n.includes(w)) && A.some(w => e.n.includes(w)));
      if (hit) gr.list.slice(0, 4).forEach(ch => add(ch, "epg", hit.t));
    }
    // 1ب) دليل برامج القنوات الوطنية لبلد البطولة
    if (H.length && A.length && g.cy && byCy[g.cy]) for (const ch of byCy[g.cy]) {
      const ep = E["c" + ch.id]; if (!ep) continue;
      const hit = ep.list.find(e => (!k || !e.s || (e.s < k + 150 * 60 && (e.e || e.s + 7200) > k - 45 * 60)) && H.some(w => e.n.includes(w)) && A.some(w => e.n.includes(w)));
      if (hit) add(ch, "epg", hit.t);
    }
    // 2) قنوات باسم المباراة (قنوات الأحداث)
    if (H.length && A.length) sp.all.forEach(ch => { const n = ch.nn; if (H.some(w => n.includes(w)) && A.some(w => n.includes(w))) add(ch, "name"); });
    // 4) (لا قنوات متوقعة)
    // لا «متوقع»: نعرض فقط ما تؤكده مصادر حقيقية (365Scores، دليل البرامج، اسم القناة، أو اختيارك)
    const hint = [];
    const PRI = { mine: 0, "365": 1, epg: 2, name: 3 };
    const gtm = genreTitles();
    best.forEach(c => { c.lang = chLang(c.name, c.gtl || gtm[String(c.g)]); });
    // كل النسخ تظهر (كما كانت) لكن العربية أولاً، وكل قناة عليها لغتها
    const list = best;
    list.sort((a, b) => (PRI[a.why] === 0 ? 0 : 1) - (PRI[b.why] === 0 ? 0 : 1) || arRank(a) - arRank(b) || (PRI[a.why] == null ? 9 : PRI[a.why]) - (PRI[b.why] == null ? 9 : PRI[b.why]));
    list.forEach(c => { c.ln = c.lang && c.lang !== "ar" ? LANG_NAME[c.lang] || "" : c.lang === "ar" ? "عربي" : ""; delete c.gtl; });
    out[g.id] = { best: list, names, hint, label: "", pending: idxWait && !list.some(arExact) ? 1 : 0 };
    if (names.length) crumb("mc " + g.id + " " + names.join("|").slice(0, 40) + " sp=" + sp.all.length + " best=" + list.length + " ar=" + list.filter(c => c.lang === "ar").length + (idxWait ? " idx=wait" : ""), true);
  }
  return { byGame: out, sports: sp.all.length, groups: sp.groups.length };
}

// اسم الشبكة الناقلة ↔ أسماء القنوات في الاشتراك (عربي/إنجليزي): «Jordan Sport» = «الأردن الرياضية» = «JRTV Sport»
const NET_ALIAS_RAW = [
  ["jordan", "الاردن", "الاردنيه", "اردن", "jrtv"], ["saudi", "ksa", "السعوديه", "سعوديه"], ["abu dhabi", "abudhabi", "ad", "ابوظبي", "ابو ظبي"],
  ["dubai", "دبي"], ["sharjah", "الشارقه"], ["oman", "عمان", "العمانيه"], ["kuwait", "ktv", "الكويت", "الكويتيه"], ["bahrain", "البحرين", "البحرينيه"],
  ["qatar", "قطر", "القطريه"], ["alkass", "al kass", "kass", "الكاس"], ["iraq", "iraqi", "iraqia", "iraqiya", "العراق", "العراقيه"],
  ["egypt", "مصر", "المصريه"], ["ontime", "on time", "اون تايم"], ["libya", "ليبيا", "الليبيه"], ["syria", "سوريا", "السوريه"],
  ["palestine", "فلسطين", "الفلسطينيه"], ["lebanon", "لبنان", "اللبنانيه"], ["yemen", "اليمن", "اليمنيه"], ["sudan", "السودان", "السودانيه"],
  ["morocco", "arryadia", "المغرب", "المغربيه"], ["algeria", "الجزائر", "الجزائريه"], ["tunisia", "تونس", "التونسيه", "watania", "الوطنيه"],
  ["thmanyah", "ثمانيه"], ["shahid", "شاهد"], ["bein", "بي ان"], ["ssc", "اس اس سي"], ["mbc", "ام بي سي"], ["yas", "ياس"], ["emirates", "الامارات", "الاماراتيه"]
];
let NET_ALIAS_N = null;   // بعد تعريف normK (تحت) — لا نحسبها عند تحميل السكربت
const netAlias = () => NET_ALIAS_N || (NET_ALIAS_N = NET_ALIAS_RAW.map(a => a.map(normK)));
const NET_SPORT = /sport|رياض|spor/;
const NET_FILL = new Set(["sport", "sports", "tv", "hd", "fhd", "uhd", "sd", "channel", "network", "plus", "الرياضيه", "رياضيه", "الرياضي", "قناه", "تلفزيون", "tv1", "the", "al", "el"]);
const netKey = nm => normK(nm);
const NET_VAR = new Set(["max", "xtra", "extra", "premium", "english", "french", "france", "turk", "turkiye", "english1", "en"]);
function netFind(items, nm) {
  const n = normT(nm);
  if (!n) return [];
  const sporty = NET_SPORT.test(n);
  const words = n.split(" ").filter(w => w && !NET_FILL.has(w)), nTok = new Set(n.split(" "));
  if (!words.length) return [];
  // الاسم كاملاً أولاً («abu dhabi» = «ابوظبي»)، وإلا كل كلمة بأسمائها البديلة. الأرقام والكلمات القصيرة تطابق كلمة كاملة (beIN 1 ≠ beIN 10)
  const AL = netAlias(), nums = words.filter(w => /^\d+$/.test(w)), lets = words.filter(w => !/^\d+$/.test(w));
  const whole = lets.length ? AL.find(x => x.includes(lets.join(""))) : null;
  const groups = (whole ? [whole] : lets.map(w => AL.find(x => x.includes(w)) || [w])).concat(nums.map(n => [n]));
  const out = [];
  for (const c of items) {
    if (!c || !c.name || !c.cmd) continue;
    const k = c.nkn || (c.nkn = normK(c.name)), toks = c.ntk || (c.ntk = normT(c.name).split(" "));
    if (sporty && !NET_SPORT.test(k)) continue;
    const has = a => /^\d+$/.test(a) ? toks.includes(a) || hasTok(k, a) : a.length <= 3 ? toks.some(t => t === a || (t.startsWith(a) && /^\d+$/.test(t.slice(a.length)))) : k.includes(a);
    if (toks.some(t => NET_VAR.has(t) && !nTok.has(t))) continue;   // «beIN SPORTS MAX 1» ليست «beIN SPORTS 1»
    if (groups.every(g => g.some(has))) out.push(c);
    if (out.length > 200) break;
  }
  return out.sort((a, b) => arRank(a) - arRank(b) || chRank(a, b)).slice(0, 8).map(c => { const o = Object.assign({}, c); delete o.nkn; delete o.ntk; delete o.nn; delete o.nk; return o; });
}
// لغة القناة من بادئتها («AR:» «FR:» «TR VIP:» «AU:») أو من قسمها — للقنوات الناقلة العربية أولاً
const LANG_OF = { ar: "ar", arb: "ar", ara: "ar", ksa: "ar", sa: "ar", uae: "ar", ae: "ar", qa: "ar", eg: "ar", mena: "ar", kw: "ar", om: "ar", bh: "ar", iq: "ar", jo: "ar", lb: "ar", sy: "ar", ps: "ar", ye: "ar", ly: "ar", tn: "ar", dz: "ar", ma: "ar", sd: "ar",
  fr: "fr", fra: "fr", be: "fr", ch: "fr", uk: "en", en: "en", gb: "en", us: "en", usa: "en", au: "en", ca: "en", ie: "en", nz: "en", za: "en", tr: "tr", tur: "tr", es: "es", sp: "es", mx: "es", de: "de", ger: "de", at: "de", it: "it", ita: "it", pt: "pt", br: "pt", nl: "nl", pl: "pl", ru: "ru", in: "hi", pk: "ur", ir: "fa", gr: "el", ro: "ro", al: "sq", rs: "sr", se: "sv", dk: "da", no: "no", fi: "fi", ex: "ex", exyu: "ex" };
const LANG_NAME = { ar: "عربي", fr: "فرنسي", en: "إنجليزي", tr: "تركي", es: "إسباني", de: "ألماني", it: "إيطالي", pt: "برتغالي", nl: "هولندي", pl: "بولندي", ru: "روسي", hi: "هندي", ur: "أردو", fa: "فارسي", el: "يوناني", ro: "روماني", sq: "ألباني", sr: "صربي", sv: "سويدي", da: "دنماركي", no: "نرويجي", fi: "فنلندي", ex: "يوغسلافي" };
function chLang(name, gtl) {
  const n = String(name || ""), g = String(gtl || "");
  if (/[\u0600-\u06FF]/.test(n)) return "ar";
  const m = n.match(/^\s*\|?\s*([a-z]{2,4})(?:[\s-]*(?:vip|hd|fhd|uhd|4k|\+|plus))?\s*[:|\-–]/i);
  if (m && LANG_OF[m[1].toLowerCase()]) return LANG_OF[m[1].toLowerCase()];
  if (/\b(arabic|mena)\b/i.test(n)) return "ar";
  if (/[\u0600-\u06FF]|\b(ar|arabic|arab|mena|ksa)\b/i.test(g)) return "ar";
  const gm = g.match(/^\s*\|?\s*([a-z]{2,4})\s*[|:\-–]/i);
  return gm && LANG_OF[gm[1].toLowerCase()] ? LANG_OF[gm[1].toLowerCase()] : "";
}
// أسماء الأقسام (لمعرفة لغة القناة من قسمها)
function genreTitles() {
  const raw = MEM.liveRaw || "";
  if (MEM.gtm && MEM.gtm.len === raw.length) return MEM.gtm.map;
  const map = {};
  try { ((JSON.parse(raw || "{}").data || {}).genres || []).forEach(g => { map[String(g.id)] = String(g.title || ""); }); } catch (e) {}
  MEM.gtm = { len: raw.length, map };
  return map;
}
const isArCh = c => chLang(c.name, c.gtl || genreTitles()[String(c.g)]) === "ar";
// ترتيب القنوات الناقلة: «AR:» نفسها (أو اسم عربي) أولاً، ثم بقية العربي (SA / KSA / قسم عربي)، ثم الإنجليزي، ثم البقية؛ ونسخ TOD / RAW بعد الأصلية
function arRank(c) {
  const code = ((String(c.name || "").match(/^\s*\|?\s*([a-z]{2,4})(?:[\s-]*(?:vip|hd|fhd|uhd|4k|\+|plus))?\s*[:|\-–]/i) || [])[1] || "").toLowerCase();
  const lang = c.lang || chLang(c.name, c.gtl || genreTitles()[String(c.g)]);
  const r = /^(ar|arb|ara)$/.test(code) || /[\u0600-\u06FF]/.test(c.name) || (!code && lang === "ar") ? 0 : lang === "ar" ? 1 : lang === "en" ? 2 : 3;
  return r * 2 + (/\b(tod|raw)\b|ᴿᴬᵂ/i.test(String(c.name)) ? 1 : 0);
}
// «AR:» صريحة (أو اسم بالعربي) وليست TOD/RAW
const arExact = c => /^\s*\|?\s*(ar|arb|ara)(?:[\s-]*(?:vip|hd|fhd|uhd|4k|\+|plus))?\s*[:|\-–]/i.test(String(c.name || "")) || /[\u0600-\u06FF]/.test(String(c.name || "")) ? !/\b(tod|raw)\b|ᴿᴬᵂ/i.test(String(c.name)) : false;
function netMine() { const p = activePortal(); return (p && DB.user[p.id] && DB.user[p.id].net) || {}; }
function netMineG() { const p = activePortal(); return (p && DB.user[p.id] && DB.user[p.id].netg) || {}; }
// القنوات الوطنية لبلد البطولة (مثل «الجزائرية الأرضية» أو «العراقية الرياضية») — نقرأ دليل برامجها للتأكد
const CC_CODES = { 122: ["sa", "ksa"], 115: ["qa"], 124: ["ae", "uae"], 131: ["eg"], 139: ["dz", "alg"], 114: ["iq", "irq"], 119: ["jo", "jor"], 125: ["sy"], 133: ["tn"], 137: ["ma"], 121: ["kw"], 116: ["om"], 113: ["bh"], 127: ["ly"], 120: ["lb"], 134: ["ps"], 126: ["ye"], 136: ["sd"] };
function countryChannels(items, cy, cc) {
  const ck = normK(cy || ""), AL = netAlias();
  const grp = ck ? AL.find(x => x.includes(ck) || x.some(a => a.length > 3 && ck.includes(a))) : null;
  const codes = CC_CODES[cc] || [];
  if (!grp && !codes.length) return [];
  const out = [], seenK = {};
  for (const c of items) {
    if (!c || !c.name || !c.cmd || NOT_SPORT.test(c.name) && !/رياض|sport/i.test(c.name)) continue;
    const k = c.nkn || (c.nkn = normK(c.name)), pre = (String(c.name).match(/^\s*([a-z]{2,3})\s*[:|]/i) || [])[1];
    if (!((grp && grp.some(a => a.length > 3 && k.includes(a))) || (pre && codes.includes(pre.toLowerCase())))) continue;
    const bk = chBaseKey(c.name) || c.id;
    if (seenK[bk]) continue;
    seenK[bk] = 1; out.push(c);
    if (out.length > 80) break;
  }
  // الرياضية أولاً ثم الأرضية/الأولى
  const sc = c => (/رياض|sport/i.test(c.name) ? 0 : /ارضي|الاولى|tv1|\b1\b|terrestre/i.test(normT(c.name)) ? 1 : 2);
  return out.sort((a, b) => sc(a) - sc(b) || chRank(a, b)).slice(0, 10);
}
const SPORT_RE = /sport|رياض|be\s*in|\bssc\b|kass|الكاس|الكأس|thmanyah|ثمانية|ثمانيه|on\s*time|abu\s*dhabi\s*sport|\bad\s*sport|dubai\s*sport|shahid|football|soccer|كرة|مباريات|\bmatch|\bevents?\b|\bppv\b|dazn|espn|eurosport|\barena\b|supersport|\btod\b|\bstc\b/i;
const NOT_SPORT = /movie|cinema|drama|box\s*office|series|أفلام|افلام|سينما|دراما|مسلسل|kids|cartoon|أطفال|news|أخبار|music|موسيقى|quran|قرآن/i;
const HINT_RE = { thmanyah: /thmanyah|ثمانية|ثمانيه/i, ssc: /\bssc\b|السعودية الرياضية/i, bein: /be\s*in\s*sports?|bein\s*sport|بي\s*[اإأ]ن\s*سبورت/i, ontime: /on\s*time\s*sports?|اون\s*تايم/i, ad: /\bad\s*sports?|abu\s*dhabi\s*sports?|ابوظبي الرياضية|أبوظبي الرياضية/i, dubai: /dubai\s*sports?|دبي الرياضية/i, kass: /al\s*kass|alkass|الكاس|الكأس/i };
const HINT_NAME = { thmanyah: "ثمانية", ssc: "SSC", bein: "beIN SPORTS", ontime: "ON Time Sports", ad: "أبوظبي الرياضية", dubai: "دبي الرياضية", kass: "الكأس" };
function chHints(g) {
  const n = String(g.cn || "") + " " + String(g.cd || ""), c = +g.cc || 0, H = [];
  if (c === 122 || /سعود|روشن|خادم الحرمين/.test(n)) H.push("thmanyah", "ssc");
  if (c === 131 || /مصر|المصري/.test(n)) H.push("ontime");
  if (c === 124 || /أدنوك|الإمارات|إماراتي/.test(n)) H.push("ad", "dubai");
  if (c === 115 || /قطر|نجوم/.test(n)) H.push("kass");
  if (/آسيا|الآسيوي|الخليج|العرب/.test(n)) H.push("ssc", "bein", "kass");
  H.push("bein");
  return [...new Set(H)];
}
const normT = t => String(t || "").toLowerCase().replace(/[\u064B-\u065F\u0670]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
const normK = t => normT(t).replace(/\s+/g, "");
// موجود كاسم/رقم مستقل: beinsports1 لا تطابق beinsports10
function hasTok(hay, q) { let i = hay.indexOf(q); while (i >= 0) { const nx = hay.charAt(i + q.length); if (!/\d/.test(q.slice(-1)) || !/\d/.test(nx)) return true; i = hay.indexOf(q, i + 1); } return false; }
const GEN_TOK = new Set(["united", "city", "real", "sporting", "athletic", "atletico", "inter", "club", "football", "deportivo", "olympique", "saint", "borussia", "racing", "dynamo", "dinamo", "young", "boys", "rovers", "town", "county", "sport", "sports", "يونايتد", "سيتي", "ريال", "اتلتيكو", "نادي", "سبورتنج", "الاهلي"]);
function teamToks(x) {
  const out = new Set();
  [x && x.n, x && x.en].forEach(n => normT(n).split(" ").forEach(w => { w = w.replace(/^ال(?=\S{3})/, ""); if (w.length >= (/[\u0600-\u06FF]/.test(w) ? 3 : 4) && !GEN_TOK.has(w) && !/^(fc|cf|sc|ac|afc|club)$/.test(w)) out.add(w); }));
  // اسم من كلمة عامة فقط (مثل «الأهلي») نستخدمه كما هو
  if (!out.size) [x && x.n, x && x.en].forEach(n => { const w = normT(n).replace(/^ال/, ""); if (w.length >= 4) out.add(w); });
  return [...out];
}
const chRank = (a, b) => (+((a.name.match(/\d+/) || [99])[0]) - +((b.name.match(/\d+/) || [99])[0])) || (/(fhd|hd)/i.test(b.name) - /(fhd|hd)/i.test(a.name));
const chBaseKey = n => normT(String(n).replace(/^[^:|]{1,12}[:|]\s*/, "")).replace(/\b(uhd|fhd|hd|sd|hevc|h265|4k|8k|50fps|60fps|fps|low|vip|backup|bk|raw|multi|ar|en)\b/g, " ").replace(/\s+/g, " ").trim();
async function sportsChannels(s) {
  const now = Date.now();
  if (MEM.sports && now - MEM.sports.at < 6 * 3600e3) return MEM.sports;
  if (MEM.spP) return MEM.spP;
  MEM.spP = sportsChannelsLoad(s, now);
  try { return await MEM.spP; } finally { MEM.spP = null; }
}
async function sportsChannelsLoad(s, now) {
  let chans = [];
  try {
    const raw = MEM.liveRaw || ((await H.liveInit({})) || {}).__raw;
    const d = (JSON.parse(raw || "{}") || {}).data || {};
    const gt = {}; (d.genres || []).forEach(g => { gt[String(g.id)] = String(g.title || ""); });
    if (d.mode === "all" && d.channels && d.channels.length) {
      chans = d.channels.filter(c => (SPORT_RE.test(c.name) || SPORT_RE.test(gt[c.g] || "")) && !NOT_SPORT.test(c.name) && !NOT_SPORT.test(gt[c.g] || "x"));
    } else {
      // القائمة كبيرة → نحمّل أقسام الرياضة فقط (العربية أولاً)
      const sg = (d.genres || []).filter(g => g.id !== "*" && SPORT_RE.test(g.title) && !NOT_SPORT.test(g.title));
      const gsc = g => (chLang("", g.title) === "ar" ? 2 : 0) + (/bein|ssc|ثماني|thmanyah|kass|الكاس|الكأس|ad sport|dubai sport|on time/i.test(g.title) ? 1 : 0);
      sg.sort((a, b) => gsc(b) - gsc(a));
      const lists = await mapLimit(sg.slice(0, 16), 3, async g => { try { return await H.liveGenre({ genre: g.id }); } catch (e) { return []; } });
      const seen = {};
      lists.forEach(l => (l || []).forEach(c => { if (!seen[c.id] && !NOT_SPORT.test(c.name)) { seen[c.id] = 1; chans.push(c); } }));
    }
  } catch (e) { crumb("sports channels: " + String(e && e.message || e).slice(0, 60)); }
  const gtm = genreTitles();
  chans = chans.slice(0, 2500).map(c => Object.assign({}, c, { nn: normT(c.name), nk: normK(c.name), gtl: gtm[String(c.g)] || "" }));
  const G = {};
  chans.forEach(c => { const k = chBaseKey(c.name) || c.id; (G[k] = G[k] || []).push(c); });
  const pri = k => /be\s*in\s*sport|bein sport|ssc|ثماني|thmanyah|kass|الكاس|ad sport|dubai sport|on time|shahid/.test(k) ? 0 : 1;
  const groups = Object.keys(G).map(k => ({ k, list: G[k].sort(chRank), rep: G[k][0] })).sort((a, b) => pri(a.k) - pri(b.k));
  MEM.sports = { at: now, all: chans, groups };
  crumb("sports channels=" + chans.length + " groups=" + groups.length, true);
  return MEM.sports;
}
// القنوات الناقلة من 365Scores (غير متوفرة لكل المباريات)
async function tvNetworks365(id) {
  const c = MTC["tv" + id];
  if (c && Date.now() - c.at < 30 * 60000) return c.v;
  let v = [];
  try {
    const r = new Request("https://webws.365scores.com/web/game/?appTypeId=5&langId=1&timezoneName=Asia%2FRiyadh&userCountryId=122&gameId=" + encodeURIComponent(id));
    r.headers = { "User-Agent": IOS_UA, "Accept": "application/json" };
    r.timeoutInterval = 12;
    const j = JSON.parse(await r.loadString()) || {}, g = j.game || {};
    const arr = g.tvNetworks || j.tvNetworks || g.tvNetworksList || [];
    v = (Array.isArray(arr) ? arr : []).map(x => String((x && (x.name || x.title || x.networkName)) || "").trim()).filter(Boolean).slice(0, 8);
  } catch (e) {}
  MTC["tv" + id] = { at: Date.now(), v };
  return v;
}

/* ───────────────────────── الواجهة (HTML) ───────────────────────── */
const HTML = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>السهرة ماك</title>
<style>
:root{
  --bg:#07080d;--bg2:#10121b;--card:rgba(255,255,255,.055);--card2:rgba(255,255,255,.1);--line:rgba(255,255,255,.08);
  --txt:#f4f5fa;--txt2:#d3d6e4;--mut:#8d92a6;--mut2:#61667b;--fg:255,255,255;
  --a1:139,92,246;--acc1:#a78bfa;--acc2:#5b7cff;--acc3:#22d3ee;
  --grad:linear-gradient(135deg,#8b5cf6 0%,#5b7cff 55%,#22d3ee 100%);
  --tile:linear-gradient(145deg,#1b1e2e,#12141f);--bar:rgba(18,20,30,.8);--sheet:linear-gradient(#141725,#0c0e16 40%);
  --input:rgba(0,0,0,.3);--toast:rgba(28,31,46,.95);--g1:rgba(139,92,246,.28);--g2:rgba(34,211,238,.13);
  --ok:#22c55e;--bad:#ef4444;--warn:#f59e0b;--gold:#fbbf24;
  --sat:env(safe-area-inset-top,0px);--sab:env(safe-area-inset-bottom,0px);
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{height:100%;background:var(--bg);color:var(--txt);font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","SF Arabic","Geeza Pro",system-ui,sans-serif;-webkit-font-smoothing:antialiased;overflow:hidden;-webkit-user-select:none;user-select:none;-webkit-text-size-adjust:100%;transition:background-color .45s,color .3s}
body::before{content:"";position:fixed;inset:-10%;pointer-events:none;z-index:0;transition:background .5s;
  background:radial-gradient(45% 30% at 90% 0%,var(--g1),transparent 70%),radial-gradient(40% 28% at 0% 18%,var(--g2),transparent 70%),radial-gradient(50% 30% at 50% 110%,rgba(var(--a1),.12),transparent 70%)}
button{font:inherit;color:inherit;border:0;background:none;cursor:pointer}
input{font:inherit;color:inherit;-webkit-user-select:text;user-select:text}
svg.ic{width:20px;height:20px;flex:none}
.hide{display:none!important}
@keyframes up{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@keyframes rot{to{transform:rotate(360deg)}}
.noanim>*{animation:none!important}

/* ── layout ── */
#app{position:fixed;inset:0;display:flex;flex-direction:column;z-index:1}
.top{display:flex;align-items:center;justify-content:center;gap:8px;padding:calc(var(--sat) + 2px) 88px 8px;min-height:calc(var(--sat) + 48px)}
.top .brand{flex:0 1 auto;justify-content:center}.top .logo{width:34px;height:34px;border-radius:11px}.top .logo svg{width:17px;height:17px}.top .bt b{font-size:15.5px}.top .bt small{font-size:11px;justify-content:center}.top .ibtn{width:34px;height:34px;border-radius:11px}.top .ibtn svg{width:17px;height:17px}
.brand{flex:1;min-width:0;display:flex;align-items:center;gap:11px;text-align:right}
.logo{width:42px;height:42px;border-radius:13px;background:var(--grad);display:grid;place-items:center;box-shadow:0 8px 22px rgba(var(--a1),.45),inset 0 1px 0 rgba(255,255,255,.35);flex:none;color:#fff}
.logo svg{width:20px;height:20px;margin-right:-2px}
.logo.xl{width:76px;height:76px;border-radius:24px}.logo.xl svg{width:34px;height:34px}
.bt{min-width:0}.bt b{display:block;font-size:17px;font-weight:800;letter-spacing:-.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bt small{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--mut);margin-top:2px;white-space:nowrap;overflow:hidden}
.dot{width:7px;height:7px;border-radius:50%;background:var(--ok);box-shadow:0 0 8px var(--ok);flex:none;transition:background .3s}
.dot.wait{background:var(--warn);box-shadow:0 0 8px var(--warn);animation:blink 1s infinite}
.dot.err{background:var(--bad);box-shadow:0 0 8px var(--bad)}
.ibtn{width:40px;height:40px;border-radius:12px;background:var(--card);border:1px solid var(--line);display:grid;place-items:center;flex:none;transition:transform .15s,background .2s}
.ibtn:active{transform:scale(.92);background:var(--card2)}
.ibtn.sm{width:36px;height:36px;border-radius:11px}.ibtn.sm svg{width:17px;height:17px}
.ibtn.red{color:#f87171}
.spin-ic svg{animation:rot 1s linear infinite}
main{flex:1;position:relative;overflow:hidden}
.view{position:absolute;inset:0;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 14px calc(var(--sab) + 96px);opacity:0;pointer-events:none;overscroll-behavior:contain}
.view.on{opacity:1;pointer-events:auto;transform:none!important;filter:none!important;visibility:visible!important}
.stick{position:sticky;top:0;z-index:5;padding:4px 14px 10px;margin:0 -14px;background:linear-gradient(var(--bg) 78%,transparent)}

/* ── search & chips ── */
.search{display:flex;align-items:center;gap:8px;height:46px;padding:0 14px;border-radius:15px;background:var(--card);border:1px solid var(--line);color:var(--mut);transition:border-color .2s,background .2s}
.search:focus-within{border-color:rgba(var(--a1),.6);background:rgba(var(--a1),.08)}
.search input{flex:1;min-width:0;height:100%;background:none;border:0;outline:0;font-size:16px;color:var(--txt)}
.search input::placeholder{color:var(--mut2)}
.search input::-webkit-search-cancel-button{display:none}
.clr{width:24px;height:24px;border-radius:50%;background:rgba(var(--fg),.12);display:none;place-items:center;font-size:13px;line-height:1;color:var(--txt2)}
.clr.on{display:grid}
.chips{display:flex;gap:8px;overflow-x:auto;padding:12px 0 2px;scrollbar-width:none;scroll-behavior:smooth}
.chips::-webkit-scrollbar{display:none}
.chip{flex:none;display:flex;align-items:center;gap:6px;height:36px;padding:0 14px;border-radius:999px;background:var(--card);border:1px solid var(--line);font-size:13.5px;font-weight:600;color:var(--txt2);white-space:nowrap;transition:all .25s}
.chip em{font-style:normal;font-size:11px;font-weight:700;padding:1px 7px;border-radius:99px;background:rgba(var(--fg),.1);color:var(--mut)}
.chip.on{background:var(--grad);color:#fff;border-color:transparent;box-shadow:0 6px 18px rgba(var(--a1),.38)}
.chip.on em{background:rgba(255,255,255,.25);color:#fff}
.chip:active{transform:scale(.95)}
.count{font-size:12px;color:var(--mut);margin-top:10px;display:flex;align-items:center;gap:6px}
.count svg{width:15px;height:15px}

/* ── channel rows ── */
.list{display:flex;flex-direction:column;gap:8px}
.ch{display:flex;align-items:center;gap:12px;padding:9px 10px 9px 6px;border-radius:16px;background:var(--card);border:1px solid var(--line);transition:transform .15s,background .2s}
.ch:active{transform:scale(.98);background:var(--card2)}
.lg{width:54px;height:54px;border-radius:14px;background:var(--tile);border:1px solid var(--line);display:grid;place-items:center;overflow:hidden;flex:none;position:relative}
.lg img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;padding:6px;background:inherit}
.ini{font-weight:800;font-size:15px;color:var(--mut);letter-spacing:.5px}
.nm{flex:1;min-width:0}
.nm b{display:block;font-size:15px;font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nm small{display:block;font-size:12px;color:var(--mut);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.star{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;color:var(--mut2);transition:transform .2s,color .2s}
.star.on{color:var(--gold)}.star.on svg{fill:var(--gold)}
.star:active{transform:scale(1.25)}
.more{height:40px}

/* ── poster grid ── */
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px 10px}
.pc{transition:transform .15s}
.pc:active{transform:scale(.96)}
.ps{position:relative;aspect-ratio:2/3;border-radius:14px;overflow:hidden;background:var(--tile);border:1px solid var(--line);box-shadow:0 8px 20px rgba(0,0,0,.3)}
.ps img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .45s}
.ps img.ld{opacity:1}
.pt{position:absolute;inset:0;display:grid;place-items:center;padding:10px;text-align:center;font-size:12px;font-weight:700;color:var(--mut2)}
.rt{position:absolute;top:6px;left:6px;font-style:normal;font-size:10.5px;font-weight:800;padding:3px 6px;border-radius:8px;background:rgba(0,0,0,.6);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);color:var(--gold)}
.sr{position:absolute;bottom:6px;right:6px;font-style:normal;font-size:10px;font-weight:800;padding:3px 7px;border-radius:8px;background:rgba(var(--a1),.9);color:#fff}
.pc .t{font-size:12.5px;font-weight:600;margin-top:7px;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}

/* ── skeleton ── */
.sk{background:linear-gradient(90deg,rgba(var(--fg),.04) 25%,rgba(var(--fg),.1) 37%,rgba(var(--fg),.04) 63%);background-size:400% 100%;animation:sh 1.3s ease infinite!important;border-radius:14px}
@keyframes sh{0%{background-position:100% 50%}100%{background-position:0 50%}}
.skr{height:74px}.skp{aspect-ratio:2/3}.skc{width:84px;height:36px;border-radius:99px;flex:none}

/* ── tab bar ── */
.tabbar{position:absolute;left:12px;right:12px;bottom:calc(var(--sab) + 10px);height:66px;border-radius:24px;background:var(--bar);backdrop-filter:blur(22px) saturate(170%);-webkit-backdrop-filter:blur(22px) saturate(170%);border:1px solid var(--line);display:flex;align-items:center;padding:0 6px;box-shadow:0 14px 34px rgba(0,0,0,.35);z-index:10;transition:background .4s}
.tab{flex:1;min-width:0;height:54px;border-radius:17px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;font-size:10px;font-weight:600;color:var(--mut);transition:color .25s,background .25s;position:relative;white-space:nowrap}
.tab.lv::after{content:"";position:absolute;top:8px;left:calc(50% - 15px);width:8px;height:8px;border-radius:50%;background:#ff3b30;box-shadow:0 0 0 2px var(--bar),0 0 8px #ff3b30;animation:blink 1.2s infinite}
.tab svg{width:23px;height:23px;transition:transform .3s cubic-bezier(.3,1.6,.5,1)}
.tab.on{color:var(--txt);background:rgba(var(--a1),.16)}
.tab.on svg{transform:translateY(-1px) scale(1.08);color:var(--acc1);filter:drop-shadow(0 0 8px rgba(var(--a1),.9))}

/* ── empty / error ── */
.empty{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;padding:50px 24px;color:var(--mut)}
.empty .eic{width:64px;height:64px;border-radius:20px;background:var(--card);border:1px solid var(--line);display:grid;place-items:center;color:var(--mut)}
.empty .eic svg{width:28px;height:28px}
.empty b{color:var(--txt);font-size:16px}
.empty small{font-size:13px;line-height:1.6;white-space:pre-line}

/* ── buttons ── */
.btn{display:flex;align-items:center;justify-content:center;gap:8px;height:50px;padding:0 18px;border-radius:15px;font-weight:700;font-size:15.5px;transition:transform .15s,opacity .2s}
.btn:active{transform:scale(.97)}
.btn:disabled{opacity:.6}
.btn.pri{background:var(--grad);color:#fff;box-shadow:0 10px 26px rgba(var(--a1),.4)}
.btn.pri svg{fill:#fff}
.btn.sec{background:var(--card2);border:1px solid var(--line)}
.btn.ghost{color:var(--mut)}
.btn.danger{background:var(--bad);color:#fff}
.btn.wide{width:100%}
.btn.sq{width:50px;padding:0;flex:none}
.btn.sq.on{color:var(--gold)}.btn.sq.on svg{fill:var(--gold)}

/* ── bottom sheet ── */
#sheet{position:fixed;inset:0;z-index:50;pointer-events:none}
.sbg{position:absolute;inset:0;background:rgba(0,0,0,.55);opacity:0;transition:opacity .3s;backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px)}
.spanel{position:absolute;inset:0;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;background:var(--sheet);transform:translateX(-102%);transition:transform .4s cubic-bezier(.2,.9,.25,1);padding-bottom:calc(var(--sab) + 28px);box-shadow:20px 0 50px rgba(0,0,0,.45)}
.spanel.drag{transition:none}
#sheet.on{pointer-events:auto}#sheet.on .sbg{opacity:1}#sheet.on .spanel{transform:none}
#sheet.inst .spanel,#sheet.inst .sbg,#sheet.inst *{transition:none!important}#sheet.inst *:not(.spin):not(.ex-sp){animation:none!important}
.grab,.sx{display:none!important}
/* شريط الصفحة: تحت أزرار Scriptable العائمة (إغلاق/مشاركة) */
.pnav{position:sticky;top:0;z-index:8;display:flex;align-items:center;gap:10px;padding:calc(var(--sat) + 46px) 14px 10px;background:var(--sheet);transition:background .25s,box-shadow .25s}
.pnav .ptl{flex:1;min-width:0;text-align:center;font-size:16px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;transition:opacity .25s}
.pback,.pnav .pend{width:40px;height:40px;flex:none}
.pback{border-radius:50%;display:grid;place-items:center;background:rgba(var(--fg),.1);color:var(--txt);transition:transform .15s,background .25s}
.pback:active{transform:scale(.9)}
.pback svg{width:20px;height:20px;stroke-width:2.6}
.pnav.over{background:transparent}
.pnav.over .ptl{opacity:0}
.pnav.over .pback{background:rgba(0,0,0,.38);color:#fff;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}
.pnav.over.solid{background:var(--sheet);box-shadow:0 1px 0 var(--line)}
.pnav.over.solid .ptl{opacity:1}
/* تطبيق الآيفون: لا توجد أزرار Scriptable العائمة → الشريط في أعلى الشاشة مباشرة */
.app .pnav{padding-top:calc(var(--sat) + 6px)}
.app .pnav.over+.hero{margin-top:calc(-1 * (var(--sat) + 56px));padding-top:calc(var(--sat) + 110px)}
.pnav.over.solid .pback{background:rgba(var(--fg),.1);color:var(--txt)}
.sx{position:absolute;top:12px;left:12px;width:34px;height:34px;border-radius:50%;background:rgba(0,0,0,.45);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);display:grid;place-items:center;z-index:4;color:#eef0f6}
.sx svg{width:17px;height:17px}
.shtl{display:flex;align-items:center;gap:10px;padding:4px 16px 0;font-size:21px;font-weight:850}
.shtl em{font-style:normal;font-size:12px;font-weight:800;padding:3px 10px;border-radius:99px;background:var(--grad);color:#fff}
.shsub{padding:4px 16px 0;font-size:12.5px;color:var(--mut)}

/* ── player ── */
.player{position:relative;margin:6px 14px 14px;aspect-ratio:16/9;border-radius:18px;overflow:hidden;background:#000;border:1px solid var(--line);box-shadow:0 14px 30px rgba(0,0,0,.4)}
.player video{width:100%;height:100%;display:block;background:#000}
.pov{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:radial-gradient(circle at 50% 45%,rgba(var(--a1),.22),transparent 70%),rgba(5,5,9,.95);font-size:13px;color:#e2e5ef;text-align:center;padding:12px}
.pov.none{display:none}
.pov.trying,.pov.loading{background:#000}.pov.trying .spin,.pov.loading .spin{width:40px;height:40px;border:3px solid rgba(255,255,255,.15);border-top-color:#fff}.pov.trying span,.pov.loading span{font-size:14px;font-weight:700;color:#f2f2f2}
.bigplay{width:70px;height:70px;border-radius:50%;background:var(--grad);display:grid;place-items:center;animation:pulse 2.2s infinite!important;color:#fff}
.bigplay svg{width:28px;height:28px;fill:#fff;stroke:none;margin-right:-4px}
@keyframes pulse{0%,100%{box-shadow:0 0 0 8px rgba(var(--a1),.18),0 12px 30px rgba(var(--a1),.5)}50%{box-shadow:0 0 0 16px rgba(var(--a1),.05),0 12px 30px rgba(var(--a1),.5)}}
.spin{width:38px;height:38px;border-radius:50%;border:3px solid rgba(255,255,255,.14);border-top-color:var(--acc1);border-left-color:var(--acc3);animation:rot .8s linear infinite!important}
.spin.sm{width:18px;height:18px;border-width:2px}
.perr{display:flex;flex-direction:column;align-items:center;gap:6px;max-width:300px}
.perr svg{width:30px;height:30px;color:#fca5a5}
.perr b{font-size:14px;color:#fff}
.perr small{font-size:11.5px;color:#b4b8ca;line-height:1.5}
.perr-b{display:flex;gap:8px;margin-top:6px}
.perr-b button{height:34px;padding:0 14px;border-radius:10px;background:rgba(255,255,255,.14);font-size:12.5px;font-weight:700;color:#fff}
.perr-b button:first-child{background:#f97316}

/* ── playback report ── */
.diag{margin:0 16px 12px;padding:12px 14px;border-radius:16px;background:var(--card);border:1px solid var(--line);font-size:12.5px}
.diag b{display:flex;align-items:center;gap:6px;font-size:13px;margin-bottom:6px}
.diag b svg{width:15px;height:15px;color:var(--acc1)}
.drow{display:flex;gap:8px;align-items:baseline;padding:5px 0;border-top:1px solid var(--line);color:var(--txt2);line-height:1.5}
.drow:first-of-type{border-top:0}
.drow i{font-style:normal;font-weight:900;flex:none;width:14px}
.drow .ok{color:var(--ok)}.drow .no{color:var(--bad)}
.drow span{flex:none;font-weight:800;min-width:74px}
.drow small{color:var(--mut);word-break:break-word}
.dbtns{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}
.dbtns button{height:34px;padding:0 12px;border-radius:10px;background:var(--card2);border:1px solid var(--line);font-size:12px;font-weight:700;color:var(--txt2)}

/* ── channel sheet ── */
.shead{display:flex;align-items:center;gap:12px;padding:0 16px}
.shead .lg{width:58px;height:58px}
.shead .nm b{font-size:18px;font-weight:800}
.chnav{display:flex;gap:8px}
.epg{margin:14px 16px 0;padding:14px;border-radius:18px;background:var(--card);border:1px solid var(--line)}
.epg .lbl{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;color:#f87171;letter-spacing:.3px}
.epg .lbl i{width:7px;height:7px;border-radius:50%;background:#ef4444;animation:blink 1.4s infinite}
@keyframes blink{50%{opacity:.25}}
.epg h4{font-size:16px;font-weight:750;margin:7px 0 4px;line-height:1.4}
.epg .tm{font-size:12px;color:var(--mut);display:flex;justify-content:space-between}
.bar{height:5px;border-radius:3px;background:rgba(var(--fg),.1);overflow:hidden;margin:9px 0 2px}
.bar i{display:block;height:100%;background:var(--grad);border-radius:3px}
.epg p{font-size:12.5px;color:var(--mut);line-height:1.6;margin-top:8px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.nx{display:flex;gap:10px;align-items:baseline;padding:9px 0;border-top:1px solid var(--line);font-size:13.5px}
.nx:first-of-type{margin-top:10px}
.nx span{flex:none;font-size:12px;font-weight:700;color:var(--acc1);font-variant-numeric:tabular-nums;width:44px}
.nx b{font-weight:550;color:var(--txt2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.muted{color:var(--mut);font-size:13px;text-align:center;padding:10px;display:flex;align-items:center;justify-content:center;gap:6px}
.trtag{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:800;color:var(--acc1);background:rgba(var(--a1),.12);padding:3px 8px;border-radius:99px;margin-inline-start:6px;vertical-align:middle}
.trtag svg{width:12px;height:12px}

/* ── external players ── */
.exts{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;padding:14px 16px 0}
.ext{display:flex;flex-direction:column;align-items:center;gap:6px;padding:10px 2px;border-radius:16px;background:var(--card);border:1px solid var(--line);font-size:11px;font-weight:650;color:var(--txt2);transition:transform .15s}
.ext:active{transform:scale(.93)}
.ext i{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;font-style:normal;font-weight:900;font-size:17px;color:#fff}
.ext i svg{width:19px;height:19px}
.e-in{background:var(--grad)}.e-in svg{fill:#fff;stroke:none}
.e-vlc{background:linear-gradient(145deg,#ff9d2f,#f05a00)}
.e-inf{background:linear-gradient(145deg,#ffb347,#e2382f)}
.e-np{background:linear-gradient(145deg,#3b82f6,#1e3a8a);font-family:Georgia,serif}
.e-cp{background:linear-gradient(145deg,#64748b,#1e293b)}

/* ── قائمة التصنيفات المنسدلة ── */
.chip.cdd{gap:5px;background:rgba(var(--a1),.14);border-color:rgba(var(--a1),.45);color:var(--acc1);font-weight:800}
.chip.cdd svg{width:15px;height:15px}.chip.cdd .dn{width:13px;height:13px;opacity:.8}
#cdd{position:fixed;inset:0;z-index:60;pointer-events:none}
#cdd.on{pointer-events:auto}
.cdbg{position:absolute;inset:0;background:rgba(0,0,0,.45);opacity:0;transition:opacity .2s}
#cdd.on .cdbg{opacity:1}
.cdp{position:absolute;left:12px;right:12px;max-height:min(64vh,560px);display:flex;flex-direction:column;background:var(--sheet);border:1px solid var(--line);border-radius:20px;box-shadow:0 24px 60px rgba(0,0,0,.5);overflow:hidden;transform-origin:top center;transform:translateY(-10px) scaleY(.92);opacity:0;transition:transform .22s cubic-bezier(.2,.9,.25,1),opacity .18s}
#cdd.on .cdp{transform:none;opacity:1}
.cdh{display:flex;align-items:center;justify-content:space-between;padding:12px 14px 6px}
.cdh b{display:flex;align-items:center;gap:7px;font-size:15px;font-weight:800}.cdh b svg{width:17px;height:17px;color:var(--acc1)}
.cdh em{font-style:normal;font-size:11px;color:var(--mut);font-weight:700}
.cdx{width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:rgba(var(--fg),.08)}.cdx svg{width:16px;height:16px}
.cds{margin:4px 12px 8px}
.cdl{overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 8px 10px;overscroll-behavior:contain}
.cdi{width:100%;display:flex;align-items:center;gap:10px;padding:11px 10px;border-radius:12px;text-align:right}
.cdi:active{background:rgba(var(--fg),.07)}
.cdi.on{background:rgba(var(--a1),.14)}
.cdt{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.cdt b{font-size:14px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cdt small{font-size:11px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cdi em{font-style:normal;font-size:11.5px;color:var(--mut);font-weight:700}
.cdi .ck{width:17px;height:17px;color:var(--acc1);flex:none}
.cde{padding:24px;text-align:center;color:var(--mut);font-size:13px}
.spin.sm{width:13px;height:13px;border-width:2px;display:inline-block;vertical-align:middle}

/* ── matches (مثل 365) ── */
.mbar{display:flex;align-items:center;gap:8px;padding-top:10px}
.mlive{display:flex;align-items:center;gap:7px;height:36px;padding:0 14px;border-radius:99px;background:var(--card);border:1px solid var(--line);font-size:13px;font-weight:800;color:var(--txt2);flex:none;transition:background .2s,color .2s}
.mlive i{width:8px;height:8px;border-radius:50%;background:#ff3b30;box-shadow:0 0 8px #ff3b30}
.mlive em{font-style:normal;font-size:11px;min-width:20px;height:20px;border-radius:99px;background:#ff3b30;color:#fff;display:grid;place-items:center;padding:0 6px}
.mlive em:empty{display:none}
.mlive.on{background:#ff3b30;border-color:#ff3b30;color:#fff}.mlive.on i{background:#fff;box-shadow:none;animation:blink 1.2s infinite}.mlive.on em{background:#fff;color:#ff3b30}
.mmaj{height:36px;padding:0 12px;border-radius:99px;background:var(--card);border:1px solid var(--line);font-size:12.5px;font-weight:700;color:var(--mut);flex:none}
.mmaj.on{color:var(--acc1);border-color:rgba(var(--a1),.5);background:rgba(var(--a1),.12)}
.mupd{flex:1;min-width:0;text-align:left;font-size:11px;color:var(--mut2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#mDays .chip em{font-style:normal;font-size:11px;opacity:.65;background:none;padding:0;min-width:0}
.mcomp{background:var(--card);border:1px solid var(--line);border-radius:18px;margin-top:12px;overflow:hidden}
.mch{display:flex;align-items:center;gap:9px;padding:10px 12px;background:rgba(var(--fg),.035)}
.mch b{font-size:13.5px;font-weight:800;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mch small{font-size:11px;color:var(--mut);flex:none}
.cl{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;flex:none;overflow:hidden;background:rgba(255,255,255,.92)}
.cl img{width:20px;height:20px;object-fit:contain}
.mrow{display:grid;grid-template-columns:minmax(0,1fr) 86px minmax(0,1fr);align-items:center;padding:12px 10px;gap:6px;border-top:1px solid var(--line);transition:background .15s}
.mrow:active{background:rgba(var(--fg),.06)}
.mrow.live{background:linear-gradient(90deg,transparent,rgba(255,59,48,.07),transparent)}
.mt{display:flex;align-items:center;gap:8px;min-width:0}
.mt.a{flex-direction:row-reverse}
.mt b{font-size:13px;font-weight:650;line-height:1.35;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;min-width:0}
.mt.a b{text-align:left}
.mt b.win{font-weight:850}
.tl{width:30px;height:30px;flex:none;display:grid;place-items:center;position:relative}
.tl img{width:30px;height:30px;object-fit:contain;position:relative}
.tl em{position:absolute;inset:2px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-size:13px;font-weight:800;color:var(--txt2);background:rgba(var(--fg),.1)}
.tl.ok em{display:none}
.tl.xl,.tl.xl img{width:66px;height:66px}.tl.xl em{font-size:26px}
.msc{display:flex;flex-direction:column;align-items:center;gap:3px;text-align:center;min-width:0}
.msc b{font-size:16.5px;font-weight:850;font-variant-numeric:tabular-nums;white-space:nowrap}
.msc b.sc{display:flex;align-items:center;gap:7px;direction:rtl}.msc b.sc i{font-style:normal;opacity:.55}
.msc b.tm{font-size:14px}
.msc small{font-size:10.5px;color:var(--mut);white-space:nowrap;display:flex;align-items:center;gap:4px;max-width:100%;overflow:hidden;text-overflow:ellipsis}
.msc .lv{color:#ff453a}
.msc small.lv{font-weight:800}
.msc small.lv i{width:6px;height:6px;border-radius:50%;background:#ff453a;flex:none;animation:blink 1.2s infinite}
.mhero{margin:2px 16px 0;padding:18px 12px 16px;border-radius:24px;background:linear-gradient(160deg,rgba(var(--a1),.24),rgba(var(--a2),.08) 70%),var(--card);border:1px solid var(--line)}
.mhc{display:flex;align-items:center;justify-content:center;gap:8px;font-size:12.5px;color:var(--txt2);font-weight:700;text-align:center}
.mteams{display:grid;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);align-items:center;gap:8px;margin-top:18px}
.mtb{display:flex;flex-direction:column;align-items:center;gap:9px;text-align:center;min-width:0}
.mtb b{font-size:14.5px;font-weight:800;line-height:1.35}
.msc.big b{font-size:36px}.msc.big b.tm{font-size:24px}.msc.big small{font-size:12.5px}
.mwhen{display:flex;align-items:center;justify-content:center;gap:6px;margin-top:16px;font-size:12px;color:var(--mut)}
.mwhen svg{width:14px;height:14px}
.mchs{padding:10px 16px 0;display:flex;flex-direction:column;gap:16px}
.mchg{display:flex;flex-direction:column;gap:8px}
.mchg>b{font-size:13px;font-weight:800;color:var(--txt2);display:flex;align-items:center;gap:6px}
.mchg>b svg{width:15px;height:15px}
.mchs .ch .ep-pl{width:18px;height:18px;color:var(--acc1);margin-left:8px;flex:none}
.mrow .mtv{grid-column:1/-1;display:flex;justify-content:center;align-items:center;gap:6px;min-height:0}
.mrow .mtv:empty{display:none}
.mtvb{display:inline-flex;align-items:center;gap:6px;height:30px;padding:0 12px;border-radius:99px;background:rgba(var(--a1),.16);border:1px solid rgba(var(--a1),.45);color:var(--acc1);font-size:12px;font-weight:800;max-width:100%;margin-top:2px}
.mtvb span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mtvb svg{width:13px;height:13px;flex:none}
.mtvb.hint{background:rgba(var(--fg),.06);border-color:var(--line);color:var(--txt2);font-weight:700}
.mtv em{font-style:normal;font-size:11px;font-weight:800;color:var(--mut)}
.mtvn{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:var(--txt2)}.mtvn svg{width:13px;height:13px}
.mtvw{display:inline-flex;align-items:center;gap:7px;font-size:11.5px;color:var(--mut)}
.mtvw .spin{width:13px;height:13px;border-width:2px}
.mchg>b.ok{color:var(--ok)}
.mnames{display:flex;flex-wrap:wrap;gap:6px}.mnames span{font-size:12.5px;font-weight:800;padding:6px 11px;border-radius:10px;background:var(--card);border:1px solid var(--line)}
.mnote{font-size:11.5px;color:var(--mut)}
.lnb{display:inline-block;margin-inline-start:6px;padding:1px 7px;border-radius:6px;background:rgba(16,185,129,.16);color:#34d399;font-size:10.5px;font-weight:800;vertical-align:1px}
.lnb.x{background:rgba(var(--fg),.08);color:var(--mut)}
.sresh{display:flex;align-items:center;gap:8px;padding:2px 2px 4px;font-size:12.5px;color:var(--mut);line-height:1.5}
.sresh svg{width:16px;height:16px;flex:none;color:var(--acc1)}
.sresh b{color:var(--txt);font-weight:800}
/* التشكيلة: ملعب كامل (المضيف تحت والضيف فوق) */
.lineup{margin:12px 16px 0}
.lsts{display:flex;align-items:center;justify-content:center;gap:6px;margin-bottom:10px;font-size:12px;font-weight:750;color:var(--mut)}
.lsts b{color:#34d399}
.lsts b.ex{color:#fbbf24}
.lhd{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px 14px 0 0;background:rgba(0,0,0,.28)}
.lhd.bot{border-radius:0 0 14px 14px}
.lhd .tl{width:26px;height:26px}
.lhd b{flex:1;font-size:14px;font-weight:800}
.lhd em{font-style:normal;font-size:13px;font-weight:800;color:var(--acc1);direction:ltr}
.pitch{position:relative;aspect-ratio:68/108;overflow:hidden;background:repeating-linear-gradient(0deg,#15803d 0 9.09%,#16a34a 9.09% 18.18%);box-shadow:inset 0 0 40px rgba(0,0,0,.35)}
.pitch i.ln{position:absolute;border:2px solid rgba(255,255,255,.42);pointer-events:none}
.pitch .c1{left:4%;right:4%;top:2.5%;bottom:2.5%}
.pitch .c2{left:4%;right:4%;top:50%;height:0;border-width:2px 0 0}
.pitch .c3{left:50%;top:50%;width:26%;aspect-ratio:1;border-radius:50%;transform:translate(-50%,-50%)}
.pitch .c4{left:22%;right:22%;top:2.5%;height:13%;border-top:0}
.pitch .c5{left:22%;right:22%;bottom:2.5%;height:13%;border-bottom:0}
.pitch .c6{left:37%;right:37%;top:2.5%;height:5%;border-top:0}
.pitch .c7{left:37%;right:37%;bottom:2.5%;height:5%;border-bottom:0}
.pl{position:absolute;width:66px;translate:-50% -50%;text-align:center;z-index:2;animation:up .4s both;animation-delay:calc(var(--i,0) * 25ms)}
.pa{position:relative;display:grid;place-items:center;width:38px;height:38px;margin:0 auto;border-radius:50%;background:#0f172a;box-shadow:0 0 0 2px #fff,0 4px 10px rgba(0,0,0,.45);overflow:hidden}
.pl.aw .pa{background:#f8fafc;box-shadow:0 0 0 2px var(--acc1),0 4px 10px rgba(0,0,0,.45)}
.pa>i{font-style:normal;font-weight:850;font-size:14px;color:#fff}
.pl.aw .pa>i{color:#0f172a}
.pa img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background:inherit;opacity:0;transition:opacity .3s}
.pl.im .pa img{opacity:1}
.pl:not(.im) .nb{display:none}
.pl .nb{position:absolute;top:-4px;inset-inline-end:8px;min-width:17px;height:17px;padding:0 3px;border-radius:9px;background:#111827;color:#fff;font-size:10px;font-weight:800;line-height:17px;font-style:normal;z-index:3;box-shadow:0 0 0 1.5px rgba(255,255,255,.8)}
.pl b{display:block;margin-top:4px;font-size:10.5px;font-weight:750;color:#fff;line-height:1.25;text-shadow:0 1px 3px rgba(0,0,0,.9);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pl .rk{position:absolute;top:-4px;inset-inline-start:6px;padding:0 4px;border-radius:6px;font-size:9.5px;font-weight:850;font-style:normal;line-height:15px;color:#fff;z-index:3;background:#f59e0b}
.pl .rk.g{background:#16a34a}.pl .rk.b{background:#2563eb}.pl .rk.r{background:#dc2626}
.lsubs{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}
.lsub{padding:12px;border-radius:14px;background:var(--card)}
.lsub h4{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:800;margin-bottom:8px}
.lsub h4 .tl{width:20px;height:20px}
.lsub .co{font-size:11.5px;color:var(--mut);margin-bottom:8px}
.lsub .co b{color:var(--txt2)}
.lsub .sb{display:flex;align-items:center;gap:8px;padding:5px 0;font-size:12.5px;border-top:1px solid var(--line)}
.lsub .sb i{flex:none;min-width:22px;height:22px;border-radius:7px;background:var(--tile);display:grid;place-items:center;font-style:normal;font-size:11px;font-weight:800;color:var(--mut)}
.lsub .sb span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── vod detail ── */
.hero{position:relative;overflow:hidden;padding:24px 16px 16px}
.pnav.over+.hero{margin-top:calc(-1 * (var(--sat) + 96px));padding-top:calc(var(--sat) + 150px)}
.hbg{position:absolute;inset:-12px;background-size:cover;background-position:center 22%;filter:blur(5px) saturate(125%);opacity:.6;transform:scale(1.04)}
.hero::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.45),transparent 26%,transparent 42%,var(--sheet) 97%)}
.bdgs{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}
.bdg{font-size:10.5px;font-weight:800;letter-spacing:.3px;padding:3px 8px;border-radius:7px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.22);color:#fff;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
.bdg.q{background:linear-gradient(135deg,#f5c542,#e0a106);border-color:transparent;color:#1a1300}
.ps .qb{position:absolute;top:7px;right:7px;z-index:2;font-style:normal;font-size:9.5px;font-weight:900;padding:2px 6px;border-radius:6px;background:linear-gradient(135deg,#f5c542,#e0a106);color:#1a1300}
.hin{position:relative;z-index:1;display:flex;gap:14px;align-items:flex-end}
.hpo{width:112px;flex:none;aspect-ratio:2/3;border-radius:16px;overflow:hidden;position:relative;background:var(--tile);box-shadow:0 18px 36px rgba(0,0,0,.45);border:1px solid var(--line);display:grid;place-items:center;font-weight:800;color:var(--mut2);font-size:20px}
.hpo img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.hinfo{min-width:0;padding-bottom:4px}
.hinfo h2{font-size:23px;font-weight:850;line-height:1.3;letter-spacing:-.3px;text-shadow:0 2px 14px rgba(0,0,0,.45)}
.hinfo .on{font-size:12.5px;color:var(--mut);margin-top:3px}
.hinfo .trn{font-size:13px;color:var(--acc1);font-weight:700;margin-top:4px}
.meta{display:flex;flex-wrap:wrap;align-items:center;gap:6px;font-size:12.5px;color:var(--txt2);margin-top:8px}
.meta .rb{color:var(--gold);font-weight:800}
.gen{font-size:12px;color:var(--mut);margin-top:6px;line-height:1.5}
.acts{display:flex;gap:10px;padding:4px 16px 0;align-items:center}
.acts .btn.pri{flex:1}
.cur-ep{flex:1;min-width:0;height:50px;border-radius:15px;background:var(--card);border:1px dashed rgba(var(--fg),.18);display:flex;align-items:center;padding:0 14px;font-size:13.5px;font-weight:650;color:var(--txt2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.desc{font-size:14px;line-height:1.85;color:var(--txt2);padding:8px 16px 0}
.dhead{display:flex;align-items:center;justify-content:space-between;margin:22px 16px 0}
.dhead .sec-t{margin:0}
.trb{font-size:11.5px;font-weight:800;color:var(--acc1);background:rgba(var(--a1),.12);padding:6px 10px;border-radius:99px;display:flex;align-items:center;gap:5px}
.trb svg{width:13px;height:13px}
.cast{padding:12px 16px 0;display:flex;flex-direction:column;gap:6px;font-size:13px;color:var(--txt2);line-height:1.6}
.cast span{color:var(--mut);margin-left:8px;font-weight:700}
/* ═════════ ثيم «نتفلكس»: أسود، أحمر، زوايا صغيرة، أزرار بيضاء، شريط سفلي كامل ═════════ */
.nf body::before{display:none}
.nf .top{justify-content:flex-start;padding-left:16px;padding-right:16px}
.nf .top .brand{flex:1;justify-content:flex-start}
.nf .logo{background:none;box-shadow:none;width:30px;height:30px;color:#e50914}
.nf .logo svg{width:26px;height:26px;fill:#e50914;stroke:#e50914}
.nf .bt b{font-size:21px;font-weight:900;color:#e50914;letter-spacing:-.3px}
.nf .top .bt b{font-size:21px}
.nf .top .ibtn{background:none;border:0}
.nf .search{border-radius:6px;background:#2a2a2a;border:0;height:42px}
.nf .search:focus-within{background:#333;border:0}
.nf .chip{height:34px;border-radius:999px;background:transparent;border:1px solid rgba(255,255,255,.45);color:#fff;font-weight:600}
.nf .chip.on{background:#fff;color:#000;border-color:#fff;box-shadow:none}
.nf .chip.on em{background:rgba(0,0,0,.12);color:#000}
.nf .chip.cdd{background:transparent;border-color:rgba(255,255,255,.45);color:#fff}
.nf .ps{border-radius:5px;border:0;box-shadow:none;background:#232323}
.nf .pc .t{font-size:12px;font-weight:500;color:#b3b3b3}
.nf .rowx .pc{width:106px}
.nf .rowx .pc .t{display:none}
.nf .rowx{gap:8px}
.nf .rowt{font-size:18px;font-weight:800;color:#fff}
.nf .rowt button{color:#b3b3b3}
.nf .home{gap:26px}
.nf .hero2{height:470px;border-radius:10px;box-shadow:0 0 0 1px rgba(255,255,255,.12),0 24px 50px rgba(0,0,0,.7)}
.nf .hero2::after{background:linear-gradient(180deg,rgba(0,0,0,0) 40%,rgba(0,0,0,.55) 68%,rgba(0,0,0,.92) 100%)}
.nf .hero2 .hk{background:#e50914;border-radius:3px;padding:3px 8px}
.nf .hero2 h3{font-size:30px;font-weight:900}
.nf .hero2 .hbtns{width:100%;gap:10px}
.nf .hero2 .hbtns .btn{flex:1;height:42px;border-radius:5px;font-weight:800}
.nf .hero2 .btn.g{background:rgba(109,109,110,.75)}
.nf .btn{border-radius:5px}
.nf .btn.pri{background:#fff;color:#000;box-shadow:none}
.nf .btn.pri svg{fill:#000;stroke:#000}
.nf .btn.pri .pbar{background:rgba(0,0,0,.18)}
.nf .btn.pri .pbar b{background:#e50914}
.nf .btn.sec{background:#2a2a2a;border:0}
.nf .seg{border-radius:6px;background:#1c1c1c;border:0}
.nf .seg button{border-radius:4px}
.nf .seg button.on{background:#e50914;box-shadow:none}
.nf .card{border-radius:8px;border:0;background:#1c1c1c}
.nf .sec-t{font-size:17px;font-weight:800;color:#fff}
.nf .ch{border-radius:6px;border:0;background:#1a1a1a}
.nf .ch.on,.nf .mchs .ch.on{background:#262626;border:0;box-shadow:inset -3px 0 0 #e50914}
.nf .tabbar{left:0;right:0;bottom:0;height:calc(58px + var(--sab));padding-bottom:var(--sab);border-radius:0;background:rgba(0,0,0,.96);border:0;border-top:1px solid rgba(255,255,255,.08);box-shadow:none}
.nf .tab{color:#808080;font-weight:600}
.nf .tab.on{background:none;color:#fff}
.nf .tab.on svg{color:#fff;filter:none;transform:none}
.nf .hero::after{background:linear-gradient(180deg,rgba(0,0,0,.35),transparent 30%,rgba(20,20,20,.6) 66%,var(--sheet) 100%)}
.nf .hbg{inset:0;filter:none;opacity:.95;transform:none}
.nf .hpo{border-radius:5px;border:0;box-shadow:0 10px 30px rgba(0,0,0,.6)}
.nf .hinfo h2{font-size:26px;font-weight:900}
.nf .bdg{background:transparent;border:1px solid rgba(255,255,255,.5);border-radius:3px;backdrop-filter:none;-webkit-backdrop-filter:none}
.nf .bdg.q{background:transparent;border-color:rgba(255,255,255,.5);color:#fff}
.nf .ps .qb{background:#e50914;color:#fff;border-radius:3px}
.nf .acts .btn.pri{height:46px}
.nf .cur-ep{border-radius:5px;background:#fff;color:#000;border:0;font-weight:800;justify-content:center}
.nf .cur-ep .pbar{background:rgba(0,0,0,.18)}
.nf .ep{background:none;border:0;border-bottom:1px solid rgba(255,255,255,.08);border-radius:0;padding:14px 4px}
.nf .ep .en{background:none;color:#fff;font-size:22px;font-weight:800;width:34px}
.nf .ep.on{background:#1f1f1f;border-radius:4px}
.nf .ep.on .en{color:#e50914}
.nf .ep.seen .en{background:none;color:#b3b3b3}
.nf .ep .epm{color:#b3b3b3}
.nf .pbar{background:rgba(255,255,255,.3);border-radius:0;height:3px}
.nf .pbar b{background:#e50914;border-radius:0;box-shadow:none}
.nf .ps .seen{background:#e50914}
.nf .lnb{background:#e50914;color:#fff}
.nf .lnb.x{background:#333;color:#b3b3b3}
.nf .pitch{background:repeating-linear-gradient(0deg,#14532d 0 9.09%,#166534 9.09% 18.18%)}
.nf .lhd em{color:#fff}
.nf .pcount{background:#e50914;color:#fff;border-radius:4px}
.nf .msbtn{border-radius:5px;border-color:rgba(255,255,255,.3);color:#fff}
.nf .toast{border-radius:6px}
.nf #splash{background:#000}
.nf #splash .logo{background:none;box-shadow:none;animation:nfIn 1.1s cubic-bezier(.2,.8,.2,1) both}
.nf #splash .logo svg{width:84px;height:84px;fill:#e50914;stroke:#e50914;filter:drop-shadow(0 0 22px rgba(229,9,20,.55))}
.nf #splash .sp-name{color:#e50914;font-size:40px;letter-spacing:-1px;text-shadow:0 0 28px rgba(229,9,20,.45)}
@keyframes nfIn{0%{transform:scale(1.9);opacity:0;filter:blur(6px)}55%{opacity:1;filter:none}100%{transform:scale(1)}}
/* أين وصلت المشاهدة: خط التقدم وعلامة «شوهدت» */
.pbar{position:absolute;left:8px;right:8px;bottom:8px;height:4px;border-radius:4px;background:rgba(255,255,255,.26);overflow:hidden;z-index:4;pointer-events:none;box-shadow:0 1px 6px rgba(0,0,0,.45)}
.pbar b{display:block;height:100%;border-radius:4px;background:var(--acc1);box-shadow:0 0 8px rgba(var(--a1),.7)}
.ps .seen{position:absolute;bottom:8px;left:8px;z-index:4;width:24px;height:24px;border-radius:50%;background:rgba(16,185,129,.95);color:#fff;display:grid;place-items:center;box-shadow:0 3px 10px rgba(0,0,0,.4)}
.ps .seen svg{width:14px;height:14px}
.ep{position:relative;overflow:hidden}
.ep .pbar{left:12px;right:12px;bottom:5px;height:3px}
.ep .epm{flex:none;font-size:11.5px;font-weight:700;color:var(--acc1);white-space:nowrap}
.ep .epm.ok{color:#34d399}
.ep.seen .en{background:rgba(16,185,129,.18);color:#34d399}
.ep.seen b{color:var(--mut)}
.cur-ep{position:relative;overflow:hidden;font:inherit;color:inherit;text-align:right;cursor:pointer}
.cur-ep .pbar{left:14px;right:14px;bottom:6px;height:3px}
.btn.pri{position:relative;overflow:hidden}
.btn.pri .pbar{left:16px;right:16px;bottom:6px;height:3px;background:rgba(255,255,255,.3)}
.btn.pri .pbar b{background:#fff;box-shadow:none}
.cwt{display:block;font-size:11px;color:var(--mut);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hrow.cw .rowt span{display:inline-flex;align-items:center;gap:6px}
.hrow.cw .rowt svg{width:16px;height:16px;color:var(--acc1)}
.hrow.cw .hplay{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%);width:46px;height:46px;border-radius:50%;background:rgba(0,0,0,.5);border:1.5px solid rgba(255,255,255,.7);display:grid;place-items:center;z-index:3;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
.hrow.cw .hplay svg{width:20px;height:20px;color:#fff;margin-right:-2px}
/* صفحة المباراة: المشغل في نفس الصفحة */
.mnow{display:flex;align-items:center;gap:8px;margin:12px 16px 0;padding:10px 14px;border-radius:14px;background:rgba(var(--a1),.14);color:var(--acc1);font-size:13px;font-weight:750}
.mnow b{color:var(--txt);font-weight:800}
.sbusy{color:var(--mut)}.sbusy .spin{margin:0 2px}
.mnow svg{width:17px;height:17px;flex:none}
.mchs .ch.on{border-color:rgba(var(--a1),.65);background:rgba(var(--a1),.14)}
.mchs .ch.on .ep-pl{color:var(--acc1)}
.msrch{margin:12px 16px 0}
.msrch .search{margin:0}
.msres{display:flex;flex-direction:column;gap:8px;margin-top:10px}
.msbtn{display:flex;align-items:center;justify-content:center;gap:8px;width:calc(100% - 32px);margin:12px 16px 0;height:46px;border-radius:14px;background:var(--card);border:1px dashed rgba(var(--a1),.5);color:var(--acc1);font-weight:800;font-size:14px}
.msbtn svg{width:18px;height:18px}
/* طاقم العمل: صور الممثلين (اضغط لترى أعماله) */
.castt{margin:18px 4px 0}
.castrow{display:flex;gap:12px;overflow-x:auto;padding:12px 16px 6px;scrollbar-width:none;-webkit-overflow-scrolling:touch}
.castrow::-webkit-scrollbar{display:none}
.castrow:empty{display:none}
.cp{flex:none;width:78px;display:flex;flex-direction:column;align-items:center;gap:7px;text-align:center;animation:up .4s both;animation-delay:calc(var(--i,0) * 40ms)}
.cp .ca{position:relative;width:70px;height:70px;border-radius:50%;overflow:hidden;background:var(--tile);box-shadow:0 0 0 2px rgba(var(--fg),.1),0 8px 20px rgba(0,0,0,.3);display:grid;place-items:center;transition:transform .15s}
.cp:active .ca{transform:scale(.92)}
.cp .ca i{font-style:normal;font-weight:800;font-size:20px;color:var(--mut)}
.cp .ca img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 20%;opacity:0;transition:opacity .4s}
.cp .ca img.ld{opacity:1}
.cp b{font-size:11.5px;font-weight:700;line-height:1.35;color:var(--txt2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;max-width:78px}
.cp.sk .ca{animation:none}
.person{display:flex;flex-direction:column;align-items:center;padding:4px 20px 2px;text-align:center}
.pph{position:relative;width:136px;height:136px;border-radius:50%;overflow:hidden;background:var(--tile);display:grid;place-items:center;box-shadow:0 16px 44px rgba(0,0,0,.5),0 0 0 3px rgba(var(--a1),.5);animation:up .45s both}
.pph i{font-style:normal;font-size:42px;font-weight:800;color:var(--mut)}
.pph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 20%}
.person h2{margin-top:14px;font-size:23px;font-weight:850;line-height:1.3}
.pdesc{margin-top:4px;font-size:13px;color:var(--mut);min-height:4px}
.pcount{margin-top:10px;display:inline-flex;gap:6px;align-items:center;padding:6px 12px;border-radius:999px;background:rgba(var(--a1),.16);color:var(--acc1);font-size:12.5px;font-weight:750}
.pnote{padding:14px 18px;color:var(--mut);font-size:13.5px;display:flex;align-items:center;gap:9px;line-height:1.6}
.pgrid{padding:12px 16px 4px}
.pwl{display:flex;flex-direction:column;gap:8px;padding:10px 16px 26px}
.pw{display:flex;align-items:center;gap:12px;padding:8px;border-radius:14px;background:var(--card);text-align:right;width:100%}
.pw:active{background:var(--card2)}
.pw .pwi{position:relative;width:44px;height:64px;border-radius:9px;overflow:hidden;flex:none;background:var(--tile);display:grid;place-items:center;color:var(--mut)}
.pw .pwi img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.pw .pwt{flex:1;min-width:0}
.pw b{display:block;font-size:14px;font-weight:750;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pw small{color:var(--mut);font-size:12px}
.pw .chev{width:16px;height:16px;color:var(--mut2);flex:none}
.pad{padding-left:16px;padding-right:16px}
.eps{display:flex;flex-direction:column;gap:8px;padding:12px 16px 0}
.ep{display:flex;align-items:center;gap:12px;padding:11px 12px;border-radius:15px;background:var(--card);border:1px solid var(--line);transition:background .2s,border-color .2s,transform .15s}
.ep:active{transform:scale(.98)}
.ep .en{width:38px;height:38px;border-radius:11px;background:rgba(var(--a1),.16);color:var(--acc1);display:grid;place-items:center;font-weight:800;font-size:14px;flex:none}
.ep b{flex:1;min-width:0;font-size:14.5px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ep .ep-pl{width:18px;height:18px;color:var(--mut);transform:scaleX(-1)}
.ep.on{background:rgba(var(--a1),.14);border-color:rgba(var(--a1),.5)}
.ep.on .en{background:var(--grad);color:#fff}
.ep.on .ep-pl{color:var(--acc1)}

/* ── settings ── */
.sec-t{font-size:13px;font-weight:800;color:var(--mut);margin:22px 4px 10px;letter-spacing:.2px}
.card{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:16px}
.card.np{padding:4px 16px}
.seg{display:flex;gap:4px;padding:4px;border-radius:15px;background:var(--card);border:1px solid var(--line)}
.seg button{flex:1;height:38px;border-radius:11px;font-size:13px;font-weight:700;color:var(--mut);transition:all .25s;white-space:nowrap}
.seg button.on{background:var(--grad);color:#fff;box-shadow:0 6px 16px rgba(var(--a1),.35)}
.acc-top{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.av{width:46px;height:46px;border-radius:14px;background:var(--grad);display:grid;place-items:center;flex:none;color:#fff}
.acc-top b{display:block;font-size:16.5px;font-weight:800}
.acc-top small{display:block;font-size:12px;color:var(--mut);margin-top:3px;word-break:break-all}
.kv{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:11px 0;border-top:1px solid var(--line);font-size:14px}
.kv span{color:var(--mut)}
.kv b{font-weight:650;text-align:left;font-variant-numeric:tabular-nums}
.kv b.okc{color:var(--ok)}.kv b.errc{color:var(--bad)}.kv b.waitc{color:var(--warn)}
.srow{display:flex;align-items:center;gap:12px;justify-content:space-between;width:100%;text-align:right}
.srow b{display:block;font-size:15px;font-weight:700}
.srow small{display:block;font-size:12px;color:var(--mut);margin-top:3px;line-height:1.5}
.srow .grow{flex:1;min-width:0}
.srow.lnk{padding:12px 0;border-bottom:1px solid var(--line)}
.card.np>.srow:last-child{border-bottom:0}
.card.np>.srow:not(.lnk){padding:12px 0}
.chev{width:18px;height:18px;color:var(--mut)}
.swt{width:44px;height:44px;border-radius:13px;flex:none;position:relative;overflow:hidden;border:1px solid var(--line)}
.swt i{position:absolute;left:8px;right:8px;bottom:9px;height:8px;border-radius:4px}
.swa{width:44px;height:44px;border-radius:13px;flex:none;background:rgba(var(--a1),.15);color:var(--acc1);display:grid;place-items:center}
.swa svg{width:22px;height:22px}
.sw{position:relative;width:51px;height:31px;flex:none}
.sw input{position:absolute;opacity:0;pointer-events:none}
.sw i{position:absolute;inset:0;border-radius:99px;background:rgba(var(--fg),.16);transition:.25s}
.sw i::after{content:"";position:absolute;top:2px;right:2px;width:27px;height:27px;border-radius:50%;background:#fff;transition:transform .25s cubic-bezier(.3,1.4,.5,1);box-shadow:0 2px 6px rgba(0,0,0,.35)}
.sw input:checked+i{background:var(--ok)}
.sw input:checked+i::after{transform:translateX(-20px)}
.btns{display:flex;flex-direction:column;gap:10px;margin-top:22px}
.about{text-align:center;color:var(--mut2);font-size:12px;margin-top:22px;line-height:1.7}

/* ── theme & animation pickers ── */
.thgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px 10px;padding:14px 16px 0}
.th{display:flex;flex-direction:column;gap:6px;font-size:10.5px;font-weight:700;color:var(--txt2);text-align:center;min-width:0}
.thp{position:relative;aspect-ratio:3/4;border-radius:15px;background:var(--tb);border:2px solid var(--line);overflow:hidden;box-shadow:0 6px 14px rgba(0,0,0,.22);transition:transform .2s}
.th:active .thp{transform:scale(.94)}
.thp::before{content:"";position:absolute;inset:-20%;background:radial-gradient(55% 45% at 85% 5%,var(--tglow),transparent 70%)}
.thp i{position:absolute;right:9px;left:9px;height:7px;border-radius:4px;background:var(--tcard)}
.thp i:nth-child(1){top:14px;left:35%;background:var(--tg)}
.thp i:nth-child(2){top:28px}
.thp i:nth-child(3){top:40px;left:45%}
.thp u{position:absolute;bottom:9px;left:9px;right:9px;height:14px;border-radius:7px;background:var(--tg);text-decoration:none}
.th.on .thp{border-color:var(--acc1);box-shadow:0 0 0 3px rgba(var(--a1),.35)}
.th.on .thp::after{content:"✓";position:absolute;top:6px;left:6px;width:19px;height:19px;border-radius:50%;background:#fff;color:#000;font-size:11px;display:grid;place-items:center;font-weight:900}
.th span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.angrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;padding:14px 16px 0}
.an{min-height:48px;border-radius:14px;background:var(--card);border:1px solid var(--line);font-size:12.5px;font-weight:750;color:var(--txt2);display:flex;align-items:center;gap:8px;padding:6px 10px;text-align:right}
.an i{width:26px;height:26px;border-radius:9px;background:rgba(var(--a1),.15);color:var(--acc1);font-style:normal;font-size:11px;font-weight:900;display:grid;place-items:center;flex:none}
.an span{flex:1;min-width:0;line-height:1.3}
.an small{display:block;font-size:10.5px;color:var(--mut);font-weight:650}
.an.on{background:var(--grad);color:#fff;border-color:transparent;box-shadow:0 8px 20px rgba(var(--a1),.35)}
.an.on i{background:rgba(255,255,255,.25);color:#fff}.an.on small{color:rgba(255,255,255,.8)}
.demo{position:relative;margin:12px 16px 0;padding:12px;border-radius:18px;background:rgba(var(--fg),.03);border:1px dashed rgba(var(--fg),.14);height:212px;overflow:hidden}
.demo .ch{padding:7px 8px;margin-bottom:7px}
.demo .lg{width:38px;height:38px;border-radius:11px}
.demo .ch b{font-size:13px}
.demo .ch .bar2{height:6px;border-radius:3px;background:rgba(var(--fg),.1);margin-top:6px;width:60%}
.picks{display:flex;gap:10px;padding:14px 16px 0}
.picks .btn{flex:1;height:44px;font-size:14px}

/* ── portals screen ── */
.screen{position:fixed;inset:0;z-index:40;background:var(--bg);overflow-y:auto;-webkit-overflow-scrolling:touch;opacity:0;pointer-events:none;transition:opacity .35s}
.screen.on{opacity:1;pointer-events:auto}
.screen::before{content:"";position:fixed;inset:0;pointer-events:none;background:radial-gradient(60% 40% at 50% 0%,var(--g1),transparent 70%),radial-gradient(40% 30% at 100% 100%,var(--g2),transparent 70%)}
.pwrap{position:relative;max-width:520px;margin:0 auto;padding:calc(var(--sat) + 34px) 18px calc(var(--sab) + 30px)}
.phero{text-align:center;display:flex;flex-direction:column;align-items:center;gap:10px;margin-bottom:8px;animation:up .6s both}
.phero h1{font-size:28px;font-weight:900;letter-spacing:-.5px;margin-top:8px}
.phero p{color:var(--mut);font-size:14px}
.plist{display:flex;flex-direction:column;gap:10px}
.pcard{display:flex;align-items:center;gap:12px;padding:12px;border-radius:18px;background:var(--card);border:1px solid var(--line);transition:transform .15s}
.pcard:active{transform:scale(.98)}
.pcard.act{border-color:rgba(var(--a1),.55);background:rgba(var(--a1),.1)}
.pav{width:44px;height:44px;border-radius:13px;background:rgba(var(--a1),.18);color:var(--acc1);display:grid;place-items:center;flex:none}
.pinfo{flex:1;min-width:0}
.pinfo b{display:block;font-size:15.5px;font-weight:750}
.pinfo small{display:block;font-size:11.5px;color:var(--mut);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:right}
.form{margin-top:18px;display:flex;flex-direction:column;gap:14px;animation:up .45s both}
.form h3{font-size:18px;font-weight:850}
.fld label{display:block;font-size:12.5px;font-weight:700;color:var(--mut);margin:0 4px 7px}
.fld input{width:100%;height:50px;border-radius:14px;background:var(--input);border:1px solid var(--line);padding:0 14px;font-size:16px;outline:0;transition:border-color .2s}
.fld input:focus{border-color:rgba(var(--a1),.7)}
.fld input[dir=ltr]{text-align:left}
.hint{font-size:11.5px;color:var(--mut2);margin:6px 4px 0;line-height:1.5}
.hint.ok{color:var(--ok)}
details{border-radius:14px;background:var(--input);border:1px solid var(--line);padding:0 14px}
details summary{list-style:none;height:46px;display:flex;align-items:center;font-size:13.5px;font-weight:700;color:var(--txt2)}
details summary::-webkit-details-marker{display:none}
details summary::after{content:"＋";margin-right:auto;color:var(--mut)}
details[open] summary::after{content:"－"}
details .fld{margin-bottom:12px}
.ferr{color:#f87171;font-size:13px;line-height:1.6;white-space:pre-line}
.ferr:empty{display:none}
.banner{margin:16px 0 0;padding:12px 14px;border-radius:14px;background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.35);color:#fca5a5;font-size:13px;line-height:1.6;white-space:pre-line}

/* ── splash ── */
#splash{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;z-index:60}
#splash .logo{width:84px;height:84px;border-radius:26px;animation:breathe 2s ease-in-out infinite}
#splash .logo svg{width:36px;height:36px}
@keyframes breathe{50%{transform:scale(1.06);box-shadow:0 12px 40px rgba(var(--a1),.7)}}
.sp-name{font-size:24px;font-weight:900;letter-spacing:-.4px}
.sp-st{font-size:13px;color:var(--mut);min-height:18px}

/* ── modal & toast ── */
#modal{position:fixed;inset:0;z-index:80;display:grid;place-items:center;pointer-events:none;opacity:0;transition:opacity .25s}
#modal.on{pointer-events:auto;opacity:1}
.mbg{position:absolute;inset:0;background:rgba(0,0,0,.55);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
.mbox{position:relative;width:min(320px,86vw);padding:22px 18px 16px;border-radius:22px;background:var(--bg2);border:1px solid var(--line);text-align:center;transform:scale(.92);transition:transform .3s cubic-bezier(.3,1.5,.5,1)}
#modal.on .mbox{transform:none}
.mbox b{font-size:17px;font-weight:800}
.mbox p{font-size:13.5px;color:var(--mut);margin:8px 0 18px;line-height:1.6}
.mbtns{display:flex;gap:10px}.mbtns .btn{flex:1;height:46px}
#toast{position:fixed;left:50%;top:calc(var(--sat) + 12px);z-index:90;max-width:88vw;padding:12px 18px;border-radius:16px;background:var(--toast);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid var(--line);font-size:13.5px;font-weight:650;box-shadow:0 12px 30px rgba(0,0,0,.35);transform:translate(-50%,-140%);opacity:0;transition:transform .4s cubic-bezier(.2,1.2,.4,1),opacity .3s;pointer-events:none;text-align:center;line-height:1.5;white-space:pre-line;color:var(--txt)}
#toast.on{transform:translate(-50%,0);opacity:1}
#toast.bad{border-color:rgba(239,68,68,.5);color:#f87171}
#toast.ok{border-color:rgba(34,197,94,.45)}

/* ── crash report ── */
.card.crash{border-color:rgba(239,68,68,.4);background:rgba(239,68,68,.07)}
.card.crash b{display:flex;align-items:center;gap:6px}.card.crash b svg{width:16px;height:16px;color:#f87171}
.card.crash pre{margin-top:10px;font:11px/1.5 ui-monospace,Menlo,monospace;color:var(--mut);white-space:pre-wrap;word-break:break-all;max-height:140px;overflow:auto;text-align:left}
/* ── memory-friendly list effects ── */
.rt{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;background:rgba(0,0,0,.72)!important}
.hbg{filter:blur(18px) saturate(130%)}
/* ── light mode 🪶 ── */
.lite *,.lite *::before,.lite *::after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
.lite body::before,.lite .screen::before{display:none!important}
.lite .hbg{filter:none!important;opacity:.3!important;transform:none!important}
.lite .ps,.lite .player,.lite .hero2,.lite .tabbar,.lite .hpo,.lite .btn.pri,.lite .chip.on,.lite .logo{box-shadow:none!important}
.lite .tabbar{background:var(--bg2)!important}
.lite .bigplay,.lite #splash .logo{animation:none!important}
/* ── tab bar with 6 tabs ── */
.tab{font-size:10px}
.tab svg{width:22px;height:22px}
/* ── YouTube ── */
.ytnote{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:var(--ok);margin-top:10px}
.ytnote svg{width:15px;height:15px}
.ytlist{display:flex;flex-direction:column;gap:16px}
.yv{transition:transform .15s}
.yv:active{transform:scale(.98)}
.yth{position:relative;aspect-ratio:16/9;border-radius:16px;overflow:hidden;background:var(--tile);border:1px solid var(--line)}
.yth img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .35s}
.yth img.ld{opacity:1}
.yth em{position:absolute;bottom:8px;left:8px;font-style:normal;font-size:11.5px;font-weight:800;padding:2px 7px;border-radius:7px;background:rgba(0,0,0,.82);color:#fff;font-variant-numeric:tabular-nums}
.yth em.live{background:#e11d48}
.ypl{position:absolute;inset:0;margin:auto;width:52px;height:52px;border-radius:50%;background:rgba(0,0,0,.55);display:grid;place-items:center;color:#fff}
.ypl svg{width:22px;height:22px;fill:#fff;stroke:none;margin-right:-3px}
.yi{padding:9px 2px 0}
.yi b{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:14.5px;font-weight:700;line-height:1.45}
.yi small{display:block;font-size:12px;color:var(--mut);margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── السهرة ماك: splash ── */
#splash{background:radial-gradient(70% 45% at 50% 38%,rgba(var(--a1),.3),transparent 70%),var(--bg);gap:12px}
#splash .logo{width:100px;height:100px;border-radius:32px;animation:spIn .9s cubic-bezier(.2,1.3,.4,1) both,breathe 2.4s 1s ease-in-out infinite}
#splash .logo svg{width:58px;height:58px;margin:0}
@keyframes spIn{from{opacity:0;transform:scale(.5) rotate(-14deg);filter:blur(8px)}to{opacity:1;transform:none;filter:none}}
#splash .sp-name{font-size:34px;font-weight:900;letter-spacing:-.5px;margin-top:10px;animation:spUp .7s .35s both}
.sp-tag{font-size:14px;color:var(--mut);animation:spUp .7s .55s both}
@keyframes spUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
.sp-bar{width:120px;height:3px;border-radius:2px;background:rgba(var(--fg),.1);overflow:hidden;margin-top:16px;animation:spUp .5s .7s both}
.sp-bar i{display:block;height:100%;width:40%;background:var(--grad);border-radius:2px;animation:spRun 1.1s ease-in-out infinite!important}
@keyframes spRun{from{transform:translateX(170%)}to{transform:translateX(-270%)}}
.logo svg{margin:0}

/* ── players & accelerators ── */
.pstat{position:absolute;top:8px;right:8px;z-index:3;font-size:11px;font-weight:800;padding:4px 9px;border-radius:99px;background:rgba(0,0,0,.6);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);color:#fff;pointer-events:none;font-variant-numeric:tabular-nums}
.pstat:empty{display:none}
.pstat b{color:var(--acc1)}
.exts.four{grid-template-columns:repeat(4,1fr)}
.engs .chip svg{width:14px;height:14px}
.card.np>.srow+.srow{border-top:1px solid var(--line)}
.chip svg.ic{width:15px;height:15px}

/* ── home: hero + rows ── */
.home{grid-column:1/-1;display:flex;flex-direction:column;gap:20px}
.hero2{position:relative;height:340px;border-radius:22px;overflow:hidden;background:var(--tile);box-shadow:0 18px 40px rgba(0,0,0,.45);animation:up .5s both}
.hero2 .hb{position:absolute;inset:0;background-size:cover;background-position:center 22%;transform:scale(1.05)}
.hero2::after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,0) 25%,rgba(0,0,0,.55) 62%,var(--bg) 100%)}
.hero2 .hc{position:absolute;left:0;right:0;bottom:0;z-index:2;padding:16px;display:flex;flex-direction:column;align-items:center;text-align:center;gap:7px}
.hero2 .hk{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:800;letter-spacing:.3px;color:#fff;background:rgba(var(--a1),.85);padding:4px 10px;border-radius:99px}
.hero2 .hk svg{width:13px;height:13px}
.hero2 h3{font-size:25px;font-weight:900;letter-spacing:-.4px;color:#fff;text-shadow:0 2px 14px rgba(0,0,0,.7);line-height:1.25}
.hero2 .hm{font-size:12px;color:rgba(255,255,255,.82)}
.hero2 .hbtns{display:flex;gap:10px;margin-top:6px}
.hero2 .hbtns .btn{height:44px;font-size:14.5px;padding:0 20px;border-radius:12px}
.hero2 .btn.w{background:#fff;color:#000}.hero2 .btn.w svg{fill:#000;stroke:#000}
.hero2 .btn.g{background:rgba(255,255,255,.22);color:#fff;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
.rowt{font-size:16.5px;font-weight:850;margin:0 2px 10px;display:flex;align-items:center;justify-content:space-between;gap:10px}
.rowt span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rowt button{flex:none;font-size:12px;color:var(--acc1);font-weight:800}
.rowx{display:flex;gap:10px;overflow-x:auto;scrollbar-width:none;scroll-snap-type:x proximity;padding-bottom:2px;margin:0 -14px;padding-left:14px;padding-right:14px}
.rowx::-webkit-scrollbar{display:none}
.rowx .pc{flex:none;width:112px;scroll-snap-align:start}
</style>
<style id="animCss"></style>
</head>
<body>
<div id="app">
  <header class="top">
    <button class="brand" id="hdr">
      <div class="logo" data-ic="brand"></div>
      <div class="bt"><b id="hName">السهرة ماك</b><small><i class="dot" id="hDot"></i><span id="hSub">—</span></small></div>
    </button>
    <button class="ibtn" id="hRefresh" data-ic="refresh" aria-label="تحديث"></button>
  </header>
  <main>
    <section class="view on" id="v-live">
      <div class="stick">
        <div class="search"><span data-ic="search"></span><input id="q-live" type="search" placeholder="ابحث باسم القناة أو رقمها" autocomplete="off" autocorrect="off" spellcheck="false"><button class="clr" data-clr="q-live">✕</button></div>
        <div class="chips" id="liveGenres"></div>
        <div class="count" id="liveCount"></div>
      </div>
      <div class="list" id="liveList"></div>
      <div class="more" id="liveMore"></div>
    </section>
    <section class="view" id="v-vod">
      <div class="stick">
        <div class="search"><span data-ic="search"></span><input id="q-vod" type="search" placeholder="ابحث عن فيلم" autocomplete="off" autocorrect="off" spellcheck="false"><button class="clr" data-clr="q-vod">✕</button></div>
        <div class="chips" id="cats-vod"></div>
      </div>
      <div class="grid" id="grid-vod"></div>
      <div class="more" id="more-vod"></div>
    </section>
    <section class="view" id="v-series">
      <div class="stick">
        <div class="search"><span data-ic="search"></span><input id="q-series" type="search" placeholder="ابحث عن مسلسل" autocomplete="off" autocorrect="off" spellcheck="false"><button class="clr" data-clr="q-series">✕</button></div>
        <div class="chips" id="cats-series"></div>
      </div>
      <div class="grid" id="grid-series"></div>
      <div class="more" id="more-series"></div>
    </section>
    <section class="view" id="v-matches">
      <div class="stick">
        <div class="chips" id="mDays" style="padding-top:2px"></div>
        <div class="mbar"><button class="mlive" id="mLive"><i></i>مباشر الآن<em id="mLiveN"></em></button><button class="mmaj on" id="mMajor">المهمة فقط</button><span class="mupd" id="mUpd"></span></div>
      </div>
      <div id="mList"></div>
    </section>
    <section class="view" id="v-yt">
      <div class="stick">
        <div class="search"><span data-ic="search"></span><input id="q-yt" type="search" placeholder="ابحث في يوتيوب أو الصق رابط فيديو" autocomplete="off" autocorrect="off" spellcheck="false"><button class="clr" data-clr="q-yt">✕</button></div>
        <div class="chips" id="ytChips"></div>
        <div class="ytnote"><span data-ic="shield"></span>بدون إعلانات — تُتخطى وتُخفى تلقائياً أثناء المشاهدة</div>
      </div>
      <div class="ytlist" id="ytList"></div>
    </section>
    <section class="view" id="v-favs">
      <div class="stick"><div class="seg" id="favSeg"><button data-v="itv" class="on">القنوات</button><button data-v="vod">الأفلام</button><button data-v="series">المسلسلات</button><button data-v="recent">مؤخراً</button></div></div>
      <div id="favBox"></div>
    </section>
    <section class="view" id="v-settings"><div id="setBox"></div></section>
  </main>
  <nav class="tabbar">
    <button class="tab on" data-tab="live"><span data-ic="tv"></span><span>مباشر</span></button>
    <button class="tab" data-tab="matches"><span data-ic="ball"></span><span>مباريات</span></button>
    <button class="tab" data-tab="vod"><span data-ic="film"></span><span>أفلام</span></button>
    <button class="tab" data-tab="series"><span data-ic="layers"></span><span>مسلسلات</span></button>
    <button class="tab" data-tab="yt"><span data-ic="ytb"></span><span>يوتيوب</span></button>
    <button class="tab" data-tab="favs"><span data-ic="star"></span><span>المفضلة</span></button>
    <button class="tab" data-tab="settings"><span data-ic="sliders"></span><span>الإعدادات</span></button>
  </nav>
</div>

<div id="sheet"><div class="sbg"></div><div class="spanel" id="spanel"></div></div>
<div id="portals" class="screen"></div>
<div id="splash" class="screen on"><div class="logo" data-ic="brand"></div><div class="sp-name">السهرة ماك</div><div class="sp-tag">سهرتك تبدأ هنا</div><div class="sp-bar"><i></i></div><div class="sp-st" id="spSt"></div></div>
<div id="modal"></div>
<div id="toast"></div>

<script>window.__BOOT = /*__BOOT__*/null;</script>
<script>window.__CACHE = /*__CACHE__*/null;</script>
<script>/* ───────── مشغل MKV: يحوّل ملفات MKV إلى MP4 مجزأ أثناء التحميل ويشغلها داخل الصفحة ─────────
   يعمل داخل صفحة مشغل السهرة (على عنوان خادم البث نفسه) بلا مكتبات خارجية.
   فيديو: H.264 / HEVC — صوت: AAC / AC-3 / E-AC-3 / MP3 — ترجمة: SRT / ASS — يفضّل الصوت والترجمة العربية. */
function alsahraMkvMain() {
  if (window.AlsahraMKV && window.AlsahraTS) return 1;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const te = s => { const o = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) o[i] = s.charCodeAt(i) & 255; return o; };
  const cat = a => { let n = 0; for (const x of a) n += x.length; const o = new Uint8Array(n); let p = 0; for (const x of a) { o.set(x, p); p += x.length; } return o; };
  const B = a => a instanceof Uint8Array ? a : new Uint8Array(a);
  const u16 = n => [(n >>> 8) & 255, n & 255];
  const u32 = n => [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
  const u64 = n => { const hi = Math.floor(n / 4294967296); return u32(hi).concat(u32(n - hi * 4294967296)); };
  const Z = n => new Uint8Array(n);
  function box(t, ...ps) {
    const parts = ps.map(B); let n = 8; for (const p of parts) n += p.length;
    const o = new Uint8Array(n); o.set(u32(n), 0); o.set(te(t), 4);
    let q = 8; for (const p of parts) { o.set(p, q); q += p.length; }
    return o;
  }
  const fbox = (t, v, f, ...ps) => box(t, [v, (f >>> 16) & 255, (f >>> 8) & 255, f & 255], ...ps);
  const MATRIX = [].concat(u32(0x10000), u32(0), u32(0), u32(0), u32(0x10000), u32(0), u32(0), u32(0), u32(0x40000000));

  /* ── MP4 ── */
  function initSeg(t) {
    const v = t.kind === "v";
    const mvhd = fbox("mvhd", 0, 0, u32(0), u32(0), u32(1000), u32(0), u32(0x10000), u16(0x100), Z(10), MATRIX, Z(24), u32(2));
    const tkhd = fbox("tkhd", 0, 3, u32(0), u32(0), u32(1), u32(0), u32(0), Z(8), u16(0), u16(0), u16(v ? 0 : 0x100), u16(0), MATRIX, u32((t.w || 0) * 65536), u32((t.h || 0) * 65536));
    const mdhd = fbox("mdhd", 0, 0, u32(0), u32(0), u32(t.ts), u32(0), u16(0x55c4), u16(0));
    const hdlr = fbox("hdlr", 0, 0, u32(0), te(v ? "vide" : "soun"), Z(12), te(v ? "VideoHandler" : "SoundHandler"), [0]);
    const mh = v ? fbox("vmhd", 0, 1, Z(8)) : fbox("smhd", 0, 0, Z(4));
    const dinf = box("dinf", fbox("dref", 0, 0, u32(1), fbox("url ", 0, 1)));
    const stbl = box("stbl", fbox("stsd", 0, 0, u32(1), t.entry), fbox("stts", 0, 0, u32(0)), fbox("stsc", 0, 0, u32(0)), fbox("stsz", 0, 0, u32(0), u32(0)), fbox("stco", 0, 0, u32(0)));
    const trak = box("trak", tkhd, box("mdia", mdhd, hdlr, box("minf", mh, dinf, stbl)));
    const mvex = box("mvex", fbox("trex", 0, 0, u32(1), u32(1), u32(0), u32(0), u32(0)));
    return cat([box("ftyp", te("isom"), u32(512), te("isom"), te("iso6"), te("mp41")), box("moov", mvhd, trak, mvex)]);
  }
  function frag(seq, base, smp) {
    const n = smp.length, trunSize = 20 + n * 16, moofSize = 8 + 16 + 8 + 16 + 20 + trunSize;
    const tr = new Uint8Array(n * 16), dv = new DataView(tr.buffer);
    let total = 0;
    for (let i = 0; i < n; i++) {
      const s = smp[i];
      dv.setUint32(i * 16, s.dur >>> 0); dv.setUint32(i * 16 + 4, s.data.length); dv.setUint32(i * 16 + 8, s.flags); dv.setInt32(i * 16 + 12, s.cts | 0);
      total += s.data.length;
    }
    const moof = box("moof", fbox("mfhd", 0, 0, u32(seq)), box("traf", fbox("tfhd", 0, 0x20000, u32(1)), fbox("tfdt", 1, 0, u64(Math.max(0, base))), fbox("trun", 1, 0xF01, u32(n), u32(moofSize + 8), tr)));
    const out = new Uint8Array(moof.length + 8 + total);
    out.set(moof, 0); out.set(u32(8 + total), moof.length); out.set(te("mdat"), moof.length + 4);
    let q = moof.length + 8;
    for (const s of smp) { out.set(s.data, q); q += s.data.length; }
    return out;
  }
  const vEntry = (fc, w, h, cfg) => box(fc, Z(6), u16(1), Z(16), u16(w), u16(h), u32(0x480000), u32(0x480000), u32(0), u16(1), Z(32), u16(0x18), u16(0xffff), cfg);
  const aEntry = (fc, ch, sr, cfg) => box(fc, Z(6), u16(1), Z(8), u16(ch), u16(16), u16(0), u16(0), u32(sr < 65536 ? sr * 65536 : 0), cfg);
  function desc(tag, body) { const n = body.length; return cat([new Uint8Array([tag, 0x80 | ((n >> 21) & 0x7f), 0x80 | ((n >> 14) & 0x7f), 0x80 | ((n >> 7) & 0x7f), n & 0x7f]), body]); }
  function esds(oti, dsi) {
    const dcd = desc(4, cat([new Uint8Array([oti, 0x15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]), dsi ? desc(5, dsi) : Z(0)]));
    return fbox("esds", 0, 0, desc(3, cat([new Uint8Array([0, 1, 0]), dcd, desc(6, new Uint8Array([2]))])));
  }
  const SRS = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
  function asc(aot, sr, ch) { let i = SRS.indexOf(sr); if (i < 0) i = 3; return new Uint8Array([(aot << 3) | (i >> 1), ((i & 1) << 7) | ((ch & 15) << 3)]); }
  function bits(f, start) { let bit = start; return n => { let v = 0; for (let i = 0; i < n; i++, bit++) v = (v * 2) + ((f[bit >> 3] >> (7 - (bit & 7))) & 1); return v; }; }
  function wbits(list) { // [[value, nbits], ...] → bytes
    const out = []; let cur = 0, nb = 0;
    for (const [v, n] of list) for (let i = n - 1; i >= 0; i--) { cur = (cur << 1) | ((v >> i) & 1); if (++nb === 8) { out.push(cur); cur = 0; nb = 0; } }
    if (nb) out.push(cur << (8 - nb));
    return out;
  }
  const chMode = ch => ch >= 6 ? [7, 1] : ch === 5 ? [7, 0] : ch === 4 ? [6, 0] : ch === 3 ? [3, 0] : ch === 1 ? [1, 0] : [2, 0];
  const fsc = sr => sr === 44100 ? 1 : sr === 32000 ? 2 : 0;
  function dac3(f, sr, ch) {
    if (f && f.length > 8 && f[0] === 0x0B && f[1] === 0x77) {
      const fscod = f[4] >> 6, frm = f[4] & 0x3f, bsid = f[5] >> 3, bsmod = f[5] & 7, rb = bits(f, 48);
      const acmod = rb(3);
      if ((acmod & 1) && acmod !== 1) rb(2);
      if (acmod & 4) rb(2);
      if (acmod === 2) rb(2);
      return box("dac3", wbits([[fscod, 2], [bsid, 5], [bsmod, 3], [acmod, 3], [rb(1), 1], [frm >> 1, 5], [0, 5]]));
    }
    const m = chMode(ch);
    return box("dac3", wbits([[fsc(sr), 2], [8, 5], [0, 3], [m[0], 3], [m[1], 1], [15, 5], [0, 5]]));
  }
  function dec3(f, sr, ch) {
    let fscod = fsc(sr), acmod = chMode(ch)[0], lfe = chMode(ch)[1], rate = 640, nb = 6;
    if (f && f.length > 8 && f[0] === 0x0B && f[1] === 0x77) {
      const rb = bits(f, 16);
      rb(2); rb(3); const frmsiz = rb(11); fscod = rb(2);
      let s = 48000, nbc = 3;
      if (fscod === 3) { s = [24000, 22050, 16000][rb(2)] || 24000; } else { nbc = rb(2); s = [48000, 44100, 32000][fscod]; }
      acmod = rb(3); lfe = rb(1);
      nb = [1, 2, 3, 6][nbc];
      rate = Math.round(((frmsiz + 1) * 16 * s) / (nb * 256) / 1000) || 640;
    }
    return { box: box("dec3", wbits([[rate, 13], [0, 3], [fscod, 2], [16, 5], [0, 1], [0, 1], [0, 3], [acmod, 3], [lfe, 1], [0, 3], [0, 4], [0, 1]])), fs: nb * 256 };
  }
  function hevcStr(c) {
    const sp = c[1] >> 6, tier = (c[1] >> 5) & 1, prof = c[1] & 31;
    let comp = ((c[2] << 24) | (c[3] << 16) | (c[4] << 8) | c[5]) >>> 0, rev = 0;
    for (let i = 0; i < 32; i++) { rev = ((rev << 1) | (comp & 1)) >>> 0; comp >>>= 1; }
    const cons = [c[6], c[7], c[8], c[9], c[10], c[11]];
    while (cons.length && !cons[cons.length - 1]) cons.pop();
    return ["", "A", "B", "C"][sp] + prof + "." + rev.toString(16) + "." + (tier ? "H" : "L") + c[12] + cons.map(b => "." + b.toString(16)).join("");
  }
  const hx = x => (x < 16 ? "0" : "") + x.toString(16);

  /* ── EBML ── */
  const vlen = b => b & 0x80 ? 1 : b & 0x40 ? 2 : b & 0x20 ? 3 : b & 0x10 ? 4 : b & 0x08 ? 5 : b & 0x04 ? 6 : b & 0x02 ? 7 : b & 0x01 ? 8 : 0;
  function hdr(d, p, end) {
    if (p >= end) return null;
    const il = vlen(d[p]); if (!il || il > 4) return { bad: 1 };
    if (p + il >= end) return null;
    const sl = vlen(d[p + il]); if (!sl) return { bad: 1 };
    if (p + il + sl > end) return null;
    let id = 0; for (let i = 0; i < il; i++) id = id * 256 + d[p + i];
    let sz = d[p + il] & (0xff >> sl), all = sz === (0xff >> sl);
    for (let i = 1; i < sl; i++) { const b = d[p + il + i]; sz = sz * 256 + b; if (b !== 255) all = false; }
    return { id, size: all ? -1 : sz, hl: il + sl };
  }
  function each(d, fn) { let p = 0; while (p < d.length) { const h = hdr(d, p, d.length); if (!h || h.bad || h.size < 0) break; const s = p + h.hl, e = Math.min(d.length, s + h.size); fn(h.id, d.subarray(s, e)); p = e; } }
  const uint = d => { let n = 0; for (let i = 0; i < d.length; i++) n = n * 256 + d[i]; return n; };
  const flt = d => { const dv = new DataView(d.buffer, d.byteOffset, d.length); return d.length === 4 ? dv.getFloat32(0) : d.length === 8 ? dv.getFloat64(0) : 0; };
  const str = d => { let s = ""; for (let i = 0; i < d.length && d[i]; i++) s += String.fromCharCode(d[i]); return s; };
  const utf8 = d => { try { return new TextDecoder("utf-8").decode(d); } catch (e) { return str(d); } };
  function parseTracks(d) {
    const out = [];
    each(d, (id, e) => {
      if (id !== 0xAE) return;
      const t = { num: 0, type: 0, codec: "", priv: null, lang: "eng", ietf: "", def: 1, forced: 0, name: "", w: 0, h: 0, sr: 0, ch: 2, strip: null, enc: false };
      each(e, (k, v) => {
        if (k === 0xD7) t.num = uint(v);
        else if (k === 0x83) t.type = uint(v);
        else if (k === 0x86) t.codec = str(v);
        else if (k === 0x63A2) t.priv = v.slice();
        else if (k === 0x22B59C) t.lang = str(v);
        else if (k === 0x22B59D) t.ietf = str(v);
        else if (k === 0x536E) t.name = utf8(v);
        else if (k === 0x88) t.def = uint(v);
        else if (k === 0x55AA) t.forced = uint(v);
        else if (k === 0xE0) each(v, (a, b) => { if (a === 0xB0) t.w = uint(b); else if (a === 0xBA) t.h = uint(b); });
        else if (k === 0xE1) each(v, (a, b) => { if (a === 0xB5) t.sr = flt(b); else if (a === 0x9F) t.ch = uint(b); });
        else if (k === 0x6D80) each(v, (a, b) => {
          if (a !== 0x6240) return;
          each(b, (c, x) => {
            if (c === 0x5034) { let algo = 0, set = null; each(x, (q, y) => { if (q === 0x4254) algo = uint(y); else if (q === 0x4255) set = y.slice(); }); if (algo === 3 && set) t.strip = set; else t.enc = true; }
            else if (c === 0x5035) t.enc = true;
          });
        });
      });
      out.push(t);
    });
    return out;
  }
  function parseBlock(d) {
    const tl = vlen(d[0]); if (!tl || d.length < tl + 3) return null;
    let track = d[0] & (0xff >> tl); for (let i = 1; i < tl; i++) track = track * 256 + d[i];
    let q = tl;
    const rel = ((d[q] << 8) | d[q + 1]) << 16 >> 16; q += 2;
    const flags = d[q++], lace = (flags >> 1) & 3;
    const frames = [];
    if (!lace) frames.push(d.subarray(q));
    else {
      const n = d[q++] + 1, sizes = [];
      if (lace === 1) { for (let i = 0; i < n - 1; i++) { let s = 0, b; do { b = d[q++]; s += b; } while (b === 255 && q < d.length); sizes.push(s); } }
      else if (lace === 3) {
        let l = vlen(d[q]), s = d[q] & (0xff >> l); for (let i = 1; i < l; i++) s = s * 256 + d[q + i]; q += l; sizes.push(s);
        for (let i = 1; i < n - 1; i++) { l = vlen(d[q]); let v = d[q] & (0xff >> l); for (let j = 1; j < l; j++) v = v * 256 + d[q + j]; q += l; s += v - (Math.pow(2, 7 * l - 1) - 1); sizes.push(s); }
      } else { const e = Math.floor((d.length - q) / n); for (let i = 0; i < n - 1; i++) sizes.push(e); }
      let used = 0; for (const s of sizes) used += s;
      sizes.push(d.length - q - used);
      for (const s of sizes) { if (s < 0 || q + s > d.length) return null; frames.push(d.subarray(q, q + s)); q += s; }
    }
    return { track, rel, key: !!(flags & 0x80), frames };
  }
  function parseCues(d, seg, scale) {
    const out = [];
    each(d, (k, v) => {
      if (k !== 0xBB) return;
      let t = -1, pos = -1;
      each(v, (a, b) => { if (a === 0xB3) t = uint(b); else if (a === 0xB7 && pos < 0) each(b, (c, x) => { if (c === 0xF1) pos = uint(x); }); });
      if (t >= 0 && pos >= 0) out.push({ t: t * scale / 1e6, pos: seg + pos });
    });
    out.sort((a, b) => a.t - b.t);
    return out;
  }
  // قارئ متدفق: يستقبل أجزاء الملف ويستخرج المسارات والإطارات
  function Demux(cb) {
    let buf = new Uint8Array(0), p = 0, abs = 0, skip = 0, resync = false, ctime = 0;
    const D = { scale: 1e6, seg: 0, segSize: -1 };
    D.reset = (at, rs) => { buf = new Uint8Array(0); p = 0; abs = at; skip = 0; resync = !!rs; };
    D.push = chunk => {
      const rest = buf.length - p;
      if (rest <= 0) { abs += buf.length; buf = chunk; }
      else { const n = new Uint8Array(rest + chunk.length); n.set(buf.subarray(p)); n.set(chunk, rest); abs += p; buf = n; }
      p = 0;
      parse();
    };
    function parse() {
      for (;;) {
        if (skip) { const k = Math.min(skip, buf.length - p); p += k; skip -= k; if (skip) return; }
        if (resync) {
          let i = p, found = -1, wait = false;
          for (; i + 4 <= buf.length; i++) {
            if (buf[i] !== 0x1F || buf[i + 1] !== 0x43 || buf[i + 2] !== 0xB6 || buf[i + 3] !== 0x75) continue;
            const h = hdr(buf, i, buf.length);
            if (!h || i + h.hl >= buf.length) { wait = true; break; }
            const c = buf[i + h.hl];
            if (!h.bad && (c === 0xE7 || c === 0xBF || c === 0xA7 || c === 0xAB)) { found = i; break; }
          }
          if (found < 0) { p = wait ? i : Math.max(p, buf.length - 3); return; }
          p = found; resync = false;
        }
        const h = hdr(buf, p, buf.length);
        if (!h) return;
        if (h.bad) { resync = true; p++; continue; }
        const id = h.id, start = p + h.hl, size = h.size, at = abs + p;
        if (id === 0x18538067) { D.seg = abs + start; D.segSize = size; p = start; continue; }
        if (id === 0x1F43B675) { p = start; cb.cluster(at); continue; }
        if (id === 0xE7 || id === 0xA3 || id === 0xA0 || id === 0x1549A966 || id === 0x1654AE6B || id === 0x114D9B74 || id === 0x1C53BB6B) {
          if (size < 0) { resync = true; p = start; continue; }
          if (size > 48 * 1048576) { skip = size; p = start; continue; }
          if (buf.length - start < size) return;
          const d = buf.subarray(start, start + size);
          p = start + size;
          handle(id, d);
          continue;
        }
        if (size < 0) { p = start; continue; }
        skip = size; p = start;
      }
    }
    function handle(id, d) {
      if (id === 0xE7) ctime = uint(d);
      else if (id === 0xA3) { const b = parseBlock(d); if (b) cb.block(b, (ctime + b.rel) * D.scale / 1e6, 0, b.key); }
      else if (id === 0xA0) {
        let blk = null, dur = 0, ref = false;
        each(d, (k, v) => { if (k === 0xA1) blk = v; else if (k === 0x9B) dur = uint(v); else if (k === 0xFB) ref = true; });
        if (blk) { const b = parseBlock(blk); if (b) cb.block(b, (ctime + b.rel) * D.scale / 1e6, dur * D.scale / 1e6, !ref); }
      }
      else if (id === 0x1549A966) { let dur = 0; each(d, (k, v) => { if (k === 0x2AD7B1) D.scale = uint(v) || 1e6; else if (k === 0x4489) dur = flt(v); }); cb.info(dur * D.scale / 1e6); }
      else if (id === 0x1654AE6B) cb.tracks(parseTracks(d));
      else if (id === 0x114D9B74) each(d, (k, v) => { if (k !== 0x4DBB) return; let sid = 0, pos = -1; each(v, (a, b) => { if (a === 0x53AB) sid = uint(b); else if (a === 0x53AC) pos = uint(b); }); if (sid === 0x1C53BB6B && pos >= 0) cb.cuesAt(D.seg + pos); });
      else if (id === 0x1C53BB6B) cb.cues(parseCues(d, D.seg, D.scale));
    }
    return D;
  }

  const isAr = t => /^(ara|ar)$/i.test(t.lang || "") || /^ar(\\b|-)/i.test(t.ietf || "") || /arab|عرب/i.test(t.name || "");
  function videoSetup(t) {
    const p = t.priv;
    if (/^V_MPEG4\\/ISO\\/AVC/.test(t.codec) && p && p.length > 6) return { codec: "avc1." + hx(p[1]) + hx(p[2]) + hx(p[3]), name: "H.264", entry: vEntry("avc1", t.w, t.h, box("avcC", p)) };
    if (/^V_MPEGH\\/ISO\\/HEVC/.test(t.codec) && p && p.length > 22) { const fc = p[22] ? "hvc1" : "hev1"; return { codec: fc + "." + hevcStr(p), name: "HEVC", entry: vEntry(fc, t.w, t.h, box("hvcC", p)) }; }
    return null;
  }
  function audioSetup(t) {
    const c = t.codec, sr = Math.round(t.sr || 48000), ch = t.ch || 2;
    if (/^A_AAC/.test(c)) {
      let a = t.priv && t.priv.length >= 2 ? t.priv : null;
      if (!a) a = asc(/MAIN/.test(c) ? 1 : /SSR/.test(c) ? 3 : /LTP/.test(c) ? 4 : 2, sr, ch);
      const aot = a[0] >> 3;
      return { codec: "mp4a.40." + (aot === 31 || !aot ? 2 : aot), name: "AAC", fs: 1024, sr, ch, aac: true, entry: () => aEntry("mp4a", ch, sr, esds(0x40, a)) };
    }
    if (c === "A_AC3") return { codec: "ac-3", name: "AC-3", fs: 1536, sr, ch, frame: true, entry: f => aEntry("ac-3", ch, sr, dac3(f, sr, ch)) };
    if (c === "A_EAC3") { const A = { codec: "ec-3", name: "E-AC-3", fs: 1536, sr, ch, frame: true }; A.entry = f => { const d = dec3(f, sr, ch); A.fs = d.fs; return aEntry("ec-3", ch, sr, d.box); }; return A; }
    if (c === "A_MPEG/L3") return { codec: "mp4a.6B", name: "MP3", fs: sr < 32000 ? 576 : 1152, sr, ch, entry: () => aEntry("mp4a", ch, sr, esds(0x6B, null)) };
    return null;
  }
  const NAMES = { A_DTS: "DTS", "A_TRUEHD": "TrueHD", A_FLAC: "FLAC", A_OPUS: "Opus", A_VORBIS: "Vorbis", "A_PCM/INT/LIT": "PCM", A_AC3: "AC-3", A_EAC3: "E-AC-3" };
  const LANGS = { ara: "العربية", ar: "العربية", eng: "English", en: "English", fre: "Français", fra: "Français", tur: "Türkçe", spa: "Español", ger: "Deutsch", deu: "Deutsch", hin: "हिन्दी", per: "فارسی", fas: "فارسی", urd: "اردو", ind: "Indonesia", und: "" };

  function start(v, url, o) {
    o = o || {};
    const MS = window.ManagedMediaSource || window.MediaSource;
    const mms = !!window.ManagedMediaSource && MS === window.ManagedMediaSource;
    const ctl = { info: { fmt: "MKV" }, subs: [], sub: -1, destroyed: false, log: [] };
    const L = m => { ctl.log.push(m); if (ctl.log.length > 30) ctl.log.shift(); };
    const fail = m => { if (ctl.destroyed || ctl.failed) return; ctl.failed = true; L("fail: " + m); stopAll(); o.onerror && o.onerror(m); };
    if (!MS) { setTimeout(() => fail("هذا الجهاز لا يدعم تشغيل MKV داخلياً (يحتاج iOS 17.1 أو أحدث)"), 0); return ctl; }
    const sup = m => { try { return MS.isTypeSupported(m); } catch (e) { return false; } };
    let ms = null, objUrl = "", msOpen = false, VT = null, AT = null, TT = {}, A = null, V = null;
    let tracks = null, duration = 0, total = 0, firstCluster = -1, cues = null, cuesAt = 0, cuesTried = false;
    let gen = 0, fetchCtl = null, started = false, eof = false, seekT = -1, seekByCue = false, seekTries = 0, seekPos = 0, seekWait = false, selfT = -1, selfUntil = 0, pend = [], pendBytes = 0;
    const setTime = t => { selfT = t; selfUntil = Date.now() + 1500; try { v.currentTime = t; } catch (e) {} };
    let vin = [], vsorted = [], vready = [], S = -1, vseq = 1, aseq = 1, ain = [], aNext = -1, lastDur = 3003, vFrags = 0, aInit = false, firstKeyMs = -1, lastKeyMs = -1, dropUntil = -1, hevc = false, rB = 0, rT = 0;
    const R = 16;
    const subKeys = new Set();

    function SBQ(kind) {
      const q = []; let sb = null, bytes = 0;
      const Q = {
        get bytes() { return bytes; }, get sb() { return sb; },
        attach(s) { sb = s; s.addEventListener("updateend", () => { Q.kick(); onUpdate(); }); s.addEventListener("error", () => fail("تعذّر فك " + (kind === "v" ? "الفيديو" : "الصوت"))); Q.kick(); },
        push(d, init) { q.push({ d, init }); bytes += d.length; Q.kick(); },
        remove(a, b) { if (b > a) { q.push({ rm: [a, b] }); Q.kick(); } },
        clear() { for (let i = q.length - 1; i >= 0; i--) if (q[i].d && !q[i].init) { bytes -= q[i].d.length; q.splice(i, 1); } },
        idle() { return !q.length && (!sb || !sb.updating); },
        kick() {
          if (!sb || ctl.destroyed || sb.updating || !q.length || !ms || ms.readyState === "closed") return;
          const op = q[0];
          try {
            if (op.rm) sb.remove(op.rm[0], op.rm[1]); else sb.appendBuffer(op.d);
            q.shift(); if (op.d) bytes -= op.d.length;
          } catch (e) {
            if (e.name === "QuotaExceededError") { evict(true); setTimeout(Q.kick, 500); }
            else if (op.rm) q.shift();
            else fail("خطأ في التشغيل: " + e.name);
          }
        }
      };
      return Q;
    }
    const vq = SBQ("v"), aq = SBQ("a");
    function buffered(sb) { try { return sb ? sb.buffered : null; } catch (e) { return null; } }
    function ahead() {
      const b = buffered(vq.sb); if (!b || !b.length) return 0;
      const t = v.currentTime;
      for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.6 && t <= b.end(i)) return b.end(i) - t;
      return 0;
    }
    ctl.ahead = () => ahead();
    function inBuf(t) { const b = buffered(vq.sb); if (!b) return false; for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.3 && t < b.end(i) - 0.2) return true; return false; }
    // معدل البيانات (بايت لكل ثانية) لتحديد حجم التخزين حسب جودة الفيلم (4K يحتاج حدوداً أصغر بالثواني)
    const rate = () => rT > 4 ? rB / rT : 0;
    const capSec = (bytes, lo, hi) => { const r = rate(); return r ? Math.max(lo, Math.min(hi, bytes / r)) : hi; };
    function evict(hard) {
      const t = v.currentTime, keep = hard ? 3 : capSec(mms ? 22e6 : 45e6, 5, 25);
      for (const Q of [vq, aq]) { const b = buffered(Q.sb); if (b && b.length && t - b.start(0) > keep + 2) Q.remove(b.start(0), t - keep); }
    }
    const MAXA = Math.round((+o.maxAhead || 75) * (mms ? 0.6 : 1));
    ctl.bytes = 0;
    ctl.trim = () => { try { evict(true); } catch (e) {} };   // تحذير ذاكرة من النظام: نفرّغ ما خلف موضع المشاهدة
    async function gate(g) {
      while (g === gen && !ctl.destroyed && !ctl.failed) {
        if (!V) { if (!tracks) return; await sleep(40); continue; }   // ننتظر تجهيز المشغل قبل قراءة المزيد
        const qb = vq.bytes + aq.bytes;
        if (!started) { if (qb < 24e6) return; }
        else if (qb < 8e6 && ahead() < capSec(mms ? 75e6 : 150e6, 10, MAXA) && !(mms && ms && ms.streaming === false && ahead() > 8)) return;
        await sleep(300);
      }
    }
    function stopAll() {
      gen++;
      try { fetchCtl && fetchCtl.abort(); } catch (e) {}
      clearInterval(ctl.evT); clearInterval(ctl.gapT);
    }
    ctl.destroy = () => {
      if (ctl.destroyed) return;
      stopAll(); ctl.destroyed = true;
      v.removeEventListener("seeking", onSeeking);
      try { v.removeAttribute("src"); v.load(); } catch (e) {}
      try { objUrl && URL.revokeObjectURL(objUrl); } catch (e) {}
      for (const s of ctl.subs) { try { s.track.mode = "disabled"; } catch (e) {} }
    };
    ctl.setSub = i => {
      ctl.sub = i;
      ctl.subs.forEach((s, k) => { try { s.track.mode = k === i ? "showing" : "disabled"; } catch (e) {} });
    };

    // ── الإعداد بعد قراءة المسارات
    function setup() {
      if (!tracks || !msOpen || V || ctl.failed) return;
      if (ms.readyState !== "open") { msOpen = false; ms.addEventListener("sourceopen", () => { msOpen = true; setup(); }, { once: true }); return; }
      const vids = tracks.filter(t => t.type === 1);
      VT = vids.find(t => !t.enc && videoSetup(t));
      if (!VT) {
        const c = vids[0] ? vids[0].codec.replace(/^V_/, "").replace(/\\/.*$/, "") : "";
        return fail(vids.length ? "صيغة الفيديو (" + c + ") غير مدعومة داخلياً — افتحه في VLC" : "لا يوجد فيديو في هذا الملف");
      }
      V = videoSetup(VT); hevc = V.name === "HEVC";
      if (!sup('video/mp4; codecs="' + V.codec + '"')) return fail("هذا الجهاز لا يدعم فيديو " + V.name + " (" + V.codec + ") — افتحه في VLC");
      const auds = tracks.filter(t => t.type === 2);
      const cands = auds.map((t, i) => ({ t, i, a: !t.enc && audioSetup(t) })).filter(x => x.a && x.a.codec !== o.noAudio && sup('audio/mp4; codecs="' + x.a.codec + '"'));
      const arW = o.audioPref === "orig" ? 0 : 4;
      cands.sort((x, y) => ((isAr(y.t) ? arW : 0) + (y.t.def ? 2 : 0) - y.i * 0.01) - ((isAr(x.t) ? arW : 0) + (x.t.def ? 2 : 0) - x.i * 0.01));
      if (cands.length) { AT = cands[0].t; A = cands[0].a; ctl.aCodec = A.codec; }
      else if (auds.length && o.noAudio) ctl.info.note = "تعذّر فك صوت هذا الملف داخلياً فشُغّل بدون صوت — للصوت افتحه في VLC";
      else if (auds.length) ctl.info.note = "صوت " + (NAMES[auds[0].codec] || auds[0].codec.replace(/^A_/, "")) + " غير مدعوم داخلياً — للصوت افتحه في VLC";
      try {
        vq.attach(ms.addSourceBuffer('video/mp4; codecs="' + V.codec + '"'));
        if (A) aq.attach(ms.addSourceBuffer('audio/mp4; codecs="' + A.codec + '"'));
      } catch (e) { return fail("تعذّر تجهيز المشغل: " + (e.message || e.name)); }
      if (duration > 0) { try { ms.duration = duration / 1000; } catch (e) {} }
      vq.push(initSeg({ kind: "v", ts: 90000, w: VT.w, h: VT.h, entry: V.entry }), true);
      if (A && !A.frame) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry() }), true); aInit = true; }
      // الترجمة
      tracks.filter(t => t.type === 17 && /^S_TEXT\\/(UTF8|ASS|SSA|WEBVTT)/.test(t.codec)).slice(0, 8).forEach(t => {
        try {
          const label = (t.name || LANGS[(t.lang || "").toLowerCase()] || t.lang || "ترجمة").slice(0, 24);
          const tt = v.addTextTrack("subtitles", label, t.ietf || t.lang || "");
          tt.mode = "disabled";
          TT[t.num] = { t, track: tt, ass: /ASS|SSA/.test(t.codec), idx: ctl.subs.length };
          ctl.subs.push({ label, lang: t.lang, ar: isAr(t), track: tt });
        } catch (e) {}
      });
      const ar = ctl.subs.findIndex(s => s.ar);
      if (ar >= 0) ctl.setSub(ar);
      ctl.info = Object.assign(ctl.info, { v: V.name, res: VT.w && VT.h ? VT.w + "×" + VT.h : "", a: A ? A.name + (AT.lang && AT.lang !== "und" ? " · " + (LANGS[AT.lang] || AT.lang) : "") : "", audios: auds.length });
      L("tracks: " + V.codec + " " + (A ? A.codec + " " + AT.lang : "no-audio") + " subs=" + ctl.subs.length);
      o.onstatus && o.onstatus(ctl.info);
      ctl.evT = setInterval(() => { if (!ctl.destroyed) evict(false); }, 4000);
      ctl.gapT = setInterval(gapJump, 500);
      const P0 = pend; pend = []; pendBytes = 0;
      if (o.start > 5 && !ctl.didStart) { ctl.didStart = true; doSeek(o.start); return; }
      for (const x of P0) { if (ctl.failed || gen !== x[4]) break; route(x[0], x[1], x[2], x[3]); }
    }

    // ── الفيديو: ترتيب أزمنة الفك (DTS) من أزمنة العرض، ثم مقاطع MP4
    function onVideo(ms_, data, key) {
      if (firstKeyMs < 0) { if (!key) return; firstKeyMs = lastKeyMs = ms_; if (landed(ms_)) return; }
      else if (key) lastKeyMs = ms_;
      else if (ms_ < lastKeyMs) {
        // HEVC (x265 open-GOP): إطارات RASL بعد إطار CRA تعتمد على ما قبله. عند البدء أو بعد القفز
        // لا يملك المفكّك ما قبله → نحذفها (لا تُعرض قبل موضع البدء أصلاً، والمعيار يمنع اعتماد غيرها عليها)
        ctl.openGop = true;
        if (hevc && (lastKeyMs === firstKeyMs || ms_ < dropUntil)) { ctl.lead = (ctl.lead || 0) + 1; return; }
      }
      if (VT.strip) data = cat([VT.strip, data]);
      const pts = Math.round(ms_ * 90);
      vin.push({ pts, data, key });
      let lo = 0, hi = vsorted.length; while (lo < hi) { const m = (lo + hi) >> 1; if (vsorted[m] < pts) lo = m + 1; else hi = m; } vsorted.splice(lo, 0, pts);
      while (vin.length > R) { const f = vin.shift(); f.dts = vsorted.shift(); vready.push(f); }
      flushVideo(false);
    }
    function flushVideo(force) {
      if (force) while (vin.length) { const f = vin.shift(); f.dts = vsorted.shift(); vready.push(f); }
      let k = -1;
      for (let i = vready.length - 1; i > 0; i--) if (vready[i].key) { k = i; break; }
      if (k < 0 && vready.length > 2 && vready[vready.length - 1].dts - vready[0].dts > 3 * 90000) k = vready.length - 1;
      if (force && vready.length) k = vready.length;
      if (k <= 0) return;
      const out = vready.splice(0, k), next = vready[0];
      if (S < 0) {
        S = 0; for (const f of out.concat(vready)) S = Math.max(S, f.dts - f.pts);
        const ds = out.concat(vready).map(f => f.dts).sort((a, b) => a - b), dd = [];
        for (let i = 1; i < ds.length; i++) if (ds[i] > ds[i - 1]) dd.push(ds[i] - ds[i - 1]);
        dd.sort((a, b) => a - b);
        S += 2 * (dd[dd.length >> 1] || 3750);   // هامش لإعادة الترتيب الأعمق في المشاهد اللاحقة
      }
      const smp = out.map((f, i) => {
        const nd = i + 1 < out.length ? out[i + 1].dts : next ? next.dts : f.dts + lastDur;
        const dur = Math.max(1, nd - f.dts); lastDur = dur;
        const c = f.pts + S - f.dts; if (c < 0) ctl.clamp = (ctl.clamp || 0) + 1;
        return { data: f.data, dur, flags: f.key ? 0x02000000 : 0x01010000, cts: Math.max(0, c) };
      });
      const fr = frag(vseq++, out[0].dts, smp);
      rB += fr.length; rT += smp.reduce((a, x) => a + x.dur, 0) / 90000;
      vq.push(fr);
      vFrags++;
      if (A && !aInit && vFrags >= 2) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry(null) }), true); aInit = true; }
      flushAudio(force);
    }
    // ── الصوت
    function onAudio(ms_, frames) {
      if (firstKeyMs < 0 && ain.length > 400) ain.shift();
      for (let j = 0; j < frames.length; j++) {
        let f = frames[j];
        if (AT.strip) f = cat([AT.strip, f]);
        if (A.aac && f.length > 7 && f[0] === 0xFF && (f[1] & 0xF6) === 0xF0) f = f.subarray((f[1] & 1) ? 7 : 9);
        if (A.frame && !aInit) { aq.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry(f) }), true); aInit = true; }
        ain.push({ t: ms_ * A.sr / 1000 + j * A.fs, data: f });
      }
      if (ain.length && (ain[ain.length - 1].t - ain[0].t) > A.sr * 2 && S >= 0) flushAudio(false);
    }
    function flushAudio() {
      if (!A || !aInit || S < 0 || !ain.length) return;
      if (firstKeyMs >= 0) { const lim = (firstKeyMs - 40) * A.sr / 1000; while (ain.length && ain[0].t < lim) ain.shift(); if (!ain.length) return; }
      let base = Math.round(ain[0].t + S * A.sr / 90000);
      if (aNext >= 0 && Math.abs(base - aNext) < A.fs * 1.5) base = aNext;
      const smp = ain.map(f => ({ data: f.data, dur: A.fs, flags: 0x02000000, cts: 0 }));
      aNext = base + smp.length * A.fs;
      const fa = frag(aseq++, base, smp); rB += fa.length;
      aq.push(fa);
      ain = [];
    }
    // ── الترجمة
    function onSub(t, ms_, dur, frames) {
      const T = TT[t.num]; if (!T) return;
      const key = t.num + ":" + Math.round(ms_);
      if (subKeys.has(key)) return; subKeys.add(key);
      let txt = utf8(frames[0] || new Uint8Array(0));
      if (T.ass) { const parts = txt.split(","); txt = parts.length > 8 ? parts.slice(8).join(",") : txt; txt = txt.replace(/\\{[^}]*\\}/g, ""); }
      txt = txt.replace(/\\\\N/gi, "\\n").replace(/<[^>]+>/g, "").trim();
      if (!txt) return;
      const st = ms_ / 1000 + Math.max(0, S) / 90000, en = st + Math.max(0.6, (dur || 3500) / 1000);
      try { const C = window.VTTCue || window.TextTrackCue, cue = new C(st, en, txt); try { cue.snapToLines = true; cue.line = o.subLine != null ? o.subLine : -1; } catch (e) {} T.track.addCue(cue); } catch (e) {}
      o.onsub && o.onsub(T.idx, st, en, txt);
    }
    // ── بعد القفز: التأكد أننا وصلنا قرب الوقت المطلوب وإلا نصحّح الموضع
    function landed(ms_) {
      if (seekT < 0) return false;
      const diff = ms_ - seekT * 1000, span = ((dmx.segSize > 0 ? dmx.seg + dmx.segSize : total) || 0) - Math.max(0, firstCluster);
      if (!seekByCue && seekTries < 4 && duration > 0 && span > 0 && (diff > 2500 || diff < -25000)) {
        seekTries++;
        const shift = Math.floor(span * ((diff > 0 ? diff + 5000 : diff + 8000) / duration));
        const np = Math.max(Math.max(0, firstCluster), Math.min(seekPos - shift, (total || seekPos) - 65536));
        L("seek refine " + Math.round(diff / 1000) + "s → " + np);
        restartAt(np, true);
        return true;
      }
      const st = ms_ / 1000 + Math.max(0, S) / 90000, want = Math.max(st + 0.03, seekT);
      if (v.currentTime < want - 0.05 || v.currentTime > want + 4) setTime(want);
      seekT = -1; seekWait = false;
      return false;
    }
    const dmx = Demux({
      cluster(at) { if (firstCluster < 0) firstCluster = at; },
      info(d) { duration = d; },
      tracks(t) { if (!tracks) { tracks = t; setup(); } },
      cuesAt(p) { if (!cuesAt) cuesAt = p; },
      cues(c) { if (!cues && c.length) cues = c; },
      block(b, ms_, dur, key) {
        if (ctl.failed) return;
        // قبل جاهزية المشغل نحتفظ بكل الإطارات (مراجع لنفس البيانات، بلا نسخ) حتى لا تضيع ثوانٍ من الفيلم
        if (!V) { if (pendBytes < 96 * 1048576) { pend.push([b, ms_, dur, key, gen]); for (const f of b.frames) pendBytes += f.length; } return; }
        if (seekWait && seekT < 0) return;
        route(b, ms_, dur, key);
      }
    });
    function route(b, ms_, dur, key) {
      if (b.track === VT.num) onVideo(ms_, b.frames[0], key);
      else if (AT && b.track === AT.num) onAudio(ms_, b.frames);
      else if (TT[b.track]) onSub(TT[b.track].t, ms_, dur, b.frames);
    }

    function resetPipes() {
      vin = []; vsorted = []; vready = []; ain = []; aNext = -1; firstKeyMs = -1; lastKeyMs = -1; eof = false;
      vq.clear(); aq.clear();
    }
    function restartAt(pos, rs) {
      stopAllFetch();
      resetPipes();
      vq.remove(0, Infinity); if (A) aq.remove(0, Infinity);
      seekPos = pos;
      dmx.reset(pos, rs);
      const g = ++gen;
      pump(pos, g);
    }
    function stopAllFetch() { try { fetchCtl && fetchCtl.abort(); } catch (e) {} }
    async function loadCues(g) {
      try {
        const end = total ? Math.min(total - 1, cuesAt + 4 * 1048576 - 1) : cuesAt + 4 * 1048576 - 1;
        const r = await fetch(url, { headers: { Range: "bytes=" + cuesAt + "-" + end }, cache: "no-store" });
        if (g !== gen || r.status !== 206) return;
        const d = new Uint8Array(await r.arrayBuffer());
        const h = hdr(d, 0, d.length);
        if (h && !h.bad && h.id === 0x1C53BB6B && h.size > 0 && h.hl + h.size <= d.length) { const c = parseCues(d.subarray(h.hl, h.hl + h.size), dmx.seg, dmx.scale); if (c.length) cues = c; }
        L("cues: " + (cues ? cues.length : 0));
      } catch (e) { L("cues failed"); }
    }
    async function doSeek(t) {
      if (ctl.destroyed || ctl.failed || !V) return;
      const g = ++gen;
      stopAllFetch();
      seekWait = true; seekPend = false; seekT = -1; ctl.seeked = true;
      if (!cues && cuesAt && !cuesTried) { cuesTried = true; await sleep(150); await loadCues(g); if (g !== gen) return; }
      seekT = t; seekTries = 0; dropUntil = t * 1000;
      let pos;
      if (cues && cues.length) { let i = 0; while (i + 1 < cues.length && cues[i + 1].t <= t * 1000 + 300) i++; pos = cues[Math.max(0, i - (t * 1000 - cues[i].t < 1500 ? 1 : 0))].pos; seekByCue = true; }
      else {
        seekByCue = false;
        const fc = Math.max(0, firstCluster), endB = (dmx.segSize > 0 ? dmx.seg + dmx.segSize : total) || 0;
        pos = duration > 0 && endB > fc ? Math.max(fc, Math.floor(fc + (endB - fc) * (t * 1000 / duration) - 262144)) : fc;
      }
      L("seek " + Math.round(t) + "s → " + pos + (seekByCue ? " (cue)" : ""));
      restartAt(pos, true);
    }
    let seekTimer = 0, seekPend = false;
    function onSeeking() {
      if (ctl.destroyed || !V) return;
      if (Date.now() < selfUntil && Math.abs(v.currentTime - selfT) < 0.6) return;
      if (inBuf(v.currentTime)) return;
      seekPend = true;
      clearTimeout(seekTimer);
      seekTimer = setTimeout(() => { if (!inBuf(v.currentTime)) doSeek(v.currentTime); else seekPend = false; }, 280);
    }
    // قفز الفجوات الصغيرة (مثلاً عندما يبدأ الصوت بعد الصورة بجزء من الثانية بعد القفز)
    function gapJump() {
      if (ctl.destroyed || v.readyState >= 3 || seekWait || seekPend || (!started && !ctl.seeked)) return;
      let b; try { b = v.buffered; } catch (e) { return; }
      const t = v.currentTime;
      for (let i = 0; i < b.length; i++) {
        const s0 = b.start(i), e0 = b.end(i);
        if (t >= s0 - 0.01 && t < e0) return;
        if (s0 > t && s0 - t < 3.5) { setTime(s0 + 0.05); L("gap → " + s0.toFixed(2)); return; }
      }
    }
    function onUpdate() {
      if (ctl.destroyed) return;
      gapJump();
      const b = buffered(vq.sb);
      if (!started && !seekWait && b && b.length && (!A || (buffered(aq.sb) || { length: 0 }).length || vFrags > 3)) {
        started = true;
        if (!ctl.seeked && v.currentTime < b.start(0) - 0.05) setTime(b.start(0) + 0.02);
        L("ready " + b.start(0).toFixed(2));
        o.onready && o.onready(ctl.info);
      }
      if (eof && V && vFrags > 0 && vq.sb && vq.idle() && aq.idle() && ms.readyState === "open") { try { ms.endOfStream(); } catch (e) {} }
    }

    async function pump(from, g) {
      let tries = 0, discard = 0;
      while (g === gen && !ctl.destroyed) {
        const ac = new AbortController(); fetchCtl = ac;
        let res;
        try { res = await (window.__fcFetch || window.fetch.bind(window))(url, { headers: { Range: "bytes=" + from + "-" }, signal: ac.signal, cache: "no-store" }); }
        catch (e) {
          if (g !== gen) return;
          L("fetch error: " + (e.message || e));
          if (++tries > 3) return fail(from === 0 ? "تعذّر الاتصال بخادم الفيلم" : "انقطع الاتصال بخادم الفيلم");
          await sleep(900 * tries); continue;
        }
        if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
        if (res.status === 416) { eof = true; flushVideo(true); onUpdate(); return; }
        if (!res.ok) {
          L("HTTP " + res.status);
          if (++tries > 2 || res.status === 401 || res.status === 403 || res.status === 404) return fail("الخادم رفض تشغيل الفيلم (HTTP " + res.status + ")");
          await sleep(1200); continue;
        }
        const cr = res.headers.get("content-range") || "", cl = +res.headers.get("content-length") || 0;
        const m = cr.match(/\\/(\\d+)/);
        if (m) total = +m[1]; else if (res.status === 200 && cl) total = cl;
        discard = res.status === 200 && from > 0 ? from : 0;
        if (from === 0) ctl.info.size = total;
        const rd = res.body.getReader();
        let first = from === 0 && !tracks, rd0 = 0;
        try {
          for (;;) {
            await gate(g);
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            const { done, value } = await rd.read();
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            if (done) break;
            rd0 += value.length; if (res.sahraAck) res.sahraAck(rd0);   // نخبر التطبيق بما قرأناه: إن لم نقرأ يتوقف التنزيل بدل أن يمتلئ ذاكرة الصفحة
            let chunk = value;
            if (discard) { if (chunk.length <= discard) { discard -= chunk.length; continue; } chunk = chunk.subarray(discard); discard = 0; }
            if (first) {
              first = false;
              if (!(chunk[0] === 0x1A && chunk[1] === 0x45 && chunk[2] === 0xDF && chunk[3] === 0xA3)) {
                try { ac.abort(); } catch (e) {}
                const k = chunk.length > 8 && chunk[4] === 0x66 && chunk[5] === 0x74 && chunk[6] === 0x79 && chunk[7] === 0x70 ? "mp4" : chunk[0] === 0x47 ? "ts" : /^#EXTM3U/.test(str(chunk.subarray(0, 7))) ? "hls" : "other";
                L("not mkv: " + k);
                stopAll(); ctl.destroyed = true; v.removeEventListener("seeking", onSeeking);
                o.onformat && o.onformat(k);
                return;
              }
            }
            from += chunk.length; tries = 0; ctl.bytes += chunk.length;
            dmx.push(chunk);
            if (ctl.failed) return;
          }
        } catch (e) {
          if (g !== gen) return;
          L("read error at " + from + ": " + (e.message || e));
          if (++tries > 5) return fail("انقطع تحميل الفيلم");
          await sleep(700 * tries); continue;
        }
        if (total && from < total) { L("early end " + from + "/" + total); if (++tries > 5) return fail("انقطع تحميل الفيلم"); await sleep(600); continue; }
        eof = true; flushVideo(true); onUpdate();
        L("eof");
        return;
      }
    }

    v.addEventListener("seeking", onSeeking);
    try {
      ms = new MS();
      ms.addEventListener("sourceopen", () => { msOpen = true; setup(); }, { once: true });
      v.disableRemotePlayback = true;
      objUrl = URL.createObjectURL(ms);
      v.src = objUrl;
    } catch (e) { setTimeout(() => fail("تعذّر تجهيز المشغل: " + (e.message || e)), 0); return ctl; }
    pump(0, gen);
    return ctl;
  }

  /* ───────── محرك TS الخاص بالسهرة: بث مباشر MPEG-TS → MP4 مجزأ (بديل تلقائي لمكتبة mpegts.js) ───────── */
  function unesc(n) { const o = []; for (let i = 0; i < n.length; i++) { if (i >= 2 && n[i] === 3 && n[i - 1] === 0 && n[i - 2] === 0) continue; o.push(n[i]); } return new Uint8Array(o); }
  function spsSize(sps) {
    try {
      const d = unesc(sps); let bit = 8;
      const rb = n => { let v = 0; for (let i = 0; i < n; i++, bit++) v = v * 2 + ((d[bit >> 3] >> (7 - (bit & 7))) & 1); return v; };
      const ue = () => { let z = 0; while (!rb(1) && z < 32) z++; return (Math.pow(2, z) - 1) + (z ? rb(z) : 0); };
      const se = () => { const k = ue(); return k & 1 ? (k + 1) / 2 : -k / 2; };
      const prof = rb(8); rb(16); ue();
      let cf = 1;
      if ([100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135].indexOf(prof) >= 0) {
        cf = ue(); if (cf === 3) rb(1); ue(); ue(); rb(1);
        if (rb(1)) for (let i = 0; i < (cf !== 3 ? 8 : 12); i++) if (rb(1)) { let last = 8, next = 8; for (let j = 0; j < (i < 6 ? 16 : 64); j++) { if (next) next = (last + se() + 256) % 256; last = next || last; } }
      }
      ue(); const poc = ue();
      if (poc === 0) ue(); else if (poc === 1) { rb(1); se(); se(); const n = ue(); for (let i = 0; i < n; i++) se(); }
      ue(); rb(1);
      const w = ue() + 1, h = ue() + 1, fmo = rb(1);
      if (!fmo) rb(1); rb(1);
      let cl = 0, cr = 0, ct = 0, cb = 0;
      if (rb(1)) { cl = ue(); cr = ue(); ct = ue(); cb = ue(); }
      const cx = cf === 0 ? 1 : 2, cy = (cf === 1 ? 2 : 1) * (2 - fmo);
      return [w * 16 - (cl + cr) * cx, (2 - fmo) * h * 16 - (ct + cb) * cy];
    } catch (e) { return [0, 0]; }
  }
  function annexB(d) {
    const out = []; let i = 0, s = -1;
    while (i + 3 <= d.length) {
      if (d[i] === 0 && d[i + 1] === 0 && (d[i + 2] === 1 || (i + 3 < d.length && d[i + 2] === 0 && d[i + 3] === 1))) {
        const sc = d[i + 2] === 1 ? 3 : 4;
        if (s >= 0 && i > s) out.push(d.subarray(s, i));
        i += sc; s = i;
      } else i++;
    }
    if (s >= 0 && s < d.length) out.push(d.subarray(s));
    return out;
  }
  const rdTs = (d, i) => ((d[i] >> 1) & 7) * 1073741824 + ((((d[i + 1] << 8) | d[i + 2]) >> 1) * 32768) + (((d[i + 3] << 8) | d[i + 4]) >> 1);
  function startTS(v, url, o) {
    o = o || {};
    const live = o.live !== false;
    const MS = window.ManagedMediaSource || window.MediaSource;
    const mms = !!window.ManagedMediaSource && MS === window.ManagedMediaSource;
    const ctl = { info: { fmt: "TS" }, log: [], destroyed: false };
    const L = m => { ctl.log.push(m); if (ctl.log.length > 30) ctl.log.shift(); };
    const fail = m => { if (ctl.destroyed || ctl.failed) return; ctl.failed = true; L("fail: " + m); stop(); o.onerror && o.onerror(m); };
    if (!MS) { setTimeout(() => fail("هذا الجهاز لا يدعم التشغيل المتقدم (يحتاج iOS 17.1 أو أحدث)"), 0); return ctl; }
    const sup = m => { try { return MS.isTypeSupported(m); } catch (e) { return false; } };
    let ms = null, objUrl = "", fetchCtl = null, gen = 0, started = false;
    let pmt = -1, vPid = -1, aPid = -1, vType = "", aType = "", aLang = "", pes = {}, rest = null;
    let sps = null, pps = null, V = null, A = null, aBuf = null, vs = [], as = [], base = -1, shift = 0, lastV = -1, lastDur = 3600, vseq = 1, aseq = 1, aNext = -1, vInitKey = "";
    const Q = []; let vsb = null, asb = null, waitAudio = 0;
    function SB(sb) {
      const q = []; let bytes = 0;
      const S = { sb, q, get bytes() { return bytes; },
        push(d) { q.push(d); bytes += d.length; S.kick(); },
        rm(a, b) { if (b > a) { q.push({ rm: [a, b] }); S.kick(); } },
        kick() {
          if (ctl.destroyed || sb.updating || !q.length || ms.readyState === "closed") return;
          const x = q[0];
          try { if (x.rm) sb.remove(x.rm[0], x.rm[1]); else sb.appendBuffer(x); q.shift(); if (!x.rm) bytes -= x.length; }
          catch (e) { if (e.name === "QuotaExceededError") { evict(4); setTimeout(S.kick, 400); } else if (x.rm) q.shift(); else fail("خطأ في التشغيل: " + e.name); }
        } };
      sb.addEventListener("updateend", () => { S.kick(); onUpd(); });
      sb.addEventListener("error", () => fail("تعذّر فك البث"));
      return S;
    }
    function stop() { gen++; try { fetchCtl && fetchCtl.abort(); } catch (e) {} clearInterval(ctl.t); }
    ctl.destroy = () => { if (ctl.destroyed) return; stop(); ctl.destroyed = true; try { v.removeAttribute("src"); v.load(); } catch (e) {} try { objUrl && URL.revokeObjectURL(objUrl); } catch (e) {} };
    function evict(keep) { const t = v.currentTime; for (const S of [vsb, asb]) { if (!S) continue; try { const b = S.sb.buffered; if (b.length && t - b.start(0) > keep + 2) S.rm(b.start(0), t - keep); } catch (e) {} } }
    function onUpd() {
      if (ctl.destroyed) return;
      let b; try { b = v.buffered; } catch (e) { return; }
      if (!started && V && b.length) {
        if (b.end(b.length - 1) - b.start(0) < SB0) return;   // ننتظر حجم التخزين المؤقت المختار قبل البدء
        started = true; try { v.currentTime = b.start(0) + 0.05; } catch (e) {}
        L("ready " + b.start(0).toFixed(2)); o.onready && o.onready(ctl.info);
      }
    }
    const SB0 = Math.max(0, +o.startBuf || 0), LMAX = Math.max(4, +o.liveMax || 12), KEEP = +o.keep || (live ? 20 : 40), REBUF = !!o.rebuf;
    let rebuf = false;
    ctl.bytes = 0;
    ctl.trim = () => { try { evict(3); } catch (e) {} };
    ctl.ahead = () => { let b; try { b = v.buffered; } catch (e) { return 0; } const t = v.currentTime; for (let i = 0; i < b.length; i++) if (t >= b.start(i) - 0.3 && t <= b.end(i)) return b.end(i) - t; return 0; };
    ctl.userPause = () => { rebuf = false; };
    function tick() {
      if (!started || ctl.destroyed) return;
      evict(KEEP);
      let b; try { b = v.buffered; } catch (e) { return; }
      if (!b.length) return;
      const t = v.currentTime, end = b.end(b.length - 1), ah = ctl.ahead();
      if (live && end - t > LMAX) { L("catch up " + (end - t).toFixed(1)); try { v.currentTime = end - Math.max(1.5, SB0 + 1); } catch (e) {} return; }
      // تخزين أكبر: عند نفاد المخزون نتوقف قليلاً حتى يمتلئ بدل التقطيع المتكرر
      if (REBUF && !rebuf && !v.paused && ah < 0.25 && v.readyState < 3) { rebuf = true; L("rebuffer"); try { v.pause(); } catch (e) {} o.onbuffer && o.onbuffer(true); }
      else if (rebuf && ah >= Math.max(1, SB0)) { rebuf = false; const p = v.play(); if (p && p.catch) p.catch(() => {}); o.onbuffer && o.onbuffer(false); }
      if (v.readyState < 3) for (let i = 0; i < b.length; i++) { if (t >= b.start(i) && t < b.end(i)) break; if (b.start(i) > t && b.start(i) - t < 4) { try { v.currentTime = b.start(i) + 0.05; } catch (e) {} break; } }
    }
    // ── المسارات: ننشئ مخازن الصورة والصوت معاً بعد وصول أول إطار مفتاحي وأول إطار صوت
    let aInfo = null, keySeen = false;
    function audioInfo(f) {
      if (aType === "aac") {
        const aot = (f[2] >> 6) + 1, si = (f[2] >> 2) & 15, ch = ((f[2] & 1) << 2) | (f[3] >> 6), sr = SRS[si] || 48000;
        return { codec: "mp4a.40." + aot, name: "AAC", sr, fs: 1024, entry: aEntry("mp4a", ch || 2, sr, esds(0x40, asc(aot, sr, ch || 2))) };
      }
      if (aType === "ac3") { const sr = [48000, 44100, 32000][f[4] >> 6] || 48000; return { codec: "ac-3", name: "AC-3", sr, fs: 1536, entry: aEntry("ac-3", 2, sr, dac3(f, sr, 2)) }; }
      if (aType === "eac3") { const d = dec3(f, 48000, 2); return { codec: "ec-3", name: "E-AC-3", sr: 48000, fs: d.fs, entry: aEntry("ec-3", 2, 48000, d.box) }; }
      return null;
    }
    const spsKey = () => Array.from(sps).join(",") + "|" + Array.from(pps).join(",");
    function vInit() {
      const wh = spsSize(sps);
      const avcC = cat([new Uint8Array([1, sps[1], sps[2], sps[3], 0xFF, 0xE1, sps.length >> 8, sps.length & 255]), sps, new Uint8Array([1, pps.length >> 8, pps.length & 255]), pps]);
      vInitKey = spsKey();
      return { wh, codec: "avc1." + hx(sps[1]) + hx(sps[2]) + hx(sps[3]), init: initSeg({ kind: "v", ts: 90000, w: wh[0], h: wh[1], entry: vEntry("avc1", wh[0], wh[1], box("avcC", avcC)) }) };
    }
    function trySetup() {
      if (V || ctl.failed || !keySeen || !sps || !pps || ms.readyState !== "open") return;
      const waited = vs.length > 1 ? vs[vs.length - 1].dts - vs[0].dts : 0;
      if (aPid >= 0 && !aInfo && waited < 180000) return;
      const x = vInit();
      if (!sup('video/mp4; codecs="' + x.codec + '"')) return fail("هذا الجهاز لا يدعم فيديو هذا البث (" + x.codec + ")");
      try { vsb = SB(ms.addSourceBuffer('video/mp4; codecs="' + x.codec + '"')); } catch (e) { return fail("تعذّر تجهيز المشغل: " + (e.message || e.name)); }
      if (aInfo) {
        if (sup('audio/mp4; codecs="' + aInfo.codec + '"')) { try { asb = SB(ms.addSourceBuffer('audio/mp4; codecs="' + aInfo.codec + '"')); A = aInfo; } catch (e) { asb = null; } }
        if (!A) ctl.info.note = "صوت " + aInfo.name + " غير مدعوم داخلياً — للصوت افتحه في VLC";
      }
      V = { codec: x.codec };
      vsb.push(x.init);
      if (A) asb.push(initSeg({ kind: "a", ts: A.sr, entry: A.entry }));
      ctl.info.v = "H.264"; ctl.info.res = x.wh[0] + "×" + x.wh[1];
      if (A) ctl.info.a = A.name + (aLang && aLang !== "und" ? " · " + (LANGS[aLang] || aLang) : "");
      L("setup " + x.codec + " " + (A ? A.codec : "no-audio"));
      o.onstatus && o.onstatus(ctl.info);
      if (!A) as = [];
      flushV(false);
    }
    // ── الطوابع الزمنية: تسلسل مستمر حتى عند انقطاع البث أو التفاف العداد
    function outT(dts) {
      if (base < 0) base = dts;
      let t = dts - base + shift;
      if (lastV >= 0 && (t < lastV - 45000 || t > lastV + 900000)) { shift += lastV + lastDur - t; t = lastV + lastDur; L("discontinuity"); aNext = -1; }
      return t;
    }
    function onVideo(pts, dts, d) {
      const ns = annexB(d); let key = false, nsps = null, npps = null; const keep = [];
      for (const n of ns) { const t = n[0] & 0x1f; if (t === 7) nsps = n; else if (t === 8) npps = n; else if (t === 9 || t === 12) continue; else { if (t === 5) key = true; keep.push(n); } }
      if (nsps) sps = nsps.slice(); if (npps) pps = npps.slice();
      if (!keySeen) { if (!key || !sps || !pps) return; keySeen = true; }
      if (V && key && nsps && vInitKey !== spsKey()) { flushV(true); const x = vInit(); vsb.push(x.init); L("sps change " + x.wh.join("x")); }
      if (!keep.length) return;
      let n = 0; for (const x of keep) n += 4 + x.length;
      const out = new Uint8Array(n); let q = 0;
      for (const x of keep) { out.set(u32(x.length), q); out.set(x, q + 4); q += 4 + x.length; }
      if (dts == null) dts = pts;
      const t = outT(dts);
      vs.push({ dts: t, cts: Math.max(0, pts - dts), data: out, key });
      lastV = t;
      if (!V) { trySetup(); if (!V) { if (vs.length > 600) vs.shift(); return; } }
      if (key && vs.length > 1) flushV(false);
      else if (vs.length > 1 && vs[vs.length - 1].dts - vs[0].dts > (live ? 90000 : 180000)) flushV(false);
    }
    function flushV(all) {
      if (!V || vs.length < (all ? 1 : 2)) return;
      const k = all ? vs.length : vs.length - 1;
      const out = vs.splice(0, k), nx = vs[0];
      const smp = out.map((f, i) => { const nd = i + 1 < out.length ? out[i + 1].dts : nx ? nx.dts : f.dts + lastDur; const dur = Math.max(1, Math.min(nd - f.dts, 90000)); lastDur = dur; return { data: f.data, dur, flags: f.key ? 0x02000000 : 0x01010000, cts: f.cts }; });
      vsb.push(frag(vseq++, out[0].dts, smp));
      flushA();
    }
    function onAudio(pts, d) {
      if (rest) { d = cat([rest, d]); rest = null; }
      const fr = [];
      let i = 0;
      while (i + 7 < d.length) {
        if (aType === "aac") {
          if (d[i] !== 0xFF || (d[i + 1] & 0xF6) !== 0xF0) { i++; continue; }
          const len = ((d[i + 3] & 3) << 11) | (d[i + 4] << 3) | (d[i + 5] >> 5), hl = (d[i + 1] & 1) ? 7 : 9;
          if (len < hl) { i++; continue; }
          if (i + len > d.length) break;
          if (!aInfo) aInfo = audioInfo(d.subarray(i, i + 7));
          fr.push(d.subarray(i + hl, i + len)); i += len;
        } else {
          if (d[i] !== 0x0B || d[i + 1] !== 0x77) { i++; continue; }
          let len;
          if (aType === "ac3") { const fs = d[i + 4] >> 6, code = d[i + 4] & 63, kb = [32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640][code >> 1], sr = [48000, 44100, 32000][fs]; if (!kb || !sr) { i++; continue; } len = 2 * (Math.floor(96000 * kb / sr) + (sr === 44100 ? code & 1 : 0)); }
          else len = ((((d[i + 2] & 7) << 8) | d[i + 3]) + 1) * 2;
          if (i + len > d.length) break;
          if (!aInfo) aInfo = audioInfo(d.subarray(i, i + len));
          fr.push(d.subarray(i, i + len)); i += len;
        }
      }
      if (i < d.length) rest = d.slice(i, Math.min(d.length, i + 8192));
      const AI = A || aInfo;
      if (!AI || !fr.length || base < 0 || (V && !A)) return;
      const t0 = (pts - base + shift) * AI.sr / 90000;
      fr.forEach((f, j) => as.push({ t: t0 + j * AI.fs, data: f }));
      if (!V) { trySetup(); if (as.length > 2000) as.splice(0, as.length - 2000); return; }
      if (as.length && as[as.length - 1].t - as[0].t > A.sr) flushA();
    }
    function flushA() {
      if (!A || !asb || !as.length) return;
      let b0 = Math.round(as[0].t);
      if (aNext >= 0 && Math.abs(b0 - aNext) < A.fs * 2) b0 = aNext;
      if (b0 < 0) { as = []; return; }
      aNext = b0 + as.length * A.fs;
      asb.push(frag(aseq++, b0, as.map(f => ({ data: f.data, dur: A.fs, flags: 0x02000000, cts: 0 }))));
      as = [];
    }
    // ── قراءة الحزم
    function psi(p) { const ptr = p[0]; return p.subarray(1 + ptr); }
    function onPkt(d, o2) {
      const pusi = d[o2 + 1] & 0x40, pid = ((d[o2 + 1] & 0x1f) << 8) | d[o2 + 2], afc = (d[o2 + 3] >> 4) & 3;
      let s = o2 + 4;
      if (afc & 2) s += 1 + d[s];
      if (!(afc & 1) || s >= o2 + 188) return;
      const pl = d.subarray(s, o2 + 188);
      if (pid === 0) {
        if (!pusi || pmt >= 0) return;
        const t = psi(pl), sl = ((t[1] & 15) << 8) | t[2];
        for (let i = 8; i + 4 <= 3 + sl - 4; i += 4) { const pn = (t[i] << 8) | t[i + 1]; if (pn) { pmt = ((t[i + 2] & 0x1f) << 8) | t[i + 3]; break; } }
        return;
      }
      if (pid === pmt) {
        if (!pusi || vPid >= 0 || aPid >= 0) return;
        const t = psi(pl), sl = ((t[1] & 15) << 8) | t[2], pil = ((t[10] & 15) << 8) | t[11];
        let i = 12 + pil; const end = Math.min(t.length, 3 + sl - 4), auds = [];
        while (i + 5 <= end) {
          const st = t[i], ep = ((t[i + 1] & 0x1f) << 8) | t[i + 2], il = ((t[i + 3] & 15) << 8) | t[i + 4];
          let lang = "", ds = "";
          for (let j = i + 5; j + 2 <= i + 5 + il;) { const tag = t[j], ln = t[j + 1]; if (tag === 0x0A && ln >= 3) lang = String.fromCharCode(t[j + 2], t[j + 3], t[j + 4]); if (tag === 0x6A) ds = "ac3"; if (tag === 0x7A) ds = "eac3"; j += 2 + ln; }
          if (st === 0x1B && vPid < 0) { vPid = ep; vType = "h264"; }
          else if (st === 0x24 && vPid < 0) { vPid = ep; vType = "hevc"; }
          else if (st === 0x0F) auds.push({ pid: ep, type: "aac", lang });
          else if (st === 0x81 || (st === 0x06 && ds === "ac3")) auds.push({ pid: ep, type: "ac3", lang });
          else if (st === 0x87 || (st === 0x06 && ds === "eac3")) auds.push({ pid: ep, type: "eac3", lang });
          i += 5 + il;
        }
        const arW = o.audioPref === "orig" ? 0 : 2;
        auds.forEach((a, k) => { a.k = k; });
        auds.sort((x, y) => (/^ar/i.test(y.lang) ? arW : 0) + (y.type === "aac" ? 1 : 0) - y.k * 0.01 - ((/^ar/i.test(x.lang) ? arW : 0) + (x.type === "aac" ? 1 : 0) - x.k * 0.01));
        if (auds[0]) { aPid = auds[0].pid; aType = auds[0].type; aLang = auds[0].lang.toLowerCase(); }
        L("pmt v=" + vType + " a=" + aType + (aLang ? "/" + aLang : ""));
        if (vType === "hevc") return fail("بث HEVC — استخدم المحرك الأساسي أو VLC");
        if (vPid < 0) return fail("لا يوجد فيديو في هذا البث");
        return;
      }
      if (pid !== vPid && pid !== aPid) return;
      const st = pes[pid] || (pes[pid] = { parts: [], len: 0 });
      if (pusi) { if (st.len) endPes(pid, st); st.parts = [pl]; st.len = pl.length; }
      else if (st.len) { st.parts.push(pl); st.len += pl.length; }
    }
    function endPes(pid, st) {
      const d = st.parts.length === 1 ? st.parts[0] : cat(st.parts);
      st.parts = []; st.len = 0;
      if (d.length < 9 || d[0] !== 0 || d[1] !== 0 || d[2] !== 1) return;
      const fl = d[7], hl = d[8];
      const pts = fl & 0x80 ? rdTs(d, 9) : null, dts = fl & 0x40 ? rdTs(d, 14) : pts;
      const body = d.subarray(9 + hl);
      if (pid === vPid) { if (pts != null) onVideo(pts, dts, body); }
      else if (pts != null || rest) onAudio(pts != null ? pts : 0, body);
    }
    let carry = null;
    function feed(chunk) {
      let d = chunk;
      if (carry) { d = cat([carry, chunk]); carry = null; }
      let i = 0;
      while (i + 188 <= d.length) {
        if (d[i] !== 0x47) { i++; continue; }
        if (i + 188 < d.length && d[i + 188] !== 0x47) { i++; continue; }
        onPkt(d, i); if (ctl.failed) return;
        i += 188;
      }
      if (i < d.length) carry = d.slice(i);
    }
    async function pump(g) {
      let tries = 0, got = 0;
      while (g === gen && !ctl.destroyed) {
        const ac = new AbortController(); fetchCtl = ac;
        try {
          const r = await (window.__fcFetch || window.fetch.bind(window))(url, { signal: ac.signal, cache: "no-store" });
          if (g !== gen) { ac.abort(); return; }
          if (!r.ok) { if (++tries > 2) return fail("الخادم رفض البث (HTTP " + r.status + ")"); await sleep(1000); continue; }
          const rd = r.body.getReader(); let rd0 = 0;
          for (;;) {
            while (g === gen && ((vsb ? vsb.bytes : 0) + (asb ? asb.bytes : 0)) > 12e6) await sleep(200);
            const { done, value } = await rd.read();
            if (g !== gen) { try { ac.abort(); } catch (e) {} return; }
            if (done) break;
            rd0 += value.length; if (r.sahraAck) r.sahraAck(rd0);
            got += value.length; ctl.bytes += value.length; tries = 0; feed(value);
            if (ctl.failed) return;
          }
        } catch (e) { if (g !== gen) return; L("net: " + (e.message || e)); if (!got) return fail("NetworkError — " + (e.message || e)); }
        if (!live) { flushV(true); return; }
        if (++tries > 4) return fail("انقطع البث");
        L("reconnect " + tries); await sleep(500 * tries);
        carry = null; rest = null; pes = {};
      }
    }
    try {
      ms = new MS();
      ms.addEventListener("sourceopen", () => { pump(gen); }, { once: true });
      v.disableRemotePlayback = true;
      objUrl = URL.createObjectURL(ms);
      v.src = objUrl;
    } catch (e) { setTimeout(() => fail("تعذّر تجهيز المشغل: " + (e.message || e)), 0); return ctl; }
    ctl.t = setInterval(tick, 500);
    return ctl;
  }
  window.AlsahraTS = { play: startTS };
  window.AlsahraMKV = { play: start };
  return 1;
}

;alsahraMkvMain();
/* ───────── صندوق مشغل السهرة: مكوّن واحد يعمل داخل صفحة التطبيق أو صفحة المشغل ─────────
   يشغّل: MKV (تحويل حي) · TS+ (محرك السهرة) · mpegts.js · HLS · مشغل iOS الأصلي
   مع: شريط تقديم، ±10، ترجمة + ترجمة تلقائية، إعدادات (تخزين مؤقت، محرك، مقاس، سرعة…)، تقرير. */
function alsahraBoxMain() {
  if (window.AlsahraBox) return 1;
  var CSS = ".epx{position:absolute;inset:0;color:#fff;font-family:-apple-system,system-ui,sans-serif;-webkit-user-select:none;user-select:none;direction:rtl;--a:#e50914}" +
    ".epx *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}" +
    ".epx button{font:inherit;color:#fff;border:0;background:rgba(255,255,255,.14);height:40px;padding:0 12px;border-radius:12px;font-weight:700;font-size:13.5px;white-space:nowrap;flex:none}" +
    ".epx button:active{transform:scale(.96)}" +
    ".ex-box{position:absolute;inset:0;background:#000;overflow:hidden}" +
    ".ex-box video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000}" +
    ".ex-box video::cue{font-size:15px;background:rgba(0,0,0,.6);font-family:-apple-system,sans-serif}" +
    ".ex-box video::-webkit-media-text-track-container{transition:transform .25s}.ex-box:not(.hid) video::-webkit-media-text-track-container{transform:translateY(-40px)}" +
    ".ex-box video::cue{line-height:1.45;text-shadow:0 1px 3px rgba(0,0,0,.9)}" +
    ".fs-s video::cue{font-size:12px}.fs-m video::cue{font-size:15px}.fs-l video::cue{font-size:19px}.fs-xl video::cue{font-size:24px}" +
    ".ex-ov{position:absolute;inset:0;z-index:3;display:flex;flex-direction:column;justify-content:space-between;background:linear-gradient(rgba(0,0,0,.45),rgba(0,0,0,0) 30%,rgba(0,0,0,0) 55%,rgba(0,0,0,.8));transition:opacity .25s}" +
    ".hid .ex-ov{opacity:0;pointer-events:none}" +
    ".ex-top{display:flex;align-items:center;gap:8px;padding:8px 10px;direction:ltr}.ex-top .sp{flex:1}" +
    ".ex-bd{font-size:11px;font-weight:800;padding:5px 10px;border-radius:99px;background:var(--a);white-space:nowrap;max-width:62%;overflow:hidden;text-overflow:ellipsis}" +
    ".ex-oc{display:flex;justify-content:center;align-items:center;gap:22px;direction:ltr}" +
    ".epx .ex-oc button{width:50px;height:50px;padding:0;border-radius:50%;background:rgba(0,0,0,.45);font-size:14px}.epx .ex-oc .pp{width:60px;height:60px;font-size:20px}" +
    ".ex-ob{padding:0 10px 8px}" +
    ".ex-seek{display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11.5px;font-weight:700;color:#ddd;font-variant-numeric:tabular-nums;direction:ltr}" +
    ".ex-rg{flex:1;-webkit-appearance:none;appearance:none;height:4px;border-radius:9px;background:linear-gradient(90deg,var(--a) var(--p,0%),rgba(255,255,255,.3) var(--p,0%));outline:0}" +
    ".ex-rg::-webkit-slider-thumb{-webkit-appearance:none;width:15px;height:15px;border-radius:50%;background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.5)}" +
    ".ex-row{display:flex;gap:8px;direction:ltr;justify-content:flex-end}.epx .ex-row button{height:32px;padding:0 10px;border-radius:10px;font-size:12.5px;background:rgba(0,0,0,.55)}" +
    ".epx .cc{display:none}.hascc .cc{display:inline-block}.epx .on.cc,.epx .on.gear{background:var(--a)}" +
    ".ex-mid{position:absolute;inset:0;z-index:4;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;text-align:center;padding:12px;pointer-events:none}" +
    ".ex-sp{width:40px;height:40px;border-radius:50%;border:3px solid rgba(255,255,255,.15);border-top-color:#fff;animation:exr .8s linear infinite}@keyframes exr{to{transform:rotate(360deg)}}" +
    ".ex-msg{font-size:14px;font-weight:700;color:#f2f2f2;max-width:92%;line-height:1.6;white-space:pre-line}" +
    ".ex-dt{font-size:10.5px;color:#9a9a9a;max-width:92%;line-height:1.5;direction:ltr;word-break:break-all;display:none;max-height:3em;overflow:hidden}.err .ex-dt{display:block}" +
    ".epx .ex-pl{pointer-events:auto;width:64px;height:64px;padding:0;border-radius:50%;background:var(--a);font-size:24px;display:none}" +
    ".ex-eb{pointer-events:auto;display:none;gap:7px;flex-wrap:wrap;justify-content:center}.epx .ex-eb button{height:34px;padding:0 11px;font-size:12.5px;border-radius:11px}" +
    ".err .ex-sp{display:none}.err .ex-eb{display:flex}.ok .ex-mid{display:none}.ok.buf .ex-mid{display:flex}.ok.buf .ex-msg{display:none}" +
    ".err .ex-ov,.load .ex-ov{background:none}.err .ex-oc,.load .ex-oc{visibility:hidden}" +
    ".epx .vlc{background:#f97316}" +
    ".live .ex-seek,.live .ex-oc,.live .cc{display:none}" +
    ".ex-note,.ex-toast{position:absolute;left:50%;transform:translateX(-50%);z-index:6;background:rgba(15,15,18,.93);border:1px solid rgba(255,255,255,.12);padding:7px 12px;border-radius:12px;font-size:12px;font-weight:600;width:max-content;max-width:90%;text-align:center;line-height:1.5;display:none}" +
    ".ex-note{top:44px}.ex-toast{bottom:52px}" +
    ".ex-rs{position:absolute;z-index:6;left:10px;bottom:48px;display:none}.epx .ex-rs button{height:32px;font-size:12px;background:rgba(20,20,24,.92);border:1px solid rgba(255,255,255,.18)}" +
    ".ex-menu{position:absolute;z-index:7;right:10px;bottom:46px;background:rgba(16,16,20,.97);border:1px solid rgba(255,255,255,.1);border-radius:14px;padding:5px;max-height:78%;overflow:auto;display:none;min-width:210px}" +
    ".epx .ex-menu button{display:flex;width:100%;justify-content:space-between;gap:12px;height:38px;background:transparent;font-size:13.5px;font-weight:600}.epx .ex-menu button.on{color:var(--a)}.epx .ex-menu button.on::after{content:'✓'}" +
    ".ex-sets{position:absolute;inset:0;z-index:8;background:rgba(10,10,14,.96);overflow-y:auto;-webkit-overflow-scrolling:touch;padding:10px 12px 14px;display:none}.ex-sets.on{display:block}" +
    ".ex-sets .hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:4px}.ex-sets .hdr b{font-size:14px}.epx .ex-sets .hdr button{height:32px;padding:0 12px;font-size:12.5px}" +
    ".ex-sets h4{font-size:12.5px;color:#aaa;margin:10px 2px 6px;font-weight:700}" +
    ".ex-sg{display:flex;gap:6px;flex-wrap:wrap}.epx .ex-sg button{height:32px;padding:0 11px;border-radius:10px;font-size:12.5px;background:rgba(255,255,255,.08)}.epx .ex-sg button.on{background:var(--a)}" +
    ".ex-sg[data-k=rate] button{direction:ltr}.ex-sets small{display:block;color:#888;font-size:11px;margin:6px 2px 0;line-height:1.6}" +
    ".epx.epx-st{position:relative;inset:auto}.epx-st .ex-sets{position:static;inset:auto;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:16px;margin:10px 14px 4px;padding:12px 14px 14px;overflow:visible}";
  var BUF = {
    low: { start: 0.3, live: 6, keep: 10, vod: 30, rebuf: false, mts: { enableStashBuffer: false, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 3, liveBufferLatencyMinRemain: 0.5 } },
    normal: { start: 1.5, live: 12, keep: 20, vod: 60, rebuf: false, mts: { enableStashBuffer: true, stashInitialSize: 384 * 1024, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 8, liveBufferLatencyMinRemain: 2 } },
    high: { start: 4, live: 25, keep: 30, vod: 120, rebuf: true, mts: { enableStashBuffer: true, stashInitialSize: 2 * 1024 * 1024, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 20, liveBufferLatencyMinRemain: 5 } },
    max: { start: 8, live: 45, keep: 40, vod: 240, rebuf: true, mts: { enableStashBuffer: true, stashInitialSize: 4 * 1024 * 1024, liveBufferLatencyChasing: false } }
  };
  var BUFN = { low: "قليل", normal: "متوازن", high: "كبير", max: "كبير جداً" };
  var BUFD = { low: "بدء فوري وأقل تأخير — للنت القوي", normal: "توازن بين سرعة البدء والثبات", high: "يخزّن ~4 ثوانٍ قبل البدء ويتوقف قليلاً بدل التقطيع", max: "يخزّن ~8 ثوانٍ — للنت الضعيف جداً" };
  var ENGL = { live: [["auto", "تلقائي"], ["own", "السهرة TS+"], ["mts", "السهرة TS"], ["hls", "السهرة HLS"], ["native", "iOS الأصلي"]], vod: [["auto", "تلقائي"], ["mkv", "السهرة MKV"], ["native", "iOS الأصلي"], ["mts", "السهرة TS"]] };
  var NET = /NetworkError|Load failed|Failed to fetch|تعذّر الاتصال|انقطع الاتصال|لا استجابة/;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var fmtT = function (s) { s = Math.max(0, Math.floor(s || 0)); var h = Math.floor(s / 3600), m = Math.floor(s / 60) % 60, x = s % 60; return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (x < 10 ? "0" : "") + x; };

  function create(root, host) {
    if (!document.getElementById("epx-css")) { var st0 = document.createElement("style"); st0.id = "epx-css"; st0.textContent = CSS; (document.head || document.documentElement).appendChild(st0); }
    var P = { state: "init", mts: null, mkv: null, ts: null, diag: [], o: {}, kind: "itv", items: [] };
    // تحذير ذاكرة من النظام (يستدعيه التطبيق): نفرّغ مخزن الصورة المشاهَد خلف الموضع الحالي
    window.__memWarn = function () { try { if (P.mkv && P.mkv.trim) P.mkv.trim(); if (P.ts && P.ts.trim) P.ts.trim(); } catch (e) {} };
    var send = function (m) { try { host.send(m); } catch (e) {} };
    var D = function (m) { P.diag.push(new Date().toTimeString().slice(0, 8) + " " + m); if (P.diag.length > 40) P.diag.shift(); };
    root.innerHTML = "<div class='epx live' data-e='ap'><div class='ex-box load' data-e='box'><video data-e='v' playsinline webkit-playsinline></video>" +
      "<div class='ex-mid'><div class='ex-sp'></div><div class='ex-msg' data-e='msg'>جاري التجهيز…</div><div class='ex-dt' data-e='dt'></div><button class='ex-pl' data-e='pl'>▶</button>" +
      "<div class='ex-eb'><button data-e='er'>إعادة</button><button class='vlc' data-e='evlc'>VLC</button><button data-e='alt'>محرك آخر ▾</button><button data-e='rep'>نسخ التقرير</button></div></div>" +
      "<div class='ex-ov'><div class='ex-top'><span class='ex-bd' data-e='bd'>مشغل السهرة</span><span class='sp'></span></div>" +
      "<div class='ex-oc'><button data-e='b10'>↺10</button><button class='pp' data-e='pp'>❚❚</button><button data-e='f10'>10↻</button></div>" +
      "<div class='ex-ob'><div class='ex-seek'><span data-e='tc'>0:00</span><input class='ex-rg' data-e='rg' type='range' min='0' max='1000' value='0'><span data-e='td'>0:00</span></div>" +
      "<div class='ex-row'><button class='cc' data-e='cc'>الترجمة</button><button class='gear' data-e='gear' aria-label='الإعدادات'>⚙︎</button><button data-e='fs' aria-label='ملء الشاشة'>⛶</button></div></div></div>" +
      "<div class='ex-menu' data-e='menu'></div><div class='ex-note' data-e='note'></div><div class='ex-toast' data-e='toast'></div><div class='ex-rs' data-e='rs'><button data-e='rsb'>↺ من البداية</button></div>" +
      "<div class='ex-sets' data-e='sets'></div></div></div>";
    // العناصر تُحفظ مرة واحدة؛ وبعد إزالة الصندوق تبقى مراجع منفصلة فلا تحدث أخطاء من المؤقتات المتأخرة
    var EL = {};
    var $ = function (id) { return EL[id] || (EL[id] = root.querySelector("[data-e='" + id + "']") || document.createElement("div")); };
    ["ap", "box", "v", "msg", "dt", "pl", "bd", "rg", "menu", "note", "toast", "rs", "sets", "cc", "gear", "pp", "tc", "td"].forEach($);
    // لوحة الإعدادات تحت الصندوق إذا وفّرت الصفحة مكاناً لها (أوسع وأسهل من داخل الصورة)
    var stw = null;
    if (host.setsHost) { stw = document.createElement("div"); stw.className = "epx epx-st"; stw.appendChild($("sets")); host.setsHost.appendChild(stw); }
    var ap = $("ap"), box = $("box"), v = $("v"), msg = $("msg"), pl = $("pl"), bd = $("bd"), rg = $("rg");
    var hideT, dragging = false, posT = 0, toastT = 0, noteT = 0, dead = false;
    var isVod = function () { return P.kind && P.kind !== "itv"; };
    var info = function (t) { try { host.info && host.info(t); } catch (e) {} };
    function show() { box.classList.remove("hid"); clearTimeout(hideT); if (P.state === "playing" && !v.paused) hideT = setTimeout(function () { if (!dragging && $("menu").style.display !== "block" && !$("sets").classList.contains("on")) box.classList.add("hid"); }, 3500); }
    function setMsg(t, kind, d) { box.classList.remove("ok", "err", "buf", "load"); box.classList.add(kind || "load"); msg.textContent = t || ""; $("dt").textContent = d || ""; }
    function state(s, m, extra) { P.state = s; var o = { c: "state", s: s, m: m || "" }; for (var k in extra || {}) o[k] = extra[k]; send(o); }
    function toast(t, ms) { var e = $("toast"); e.textContent = t; e.style.display = "block"; clearTimeout(toastT); toastT = setTimeout(function () { e.style.display = "none"; }, ms || 2600); }
    function note(t) { var e = $("note"); e.textContent = t; e.style.display = "block"; clearTimeout(noteT); noteT = setTimeout(function () { e.style.display = "none"; }, 7000); }
    box.addEventListener("click", function (e) {
      if (e.target.closest && e.target.closest("button,input,.ex-menu,.ex-sets")) return;
      if ($("menu").style.display === "block") { $("menu").style.display = "none"; return; }
      if (box.classList.contains("hid")) show(); else if (P.state === "playing") box.classList.add("hid");
    });
    function sendPos() { if (isVod() && P.state === "playing" && isFinite(v.duration) && v.duration > 60) send({ c: "pos", t: Math.floor(v.currentTime), d: Math.floor(v.duration) }); }
    $("evlc").onclick = function () { sendPos(); send({ c: "vlc", t: Math.floor(v.currentTime || 0) }); };
    $("er").onclick = function () { setMsg("جاري إعادة المحاولة…"); send({ c: "retry", t: Math.floor(P.lastT || 0) }); };
    $("rep").onclick = function () { send({ c: "report", diag: P.diag.concat(P.mkvLog || []).slice(-50), info: P.info || {} }); };
    $("fs").onclick = function () { try { if (v.webkitEnterFullscreen) v.webkitEnterFullscreen(); else if (v.requestFullscreen) v.requestFullscreen(); } catch (e) {} };
    $("pp").onclick = function () { if (!v.paused && P.ts && P.ts.userPause) P.ts.userPause(); if (v.paused) { var p = v.play(); if (p && p.catch) p.catch(onPlayErr); } else v.pause(); show(); };
    $("b10").onclick = function () { try { v.currentTime = Math.max(0, v.currentTime - 10); } catch (e) {} show(); };
    $("f10").onclick = function () { try { v.currentTime = Math.min((v.duration || 1e9) - 1, v.currentTime + 10); } catch (e) {} show(); };
    $("rsb").onclick = function () { $("rs").style.display = "none"; try { v.currentTime = 0; } catch (e) {} };
    rg.addEventListener("input", function () { dragging = true; var d = v.duration || 0; $("tc").textContent = fmtT(rg.value / 1000 * d); rg.style.setProperty("--p", rg.value / 10 + "%"); show(); });
    rg.addEventListener("change", function () { dragging = false; var d = v.duration || 0; if (d && isFinite(d)) { try { v.currentTime = rg.value / 1000 * d; } catch (e) {} } show(); });
    pl.onclick = function () { pl.style.display = "none"; setMsg("جاري التشغيل…"); var p = P.mts ? P.mts.play() : v.play(); if (p && p.catch) p.catch(function () {}); };
    $("alt").onclick = function () {
      var m = $("menu"), cur = P.o.force || "auto";
      m.innerHTML = ENGL[isVod() ? "vod" : "live"].map(function (e) { return "<button data-eng='" + e[0] + "' class='" + (e[0] === cur ? "on" : "") + "'><span>" + e[1] + "</span></button>"; }).join("");
      m.style.display = "block";
    };

    /* ── الترجمة: مسارات الملف + ترجمة تلقائية مع زر إيقاف ── */
    var S = { subs: [], sel: -1, auto: null, src: -1, q: [], seen: {}, pend: {}, id: 0, busy: 0, fail: 0, log: {}, init: false };
    function trName() { return (P.o.trLang || "ar") === "ar" ? "العربية" : String(P.o.trLang).toUpperCase(); }
    function collectSubs() {
      var arr = [];
      if (P.mkv && P.mkv.subs) P.mkv.subs.forEach(function (s, k) { arr.push({ label: s.label, ar: s.ar, lang: s.lang || "", track: s.track, src: "mkv", k: k }); });
      else for (var i = 0; i < v.textTracks.length; i++) {
        var t = v.textTracks[i];
        if (t === S.auto || t.__als || (t.kind !== "subtitles" && t.kind !== "captions")) continue;
        arr.push({ label: t.label || t.language || ("ترجمة " + (arr.length + 1)), ar: /^ar/i.test(t.language || "") || /عرب|arab/i.test(t.label || ""), lang: t.language || "", track: t, src: "native" });
      }
      S.subs = arr;
      ap.classList.toggle("hascc", arr.length > 0);
      return arr;
    }
    function source() {
      var i = -1;
      S.subs.forEach(function (s, k) { if (i < 0 && !s.ar && (/^en/i.test(s.lang) || /english|انجليز|إنجليز/i.test(s.label))) i = k; });
      if (i < 0) S.subs.forEach(function (s, k) { if (i < 0 && !s.ar) i = k; });
      return i;
    }
    function applySubs() {
      collectSubs();
      if (!S.subs.length || S.init) return;
      S.init = true;
      var ar = -1; S.subs.forEach(function (s, k) { if (ar < 0 && s.ar) ar = k; });
      var want = P.o.subOn === false ? -1 : ar >= 0 ? ar : (P.o.tr !== false && source() >= 0 ? -2 : -1);
      selectSub(want, false);
      if (want === -2) note("ترجمة تلقائية إلى " + trName() + " — اضغط «الترجمة» لإيقافها");
    }
    function selectSub(sel, user) {
      S.sel = sel;
      var src = sel === -2 ? source() : -1;
      S.subs.forEach(function (s, k) { try { s.track.mode = k === sel ? "showing" : (k === src && s.src === "native" ? "hidden" : "disabled"); } catch (e) {} });
      if (sel === -2) startAuto(src);
      if (S.auto) { try { S.auto.mode = sel === -2 ? "showing" : "disabled"; } catch (e) {} }
      $("cc").classList.toggle("on", sel !== -1);
      if (user) {
        send({ c: "subpref", on: sel !== -1 });
        toast(sel === -1 ? "تم إيقاف الترجمة" : sel === -2 ? "ترجمة تلقائية إلى " + trName() : "الترجمة: " + S.subs[sel].label, 1600);
      }
    }
    function startAuto(src) {
      if (src < 0) return;
      if (!S.auto) { S.auto = v.addTextTrack("subtitles", trName() + " · ترجمة تلقائية", P.o.trLang || "ar"); S.auto.__als = 1; }
      if (S.src === src) return;
      S.src = src; S.q = []; S.seen = {};
      clearAuto(false);
      var s = S.subs[src];
      if (s.src === "mkv") (S.log[s.k] || []).forEach(queueCue);
      else pollNative();
    }
    function clearAuto(off) {
      if (!S.auto) return;
      try { var m = S.auto.mode; S.auto.mode = "hidden"; var cs = S.auto.cues ? Array.prototype.slice.call(S.auto.cues) : []; cs.forEach(function (c) { S.auto.removeCue(c); }); S.auto.mode = off ? "disabled" : m; } catch (e) {}
    }
    function pollNative() {
      var s = S.subs[S.src]; if (!s || s.src !== "native" || S.sel !== -2) return;
      try { var cs = s.track.cues; if (cs) for (var i = 0; i < cs.length; i++) queueCue({ st: cs[i].startTime, en: cs[i].endTime, txt: cs[i].text }); } catch (e) {}
    }
    function queueCue(c) {
      var txt = String(c.txt || "").replace(/<[^>]+>/g, "").trim(); if (!txt) return;
      var key = Math.round(c.st * 10) + "|" + txt; if (S.seen[key]) return; S.seen[key] = 1;
      S.q.push({ st: c.st, en: c.en, txt: txt });
    }
    function flushTr() {
      if (S.sel !== -2 || !S.q.length || S.busy >= 2 || S.fail > 4) return;
      var t = v.currentTime || 0;
      S.q.sort(function (a, b) { return (a.en < t - 1 ? 1e9 : 0) + a.st - ((b.en < t - 1 ? 1e9 : 0) + b.st); });
      var batch = S.q.splice(0, 25), id = ++S.id;
      S.pend[id] = { b: batch, src: S.src }; S.busy++;
      send({ c: "tr", id: id, texts: batch.map(function (c) { return c.txt.replace(/\\s*\\n\\s*/g, " "); }) });
    }
    function trRes(id, arr) {
      S.busy = Math.max(0, S.busy - 1);
      var p = S.pend[id]; delete S.pend[id];
      if (!p || p.src !== S.src || !S.auto) return 1;
      if (!arr) { S.fail++; p.b.forEach(function (c) { S.q.push(c); }); if (S.fail === 5) note("تعذّرت الترجمة التلقائية — تحقق من الإنترنت"); return 1; }
      S.fail = 0;
      var C = window.VTTCue || window.TextTrackCue;
      p.b.forEach(function (c, i) { try { var q = new C(c.st, c.en, arr[i] || c.txt); cueLine(q); S.auto.addCue(q); } catch (e) {} });
      flushTr();
      return 1;
    }
    var trT = setInterval(function () { if (S.sel === -2) { pollNative(); flushTr(); } }, 1200);
    $("cc").onclick = function () {
      var m = $("menu");
      if (m.style.display === "block") { m.style.display = "none"; return; }
      collectSubs();
      var opts = [{ s: -1, l: "إيقاف الترجمة" }];
      if (source() >= 0) opts.push({ s: -2, l: trName() + " — ترجمة تلقائية" });
      S.subs.forEach(function (x, k) { opts.push({ s: k, l: x.label }); });
      m.innerHTML = opts.map(function (o) { return "<button data-s='" + o.s + "' class='" + (o.s === S.sel ? "on" : "") + "'><span dir='auto'>" + esc(o.l) + "</span></button>"; }).join("");
      m.style.display = "block"; show();
    };
    $("menu").addEventListener("click", function (e) {
      var b = e.target.closest && e.target.closest("button"); if (!b) return;
      $("menu").style.display = "none";
      var eng = b.getAttribute("data-eng");
      if (eng) { setMsg("جاري التشغيل بمحرك " + b.textContent + "…"); send({ c: "retry", force: eng, t: Math.floor(P.lastT || 0) }); return; }
      selectSub(+b.getAttribute("data-s"), true);
    });
    v.textTracks.addEventListener && v.textTracks.addEventListener("addtrack", function () { if (!P.mkv) { collectSubs(); if (!S.init) setTimeout(applySubs, 300); } });
    function resetSubs() {
      if (S.auto) clearAuto(true);
      S.subs = []; S.sel = -1; S.src = -1; S.q = []; S.seen = {}; S.pend = {}; S.busy = 0; S.fail = 0; S.log = {}; S.init = false;
      $("menu").style.display = "none"; $("cc").classList.remove("on"); ap.classList.remove("hascc");
    }

    /* ── إعدادات المشغل ── */
    var Pset = function () { return P.o.set || {}; };
    var bufOf = function () { return BUF[Pset().buf] || BUF.normal; };
    function setV(k, val) { P.o.set = Object.assign({}, Pset()); P.o.set[k] = val; send({ c: "set", key: k, val: val }); }
    // الترجمة في أسفل الصورة (السطر الأخير) — كانت تظهر في منتصف الشاشة خاصة بملء الشاشة
    function cueLine(q) { try { q.snapToLines = true; q.line = (Pset().subPos || "low") === "high" ? -3 : -1; } catch (e) {} }
    function relineCues() { try { for (var i = 0; i < v.textTracks.length; i++) { var cs = v.textTracks[i].cues; if (cs) for (var j = 0; j < cs.length; j++) cueLine(cs[j]); } } catch (e) {} }
    // ترجمات الملف نفسه (MP4/HLS) أيضاً تُنزل لأسفل الصورة
    function hookTrack(t) { if (!t || t.__ln) return; t.__ln = 1; try { t.addEventListener("cuechange", function () { var a = t.activeCues; if (a) for (var k = 0; k < a.length; k++) { var want = (Pset().subPos || "low") === "high" ? -3 : -1; if (a[k].line !== want) cueLine(a[k]); } }); } catch (e) {} }
    try { for (var ti = 0; ti < v.textTracks.length; ti++) hookTrack(v.textTracks[ti]); v.textTracks.addEventListener("addtrack", function (e) { hookTrack(e.track); }); } catch (e) {}
    function applyLook() {
      var st = Pset();
      v.style.objectFit = st.fit === "cover" ? "cover" : st.fit === "fill" ? "fill" : "contain";
      ap.classList.remove("fs-s", "fs-m", "fs-l", "fs-xl"); ap.classList.add("fs-" + (st.subSize || "m"));
    }
    function seg(key, cur, list) { return "<div class='ex-sg' data-k='" + key + "'>" + list.map(function (o) { return "<button data-v='" + o[0] + "' class='" + (String(o[0]) === String(cur) ? "on" : "") + "'>" + o[1] + "</button>"; }).join("") + "</div>"; }
    function renderSets() {
      var st = Pset(), vod = isVod();
      $("sets").innerHTML = "<div class='hdr'><b>إعدادات المشغل</b><button data-close='1'>تم</button></div>" +
        "<h4>نوع المشغل</h4>" + seg("eng", P.o.force || "auto", ENGL[vod ? "vod" : "live"]) +
        "<h4>التخزين المؤقت</h4>" + seg("buf", st.buf || "normal", [["low", BUFN.low], ["normal", BUFN.normal], ["high", BUFN.high], ["max", BUFN.max]]) + "<small>" + BUFD[st.buf || "normal"] + "</small>" +
        "<h4>مقاس الصورة</h4>" + seg("fit", st.fit || "contain", [["contain", "ملائم"], ["cover", "ملء (قص)"], ["fill", "تمديد"]]) +
        (vod ? "<h4>سرعة التشغيل</h4>" + seg("rate", P.rate || v.playbackRate || 1, [[0.75, "0.75×"], [1, "عادي"], [1.25, "1.25×"], [1.5, "1.5×"], [2, "2×"]]) : "") +
        "<h4>حجم الترجمة</h4>" + seg("subSize", st.subSize || "m", [["s", "صغير"], ["m", "متوسط"], ["l", "كبير"], ["xl", "كبير جداً"]]) +
        "<h4>موضع الترجمة</h4>" + seg("subPos", st.subPos || "low", [["low", "أسفل الشاشة"], ["high", "أعلى قليلاً"]]) +
        "<h4>الصوت المفضّل</h4>" + seg("audio", st.audio || "ar", [["ar", "العربي أولاً"], ["orig", "الأصلي"]]) +
        (vod ? "<h4>الحلقة التالية تلقائياً</h4>" + seg("autoNext", st.autoNext === false ? "0" : "1", [["1", "تشغيل"], ["0", "إيقاف"]]) : "") +
        "<h4>إظهار السرعة والمخزون</h4>" + seg("stats", st.stats === false ? "0" : "1", [["1", "تشغيل"], ["0", "إيقاف"]]);
    }
    function setsOpen(on) { $("sets").classList.toggle("on", on); $("gear").classList.toggle("on", on); if (on) { renderSets(); if (stw) { try { $("sets").scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch (e) {} } } show(); }
    $("gear").onclick = function () { setsOpen(!$("sets").classList.contains("on")); };
    $("sets").addEventListener("click", function (e) {
      if (e.target.closest && e.target.closest("[data-close]")) { setsOpen(false); return; }
      var b = e.target.closest && e.target.closest(".ex-sg button"); if (!b) return;
      var k = b.parentNode.getAttribute("data-k"), val = b.getAttribute("data-v");
      var reload = function (why) { toast(why, 1600); send({ c: "retry", t: Math.floor(P.lastT || v.currentTime || 0), force: P.o.force || "auto" }); };
      if (k === "eng") { setV(isVod() ? "vmode" : "pmode", val); toast("المحرك: " + b.textContent, 1500); send({ c: "retry", force: val, t: Math.floor(P.lastT || v.currentTime || 0) }); }
      else if (k === "buf") { setV("buf", val); renderSets(); reload("التخزين المؤقت: " + BUFN[val] + " — إعادة التحميل…"); return; }
      else if (k === "fit") { setV("fit", val); applyLook(); }
      else if (k === "rate") { P.rate = +val; try { v.playbackRate = +val; } catch (e) {} }
      else if (k === "subSize") { setV("subSize", val); applyLook(); }
      else if (k === "subPos") { setV("subPos", val); applyLook(); relineCues(); }
      else if (k === "audio") { setV("audio", val); renderSets(); if (P.mkv || P.ts) reload(val === "ar" ? "الصوت العربي أولاً — إعادة التحميل…" : "الصوت الأصلي — إعادة التحميل…"); return; }
      else if (k === "autoNext") setV("autoNext", val === "1");
      else if (k === "stats") setV("stats", val === "1");
      renderSets();
    });
    var lastB = 0, lastBt = 0;
    var stT = setInterval(function () {
      var E = P.ts || P.mkv; if (!E || P.state !== "playing" || Pset().stats === false) { lastB = 0; return; }
      var now = Date.now(), by = E.bytes || 0;
      if (by < lastB) lastB = 0;
      if (lastB && now > lastBt) {
        var kbs = (by - lastB) / 1024 / ((now - lastBt) / 1000), ah = E.ahead ? E.ahead() : 0;
        bd.textContent = (P.ts ? "السهرة TS+" : "MKV") + " · " + (kbs >= 1024 ? (kbs / 1024).toFixed(1) + " MB/s" : Math.round(kbs) + " KB/s") + " · " + ah.toFixed(0) + "ث";
      }
      lastB = by; lastBt = now;
    }, 2000);

    /* ── المحركات ── */
    function stop() {
      clearTimeout(P.wd); clearTimeout(P.st); clearTimeout(P.bk);
      if (P.mts) { try { P.mts.pause(); P.mts.unload(); P.mts.detachMediaElement(); P.mts.destroy(); } catch (e) {} P.mts = null; }
      if (P.mkv) { try { P.mkvLog = P.mkv.log.slice(); P.mkv.destroy(); } catch (e) {} P.mkv = null; }
      if (P.ts) { try { P.mkvLog = P.ts.log.slice(); P.ts.destroy(); } catch (e) {} P.ts = null; }
      resetSubs(); $("rs").style.display = "none";
      try { v.pause(); v.removeAttribute("src"); v.load(); } catch (e) {}
    }
    function fail(m) {
      m = String(m || "خطأ");
      D("fail: " + m);
      // الخادم رفض الرابط (404/403/410): نتذكره لنعطي رسالة واضحة بدل آخر خطأ من المحركات الاحتياطية
      var hs = /HTTP\\s*\\(?(403|404|410)|\\b(403|404|410)\\s+(Not Found|Forbidden|Gone)/i.exec(m);
      if (hs) P.httpErr = hs[1] || hs[2];
      // تجربة HLS (بدون نقل التطبيق) لم تنجح → نرجع للمحرك العادي
      if (P.o.trial && !P.played) { stop(); pl.style.display = "none"; P.o.trial = ""; P.state = "loading"; setMsg(isVod() ? "جاري تجهيز الفيديو…" : "جاري تشغيل البث…"); show(); state("trialfail", m); return; }
      if (P.state !== "playing" && NET.test(m) && P.o.rs && !P.o.resolved) { stop(); setMsg("جاري البحث عن مسار آخر للبث…"); state("netfail", m); return; }
      if (P.hls && !P.triedHls && !isVod()) { P.triedHls = 1; stop(); setMsg("جاري تجربة HLS…"); native(P.hls); return; }
      // فيلم/حلقة اشتغلت ثم توقفت بخطأ → استئناف تلقائي من نفس الموضع (رابط جديد) بدل رسالة فشل
      if (isVod() && P.played && !/لا يدعم|غير مدعوم|لا يشغلها/.test(m)) {
        var ac = (P.mkv && P.mkv.aCodec) || "", t = Math.floor(P.lastT || v.currentTime || 0);
        P.played = false; stop(); pl.style.display = "none";
        P.state = "loading"; setMsg("توقف التشغيل — جاري الاستئناف تلقائياً…"); show();
        send({ c: "recover", t: t, m: m, dec: /فك|decode/i.test(m) ? 1 : 0, ac: ac });
        return;
      }
      stop(); pl.style.display = "none";
      if (P.httpErr && !isVod()) m = "الخادم لا يبث هذه القناة الآن (HTTP " + P.httpErr + ") — جرّب لاحقاً أو قناة أخرى";
      setMsg(isVod() ? "تعذّر تشغيل الفيديو" : "تعذّر تشغيل البث", "err", m); state("error", m); show();
    }
    function onPlayErr(e) { if (e && e.name === "NotAllowedError") { clearTimeout(P.wd); setMsg(isVod() ? "الفيديو جاهز — اضغط للتشغيل" : "البث جاهز — اضغط للتشغيل"); pl.style.display = "block"; } }
    function tryPlay() { var p = v.play(); if (p && p.catch) p.catch(onPlayErr); }
    function wd(ms) { clearTimeout(P.wd); P.wd = setTimeout(function () { if (P.state !== "playing" && pl.style.display !== "block") fail("لا استجابة من الخادم"); }, ms); }
    function native(u) {
      bd.textContent = /m3u8/i.test(u) ? "HLS" : "iOS";
      if (isVod()) info(/m3u8/i.test(u) ? "HLS" : String(P.fmt === "auto" ? "" : P.fmt || "").toUpperCase());
      v.disableRemotePlayback = false; v.src = u; tryPlay(); wd(P.o.trial === "hls" || P.o.trial === "nts" ? 9000 : isVod() ? 20000 : 12000);
    }
    function ownTS(u, live) {
      if (!window.AlsahraTS) return native(u);
      P.triedOwn = 1;
      bd.textContent = "السهرة TS+";
      var B = bufOf();
      P.ts = window.AlsahraTS.play(v, u, {
        live: live, startBuf: B.start, liveMax: B.live, keep: B.keep, rebuf: B.rebuf, audioPref: Pset().audio || "ar",
        onbuffer: function (on) { box.classList.toggle("buf", !!on); },
        onerror: function (m) {
          var M = window.mpegts;
          if (!P.triedMts && !NET.test(m) && M && M.getFeatureList && M.getFeatureList().mseLivePlayback) { D("own engine: " + m + " → mpegts.js"); stop(); P.o.own = false; P.fb = 1; mtsPlay(u, live); }
          else fail(m);
        },
        onstatus: function (i) { P.info = i; D("ts+ " + [i.v, i.res, i.a, i.note].filter(Boolean).join(" | ")); if (i.note) note(i.note); },
        onready: function () { tryPlay(); }
      });
      wd(16000);
    }
    function mtsPlay(u, live) {
      var M = window.mpegts;
      if (P.o.force === "mts" && (!M || !M.getFeatureList)) return fail("تعذّر تحميل محرك السهرة TS — تحقق من الإنترنت");
      if (P.o.force !== "mts" && (P.o.own || !M || !M.getFeatureList || !M.getFeatureList().mseLivePlayback)) return window.AlsahraTS ? ownTS(u, live) : native(u);
      P.triedMts = 1;
      bd.textContent = "السهرة TS";
      try {
        v.disableRemotePlayback = true;
        var p = M.createPlayer({ type: "mpegts", isLive: live, url: u, cors: true }, Object.assign({ enableWorker: false, lazyLoad: false, autoCleanupSourceBuffer: true }, bufOf().mts));
        P.mts = p;
        p.on(M.Events.ERROR, function (t, d, i) {
          var m = t + " / " + d + (i && i.msg ? " — " + i.msg : "");
          if (P.state === "playing" && live) { setMsg("إعادة الاتصال…"); state("stall", m); send({ c: "reconnect" }); }
          else if (!P.triedOwn && window.AlsahraTS && !NET.test(m)) { D("mpegts: " + m + " → own engine"); stop(); ownTS(u, live); }
          else fail(m);
        });
        p.attachMediaElement(v); p.load();
        var pr = p.play(); if (pr && pr.catch) pr.catch(onPlayErr);
        wd(16000);
      } catch (e) { fail(String((e && e.message) || e)); }
    }
    function mkvPlay(u) {
      if (!window.AlsahraMKV) return native(u);
      bd.textContent = "السهرة MKV";
      P.mkv = window.AlsahraMKV.play(v, u, {
        start: P.o.start || 0, maxAhead: bufOf().vod, audioPref: Pset().audio || "ar", noAudio: P.o.noAud || "", subLine: (Pset().subPos || "low") === "high" ? -3 : -1,
        onerror: function (m) { fail(m); },
        onstatus: function (i) {
          P.info = i;
          bd.textContent = "MKV · " + i.v + (i.a ? " · " + String(i.a).split(" · ")[0] : "");
          info([i.v, i.res, i.a].filter(Boolean).join(" · "));
          D("mkv " + [i.v, i.res, i.a, i.note].filter(Boolean).join(" | "));
          if (i.note) note(i.note);
          applySubs();
        },
        onsub: function (k, st, en, txt) { (S.log[k] = S.log[k] || []).push({ st: st, en: en, txt: txt }); if (S.sel === -2 && S.subs[S.src] && S.subs[S.src].k === k) queueCue({ st: st, en: en, txt: txt }); },
        onready: function () { tryPlay(); },
        onformat: function (k) { D("format " + k); P.mkv = null; if (k === "ts") mtsPlay(u, false); else native(u); }
      });
      wd(30000);
    }
    v.addEventListener("loadedmetadata", function () {
      if (!P.mkv && P.o.start > 5 && isVod() && v.duration > P.o.start + 30) { try { v.currentTime = P.o.start; } catch (e) {} }
      if (!P.mkv && isVod()) setTimeout(applySubs, 800);
    });
    v.addEventListener("playing", function () {
      clearTimeout(P.wd); clearTimeout(P.st); pl.style.display = "none"; setMsg("", "ok"); P.played = true;
      if (P.mts && !P.triedOwn && window.AlsahraTS) { clearTimeout(P.bk); P.bk = setTimeout(function () { var mi = P.mts && P.mts.mediaInfo; if (P.mts && !v.videoWidth && mi && mi.hasVideo) { D("black picture → own engine"); var u = P.url; stop(); setMsg("جاري تجربة محرك آخر…"); P.state = "loading"; ownTS(u, !isVod()); } }, 5000); }
      if (P.state !== "playing") { state("playing", "", { fmt: P.fmt, eng: P.ts ? "own" : P.mts ? (P.fb ? "mts-fb" : "mts") : P.mkv ? "mkv" : "native" }); D("playing " + (v.videoWidth || 0) + "×" + (v.videoHeight || 0)); if (isVod() && P.o.start > 5) { $("rs").style.display = "block"; setTimeout(function () { $("rs").style.display = "none"; }, 8000); toast("استئناف من " + fmtT(P.o.start)); } }
      if (P.rate && isVod() && v.playbackRate !== P.rate) { try { v.playbackRate = P.rate; } catch (e) {} }
      $("pp").textContent = "❚❚"; show();
    });
    v.addEventListener("pause", function () { $("pp").textContent = "▶"; show(); sendPos(); });
    v.addEventListener("waiting", function () {
      if (P.state !== "playing") return;
      if (isVod()) { box.classList.add("buf"); return; }
      clearTimeout(P.st); P.st = setTimeout(function () { setMsg("إعادة الاتصال…"); state("stall"); send({ c: "reconnect" }); }, 15000);
    });
    v.addEventListener("timeupdate", function () {
      clearTimeout(P.st); box.classList.remove("buf");
      if (v.currentTime > 1) P.lastT = v.currentTime;
      if (isVod()) {
        var d = v.duration;
        if (d && isFinite(d)) { $("td").textContent = fmtT(d); if (!dragging) { var x = Math.round(v.currentTime / d * 1000); rg.value = x; rg.style.setProperty("--p", x / 10 + "%"); $("tc").textContent = fmtT(v.currentTime); } }
        if (Date.now() - posT > 15000) { posT = Date.now(); sendPos(); }
      }
    });
    v.addEventListener("ended", function () { if (isVod()) { send({ c: "pos", t: 0, d: Math.floor(v.duration || 0), end: 1 }); if (P.o.eps && Pset().autoNext !== false) { toast("الحلقة التالية…"); send({ c: "next", auto: 1 }); } else { $("pp").textContent = "▶"; show(); } } });
    v.addEventListener("error", function () {
      if (!v.getAttribute("src") || P.mts) return;
      if (P.ts) return fail("تعذّر فك البث");
      var e = v.error, c = e ? e.code : 0, m = e && e.message ? String(e.message).slice(0, 90) : "";
      if (P.mkv) return fail("تعذّر فك الفيديو" + (m ? " — " + m : ""));
      fail(c === 4 ? "صيغة هذا الملف لا يشغلها iOS — افتحه في VLC" + (m ? " (" + m + ")" : "") : c === 2 ? "انقطع الاتصال بالخادم" + (m ? " — " + m : "") : c === 3 ? "تعذّر فك الفيديو" + (m ? " — " + m : "") : "رمز " + c + (m ? " — " + m : ""));
    });

    var api = {
      get state() { return P.state; }, get lastT() { return P.lastT || 0; }, get video() { return v; },
      get diag() { return P.diag; }, get engine() { return P.ts ? "own" : P.mts ? "mts" : P.mkv ? "mkv" : v.getAttribute("src") ? "native" : ""; },
      busy: function (t) { stop(); P.state = "loading"; setMsg(t || "جاري المحاولة…"); show(); return 1; },
      toast: function (t) { toast(t); return 1; },
      note: function (t) { note(t); return 1; },
      err: function (m) { P.o.resolved = true; fail(m); return 1; },
      trRes: trRes,
      pos: sendPos,
      stop: function () { sendPos(); stop(); P.state = "stopped"; setMsg("", "load"); },
      destroy: function () { if (dead) return; dead = true; sendPos(); stop(); clearInterval(trT); clearInterval(stT); root.innerHTML = ""; if (stw && stw.parentNode) stw.parentNode.removeChild(stw); },
      play: function (url, title, sub, hls, accent, o) {
        stop();
        o = o || {};
        P.played = false; P.httpErr = "";
        P.o = o; P.kind = o.kind || "itv";
        // التجارب بدون نقل التطبيق لها مهلة قصيرة حتى لا ينتظر المستخدم
        clearTimeout(P.trT);
        if (o.trial) P.trT = setTimeout(function () { if (!P.played && P.o === o && o.trial) fail("trial timeout"); }, o.trial === "swap" ? 7000 : 9000);
        applyLook(); if ($("sets").classList.contains("on")) renderSets();
        P.url = url; P.hls = hls && hls !== url ? hls : ""; P.triedHls = 0; P.triedOwn = 0; P.triedMts = 0; P.fb = 0; P.state = "loading"; P.lastT = o.start || 0; P.info = null;
        if (accent) { ap.style.setProperty("--a", accent); if (stw) stw.style.setProperty("--a", accent); }
        ap.className = (isVod() ? "epx vod" : "epx live") + (" fs-" + (Pset().subSize || "m"));
        rg.value = 0; rg.style.setProperty("--p", "0%"); $("tc").textContent = "0:00"; $("td").textContent = "0:00";
        info("");
        setMsg(isVod() ? "جاري تجهيز الفيديو…" : "جاري تشغيل البث…"); pl.style.display = "none"; show();
        var f = o.fmt || (/m3u8/i.test(url) ? "hls" : /\\.(mp4|m4v|mov)(\\?|$)/i.test(url) ? "mp4" : /\\.(mkv|webm)(\\?|$)/i.test(url) ? "mkv" : isVod() ? "auto" : "ts");
        P.fmt = f;
        var F = o.force || "";
        D("play " + P.kind + " " + f + (F ? " force=" + F : "") + " @" + location.origin);
        if (F) { P.triedOwn = P.triedMts = P.triedHls = 1; }
        if (F === "own") ownTS(url, !isVod());
        else if (F === "mts") mtsPlay(url, !isVod());
        else if (F === "hls") native(P.hls || url);
        else if (F === "native") native(url);
        else if (F === "mkv") mkvPlay(url);
        else if (f === "hls" || f === "mp4" || f === "avi") native(url);
        else if (f === "mkv" || f === "auto") mkvPlay(url);
        else mtsPlay(url, !isVod());
        return 1;
      }
    };
    return api;
  }
  window.AlsahraBox = { create: create };
  return 1;
}

;alsahraBoxMain();</script>
<script>
(function () {
"use strict";

/* ═════════ helpers ═════════ */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const cssUrl = u => String(u || "").replace(/["'()\\\\\\s]/g, c => encodeURIComponent(c));
const IC = {
  tv: '<rect x="2" y="7" width="20" height="14" rx="3"/><polyline points="17 2 12 7 7 2"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  ball: '<circle cx="12" cy="12" r="9.5"/><path d="M12 7.2l4.2 3-1.6 4.9H9.4L7.8 10.2z"/><path d="M12 2.5v4.7M16.2 10.2l4.6-1.5M14.6 15.1l2.8 3.9M9.4 15.1l-2.8 3.9M7.8 10.2L3.2 8.7"/>',
  film: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 3v18M17 3v18M3 8h4M17 8h4M3 16h4M17 16h4M3 12h18"/>',
  layers: '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  search: '<circle cx="11" cy="11" r="7.5"/><path d="M21 21l-4.6-4.6"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.64-6.36"/><polyline points="21 3 21 9 15 9"/>',
  play: '<polygon points="7 4 20 12 7 20 7 4"/>',
  playf: '<polygon points="7 4 20 12 7 20 7 4" fill="currentColor"/>',
  x: '<path d="M18 6L6 18M6 6l12 12"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
  edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>',
  server: '<rect x="2" y="3" width="20" height="8" rx="2.5"/><rect x="2" y="13" width="20" height="8" rx="2.5"/><path d="M6 7h.01M6 17h.01"/>',
  next: '<polyline points="15 18 9 12 15 6"/>',
  prev: '<polyline points="9 18 15 12 9 6"/>',
  alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  cone: '<path d="M10 3h4l1.3 5H8.7zM8.2 10h7.6l1.3 5H6.9zM6.4 17h11.2L19 21H5z" fill="currentColor" stroke="none"/>',
  flame: '<path d="M12 2s5 4.5 5 10a5 5 0 0 1-10 0c0-2.2 1.2-4 2.5-5 0 2 1 3 2 3 0-3 .5-5.5.5-8z" fill="currentColor" stroke="none"/>',
  brand: '<defs><mask id="bmk"><rect width="24" height="24" fill="#fff"/><circle cx="17.2" cy="8" r="6.6" fill="#000"/></mask></defs><circle cx="11.2" cy="12.8" r="8.6" fill="currentColor" stroke="none" mask="url(#bmk)"/><path d="M18.9 13.4l.75 1.9 1.9.75-1.9.75-.75 1.9-.75-1.9-1.9-.75 1.9-.75z" fill="currentColor" stroke="none"/><polygon points="6.3 10.1 10.4 12.8 6.3 15.5" fill="rgba(0,0,0,.42)" stroke="none"/>',
  ytb: '<rect x="2" y="5" width="20" height="14" rx="4"/><polygon points="10 9 15 12 10 15" fill="currentColor"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>',
  wifi: '<path d="M5 12.55a11 11 0 0 1 14 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/>',
  palette: '<circle cx="13.5" cy="6.5" r="1.5"/><circle cx="17.5" cy="10.5" r="1.5"/><circle cx="8.5" cy="7.5" r="1.5"/><circle cx="6.5" cy="12.5" r="1.5"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.4A5.6 5.6 0 0 0 22 9.8C22 5.5 17.5 2 12 2z"/>',
  spark: '<path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.4z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 4 10 15 15 0 0 1-4 10 15 15 0 0 1-4-10 15 15 0 0 1 4-10z"/>',
  dice: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 8h.01M16 8h.01M12 12h.01M8 16h.01M16 16h.01"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h10"/>',
  down: '<polyline points="6 9 12 15 18 9"/>',
  lang: '<path d="M5 8l6 6M4 14l6-6 2-3M2 5h12M7 2h1M22 22l-5-10-5 10M14 18h6"/>'
};
const APPN = "السهرة ماك";
const ic = (n, c) => '<svg class="ic ' + (c || "") + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + (IC[n] || "") + "</svg>";
const fmtN = n => Number(n || 0).toLocaleString("en-US");
const debounce = (fn, ms) => { let t; return function () { const a = arguments; clearTimeout(t); t = setTimeout(() => fn.apply(null, a), ms); }; };
function initials(n) {
  const w = String(n || "").replace(/[|\\[\\](){}:_\\-–.#*★•]+/g, " ").trim().split(/\\s+/).filter(Boolean);
  if (!w.length) return "TV";
  const pick = w.length > 1 && /^[A-Z]{2,3}$/i.test(w[0]) ? w[1] : w[0];
  return pick.slice(0, 2).toUpperCase();
}
function toast(msg, kind) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "on " + (kind || "");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { t.className = kind || ""; }, kind === "bad" ? 3800 : 2200);
}
const T0 = Date.now();
function splash(on, msg) {
  const el = $("#splash");
  if (msg != null) $("#spSt").textContent = msg;
  clearTimeout(splash.t);
  if (on) { el.classList.add("on"); return; }
  const wait = splash.done ? 0 : Math.max(0, 1600 - (Date.now() - T0));
  splash.done = true;
  if (wait) splash.t = setTimeout(() => el.classList.remove("on"), wait); else el.classList.remove("on");
}
const skelRows = n => Array.from({ length: n }, () => '<div class="sk skr"></div>').join("");
const skelPosters = n => Array.from({ length: n }, () => '<div><div class="sk skp"></div></div>').join("");
const skelChips = n => Array.from({ length: n }, () => '<div class="sk skc"></div>').join("");
const emptyBox = (icn, title, sub, retry) => \`<div class="empty"><div class="eic">\${ic(icn)}</div><b>\${esc(title)}</b>\${sub ? \`<small>\${esc(sub)}</small>\` : ""}\${retry ? \`<button class="btn sec" data-retry="\${retry}" style="margin-top:8px;height:44px">\${ic("refresh")} إعادة المحاولة</button>\` : ""}</div>\`;

/* ═════════ images: load near the screen, release far away (memory) ═════════ */
const IMGIO = ("IntersectionObserver" in window) ? new IntersectionObserver(es => {
  for (const e of es) {
    const i = e.target;
    if (e.isIntersecting) { if (i.getAttribute("src") !== i.dataset.src) i.src = i.dataset.src; }
    else if (i.getAttribute("src")) { i.removeAttribute("src"); i.classList.remove("ld"); }
  }
}, { rootMargin: "1400px 900px" }) : null;
function watchImgs(root) {
  (root || document).querySelectorAll("img[data-src]:not([data-w])").forEach(i => { i.setAttribute("data-w", "1"); if (IMGIO) IMGIO.observe(i); else i.src = i.dataset.src; });
}
new MutationObserver(ms => { for (const m of ms) if (m.addedNodes.length) { watchImgs(m.target); } }).observe(document.body || document.documentElement, { childList: true, subtree: true });

/* ═════════ bridge to Scriptable (short polling — never hangs) ═════════ */
const Bridge = window.Bridge = {
  q: [], seq: 0, p: {},
  call(action, data) {
    return new Promise((res, rej) => {
      const id = ++this.seq;
      const to = setTimeout(() => { if (this.p[id]) { delete this.p[id]; rej(new Error("انتهت مهلة الاستجابة — حاول مرة أخرى")); } }, 120000);
      this.p[id] = { res: v => { clearTimeout(to); res(v); }, rej: e => { clearTimeout(to); rej(e); } };
      this.q.push({ id, action, data: data || {} });
      // داخل تطبيق الآيفون: نوقظ التطبيق فوراً بدل انتظار الاستطلاع التالي
      if (window.SAHRA_APP && !this.wk) { this.wk = 1; setTimeout(() => { this.wk = 0; try { window.webkit.messageHandlers.sahra.postMessage("alsahra-wake:" + id); } catch (e) {} }, 0); }
    });
  },
  take() { return this.q.length ? JSON.stringify(this.q.splice(0)) : ""; },
  sync(resps) {
    if (resps) for (let i = 0; i < resps.length; i++) { try { this.resolve(resps[i]); } catch (e) {} }
    return this.take();
  },
  resolve(m) {
    const p = this.p[m.id];
    if (!p) return;
    delete this.p[m.id];
    if (m.ok) p.res(m.res); else p.rej(new Error(m.res || "خطأ غير معروف"));
  }
};

/* ═════════ state ═════════ */
const newVod = () => ({ loaded: false, raw: [], cats: [], cat: null, items: [], page: 0, pages: 1, q: "", loading: false, tk: 0 });
const newLive = () => ({ loaded: false, mode: "all", raw: [], genres: [], channels: [], byGenre: {}, counts: {}, arSet: new Set(), genre: null, q: "", list: [], shown: 0, tk: 0, allCache: null });
const S = {
  settings: { player: "internal", inApp: true, catAr: true, trTitles: "smart", pmode: "auto", vmode: "auto", buf: "normal", fit: "contain", subSize: "m", subPos: "low", audio: "ar", autoNext: true, resume: true, subTr: true, arabic: "first", theme: 0, anim: 1, motion: true, tr: true, trLang: "ar", accel: "balanced", autoRe: true, stats: true, sameOrigin: true, tmdbKey: "" },
  eng: {},
  portals: [], activeId: null, portal: null, account: null, connected: false, conn: "idle", version: "",
  favs: { itv: [], vod: [], series: [] }, recent: [], pos: {}, done: {},
  tab: "live", favTab: "itv",
  live: newLive(), vod: { vod: newVod(), series: newVod() }, yt: { q: "", items: [], loaded: false, tk: 0 },
  cur: null, playTk: 0, wd: null, pov: "idle", showOrig: false
};
const PN = { internal: "المشغل الداخلي", vlc: "VLC", infuse: "Infuse", nplayer: "nPlayer" };

/* ═════════ 100 themes (20 colors × 5 styles) ═════════ */
const HUES = [["بنفسجي", 262, 82], ["نيلي", 236, 74], ["ملكي", 218, 86], ["سماوي", 199, 90], ["فيروزي", 178, 74], ["زمردي", 155, 68], ["نعناعي", 140, 58], ["زيتوني", 88, 44], ["ليموني", 66, 78], ["ذهبي", 45, 90], ["كهرماني", 33, 95], ["برتقالي", 22, 95], ["مرجاني", 8, 85], ["ياقوتي", 350, 80], ["كرزي", 336, 70], ["وردي", 322, 80], ["فوشيا", 302, 74], ["أرجواني", 282, 70], ["فولاذي", 212, 22], ["قهوة", 26, 34]];
const STYLES = ["ليلي", "أسود", "زجاجي", "نهاري", "نيون"];
const THEMES = [];
STYLES.forEach((st, si) => HUES.forEach(h => THEMES.push({ name: h[0] + " " + st, h: h[1], s: h[2], st: si })));
// ثيمات مميزة (تُضاف بعد المئة حتى لا يتغير ثيمك الحالي)
[{ name: "سينما الأحمر", v: { a1: "229,9,20", acc1: "#ff4d57", acc2: "#e50914", acc3: "#b20710", grad: "linear-gradient(135deg,#ff2a36 0%,#e50914 50%,#b20710 100%)", bg: "#0b0b0b", bg2: "#181818", tile: "linear-gradient(145deg,#262626,#161616)", bar: "rgba(14,14,14,.92)", sheet: "linear-gradient(#1d1d1d,#0b0b0b 40%)", g1: "rgba(229,9,20,.16)", g2: "rgba(229,9,20,.05)", card: "rgba(255,255,255,.06)" } },
 { name: "ليالي السهرة", v: { a1: "232,149,15", acc1: "#ffc857", acc2: "#e8950f", acc3: "#c56a06", grad: "linear-gradient(135deg,#ffc24d 0%,#e8950f 55%,#c56a06 100%)", bg: "#0a0918", bg2: "#15132b", tile: "linear-gradient(145deg,#1f1c3d,#13112a)", bar: "rgba(19,17,40,.86)", sheet: "linear-gradient(#1b1936,#0a0918 40%)", g1: "rgba(124,92,255,.28)", g2: "rgba(232,149,15,.12)", card: "rgba(255,255,255,.06)" } },
 { name: "زمرد الليل", v: { a1: "16,185,129", acc1: "#34d399", acc2: "#10b981", acc3: "#047857", grad: "linear-gradient(135deg,#34d399 0%,#10b981 55%,#047857 100%)", bg: "#050807", bg2: "#0e1512", tile: "linear-gradient(145deg,#16211c,#0c1310)", bar: "rgba(10,16,13,.9)", sheet: "linear-gradient(#131c18,#050807 40%)", g1: "rgba(16,185,129,.18)", g2: "rgba(16,185,129,.06)", card: "rgba(255,255,255,.055)" } },
 { name: "نتفلكس", nf: 1, v: { a1: "229,9,20", acc1: "#e50914", acc2: "#e50914", acc3: "#b20710", grad: "#e50914", bg: "#000000", bg2: "#141414", tile: "#232323", bar: "rgba(0,0,0,.94)", sheet: "#141414", g1: "transparent", g2: "transparent", card: "#1c1c1c" } }
].forEach(t => THEMES.push(Object.assign({ st: 5 }, t)));
const STYLE_F = STYLES.concat(["مميز"]);
function hsl2rgb(h, s, l) {
  s /= 100; l /= 100;
  const k = n => (n + h / 30) % 12, a = s * Math.min(l, 1 - l);
  const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [f(0), f(8), f(4)].map(x => Math.round(x * 255));
}
function themeVars(t) {
  if (t.v) {
    const x = t.v;
    return { "--a1": x.a1, "--acc1": x.acc1, "--acc2": x.acc2, "--acc3": x.acc3, "--grad": x.grad, "--bg": x.bg, "--bg2": x.bg2, "--card": x.card, "--card2": "rgba(255,255,255,.11)",
      "--line": "rgba(255,255,255,.08)", "--txt": "#f5f5f5", "--txt2": "#d8d8d8", "--mut": "#9a9a9a", "--mut2": "#666", "--fg": "255,255,255", "--tile": x.tile, "--bar": x.bar,
      "--sheet": x.sheet, "--input": "rgba(0,0,0,.35)", "--toast": "rgba(32,32,32,.96)", "--g1": x.g1, "--g2": x.g2, scheme: "dark" };
  }
  const h = t.h, st = t.st, H = d => (h + d + 360) % 360;
  const light = st === 3, neon = st === 4, amoled = st === 1, glass = st === 2;
  const sat = neon ? Math.min(100, t.s + 22) : t.s;
  const L = light ? 50 : neon ? 62 : 66;
  const a1 = hsl2rgb(h, sat, L), a2 = hsl2rgb(H(26), sat, L - 6), a3 = hsl2rgb(H(56), sat, L - 9);
  const rgb = a => "rgb(" + a.join(",") + ")";
  const v = { "--a1": a1.join(","), "--acc1": rgb(light ? hsl2rgb(h, sat, 44) : hsl2rgb(h, sat, Math.min(78, L + 8))), "--acc2": rgb(a2), "--acc3": rgb(a3),
    "--grad": \`linear-gradient(135deg,\${rgb(a1)} 0%,\${rgb(a2)} 55%,\${rgb(a3)} 100%)\` };
  if (light) Object.assign(v, {
    "--bg": \`hsl(\${h},32%,96%)\`, "--bg2": "#ffffff", "--card": "rgba(255,255,255,.88)", "--card2": "#ffffff", "--line": "rgba(0,0,0,.08)",
    "--txt": "#12141c", "--txt2": "#2d3142", "--mut": "#6b7084", "--mut2": "#9a9fb2", "--fg": "0,0,0",
    "--tile": \`linear-gradient(145deg,hsl(\${h},28%,94%),hsl(\${h},22%,88%))\`, "--bar": "rgba(255,255,255,.86)",
    "--sheet": \`linear-gradient(#ffffff,hsl(\${h},32%,97%) 40%)\`, "--input": \`hsl(\${h},28%,95%)\`, "--toast": "rgba(255,255,255,.97)",
    "--g1": \`rgba(\${a1},.2)\`, "--g2": \`rgba(\${a3},.13)\`, scheme: "light" });
  else {
    const bL = amoled ? 0 : neon ? 3 : glass ? 8 : 4.5, bs = amoled ? 0 : glass ? 42 : neon ? 45 : 28;
    Object.assign(v, {
      "--bg": \`hsl(\${h},\${bs}%,\${bL}%)\`, "--bg2": amoled ? "#0c0c0e" : \`hsl(\${h},\${bs}%,\${bL + 5}%)\`,
      "--card": neon ? \`rgba(\${a1},.07)\` : glass ? "rgba(255,255,255,.075)" : "rgba(255,255,255,.055)",
      "--card2": neon ? \`rgba(\${a1},.14)\` : "rgba(255,255,255,.1)",
      "--line": neon ? \`rgba(\${a1},.3)\` : glass ? "rgba(255,255,255,.13)" : "rgba(255,255,255,.08)",
      "--txt": "#f4f5fa", "--txt2": "#d3d6e4", "--mut": "#8d92a6", "--mut2": "#61667b", "--fg": "255,255,255",
      "--tile": amoled ? "linear-gradient(145deg,#161616,#0a0a0a)" : \`linear-gradient(145deg,hsl(\${h},\${bs}%,\${bL + 10}%),hsl(\${h},\${bs}%,\${bL + 4}%))\`,
      "--bar": amoled ? "rgba(14,14,16,.88)" : \`hsla(\${h},\${bs}%,\${bL + 6}%,\${glass ? .55 : .82})\`,
      "--sheet": amoled ? "linear-gradient(#141414,#000 40%)" : \`linear-gradient(hsl(\${h},\${bs}%,\${bL + 9}%),hsl(\${h},\${bs}%,\${bL + 2}%) 40%)\`,
      "--input": "rgba(0,0,0,.3)", "--toast": amoled ? "rgba(26,26,28,.96)" : \`hsla(\${h},\${bs}%,\${bL + 11}%,.96)\`,
      "--g1": \`rgba(\${a1},\${amoled ? .13 : glass ? .55 : neon ? .32 : .28})\`, "--g2": \`rgba(\${a3},\${amoled ? .06 : glass ? .35 : .13})\`, scheme: "dark" });
  }
  return v;
}
function applyTheme() {
  const i = Math.max(0, Math.min(THEMES.length - 1, +S.settings.theme || 0));
  const v = themeVars(THEMES[i]), r = document.documentElement;
  Object.keys(v).forEach(k => { if (k !== "scheme") r.style.setProperty(k, v[k]); });
  r.style.colorScheme = v.scheme;
  r.classList.toggle("nf", !!THEMES[i].nf);
  if (THEMES[i].nf) { r.style.setProperty("--txt", "#ffffff"); r.style.setProperty("--txt2", "#e5e5e5"); r.style.setProperty("--mut", "#b3b3b3"); r.style.setProperty("--mut2", "#808080"); r.style.setProperty("--line", "rgba(255,255,255,.1)"); r.style.setProperty("--card2", "#2a2a2a"); }
}

/* ═════════ 100 animations (20 effects × 5 styles) ═════════ */
const FX = [["تلاشي", "", ""], ["انزلاق للأعلى", "translateY(18px)", ""], ["انزلاق للأسفل", "translateY(-18px)", ""], ["من اليمين", "translateX(34px)", ""], ["من اليسار", "translateX(-34px)", ""],
  ["تكبير", "scale(.86)", ""], ["تصغير", "scale(1.12)", ""], ["قلب أفقي", "perspective(700px) rotateX(-65deg)", ""], ["قلب عمودي", "perspective(700px) rotateY(65deg)", ""], ["دوران", "rotate(-7deg) scale(.92)", ""],
  ["ارتداد", "translateY(42px) scale(.92)", ""], ["ضبابي", "", "blur(10px)"], ["ميلان", "skewY(5deg) translateY(14px)", ""], ["تدحرج", "translateX(44px) rotate(10deg)", ""], ["سقوط", "translateY(-44px) scale(1.04)", ""],
  ["صعود ضبابي", "translateY(26px)", "blur(6px)"], ["انفتاح", "scaleY(.5)", ""], ["تمدد", "scaleX(.6)", ""], ["عمق", "perspective(800px) translateZ(-140px)", ""], ["ومضة", "", "brightness(2) saturate(0)"]];
const VARS = [["ناعم", 420, "cubic-bezier(.2,.9,.3,1)", 22], ["سريع", 230, "cubic-bezier(.3,.7,.4,1)", 12], ["نابض", 620, "cubic-bezier(.34,1.56,.64,1)", 30], ["سينمائي", 820, "cubic-bezier(.16,1,.3,1)", 46], ["موجي", 520, "cubic-bezier(.2,.9,.3,1)", 70]];
const ANIMS = [];
VARS.forEach((v, vi) => FX.forEach(f => ANIMS.push({ fx: f[0], vn: v[0], t: f[1], f: f[2], d: v[1], e: v[2], st: v[3], g: vi })));
const animName = a => a.fx + " · " + a.vn;
function applyLite() { document.documentElement.classList.toggle("lite", !!S.settings.lite); }
function applyAnim() {
  const a = ANIMS[+S.settings.anim] || ANIMS[1];
  const css = S.settings.motion === false || S.settings.lite
    ? ".ch,.pc,.ep,.pcard,.nx,.th,.an{animation:none!important}.view{transition:opacity .12s}"
    : \`@keyframes ent{from{opacity:0;transform:\${a.t || "none"};filter:\${a.f || "none"}}to{opacity:1;transform:none;filter:none}}
.ch,.pc,.ep,.pcard,.nx,.th,.an,.yv{animation:ent \${a.d}ms \${a.e} both;animation-delay:calc(var(--i,0) * \${a.st}ms)}
.view{transition:opacity \${Math.round(a.d * .8)}ms ease,transform \${a.d}ms \${a.e},filter \${a.d}ms ease,visibility 0s}
.view:not(.on){transform:\${a.t || "translateY(8px)"};filter:\${a.f || "none"};visibility:hidden;transition-delay:0s,0s,0s,\${a.d}ms}\`;
  $("#animCss").textContent = css;
}

/* ═════════ auto translation ═════════ */
const LANGS = [["ar", "العربية"], ["en", "English"], ["fr", "Français"], ["tr", "Türkçe"], ["ur", "اردو"], ["fa", "فارسی"], ["es", "Español"], ["de", "Deutsch"], ["id", "Indonesia"], ["hi", "हिन्दी"]];
const TR = {};
const AR_CH = /[؀-ۿ]/;
// نص بحروف عربية لكنه فارسي/أوردو/كردي/بشتو (پ چ ژ گ ک ی ...) — يُترجم ولا يُعامل كعربي
const FA_W = /(^|[\\s\\-–(«"'.,،:|])(است|می|نمی|های|هایی|این|آن|را|از|که|برای|یک|شود|بود|دوبله|زیرنویس|فارسی|ایرانی|سریال|شما|آنها|خود|نیز|ولی|چه|چون|تا)(?=$|[\\s\\-–)»"'.,،:!?؟|])/g;
function isFaText(t) {
  t = String(t || "");
  if (!AR_CH.test(t)) return false;
  const fa = (t.match(/[\\u0672-\\u06A3\\u06A5-\\u06A7\\u06A9-\\u06D5]/g) || []).length + 3 * (t.match(FA_W) || []).length;
  const ar = (t.match(/[\\u0629\\u064A\\u0643\\u0649]/g) || []).length;
  return fa > 0 && fa > ar;
}
function inTarget(t, lang) {
  if (/^(ar|fa|ur)$/.test(lang)) {
    const letters = (t.match(/\\p{L}/gu) || []).length, ar = (t.match(/[؀-ۿ]/g) || []).length;
    if (!(letters > 0 && ar / letters > .4)) return false;
    return lang === "ar" ? !isFaText(t) : isFaText(t);
  }
  if (lang === "hi") return /[ऀ-ॿ]/.test(t);
  return !AR_CH.test(t) && /^[\\x00-\\x7FÀ-ɏ\\s\\d\\p{P}]+$/u.test(t) && lang === "en";
}
async function translateMany(texts) {
  const lang = S.settings.trLang || "ar";
  const out = texts.map(t => String(t || ""));
  if (!S.settings.tr) return out;
  const need = [];
  out.forEach((t, i) => { const k = lang + "|" + t; if (!t.trim() || /^[\\d\\s\\p{P}]+$/u.test(t) || inTarget(t, lang)) return; if (TR[k] != null) out[i] = TR[k]; else need.push(i); });
  if (need.length) {
    try {
      const r = await Bridge.call("translate", { texts: need.map(i => out[i]), to: lang });
      need.forEach((i, j) => { const k = lang + "|" + out[i]; TR[k] = r[j] || out[i]; out[i] = TR[k]; });
    } catch (e) {}
  }
  return out;
}

// ترجمة قائمة نصوص قصيرة دفعة واحدة (عناوين/أقسام) مع ذاكرة دائمة في Scriptable
async function trList(texts, lang) {
  lang = lang || S.settings.trLang || "ar";
  const out = texts.map(t => String(t || "")), need = [];
  out.forEach((t, i) => { if (!t.trim()) return; const k = lang + "|" + t; if (TR[k] != null) out[i] = TR[k]; else if (need.indexOf(i) < 0) need.push(i); });
  if (need.length) {
    try {
      const r = await Bridge.call("trList", { texts: need.map(i => out[i]), to: lang });
      need.forEach((i, j) => { const k = lang + "|" + out[i]; TR[k] = (r && r[j]) || out[i]; out[i] = TR[k]; });
    } catch (e) {}
  }
  return out;
}

/* ═════════ Arabic-first ═════════ */
const AR_W = /\\b(AR|ARA|ARAB|ARABIC|ARABIA|MBC|ROTANA|OSN|SHAHID|BEIN|SSC|ALKASS|KSA|SAUDI|EGYPT|EGYPTIAN|GULF|KHALEEJI|IRAQ|IRAQI|SYRIA|SYRIAN|LEBANON|LEBANESE|MAROC|MOROCCO|MAGHREB|ALGERIA|TUNISIA|JORDAN|KUWAIT|UAE|EMIRATES|QATAR|OMAN|BAHRAIN|YEMEN|SUDAN|LIBYA|PALESTINE|NILESAT|QURAN|ISLAMIC|RAMADAN)\\b/i;
const isAr = t => (AR_CH.test(t || "") && !isFaText(t)) || AR_W.test(t || "");
const DUB_RE = /مدبلج|دبلج|\\bDUB(BED|LAJ|S)?\\b|\\bARA?\\s*DUB/i;
const SUB_RE = /مترجم|ترجمة|\\bSUB(S|BED|TITLED?|TITLES)?\\b|\\bVOSTFR\\b/i;
// ترتيب المحتوى: 0 عربي · 1 مدبلج · 2 مترجم/عربي آخر · 3 باقي الأقسام
function tier(t) {
  t = String(t || "");
  if (DUB_RE.test(t)) return 1;
  if (SUB_RE.test(t)) return isAr(t) ? 2 : 3;
  return isAr(t) ? 0 : 3;
}
function arrange(arr) {
  const m = S.settings.arabic;
  if (m === "off") return arr.slice();
  const all = arr.filter(x => x.id === "*"), rest = arr.filter(x => x.id !== "*");
  const T = [[], [], [], []];
  rest.forEach(x => T[tier(x.title)].push(x));
  if (m === "only" && (T[0].length || T[1].length)) return all.concat(T[0], T[1]);
  return all.concat(T[0], T[1], T[2], T[3]);
}
function defaultOf(list) {
  if (S.settings.arabic !== "off") { const g = list.find(x => x.id !== "*" && isAr(x.title)); if (g) return g.id; }
  return list.length ? list[0].id : "*";
}
function normGenres(list) {
  const g = (list || []).map(x => ({ id: String(x.id), title: (String(x.id) === "*" || /^(all|الكل)$/i.test(String(x.title).trim())) ? "الكل" : String(x.title) }));
  if (!g.some(x => x.id === "*")) g.unshift({ id: "*", title: "الكل" });
  return g;
}

/* ═════════ أسماء الأقسام والعناوين بالعربي ═════════ */
// رمز الدولة/اللغة في بداية الاسم → [رمز العلم، الصفة]
const CC = {
  AR: ["", "عربي"], ARA: ["", "عربي"], ARB: ["", "عربي"], EN: ["", "أجنبي"], ENG: ["", "أجنبي"],
  IR: ["IR", "إيراني"], FA: ["IR", "إيراني"], PER: ["IR", "إيراني"], IRN: ["IR", "إيراني"], TR: ["TR", "تركي"], TUR: ["TR", "تركي"],
  IN: ["IN", "هندي"], IND: ["IN", "هندي"], HIN: ["IN", "هندي"], KR: ["KR", "كوري"], KOR: ["KR", "كوري"], JP: ["JP", "ياباني"], JPN: ["JP", "ياباني"],
  CN: ["CN", "صيني"], CHN: ["CN", "صيني"], FR: ["FR", "فرنسي"], FRA: ["FR", "فرنسي"], DE: ["DE", "ألماني"], GER: ["DE", "ألماني"], DEU: ["DE", "ألماني"],
  ES: ["ES", "إسباني"], ESP: ["ES", "إسباني"], SPA: ["ES", "إسباني"], IT: ["IT", "إيطالي"], ITA: ["IT", "إيطالي"], PT: ["PT", "برتغالي"], POR: ["PT", "برتغالي"],
  BR: ["BR", "برازيلي"], RU: ["RU", "روسي"], RUS: ["RU", "روسي"], PK: ["PK", "باكستاني"], PAK: ["PK", "باكستاني"], UR: ["PK", "أوردو"], URD: ["PK", "أوردو"],
  AF: ["AF", "أفغاني"], AFG: ["AF", "أفغاني"], KU: ["", "كردي"], KUR: ["", "كردي"], US: ["US", "أمريكي"], USA: ["US", "أمريكي"], UK: ["GB", "بريطاني"], GB: ["GB", "بريطاني"],
  CA: ["CA", "كندي"], AU: ["AU", "أسترالي"], SA: ["SA", "سعودي"], KSA: ["SA", "سعودي"], EG: ["EG", "مصري"], EGY: ["EG", "مصري"], AE: ["AE", "إماراتي"], UAE: ["AE", "إماراتي"],
  KW: ["KW", "كويتي"], QA: ["QA", "قطري"], BH: ["BH", "بحريني"], OM: ["OM", "عماني"], IQ: ["IQ", "عراقي"], SY: ["SY", "سوري"], LB: ["LB", "لبناني"], JO: ["JO", "أردني"],
  PS: ["PS", "فلسطيني"], YE: ["YE", "يمني"], SD: ["SD", "سوداني"], LY: ["LY", "ليبي"], TN: ["TN", "تونسي"], DZ: ["DZ", "جزائري"], MA: ["MA", "مغربي"],
  NL: ["NL", "هولندي"], SE: ["SE", "سويدي"], NO: ["NO", "نرويجي"], DK: ["DK", "دنماركي"], GR: ["GR", "يوناني"], AL: ["AL", "ألباني"], PL: ["PL", "بولندي"], RO: ["RO", "روماني"],
  AZ: ["AZ", "أذربيجاني"], BD: ["BD", "بنغالي"], PH: ["PH", "فلبيني"], TH: ["TH", "تايلندي"], ID: ["ID", "إندونيسي"], MY: ["MY", "ماليزي"], MX: ["MX", "مكسيكي"],
  LAT: ["", "لاتيني"], AFR: ["", "أفريقي"], ASIA: ["", "آسيوي"]
};
const flagOf = cc => cc ? String.fromCodePoint(...[...cc].map(c => 0x1F1E6 + c.charCodeAt(0) - 65)) : "";
// n: اسم رئيسي (جمع/مؤنث) · g: نوع مذكّر · gf: نوع مؤنّث · a: صفة (تتأنث) · an: جنسية · b: علامة تجارية · x: تُحذف
const WD = {};
[["n", "أفلام", "MOVIES MOVIE FILMS FILM VOD CINEMAS"], ["n", "سينما", "CINEMA"], ["n", "مسلسلات", "SERIES SERIALS SERIE SERIEN DIZI"], ["n", "قنوات", "CHANNELS CHANNEL TV"],
 ["n", "برامج", "PROGRAMS PROGRAMMES SHOWS SHOW|TV SHOWS"], ["n", "مسرحيات", "PLAYS THEATER THEATRE THEATRES"], ["n", "قنوات عامة", "GENERAL GENERALIST"], ["n", "حفلات", "CONCERTS CONCERT"],
 ["n", "وثائقيات", "DOCUMENTARIES DOCS"], ["n", "مباريات", "MATCHES MATCH"], ["n", "أخبار", "NEWS"], ["n", "أغاني", "SONGS CLIPS"], ["n", "مواسم", "SEASONS"], ["n", "حلقات", "EPISODES"],
 ["g", "أكشن", "ACTION|ACTION ADVENTURE"], ["g", "كوميدي", "COMEDY COMEDIES"], ["gf", "دراما", "DRAMA DRAMAS"], ["g", "رعب", "HORROR"], ["gf", "إثارة", "THRILLER THRILLERS SUSPENSE"],
 ["gf", "جريمة", "CRIME"], ["g", "رومانسي", "ROMANCE ROMANTIC LOVE"], ["gf", "مغامرات", "ADVENTURE ADVENTURES"], ["gf", "فانتازيا", "FANTASY"], ["g", "خيال علمي", "SCIFI SCI-FI|SCI FI|SCIENCE FICTION"],
 ["g", "حروب", "WAR WARS"], ["g", "ويسترن", "WESTERN WESTERNS"], ["g", "غموض", "MYSTERY"], ["g", "تاريخي", "HISTORY HISTORICAL"], ["gf", "سيرة ذاتية", "BIOGRAPHY BIOPIC"],
 ["g", "عائلي", "FAMILY"], ["gf", "موسيقى", "MUSIC MUSICAL MUSICALS"], ["g", "ترفيه", "ENTERTAINMENT"], ["g", "ديني", "RELIGIOUS RELIGION"], ["b", "إسلامي", "ISLAMIC ISLAM"],
 ["b", "قرآن", "QURAN KORAN"], ["b", "رمضان", "RAMADAN"], ["g", "وثائقي", "DOCUMENTARY DOC DOCU"], ["g", "أطفال", "KIDS KID CHILDREN CHILD JUNIOR"], ["g", "كرتون", "CARTOON CARTOONS TOONS"],
 ["g", "أنمي", "ANIME"], ["g", "أنيميشن", "ANIMATION ANIMATED"], ["gf", "رياضة", "SPORTS SPORT"], ["g", "منوعات", "VARIETY LIFESTYLE MIX MIXED"], ["g", "طبخ", "COOKING FOOD"],
 ["gf", "طبيعة", "NATURE WILDLIFE"], ["g", "علوم", "SCIENCE"], ["g", "تعليمي", "EDUCATION EDUCATIONAL"], ["g", "تسوق", "SHOPPING"], ["g", "فنون قتالية", "MARTIAL|MARTIAL ARTS"],
 ["g", "زومبي", "ZOMBIE ZOMBIES"], ["g", "أبطال خارقون", "SUPERHERO SUPERHEROES"], ["g", "كرة القدم", "FOOTBALL SOCCER"], ["g", "سياسة", "POLITICS"], ["g", "اقتصاد", "BUSINESS ECONOMY"],
 ["gd", "أفضل الأعمال", "TOP BEST|TOP RATED"], ["g", "رائج", "POPULAR TRENDING|MOST VIEWED"], ["g", "مباشر", "LIVE"], ["x", "", "ALL"],
 ["an", "عربي", "ARABIC ARAB ARABE ARABIAN"], ["an", "أجنبي", "ENGLISH FOREIGN"], ["an", "تركي", "TURKISH TURKEY TURK"], ["an", "هندي", "INDIAN INDIA HINDI BOLLYWOOD"],
 ["an", "كوري", "KOREAN KOREA"], ["gfn", "دراما كورية", "K-DRAMA KDRAMA"], ["gfn", "دراما تركية", "TURKISH-DRAMA"], ["an", "ياباني", "JAPANESE JAPAN"], ["an", "صيني", "CHINESE CHINA"], ["an", "إيراني", "IRANIAN IRAN PERSIAN FARSI"],
 ["an", "فرنسي", "FRENCH FRANCE"], ["an", "ألماني", "GERMAN GERMANY"], ["an", "إسباني", "SPANISH SPAIN"], ["an", "إيطالي", "ITALIAN ITALY"], ["an", "روسي", "RUSSIAN RUSSIA"],
 ["an", "باكستاني", "PAKISTANI PAKISTAN URDU"], ["an", "أمريكي", "AMERICAN AMERICA HOLLYWOOD"], ["an", "بريطاني", "BRITISH"], ["an", "مصري", "EGYPTIAN EGYPT"], ["an", "سعودي", "SAUDI KSA"],
 ["an", "خليجي", "KHALEEJI GULF KHALIJI"], ["an", "سوري", "SYRIAN SYRIA"], ["an", "لبناني", "LEBANESE LEBANON"], ["an", "عراقي", "IRAQI IRAQ"], ["an", "كويتي", "KUWAITI KUWAIT"],
 ["an", "مغربي", "MOROCCAN MOROCCO MAROC MAGHREB"], ["an", "جزائري", "ALGERIAN ALGERIA"], ["an", "تونسي", "TUNISIAN TUNISIA"], ["an", "أردني", "JORDANIAN JORDAN"], ["an", "إماراتي", "EMIRATI EMIRATES"],
 ["an", "آسيوي", "ASIAN ASIA"], ["an", "لاتيني", "LATIN LATINO"], ["an", "أفريقي", "AFRICAN AFRICA"], ["an", "كردي", "KURDISH KURDI"], ["an", "أفغاني", "AFGHAN AFGHANISTAN"],
 ["an", "أوروبي", "EUROPEAN EUROPE"], ["an", "فلبيني", "FILIPINO PHILIPPINES"], ["an", "تايلندي", "THAI THAILAND"],
 ["a", "مدبلج", "DUBBED DUB DUBS DUBLAJ"], ["a", "مترجم", "SUBBED SUB SUBS SUBTITLED SUBTITLES VOSTFR"], ["a", "كلاسيكي", "CLASSIC CLASSICS OLDIES"], ["a", "جديد", "NEW LATEST RECENT"],
 ["a", "قديم", "OLD"], ["a", "حصري", "EXCLUSIVE"], ["a", "مميز", "PREMIUM FEATURED"], ["a", "مختار", "SELECTED PICKS"],
 ["b", "نتفليكس", "NETFLIX"], ["b", "شاهد", "SHAHID"], ["b", "أمازون برايم", "AMAZON|AMAZON PRIME|PRIME VIDEO"], ["b", "ديزني", "DISNEY|DISNEY PLUS|DISNEY+"], ["b", "أبل تي في", "APPLE|APPLE TV|APPLE TV+"],
 ["b", "روتانا", "ROTANA"], ["b", "بي إن سبورت", "BEIN|BEIN SPORTS|BEIN SPORT"], ["b", "الكأس", "ALKASS|AL KASS"], ["b", "أبوظبي", "ABUDHABI AD|ABU DHABI"], ["b", "دبي", "DUBAI"],
 ["b", "الجزيرة", "ALJAZEERA|AL JAZEERA|JAZEERA"], ["b", "العربية", "ALARABIYA|AL ARABIYA"], ["b", "سكاي نيوز", "|SKY NEWS"], ["b", "ناشيونال جيوغرافيك", "NATGEO|NAT GEO|NATIONAL GEOGRAPHIC"],
 ["b", "ديسكفري", "DISCOVERY"], ["b", "سبيستون", "SPACETOON"], ["b", "ماجد", "MAJID"], ["b", "كرتون نتورك", "|CARTOON NETWORK"], ["b", "ستارز بلاي", "STARZPLAY|STARZ PLAY|STARZ"], ["b", "ووتش إت", "WATCHIT|WATCH IT"],
 ["b", "النيل", "NILE|NILESAT"], ["b", "يانغو", "YANGO"], ["b", "تود", "TOD"],
 ["x", "", "AND & THE OF WITH - + ON IN"]].forEach(([t, ar, ws]) => ws.split("|").forEach((seg, si) => (si ? [seg] : seg.split(" ")).forEach(w => w && (WD[w] = [ar, t]))));
// وسوم الجودة في بداية الاسم مثل «4K-AR-DO - …»
const QT = { "4K": "4K", "8K": "8K", UHD: "4K", FHD: "FHD", HD: "HD", SD: "SD", HDR: "HDR", HDR10: "HDR", DV: "Dolby Vision", DO: "Dolby", DOLBY: "Dolby", ATMOS: "Atmos", HEVC: "HEVC", H265: "HEVC", X265: "HEVC", "3D": "3D", MULTI: "متعدد اللغات", VIP: "VIP", DUB: "مدبلج", SUB: "مترجم" };
const TOKRE = /\\s*[|\\[(]?\\s*([A-Z0-9+]{2,6})\\s*([\\])|])?\\s*([|:\\-–—•»#_\\/.])?\\s*/y;
function splitCode(t) {
  t = String(t || "");
  const toks = []; let i = 0, good = 0, end = 0;
  while (toks.length < 6) {
    TOKRE.lastIndex = i; const m = TOKRE.exec(t);
    if (!m || !(CC[m[1]] || QT[m[1]])) break;
    toks.push(m[1]); i = TOKRE.lastIndex;
    if (m[2] || m[3]) { good = toks.length; end = i; } else break;
  }
  if (good) {
    const tk = toks.slice(0, good), code = tk.find(x => CC[x]) || "", c = code ? CC[code] : null;
    const tags = [...new Set(tk.filter(x => QT[x] && !(CC[x] && x === code)).map(x => QT[x]))];
    return { cc: code, flag: c ? flagOf(c[0]) : "", adj: c ? c[1] : "", tags, rest: t.slice(end) };
  }
  const m2 = t.match(/^\\s*([A-Z]{2,4})\\s+(?=\\S)/);
  if (m2 && CC[m2[1]] && !WD[m2[1]]) { const c = CC[m2[1]]; return { cc: m2[1], flag: flagOf(c[0]), adj: c[1], tags: [], rest: t.slice(m2[0].length) }; }
  return { cc: "", flag: "", adj: "", tags: [], rest: t };
}
// الموسم/الحلقة بالعربي (Season 1 → الموسم 1)
function arSE(n) {
  n = String(n == null ? "" : n).trim();
  let m;
  if ((m = n.match(/^(?:season|saison|temporada|staffel|sezon|stagione|seizoen|فصل|سيزن)\\s*[-:#.]?\\s*0*(\\d+)$/i)) || (m = n.match(/^S0*(\\d+)$/i))) return "الموسم " + m[1];
  if ((m = n.match(/^(?:episode|episodio|épisode|folge|bölüm|ep|e|قسمت)\\s*[-:#.]?\\s*0*(\\d+)$/i))) return "الحلقة " + m[1];
  if ((m = n.match(/^S\\d+\\s*[-.]?\\s*E0*(\\d+)$/i)) || (m = n.match(/^(?:season|s)\\s*\\d+\\s*(?:episode|ep|e)\\s*0*(\\d+)$/i))) return "الحلقة " + m[1];
  return n;
}
const femOf = w => /ة$/.test(w) ? w : w.split(" ").map((x, i) => i === 0 ? x + "ة" : x).join(" ");
function catCompose(rest, p) {
  const toks = rest.replace(/[_|\\\\•·:–—,()[\\]{}»«#"]+/g, " ").replace(/\\s-\\s|^-|-$/g, " ").split(/\\s+/).filter(Boolean);
  const N = [], G = [], A = [], B = [], K = [];
  let nat = false, gFem = false, def = false;
  for (let i = 0; i < toks.length; i++) {
    const w = toks[i].toUpperCase();
    let e = null, used = 1;
    for (const n of [3, 2]) { if (i + n <= toks.length) { const k = toks.slice(i, i + n).join(" ").toUpperCase(); if (WD[k]) { e = WD[k]; used = n; break; } } }
    if (!e) e = WD[w];
    if (!e && /^[A-Z]{2,4}$/.test(toks[i]) && CC[toks[i]] && i === 0) e = [CC[toks[i]][1], "an"];
    i += used - 1;
    if (e) {
      const [ar, ty] = e;
      if (ty === "x") continue;
      if (ty === "n") { if (!N.length) N.push(ar); continue; }
      if (ty === "g" || ty === "gf" || ty === "gfn" || ty === "gd") { if (!G.length) { gFem = ty === "gf" || ty === "gfn"; def = ty === "gd"; } if (ty === "gfn") nat = true; if (!G.includes(ar)) G.push(ar); continue; }
      if (ty === "an") { if (!nat) { A.unshift(ar); nat = true; } continue; }
      if (ty === "a") { if (!A.includes(ar)) A.push(ar); continue; }
      if (ty === "b") { if (!B.includes(ar)) B.push(ar); continue; }
    }
    const raw = toks[i];
    if (/\\d/.test(raw) || /^(UHD|FHD|HD|SD|HEVC|VIP|PPV|3D|HDR|\\+18|18\\+)$/i.test(raw)) { K.push(raw.toUpperCase()); continue; }
    if (/^[A-Z][A-Z+&]{1,4}$/.test(raw)) { B.push(raw); continue; }
    if (AR_CH.test(raw) && !isFaText(raw)) { K.push(raw); continue; }
    return null;
  }
  if (p && p.adj && !nat && !B.length && (N.length || G.length || !K.length)) A.unshift(p.adj);
  if (!N.length && !G.length && !A.length && !B.length) return K.length ? K.join(" ") : null;
  const fem = N.length || def ? true : gFem;
  const adj = A.map(a => (def && !N.length ? "ال" : "") + (fem ? femOf(a) : a));
  if (G.length > 1) G.splice(0, G.length, G.slice(0, -1).join("، ") + " و" + G[G.length - 1]);
  return N.concat(G, B, adj, K).join(" ").replace(/\\s+/g, " ").trim() || null;
}
const catOn = () => S.settings.catAr !== false && (S.settings.trLang || "ar") === "ar";
const CN = {};
function catLocal(t) {
  t = String(t || "");
  if (t === "الكل" || t === "الرئيسية") return t;
  const p = splitCode(t), rest = p.rest.trim(), fl = p.flag ? p.flag + " " : "", tg = p.tags.length ? " " + p.tags.join(" ") : "";
  if (!rest) return p.cc ? fl + p.adj + tg : p.tags.length ? p.tags.join(" ") : t;
  if (AR_CH.test(rest) && !isFaText(rest) && !/[A-Za-z]{3,}/.test(rest)) return fl + rest + tg;
  const b = catCompose(rest, p);
  return b != null ? fl + b + tg : null;
}
// اسم القسم المعروض (الأصل يبقى للترتيب والتصفية)
function catLabel(t) {
  t = String(t == null ? "" : t);
  if (!catOn()) return t;
  if (CN[t] != null) return CN[t];
  const r = catLocal(t);
  if (r != null) { CN[t] = r; return r; }
  return t;
}
const titleCase = s => s.replace(/[A-Za-z][A-Za-z']*/g, w => w.length <= 3 && w === w.toUpperCase() ? w : w[0].toUpperCase() + w.slice(1).toLowerCase());
// الأقسام التي لم يعرفها القاموس تُترجم دفعة واحدة
async function catsAr(titles) {
  if (!catOn() || !S.settings.tr) return;
  const pend = [...new Set((titles || []).map(String))].filter(t => CN[t] == null && catLocal(t) == null);
  if (!pend.length) return;
  const ps = pend.map(splitCode), src = ps.map(p => titleCase(p.rest.trim()));
  const r = await trList(src, "ar");
  pend.forEach((t, i) => {
    const b = String(r[i] || "").trim(), p = ps[i];
    if (!b || b === src[i] || !AR_CH.test(b)) { CN[t] = p.flag ? p.flag + " " + p.rest.trim() : t; return; }
    CN[t] = (p.flag ? p.flag + " " : "") + b + (!p.flag && p.adj && b.indexOf(p.adj) < 0 ? " " + p.adj : "");
  });
  applyNames();
}
// أنواع الفيلم (Action, Drama → أكشن، دراما)
function genLocal(s) {
  s = String(s || "").trim();
  if (!s || !catOn()) return s;
  if (AR_CH.test(s) && !isFaText(s)) return s.replace(/\\s*,\\s*/g, "، ");
  const parts = s.split(/\\s*[,،/|]\\s*/).filter(Boolean), out = [];
  for (const x of parts) {
    const e = WD[x.toUpperCase()] || WD[x.toUpperCase().replace(/-/g, " ")];
    if (e && e[1] !== "x" && e[0]) out.push(e[0]);
    else if (AR_CH.test(x) && !isFaText(x)) out.push(x);
    else return null;
  }
  return out.join("، ");
}
// عناوين الأعمال: "smart" يترجم غير اللاتيني (فارسي وغيره) · "all" الكل · "off"
const TN = {};
function trTitlesMode() { return S.settings.tr ? (S.settings.trTitles || "smart") : "off"; }
function needTitleTr(n) {
  const lang = S.settings.trLang || "ar", mode = trTitlesMode();
  if (mode === "off") return false;
  const rest = splitCode(n).rest;
  if (!/\\p{L}/u.test(rest) || inTarget(rest, lang)) return false;
  if (mode === "all") return true;
  return /[^\\p{Script=Latin}\\P{L}]/u.test(rest) && !(lang === "ar" && AR_CH.test(rest) && !isFaText(rest));
}
function showName(n) {
  n = String(n || "");
  if (TN[n] != null) return TN[n];
  const p = splitCode(n);
  if ((!p.cc && !p.tags.length) || !p.rest.trim()) return n;
  return (p.flag ? p.flag + " " : "") + p.rest.trim();
}
async function trTitles(items) {
  const lang = S.settings.trLang || "ar";
  const names = [...new Set((items || []).map(m => m && m.name).filter(n => n && TN[n] == null && needTitleTr(n)))];
  if (!names.length) return;
  const ps = names.map(splitCode), r = await trList(ps.map(p => p.rest.trim()), lang);
  names.forEach((n, i) => { const b = String(r[i] || "").trim(); if (b) TN[n] = (ps[i].flag ? ps[i].flag + " " : "") + b; });
  applyNames();
}
const qBadge = n => { const t = splitCode(n).tags.find(x => /^(4K|8K)$/.test(x)); return t ? \`<em class="qb">\${t}</em>\` : ""; };
// يحدّث النصوص المعروضة بعد وصول الترجمة بدون إعادة رسم الصفحة
function applyNames() {
  document.querySelectorAll("[data-co]").forEach(el => { const v = catLabel(el.dataset.co); if (el.textContent !== v) el.textContent = v; });
  document.querySelectorAll("[data-tn]").forEach(el => { const v = showName(el.dataset.tn); if (el.textContent !== v) el.textContent = v; });
}

/* ═════════ header ═════════ */
// تاريخ قصير للشريط العلوي: "December 31, 2026, 11:59 pm" → "31/12/2026"
function shortDate(x) {
  x = String(x || "").trim();
  const mn = x.match(/([A-Za-z]{3,})\\.?\\s+(\\d{1,2}),?\\s+(\\d{4})/), MS = "janfebmaraprmayjunjulaugsepoctnovdec";
  if (mn && MS.indexOf(mn[1].slice(0, 3).toLowerCase()) >= 0) return +mn[2] + "/" + (MS.indexOf(mn[1].slice(0, 3).toLowerCase()) / 3 + 1) + "/" + mn[3];
  const d = new Date(x.replace(/,\\s*(\\d{1,2}:\\d{2})/, " $1").replace(/\\s*(am|pm)$/i, " $1"));
  if (!isNaN(d)) return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();
  const m = x.match(/(\\d{4})-(\\d{2})-(\\d{2})/); if (m) return +m[3] + "/" + +m[2] + "/" + m[1];
  return x.length > 16 ? x.slice(0, 16) : x;
}
function renderHeader() {
  $("#hName").textContent = (S.portal && S.portal.name) || APPN;
  const a = S.account || {}, c = S.conn;
  $("#hSub").textContent = c === "error" ? "غير متصل — اضغط ⟳" : a.expiry ? "ينتهي " + shortDate(a.expiry) : c === "connecting" ? "جاري الاتصال…" : "متصل";
  $("#hDot").className = "dot" + (c === "connecting" ? " wait" : c === "error" ? " err" : "");
}

/* ═════════ tabs ═════════ */
function switchTab(t) {
  S.tab = t;
  Bridge.call("log", { msg: "tab " + t }).catch(() => {});
  $$(".tab").forEach(b => b.classList.toggle("on", b.dataset.tab === t));
  $$(".view").forEach(v => v.classList.toggle("on", v.id === "v-" + t));
  if (t !== "matches") mLeave();
  if (t === "vod" || t === "series") vodEnter(t);
  else if (t === "matches") mEnter();
  else if (t === "yt") ytEnter();
  else if (t === "favs") renderFavs();
  else if (t === "settings") renderSettings();
}

/* ═════════ live ═════════ */
function applyLive(r, keep) {
  const L = S.live;
  L.mode = r.mode || "all";
  L.channels = r.channels || [];
  L.raw = normGenres(r.genres);
  L.byGenre = {};
  L.loaded = true;
  prepLive();
  if (L.mode === "paged") selectGenre(L.genre, false);
  else { liveCompute(); renderLive(true, keep); }
}
async function liveInit(force, quiet) {
  const L = S.live;
  if (!quiet) { $("#liveList").innerHTML = skelRows(9); if (!L.raw.length) $("#liveGenres").innerHTML = skelChips(5); $("#liveCount").textContent = ""; }
  try {
    const r0 = await Bridge.call("liveInit", { force: !!force });
    applyLive(r0 && r0.ts && r0.data ? r0.data : r0, quiet);
  } catch (e) {
    if (quiet && L.list.length) { if (L.mode === "quick") toast("تعذّر تحميل كل القنوات — يتم عرض جزء منها", "bad"); return; }
    $("#liveGenres").innerHTML = "";
    $("#liveList").innerHTML = emptyBox("wifi", "تعذّر تحميل القنوات", e.message, "live");
  }
}
function liveFirstLoad(genres) {
  const L = S.live;
  if (genres && genres.length && !L.loaded) {
    L.mode = "quick";
    L.raw = normGenres(genres);
    prepLive();
    selectGenre(L.genre);
  }
  liveInit(false, L.mode === "quick");
}
function prepLive() {
  const L = S.live;
  L.arSet = new Set(L.raw.filter(x => x.id !== "*" && tier(x.title) <= 1).map(x => x.id));
  L.allCache = null;
  let g = arrange(L.raw);
  L.counts = {};
  if (L.mode === "all") {
    L.channels.forEach(c => { L.counts[c.g] = (L.counts[c.g] || 0) + 1; });
    g = g.filter(x => x.id === "*" || L.counts[x.id]);
  }
  L.genres = g;
  if (!L.genre || !g.some(x => x.id === L.genre)) L.genre = defaultOf(g);
  renderGenres();
  catsAr(g.map(x => x.title));
}
function allChannels() {
  const L = S.live, m = S.settings.arabic;
  if (L.allCache && L.allCache.m === m) return L.allCache.list;
  let list = L.channels;
  if (m !== "off") {
    const ar = [], ot = [];
    L.channels.forEach(c => (L.arSet.has(c.g) || (AR_CH.test(c.name) && !isFaText(c.name)) ? ar : ot).push(c));
    list = m === "only" && ar.length ? ar : ar.concat(ot);
  }
  L.allCache = { m, list };
  return list;
}
function renderGenres() {
  const L = S.live;
  $("#liveGenres").innerHTML = L.genres.map((g, i) => {
    const n = L.mode === "all" ? (g.id === "*" ? allChannels().length : L.counts[g.id]) : 0;
    return \`<button class="chip \${g.id === L.genre ? "on" : ""}" data-g="\${esc(g.id)}"><span dir="auto" data-co="\${esc(g.title)}">\${esc(catLabel(g.title))}</span>\${n ? \`<em>\${fmtN(n)}</em>\` : ""}</button>\` + (i === 0 ? cddChip("live") : "");
  }).join("");
  const on = $("#liveGenres .chip.on");
  if (on) on.scrollIntoView({ inline: "center", block: "nearest" });
}
async function selectGenre(id, force) {
  const L = S.live;
  L.genre = id;
  $$("#liveGenres .chip").forEach(b => b.classList.toggle("on", b.dataset.g === id));
  if ((L.mode === "paged" || L.mode === "quick") && (force || !L.byGenre[id])) {
    const tk = ++L.tk, mode = L.mode;
    $("#liveList").innerHTML = skelRows(9);
    $("#liveCount").textContent = "";
    let r;
    try { r = await Bridge.call(mode === "quick" ? "liveQuick" : "liveGenre", { genre: id, force: !!force }); }
    catch (e) { if (tk === L.tk && L.mode === mode) $("#liveList").innerHTML = emptyBox("wifi", "تعذّر تحميل القنوات", e.message, "genre"); return; }
    if (tk !== L.tk || L.mode !== mode) return;
    L.byGenre[id] = r;
  }
  liveCompute();
  renderLive(true);
}
// البحث: يتجاهل الهمزات والتشكيل والمسافات، ويفهم الأسماء العربية الشائعة (بي ان سبورت ↔ beIN SPORTS)
const CH_ALIAS = [[/بي\\s*[اإأ]?ن\\s*|بين\\s*سبورت/g, "bein "], [/[اإأ]م\\s*بي\\s*سي/g, "mbc"], [/[اإأ]س\\s*[اإأ]س\\s*سي/g, "ssc"], [/سبورت(س)?/g, "sport"], [/روتانا/g, "rotana"], [/(ال)?جزيره/g, "jazeera"], [/(ال)?عربيه/g, "arabiya"], [/دبي/g, "dubai"], [/[اإأ]بو\\s*ظبي/g, "abu dhabi"], [/(ال)?كاس/g, "kass"], [/شاهد/g, "shahid"], [/نتفليكس/g, "netflix"], [/سينما/g, "cinema"], [/[اإأ]كشن/g, "action"], [/دراما/g, "drama"], [/كرتون/g, "cartoon"], [/سبيستون/g, "spacetoon"], [/ناشيونال|ناشونال/g, "national"], [/جيو\\s*غرافيك|جيوجرافيك/g, "geographic"], [/[اإأ]وربت/g, "orbit"], [/ثمانيه/g, "thmanyah"], [/ديسكفري|ديسكوفري/g, "discovery"], [/ماجد/g, "majid"], [/نايل|النيل/g, "nile"], [/سكاي/g, "sky"], [/نيوز/g, "news"], [/[اإأ]ون\\s*تايم/g, "on time"], [/ستارز/g, "starz"], [/فوكس/g, "fox"], [/[اإأ]وه\\s*[اإأ]س\\s*[اإأ]ن|[اإأ]و\\s*[اإأ]س\\s*[اإأ]ن/g, "osn"], [/هيستوري/g, "history"], [/بي\\s*بي\\s*سي/g, "bbc"], [/سي\\s*[اإأ]ن\\s*[اإأ]ن/g, "cnn"]];
const chN = t => String(t || "").toLowerCase().replace(/[\\u064B-\\u065F\\u0670]/g, "").replace(/[أإآٱ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/[^\\p{L}\\p{N}]+/gu, " ").trim();
function chQs(q) { const n = chN(q), out = [n]; let a = n; CH_ALIAS.forEach(([re, v]) => { a = a.replace(re, v + " "); }); a = a.replace(/\\s+/g, " ").trim(); if (a && a !== n) out.push(a); return out.filter(Boolean); }
function chRankQ(c, qs, num) {
  if (num && c.num === num) return 0;
  const nn = c._n || (c._n = chN(c.name)), nk = c._k || (c._k = nn.replace(/\\s+/g, ""));
  let best = 9;
  for (const x of qs) {
    const xk = x.replace(/\\s+/g, ""); if (!xk) continue;
    if (nn.startsWith(x) || nk.startsWith(xk)) return 1;
    if (nk.includes(xk)) best = Math.min(best, 2);
    else if (x.split(" ").every(w => w && nk.includes(w))) best = Math.min(best, 3);
  }
  return best;
}
function chFilter(list, q) {
  const qs = chQs(q), num = /^\\d+$/.test(q.trim()) ? +q.trim() : 0, hit = [];
  for (const c of list) { const r = chRankQ(c, qs, num); if (r < 9) hit.push([r, c]); }
  hit.sort((a, b) => a[0] - b[0] || (a[1].num || 99999) - (b[1].num || 99999));
  return hit.map(x => x[1]);
}
function liveCompute() {
  const L = S.live, q = L.q.trim();
  let arr;
  if (L.mode === "all") {
    if (q) arr = chFilter(L.channels, q);
    else if (L.genre === "*") arr = allChannels();
    else arr = L.channels.filter(c => c.g === L.genre);
  } else if (q) {
    // نتائج من كل القنوات (فهرس البحث) + ما هو محمّل هنا
    const seen = {}, pool = [];
    Object.keys(L.byGenre).forEach(k => L.byGenre[k].forEach(c => { if (!seen[c.id]) { seen[c.id] = 1; pool.push(c); } }));
    arr = chFilter(pool, q);
    if (L.sq === q && L.sres) { const have = {}; arr.forEach(c => { have[c.id] = 1; }); L.sres.forEach(c => { if (!have[c.id]) { have[c.id] = 1; arr.push(c); } }); }
  } else arr = L.byGenre[L.genre] || [];
  L.list = arr;
}
// بحث الخادم في كل القنوات (عند القوائم الضخمة)
async function remoteSearch(q) {
  const L = S.live, tk = L.stk = (L.stk || 0) + 1;
  L.sq = q; L.sres = null; L.sbusy = true;
  renderLive(true);
  let r = null;
  try { r = await Bridge.call("liveSearch", { q, build: true }); } catch (e) {}
  if (tk !== L.stk || L.q.trim() !== q) return;
  L.sbusy = false; L.sres = (r && r.items) || [];
  liveCompute(); renderLive(true);
}
function chRow(c, i) {
  const fav = isFav("itv", c.id);
  const g = S.live.raw.find(x => x.id === c.g);
  const sub = [c.num ? "#" + c.num : "", g && g.id !== "*" ? catLabel(g.title) : ""].filter(Boolean).join("  ·  ");
  return \`<div class="ch" data-i="\${i}" style="--i:\${Math.min(i % 60, 14)}">
    <div class="lg"><span class="ini">\${esc(initials(c.name))}</span>\${c.logo ? \`<img data-src="\${esc(c.logo)}" decoding="async" onerror="this.remove()">\` : ""}</div>
    <div class="nm"><b dir="auto">\${esc(c.name)}</b><small dir="auto">\${esc(sub)}</small></div>
    <button class="star \${fav ? "on" : ""}" data-fav="\${i}">\${ic("star")}</button></div>\`;
}
function appendLive() {
  const L = S.live, end = Math.min(L.list.length, L.shown + 60);
  let h = "";
  for (let i = L.shown; i < end; i++) h += chRow(L.list[i], i);
  $("#liveList").insertAdjacentHTML("beforeend", h);
  L.shown = end;
}
function renderLive(reset, keep) {
  const L = S.live, box = $("#liveList"), view = $("#v-live");
  if (!reset) { appendLive(); setTimeout(liveMore, 60); return; }
  const st = keep ? view.scrollTop : 0;
  box.innerHTML = ""; L.shown = 0;
  const sb = L.q && L.mode !== "all" && L.sbusy;
  $("#liveCount").innerHTML = L.list.length || sb ? \`\${sb ? '<i class="spin sm"></i>' : ic("tv")}<span>\${fmtN(L.list.length)} قناة\${L.q ? (sb ? " — جاري البحث في كل القنوات…" : " — نتائج البحث") : L.mode === "quick" ? " — جاري تحميل الباقي…" : ""}</span>\` : "";
  if (!L.list.length) { box.innerHTML = sb ? skelRows(6) : L.q ? emptyBox("search", "لا توجد نتائج", "جرّب كلمة أخرى أو رقم القناة") : emptyBox("tv", "لا توجد قنوات في هذا القسم"); return; }
  if (keep) box.classList.add("noanim");
  appendLive();
  if (keep && st > 0) { while (L.shown < L.list.length && box.offsetHeight < st + view.clientHeight + 200) appendLive(); view.scrollTop = st; }
  else view.scrollTop = 0;
  if (keep) setTimeout(() => box.classList.remove("noanim"), 50);
  setTimeout(liveMore, 60);
}

/* ═════════ sheet & player ═════════ */
// صفحة كاملة مثل التطبيقات: شريط علوي فيه زر رجوع وعنوان (تحت أزرار Scriptable العائمة)
function sheetWrap(html, o) {
  o = o || {};
  return \`<div class="pnav\${o.over ? " over" : ""}"><button class="pback" data-act="close" aria-label="رجوع">\${ic("prev")}</button><div class="ptl" dir="auto">\${esc(o.title || "")}</div><span class="pend"></span></div>\` + html;
}
function openSheet(html, o) {
  const p = $("#spanel");
  p.innerHTML = sheetWrap(html, o);
  p.scrollTop = 0;
  $("#sheet").classList.add("on");
}
function killEng() {
  const e = S.eng || {};
  S.eng = {};
  if (e.mts) { try { e.mts.pause(); e.mts.unload(); e.mts.detachMediaElement(); e.mts.destroy(); } catch (x) {} }
  if (e.hjs) { try { e.hjs.destroy(); } catch (x) {} }
}
// نخبر التطبيق بما يُشغَّل الآن، ليكمله تلقائياً إن أغلق النظام الصفحة لنفاد الذاكرة
function npSet(c) {
  let k = "", t = "";
  try { if (c && c.item && c.item.id != null) { t = curFavType(); k = t + ":" + c.item.id; } } catch (e) { k = ""; }
  if ((S.npKey || "") === k) return;
  S.npKey = k;
  Bridge.call("nowPlaying", k ? { t, item: slim(t, c.item), label: c.epLabel || "" } : { on: false }).catch(() => {});
}
function stopVideo() {
  npSet(null);
  epKill();
  S.playTk++;
  S.trying = false;
  S.resumeFn = null;
  clearTimeout(S.wd); clearTimeout(S.stall); clearInterval(S.statT);
  killEng();
  const v = $("#vid");
  if (v) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (e) {} }
}
// بعد الرجوع من صفحة فيلم/مسلسل: خطوط التقدم في القوائم وصف «تابع المشاهدة» تتحدث
function progCards() {
  ["vod", "series"].forEach(t => {
    const V = S.vod[t]; if (!V) return;
    $$("#grid-" + t + " .pc").forEach(el => {
      let m = null;
      if (el.dataset.i != null) m = V.items && V.items[+el.dataset.i];
      else if (el.dataset.h) { const [k, i] = el.dataset.h.split(":").map(Number); m = V.home && V.home[k] && V.home[k].items[i]; }
      const ps = m && el.querySelector(".ps"); if (!ps) return;
      ps.querySelectorAll(".pbar,.seen").forEach(x => x.remove());
      const h = cardProg(m); if (h) ps.insertAdjacentHTML("beforeend", h);
    });
    const home = $("#grid-" + t + " .home");
    if (home) {
      const old = $("#hr-" + t + "-cw"), nh = contRow(t);
      if (old) old.outerHTML = nh || "";
      else if (nh) { const hero = $("#hero-" + t); if (hero) hero.insertAdjacentHTML("afterend", nh); else home.insertAdjacentHTML("afterbegin", nh); }
    }
  });
  if (S.tab === "favs") renderFavs();
}
function closeSheet() { const was = S.cur && S.cur.kind !== "itv"; stopVideo(); S.forceEng = null; S.navBack = null; S.backMatch = null; $("#sheet").classList.remove("on"); S.cur = null; S.sheetKind = null; S.curMatch = null; if (was) setTimeout(progCards, 60); }
// الرجوع: إلى الصفحة السابقة (مثلاً من القناة إلى المباراة) أو إغلاق الصفحة
function sheetBack() { const f = S.navBack; if (f) { S.navBack = null; S.backMatch = null; stopVideo(); S.cur = null; f(); } else closeSheet(); }
const playerHTML = hidden => \`<div class="player\${hidden ? " hide" : ""}" id="pl"><video id="vid" playsinline webkit-playsinline controls preload="auto"></video><div class="pstat" id="pstat"></div><div class="pov" id="pov"></div></div><div id="diag"></div>\`;
// كل المشغلات الداخلية تعمل داخل «مشغل السهرة» (على عنوان خادم البث) فلا يحجبها المتصفح
const ENGS_LIVE = [["auto", "تلقائي"], ["own", "السهرة TS+ ⭐"], ["mts", "السهرة TS"], ["hls", "السهرة HLS"], ["native", "iOS الأصلي"]];
const ENGS_VOD = [["auto", "تلقائي"], ["mkv", "السهرة MKV ⭐"], ["native", "iOS الأصلي"], ["mts", "السهرة TS"]];
const ENGS = ENGS_LIVE;
const engsFor = kind => kind === "itv" ? ENGS_LIVE : ENGS_VOD;
const validEng = (kind, e) => e && engsFor(kind).some(x => x[0] === e && e !== "auto") ? e : null;
function playersRow() {
  const cur = S.forceEng || "auto", list = engsFor(S.cur ? S.cur.kind : "itv");
  return \`<div class="sec-t pad" style="margin:16px 4px 0">المشغلات الداخلية</div>
    <div class="chips pad engs" style="padding-top:10px">\${list.map(e => \`<button class="chip \${cur === e[0] ? "on" : ""}" data-eng="\${e[0]}">\${e[0] === "auto" ? ic("spark") : ""}\${e[1]}</button>\`).join("")}</div>
    <div class="sec-t pad" style="margin:14px 4px 0">مشغلات خارجية</div>
    <div class="exts four">
    <button class="ext" data-ext="vlc"><i class="e-vlc">\${ic("cone")}</i><span>VLC</span></button>
    <button class="ext" data-ext="infuse"><i class="e-inf">\${ic("flame")}</i><span>Infuse</span></button>
    <button class="ext" data-ext="nplayer"><i class="e-np">n</i><span>nPlayer</span></button>
    <button class="ext" data-act="copy"><i class="e-cp">\${ic("copy")}</i><span>نسخ الرابط</span></button></div>\`;
}
function hookVideo(v) {
  const cur = () => v === $("#vid");
  v.addEventListener("playing", () => { if (!cur()) return; clearTimeout(S.wd); clearTimeout(S.stall); if (!S.trying) setPov("none"); });
  v.addEventListener("timeupdate", () => { if (cur()) clearTimeout(S.stall); });
  v.addEventListener("waiting", () => { if (!cur() || S.trying) return; clearTimeout(S.stall); S.stall = setTimeout(() => onLateError("توقف البث"), 15000); });
  v.addEventListener("error", () => { if (!cur() || S.trying || (!v.getAttribute("src") && !v.currentSrc)) return; onLateError(mediaErr(v.error)); });
}
function freshVideo() {
  // عنصر فيديو جديد لكل محاولة حتى لا تتداخل طرق التشغيل
  const old = $("#vid");
  if (!old) return null;
  const v = document.createElement("video");
  v.id = "vid"; v.controls = true; v.preload = "auto";
  v.setAttribute("playsinline", ""); v.setAttribute("webkit-playsinline", "");
  old.replaceWith(v);
  try { old.pause(); old.removeAttribute("src"); old.load(); } catch (e) {}
  hookVideo(v);
  return v;
}
function bindVideo() {
  const v = $("#vid");
  if (!v) return;
  hookVideo(v);
  // أثناء إكمال التشغيل بعد نقل التطبيق: نفس شاشة التحميل السوداء (بدون ومضة زر التشغيل الملوّن)
  if (S.restoring) setPov("trying", S.cur && S.cur.kind === "itv" ? "جاري تشغيل البث…" : "جاري تجهيز الفيديو…");
  else setPov("idle");
}
function setPov(st, msg) {
  S.pov = st;
  const o = $("#pov");
  if (!o) return;
  o.className = "pov " + st;
  if (st === "none") o.innerHTML = "";
  else if (st === "idle") o.innerHTML = \`<button class="bigplay" data-act="play">\${ic("play")}</button><span>\${S.settings.player === "internal" ? "اضغط للتشغيل" : "تشغيل عبر " + PN[S.settings.player]}</span>\`;
  else if (st === "loading") o.innerHTML = \`<div class="spin"></div><span>جاري تجهيز البث…</span>\`;
  else if (st === "tap") o.innerHTML = \`<button class="bigplay" data-act="resume">\${ic("play")}</button><span>البث جاهز — اضغط للتشغيل</span>\`;
  else if (st === "trying") o.innerHTML = \`<div class="spin"></div><span>\${esc(msg || "جاري التجهيز…")}</span>\`;
  if (st === "error") {
    killEng();
    const v = $("#vid"); if (v && v.getAttribute("src")) { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (e) {} }
    const ps = $("#pstat"); if (ps) ps.innerHTML = "";
    o.innerHTML = \`<div class="perr">\${ic("alert")}<b>\${esc(msg || "تعذّر تشغيل البث داخل التطبيق")}</b><small>جرّب محركاً آخر من «المشغلات الداخلية» بالأسفل، أو VLC</small><div class="perr-b"><button data-eng="auto">مشغل السهرة</button><button data-ext="vlc">VLC</button><button data-act="retry">إعادة</button></div></div>\`;
  }
}
function openChannel(list, i) {
  const c = list[i];
  if (!c) return;
  stopVideo();
  S.cur = { kind: "itv", item: c, cmd: c.cmd, series: "", list, idx: i, title: c.name };
  S.sheetKind = "channel";
  const fav = isFav("itv", c.id);
  const g = S.live.raw.find(x => x.id === c.g);
  const html = \`
    \${playerHTML(false)}
    <div class="shead">
      <div class="lg"><span class="ini">\${esc(initials(c.name))}</span>\${c.logo ? \`<img src="\${esc(c.logo)}" onerror="this.remove()">\` : ""}</div>
      <div class="nm"><b dir="auto">\${esc(c.name)}</b><small dir="auto">\${esc([c.num ? "#" + c.num : "", g && g.id !== "*" ? catLabel(g.title) : ""].filter(Boolean).join("  ·  "))}</small></div>
      <div class="chnav">
        <button class="ibtn sm" data-act="prev" \${i <= 0 ? "disabled style=opacity:.35" : ""}>\${ic("prev")}</button>
        <button class="ibtn sm" data-act="next" \${i >= list.length - 1 ? "disabled style=opacity:.35" : ""}>\${ic("next")}</button>
        <button class="ibtn sm star \${fav ? "on" : ""}" data-act="favcur">\${ic("star")}</button>
      </div>
    </div>
    <div class="epg" id="epg"><div class="sk" style="height:16px;width:40%"></div><div class="sk" style="height:20px;margin-top:10px"></div><div class="sk" style="height:5px;margin-top:12px"></div></div>
    \${playersRow()}\`;
  if ($("#sheet").classList.contains("on")) { $("#spanel").innerHTML = sheetWrap(html, { title: "بث مباشر" }); }
  else openSheet(html, { title: "بث مباشر" });
  bindVideo();
  loadEpg(c);
  if (S.settings.player === "internal" && !S.noAuto) startPlay("internal");
}
function stepChannel(d) {
  const c = S.cur;
  if (!c || c.kind !== "itv" || !c.list) return;
  const j = c.idx + d;
  if (j < 0 || j >= c.list.length) return;
  openChannel(c.list, j);
}
async function loadEpg(c) {
  let list = [];
  try { list = await Bridge.call("epg", { id: c.id }); } catch (e) {}
  if (!S.cur || S.cur.item !== c) return;
  list = (list || []).filter(e => e.name).sort((a, b) => a.start - b.start);
  if (!list.length) { const b = $("#epg"); if (b) b.innerHTML = \`<div class="muted">\${ic("clock")} لا يتوفر دليل برامج لهذه القناة</div>\`; return; }
  const now = Date.now() / 1000;
  let ci = list.findIndex(e => e.start <= now && e.end > now);
  if (ci < 0) ci = list.findIndex(e => e.start > now) >= 0 ? -1 : 0;
  const shown = list.slice(Math.max(ci, 0), Math.max(ci, 0) + 5);
  renderEpg(shown, ci >= 0, false);
  if (S.settings.tr) {
    const texts = shown.map(e => e.name).concat(shown[0] && ci >= 0 ? [shown[0].desc] : []);
    const tr = await translateMany(texts);
    if (!S.cur || S.cur.item !== c) return;
    const changed = tr.some((t, i) => t !== texts[i]);
    if (!changed) return;
    const out = shown.map((e, i) => Object.assign({}, e, { name: tr[i] }));
    if (ci >= 0 && out[0]) out[0].desc = tr[shown.length] || out[0].desc;
    renderEpg(out, ci >= 0, true);
  }
}
function renderEpg(list, live, translated) {
  const box = $("#epg");
  if (!box) return;
  const now = Date.now() / 1000;
  const tf = (ts, alt) => ts ? new Date(ts * 1000).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : (alt || "");
  let h = "", rest = list;
  if (live && list[0]) {
    const e = list[0];
    const pct = e.end > e.start ? Math.max(0, Math.min(100, (now - e.start) / (e.end - e.start) * 100)) : 0;
    const left = e.end ? Math.max(0, Math.round((e.end - now) / 60)) : 0;
    h += \`<span class="lbl"><i></i>يُعرض الآن</span>\${translated ? \`<span class="trtag">\${ic("lang")}مترجم</span>\` : ""}<h4 dir="auto">\${esc(e.name)}</h4>
      <div class="bar"><i style="width:\${pct.toFixed(1)}%"></i></div>
      <div class="tm"><span>\${tf(e.start, e.t1)} – \${tf(e.end, e.t2)}</span><span>\${left ? "متبقي " + left + " د" : ""}</span></div>
      \${e.desc ? \`<p dir="auto">\${esc(e.desc)}</p>\` : ""}\`;
    rest = list.slice(1);
  }
  rest.forEach((e, k) => { h += \`<div class="nx" style="--i:\${k}"><span>\${tf(e.start, e.t1)}</span><b dir="auto">\${esc(e.name)}</b></div>\`; });
  box.innerHTML = h || \`<div class="muted">لا يتوفر دليل برامج</div>\`;
}
/* ── internal players: several engines, each with a fresh link ── */
const ENG = { fsp: "مشغل السهرة", auto: "تلقائي", own: "السهرة TS+", mts: "السهرة TS", hls: "السهرة HLS", native: "iOS الأصلي", mkv: "السهرة MKV", hjs: "السهرة HLS", raw: "iOS الأصلي" };
const canMSE = () => !!(window.ManagedMediaSource || window.MediaSource);
const LIBP = {};
function loadLib(name) {
  const g = name === "hls" ? "Hls" : "mpegts";
  if (window[g]) return Promise.resolve(window[g]);
  if (!LIBP[name]) LIBP[name] = Bridge.call("lib", { name }).then(src => {
    const el = document.createElement("script");
    el.textContent = src;
    document.head.appendChild(el);
    if (!window[g]) throw new Error("تعذّر تهيئة مكتبة التشغيل");
    return window[g];
  }).catch(e => { delete LIBP[name]; throw e; });
  return LIBP[name];
}
const loadMpegts = () => loadLib("mpegts");
// ⚡ مسرّعات التشغيل
const ACCEL = {
  fast: { mts: { enableStashBuffer: false, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 3, liveBufferLatencyMinRemain: .5 }, hls: { lowLatencyMode: true, maxBufferLength: 12, liveSyncDurationCount: 2, backBufferLength: 10 } },
  balanced: { mts: { enableStashBuffer: true, stashInitialSize: 384 * 1024, liveBufferLatencyChasing: true, liveBufferLatencyMaxLatency: 8, liveBufferLatencyMinRemain: 2 }, hls: { maxBufferLength: 30, liveSyncDurationCount: 3, backBufferLength: 30 } },
  stable: { mts: { enableStashBuffer: true, stashInitialSize: 2 * 1024 * 1024, liveBufferLatencyChasing: false }, hls: { maxBufferLength: 60, maxMaxBufferLength: 120, liveSyncDurationCount: 5, backBufferLength: 60 } }
};
const BUF_DESC = { low: "بدء فوري وأقل تأخير عن البث — للنت القوي", normal: "توازن بين سرعة البدء وثبات البث", high: "يخزّن ~4 ثوانٍ قبل البدء، ويتوقف لحظة لإعادة التخزين بدل التقطيع", max: "يخزّن ~8 ثوانٍ ودقائق من الأفلام مسبقاً — للنت الضعيف جداً" };
const ACCEL_DESC = { fast: "أقل تأخير وبدء أسرع — للنت القوي", balanced: "توازن بين سرعة البدء وثبات البث", stable: "تخزين أكبر يقلل التقطيع على النت الضعيف" };
function mediaErr(e) {
  if (!e) return "خطأ غير معروف";
  const m = { 1: "أُلغي التحميل", 2: "خطأ شبكة أو رفض من الخادم", 3: "تعذّر فك ترميز البث", 4: "الصيغة غير مدعومة في مشغل الآيفون" }[e.code] || ("خطأ " + e.code);
  return m + (e.message ? " — " + String(e.message).slice(0, 80) : "");
}
const maskUrl = u => String(u || "")
  .replace(/([?&](?:mac|token|play_token|password|username|sn|stream_token|uid)=)[^&]+/gi, "$1***")
  .replace(/^([a-z]+:\\/\\/[^\\/]+)\\/([^?#]*)/i, (m, o, p) => {
    const parts = p.split("/"), cred = {};
    if (/^(live|movie|series|timeshift)$/i.test(parts[0]) && parts.length >= 4) { cred[1] = cred[2] = 1; }
    else if (parts.length >= 3 && /^\\d+(\\.\\w+)?$/.test(parts[parts.length - 1])) { cred[0] = cred[1] = 1; }
    return o + "/" + parts.map((x, i) => cred[i] || (/^[A-Za-z0-9_-]{6,}$/.test(x) && !/^\\d+$/.test(x) && !/^(series|movies?|live)$/i.test(x)) ? "***" : x).join("/");
  });
const SRC = { direct: "رابط القناة", link: "رابط البوابة", repaired: "رابط مُصلَح", broken: "رابط معطوب" };
const originOf = u => (String(u || "").match(/^[a-z][a-z0-9+.-]*:\\/\\/[^\\/?#]+/i) || [""])[0].toLowerCase();
function playPlan(c) {
  const mode = S.forceEng || S.settings.pmode || "auto";
  // تلقائي: HLS داخل التطبيق إن توفر، وإلا مشغل السهرة بملء الشاشة على عنوان خادم البث
  let engs = mode !== "auto" ? [mode] : (c.kind === "itv" ? ["hls", "fsp"] : ["fsp", "raw"]);
  let plan = engs.map(e => ({ eng: e, pick: 0 })).concat(engs.filter(e => e !== "fsp" && !(c.kind === "itv" && e === "raw")).map(e => ({ eng: e, pick: 1 })));
  const first = S.firstTry; S.firstTry = null;
  const pref = (first ? first.eng + ":" + first.pick : (mode === "auto" ? String((S.pm || {})[c.kind] || "") : "")).split(":");
  if (pref[0]) { const i = plan.findIndex(a => a.eng === pref[0] && a.pick === (+pref[1] || 0)); if (i > 0) plan.unshift(plan.splice(i, 1)[0]); }
  return plan;
}
const linkOpts = (c, extra) => Object.assign({ kind: c.kind, cmd: c.cmd, series: c.series, tmp: c.item && c.item.tmp, lb: c.item && c.item.lb, pick: +String((S.pm || {})[c.kind] || "").split(":")[1] || 0 }, extra || {});
function tryEngine(eng, pick, c, tk) {
  return new Promise(async res0 => {
    let meta = {};
    const res = x => res0(Object.assign(x, meta));
    const fmt = eng === "hls" || eng === "hjs" ? "hls" : "raw";
    let r;
    try { r = await Bridge.call("play", linkOpts(c, { ext: "internal", fmt, pick })); }
    catch (e) { return res({ ok: false, err: e.message, fatal: true }); }
    if (tk !== S.playTk) return res({ ok: false, err: "cancel" });
    c.raw = r.raw; c.nLinks = r.n || 1;
    meta = { src: r.src, n: r.n || 1, url: r.url };
    if (fmt === "hls" && r.url === r.raw && !/m3u8/i.test(r.raw)) return res({ ok: false, err: "لا يوجد رابط HLS لهذا البث", skip: true });
    if (eng === "mts" && /m3u8/i.test(r.raw)) return res({ ok: false, err: "البث بصيغة HLS أصلاً", skip: true });
    if (c.kind !== "itv" && /\\.(mkv|webm|avi|wmv|flv)(\\?|$)/i.test(r.raw)) return res({ ok: false, err: "ملف " + (r.raw.match(/\\.(mkv|webm|avi|wmv|flv)(\\?|$)/i)[1].toUpperCase()) + " — يُشغَّل في مشغل السهرة", skip: true });
    const v = freshVideo();
    if (!v) return res({ ok: false, err: "cancel" });
    let done = false, timer = null;
    const finish = (ok, err, extra) => { if (done) return; done = true; clearTimeout(timer); res(Object.assign({ ok, err }, extra || {})); };
    const arm = ms => { clearTimeout(timer); timer = setTimeout(() => finish(false, "لا استجابة من الخادم خلال " + Math.round(ms / 1000) + " ث"), ms); };
    // نعتبر التشغيل ناجحاً فقط عندما تتقدم الصورة فعلاً (وليس عند وصول البيانات الوصفية فقط)
    let blocked = false, t0 = -1, pt = null;
    v.addEventListener("canplay", () => { if (blocked) finish(true); });
    v.addEventListener("playing", () => { t0 = v.currentTime; clearTimeout(pt); pt = setTimeout(() => { if (!done && !v.paused) finish(false, "البث متوقف — لا تصل صورة"); }, 7000); });
    v.addEventListener("timeupdate", () => { if (!done && t0 >= 0 && v.currentTime - t0 >= 0.25) { clearTimeout(pt); finish(true); } });
    v.addEventListener("error", () => { if (!done) finish(false, mediaErr(v.error)); });
    const onPlayErr = err => {
      if (!err || err.name !== "NotAllowedError" || tk !== S.playTk) return;
      blocked = true;
      if (v.readyState >= 2) finish(true);
      clearTimeout(timer);
      S.resumeFn = () => { setPov("trying", "جاري التشغيل…"); if (!done) arm(15000); (S.eng.mts ? S.eng.mts.play() : v.play()).catch(() => {}); };
      setPov("tap");
    };
    const A = ACCEL[S.settings.accel] || ACCEL.balanced;
    arm(eng === "mts" || eng === "hjs" ? 16000 : 12000);
    if (eng === "mts") {
      let m;
      try { m = await loadLib("mpegts"); } catch (e) { return finish(false, e.message); }
      if (done || tk !== S.playTk) return;
      if (!m.getFeatureList().mseLivePlayback) return finish(false, "هذا الجهاز لا يدعم تشغيل TS داخلياً (يحتاج iOS 17.1+)");
      try {
        v.disableRemotePlayback = true;
        const p = m.createPlayer({ type: "mpegts", isLive: c.kind === "itv", url: r.url, cors: true, withCredentials: false },
          Object.assign({ enableWorker: false, lazyLoad: false, autoCleanupSourceBuffer: true }, A.mts));
        S.eng.mts = p;
        p.on(m.Events.ERROR, (type, detail, info) => {
          const msg = "mpegts: " + type + " / " + detail + (info && info.msg ? " — " + String(info.msg).slice(0, 60) : "");
          if (done) onLateError(msg); else finish(false, msg, { cors: type === "NetworkError" && detail === "Exception" });
        });
        p.attachMediaElement(v);
        p.load();
        const pp = p.play();
        if (pp && pp.catch) pp.catch(onPlayErr);
      } catch (e) { finish(false, "mpegts: " + e.message); }
    } else if (eng === "hjs") {
      let H;
      try { H = await loadLib("hls"); } catch (e) { return finish(false, e.message); }
      if (done || tk !== S.playTk) return;
      if (!H.isSupported()) return finish(false, "هذا الجهاز لا يدعم السهرة HLS (يحتاج iOS 17.1+)");
      try {
        v.disableRemotePlayback = true;
        const h = new H(Object.assign({ enableWorker: false }, A.hls));
        S.eng.hjs = h;
        h.on(H.Events.ERROR, (e, d) => {
          if (!d || !d.fatal) return;
          const msg = "hls.js: " + d.type + " / " + d.details + (d.response && d.response.code ? " (HTTP " + d.response.code + ")" : "");
          if (done) onLateError(msg); else finish(false, msg);
        });
        h.loadSource(r.url);
        h.attachMedia(v);
        const pp = v.play();
        if (pp && pp.catch) pp.catch(onPlayErr);
      } catch (e) { finish(false, "hls.js: " + e.message); }
    } else {
      v.src = r.url;
      const pp = v.play();
      if (pp && pp.catch) pp.catch(onPlayErr);
    }
  });
}
function onLateError(msg) {
  const c = S.cur;
  if (!c || S.trying || S.pov === "error") return;
  clearTimeout(S.stall);
  if (S.settings.autoRe !== false && (c.rc || 0) < 3 && c.engine) {
    c.rc = (c.rc || 0) + 1;
    toast("⚡ إعادة الاتصال تلقائياً (" + c.rc + "/3)…");
    startPlay("internal", { only: [{ eng: c.engine, pick: c.pick || 0 }], keepRc: true });
  } else setPov("error", "انقطع البث — " + msg);
}
function startStats() {
  clearInterval(S.statT);
  const el = $("#pstat");
  if (!el) return;
  if (S.settings.stats === false) { el.innerHTML = ""; return; }
  const tick = () => {
    const v = $("#vid");
    if (!v || !S.cur || !S.cur.engine) return;
    let sp = 0, buf = 0;
    try { if (S.eng.mts && S.eng.mts.statisticsInfo) sp = S.eng.mts.statisticsInfo.speed || 0; else if (S.eng.hjs) sp = (S.eng.hjs.bandwidthEstimate || 0) / 8192; } catch (e) {}
    try { for (let i = 0; i < v.buffered.length; i++) if (v.buffered.start(i) <= v.currentTime + .5) buf = Math.max(buf, v.buffered.end(i) - v.currentTime); } catch (e) {}
    const spd = sp ? (sp >= 1024 ? (sp / 1024).toFixed(1) + " MB/s" : Math.round(sp) + " KB/s") : "";
    el.innerHTML = \`⚡ <b>\${esc(ENG[S.cur.engine] || "")}</b>\${spd ? " · " + spd : ""}\${buf > 0 ? " · " + buf.toFixed(1) + "ث" : ""}\`;
  };
  tick();
  S.statT = setInterval(tick, 1000);
}
function probeLines(c) {
  if (!c.probe) return [];
  return ["ts", "hls"].filter(k => c.probe[k]).map(k => {
    const x = c.probe[k];
    return { k: "فحص " + (k === "ts" ? "TS" : "HLS"), t: [x.status ? "HTTP " + x.status : (x.err || "لا رد"), x.type, "CORS: " + (x.cors || "لا"), x.redirect ? "تحويل ← " + maskUrl(x.redirect) : "", k === "hls" && x.body ? "«" + x.body.slice(0, 32) + "»" : ""].filter(Boolean).join(" · ") };
  });
}
function renderDiag(c, failed) {
  const box = $("#diag");
  if (!box) return;
  if (!failed) { box.innerHTML = ""; return; }
  const rows = (c.diag || []).map(d => \`<div class="drow"><i class="\${d.ok ? "ok" : "no"}">\${d.ok ? "✓" : "✗"}</i><span>\${esc(ENG[d.eng])}</span><small>\${d.src ? esc(SRC[d.src] || d.src) + " — " : ""}\${esc(d.err || "")}</small></div>\`).join("");
  const pl = probeLines(c);
  const pr = pl.length ? pl.map(x => \`<div class="drow"><i class="ok">ⓘ</i><span>\${esc(x.k)}</span><small dir="ltr">\${esc(x.t)}</small></div>\`).join("") : (c.probing ? \`<div class="drow"><i>…</i><span>فحص الخادم</span><small>جارٍ الفحص…</small></div>\` : "");
  box.innerHTML = \`<div class="diag"><b>\${ic("alert")} تقرير التشغيل</b>\${rows}\${pr}
    <div class="dbtns"><button data-act="report">\${ic("copy")} نسخ التقرير</button><button data-act="getvlc">تحميل VLC مجاناً</button></div></div>\`;
}
async function runProbe(c, tk) {
  const d = c.diag || [];
  const ts = (d.find(x => x.eng === "mts" || x.eng === "raw") || {}).url || c.raw;
  const hl = (d.find(x => (x.eng === "hls" || x.eng === "hjs") && /m3u8/i.test(x.url || "")) || {}).url || "";
  if (!ts && !hl) return;
  c.probing = true;
  renderDiag(c, true);
  try { c.probe = await Bridge.call("probe", { ts, hls: hl }); } catch (e) {}
  c.probing = false;
  if (tk === S.playTk && S.cur === c) renderDiag(c, true);
}
function reportText(c) {
  return [APPN + " v" + S.version + " — تقرير تشغيل", "القناة: " + (c.title || ""), "النوع: " + c.kind, "الصفحة: " + location.origin, "الرابط: " + maskUrl(c.raw || "")]
    .concat((c.diag || []).map(d => (d.ok ? "✓ " : "✗ ") + ENG[d.eng] + " / " + (SRC[d.src] || d.src || "?") + ": " + (d.err || "OK") + (d.url ? " [" + maskUrl(d.url) + "]" : "")))
    .concat(probeLines(c).map(x => "ⓘ " + x.k + ": " + x.t)).join("\\n");
}
function restoreState(c, first) {
  const t = c.kind === "itv" ? "itv" : (c.item.isSeries ? "series" : "vod");
  return { kind: c.kind, tab: S.tab, item: slim(t, c.item), fromLive: c.list === S.live.list, genre: S.live.genre, q: S.live.q,
    cmd: c.kind === "vod" ? c.cmd : "", series: c.series || "", epLabel: c.epLabel || "", first, force: S.forceEng || null };
}
async function doRestore(R) {
  if (R && R.tab === "yt" && R.yt) {
    S.yt = Object.assign({ tk: 0 }, R.yt, { loaded: true });
    switchTab("yt");
    ytRenderChips(); ytRender();
    setTimeout(() => { $("#v-yt").scrollTop = R.yt.scroll || 0; }, 60);
    return;
  }
  if (R && R.recovered) toast("تمت استعادة التطبيق — فعّلنا الوضع الخفيف لتوفير الذاكرة", "ok");
  if (R && R.died) {
    // أغلق النظام الصفحة لتوفير الذاكرة وأعاد فتحها: نكمل ما كان يعمل من آخر موضع محفوظ
    const r = R.resume;
    if (!r || !r.item) { toast("أغلق النظام الصفحة لتوفير الذاكرة — أُعيد فتحها", "ok"); return; }
    toast("أغلق النظام الصفحة لتوفير الذاكرة — نكمل «" + (r.item.name || "") + "»…", "ok");
    setTimeout(() => {
      try {
        if (r.t === "itv") openChannel([r.item], 0);
        else { openVod(r.item); if (!r.item.isSeries) startPlay(); }
      } catch (e) {}
    }, 700);
    return;
  }
  if (R && R.inApp && R.item) {
    S.restoring = !R.moveFailed;
    if (R.moveFailed) toast("تعذّر التشغيل داخل الصفحة مع هذا الخادم — نستخدم صفحة المشغل", "bad");
    S.forceEng = R.force || null;
    const sp0 = R.snap && R.snap.top ? R.snap.top : 0;
    const settle = () => { if (sp0) $("#spanel").scrollTop = sp0; setTimeout(() => $("#sheet").classList.remove("inst"), 700); };
    if (R.bm) { S.backMatch = R.bm; S.navBack = () => openMatch(R.bm); }
    const go = () => { const c = S.cur; settle(); S.restoring = false; if (c && R.st) { c.resolveTried = !!R.st.rt; c.noTrials = R.st.nt || {}; c.moves = R.st.mv || 0; c.movesAt = Date.now(); c.rc = R.st.rc || 0; } if (c && c.cmd) { if (R.noAud) c.noAud = R.noAud; if (R.vr) { c.vr = R.vr; c.vrAt = Date.now(); c.vrT = R.startAt || 0; } playInApp(c, R.force || null, { startAt: R.startAt, noAud: R.noAud, pre: R.pre }); } };
    if (R.kind === "itv" && R.im) {
      switchTab("matches");
      S.noAuto = true; openMatch(R.im); mPlayCh(R.item, true); S.noAuto = false;
      go();
    } else if (R.kind === "itv") {
      switchTab(R.tab === "favs" ? "favs" : R.tab === "matches" ? "matches" : "live");
      if (R.fromLive) for (let k = 0; k < 60 && !S.live.loaded && S.live.mode !== "quick"; k++) await new Promise(z => setTimeout(z, 100));
      const L = S.live;
      let list = [R.item], i = 0;
      if (R.fromLive && L.loaded) {
        if (R.genre && L.genre !== R.genre && L.genres.some(g => g.id === R.genre)) { L.genre = R.genre; renderGenres(); }
        L.q = R.q || ""; $("#q-live").value = L.q; $('[data-clr="q-live"]').classList.toggle("on", !!L.q);
        liveCompute(); renderLive(true);
        const j = L.list.findIndex(x => x.id === R.item.id);
        if (j >= 0) { list = L.list; i = j; }
      }
      S.noAuto = true; openChannel(list, i); S.noAuto = false;
      go();
    } else {
      switchTab(R.tab === "series" ? "series" : R.tab === "favs" ? "favs" : "vod");
      S.wantSi = R.si; S.wantEp = R.ep;
      openVod(R.item);
      // الحلقة كانت تعمل: نُبقي مربع المشغل ظاهراً (لا يختفي ثم يظهر)
      if (R.cmd) { const pl = $("#pl"); if (pl) pl.classList.remove("hide"); setPov("trying", "جاري تجهيز الفيديو…"); }
      if (sp0) $("#spanel").scrollTop = sp0;
      const c = S.cur;
      if (R.cmd) { c.cmd = R.cmd; c.series = R.series; c.epLabel = R.epLabel; c.epIdx = R.ep; const ce = $("#curEp"); if (ce && R.epLabel) ce.textContent = "▶ " + R.epLabel; }
      if (c.item.isSeries && c.cmd) { for (let k = 0; k < 80 && !(c.eps && c.eps.length); k++) await new Promise(z => setTimeout(z, 100)); }
      go();
    }
    return;
  }
  if (R && R.vodBack && R.item) {
    switchTab(R.tab === "series" ? "series" : R.tab === "favs" ? "favs" : "vod");
    S.wantSi = R.si; S.wantEp = R.ep;
    S.noAuto = true;
    openVod(R.item);
    S.noAuto = false;
    if (R.playerFailed) { const pl = $("#pl"); if (pl) pl.classList.remove("hide"); setPov("error", R.playerFailed); }
    return;
  }
  if (R && R.listOnly && !R.playerFailed) {
    if (R.kind === "itv") {
      switchTab(R.tab === "favs" ? "favs" : "live");
      if (R.fromLive) {
        for (let k = 0; k < 60 && !S.live.loaded && S.live.mode !== "quick"; k++) await new Promise(z => setTimeout(z, 100));
        const L = S.live;
        if (R.genre && L.genre !== R.genre && L.genres.some(g => g.id === R.genre)) { L.genre = R.genre; renderGenres(); if (L.mode === "paged") await selectGenre(R.genre); }
        L.q = R.q || ""; $("#q-live").value = L.q; $('[data-clr="q-live"]').classList.toggle("on", !!L.q);
        liveCompute(); renderLive(true);
        const j = L.list.findIndex(x => x.id === R.lastId);
        if (j >= 0) { while (L.shown <= j && L.shown < L.list.length) appendLive(); const row = $('#liveList .ch[data-i="' + j + '"]'); if (row) row.scrollIntoView({ block: "center" }); }
      }
    } else switchTab(R.tab === "series" ? "series" : R.tab === "favs" ? "favs" : "vod");
    return;
  }
  if (R && R.playerFailed) { S.noAuto = true; R.first = null; }
  if (!R || !R.item) return;
  S.forceEng = R.force || null;
  if (R.originFailed) {
    R.first = null;
    toast("خادم البث لا يسمح بالتشغيل الداخلي لبث TS هنا — نجرب الطرق الأخرى", "bad");
  }
  if (R.kind === "itv" && R.fromLive) for (let k = 0; k < 60 && !S.live.loaded; k++) await new Promise(z => setTimeout(z, 100));
  if (R.kind === "itv") {
    switchTab(R.tab === "favs" ? "favs" : "live");
    const L = S.live;
    let list = [R.item], i = 0;
    if (R.fromLive && L.loaded) {
      if (R.genre && L.genre !== R.genre && L.genres.some(g => g.id === R.genre)) { L.genre = R.genre; renderGenres(); }
      L.q = R.q || ""; $("#q-live").value = L.q; $('[data-clr="q-live"]').classList.toggle("on", !!L.q);
      liveCompute(); renderLive(true);
      const j = L.list.findIndex(x => x.id === R.item.id);
      if (j >= 0) { list = L.list; i = j; }
    }
    S.firstTry = R.first;
    openChannel(list, i);
    if (R.playerFailed) { S.noAuto = false; setPov("error", R.playerFailed); }
    else if (S.settings.player !== "internal") startPlay("internal");
  } else {
    switchTab(R.tab === "series" ? "series" : R.tab === "favs" ? "favs" : "vod");
    openVod(R.item);
    if (R.playerFailed) { S.noAuto = false; setPov("error", R.playerFailed); }
    else if (R.cmd) {
      const c = S.cur;
      c.cmd = R.cmd; c.series = R.series; c.epLabel = R.epLabel;
      const ce = $("#curEp"); if (ce && R.epLabel) ce.textContent = "▶ " + R.epLabel;
      S.firstTry = R.first;
      startPlay("internal");
    }
  }
}
/* ═════════ المشغل داخل الصفحة: يعمل في مربع صفحة التفاصيل نفسها ═════════
   أول تشغيل ينقل التطبيق إلى عنوان خادم البث (مرة واحدة) ثم يشغّل كل شيء داخل الصفحة بلا فتح صفحة أخرى */
// نفس الخادم باسم مختلف: abc.f22.site.me و xyz.f22.site.me (كل الأجزاء نفسها ما عدا الأول، ونفس المنفذ)
// نفس مزوّد البث باسم خادم مختلف (abc.f22.site.me / xyz.f23.site.me): نفس النطاق الأساسي ونفس المنفذ
function regDom(h) { const x = h.split("."), three = x.length >= 3 && x[x.length - 1].length === 2 && /^(co|com|net|org|gov|edu|ac)$/.test(x[x.length - 2]); return x.slice(three ? -3 : -2).join("."); }
function sibHost(a, b) {
  try {
    const A = new URL(a), B = new URL(b);
    if (A.protocol !== B.protocol || A.port !== B.port || A.hostname === B.hostname) return false;
    if (/^[\\d.]+$/.test(A.hostname) || /^[\\d.]+$/.test(B.hostname)) return false;
    if (A.hostname.split(".").length < 3) return false;
    return regDom(A.hostname) === regDom(B.hostname);
  } catch (e) { return false; }
}
// نتذكر لكل «عائلة خوادم» هل التشغيل على الخادم الحالي يعمل
const famOf = u => { try { const h = new URL(u).hostname.split("."); return h.slice(1).join("."); } catch (e) { return ""; } };
const swapKey = (o, here) => famOf(o) + ">" + famOf(here);
const normOrigin = u => originOf(u).replace(/^(http:\\/\\/[^\\/]+):80$/i, "$1").replace(/^(https:\\/\\/[^\\/]+):443$/i, "$1");
function epKey(c) {
  if (c.kind === "itv") return c.item.id;
  const se = c.seasons && c.seasons[c.si];
  return c.item.isSeries ? c.item.id + "|" + (se ? se.id : "") + "|" + (c.epNum != null ? c.epNum : "") : c.item.id;
}
function epKill() { if (S.ep) { try { S.ep.destroy(); } catch (e) {} S.ep = null; } const w = $("#epw"); if (w) w.remove(); const sw = $("#epSets"); if (sw) sw.remove(); }
function epMount(c) {
  if (S.ep && S.ep.__c === c && $("#epw")) return S.ep;
  epKill();
  const pl = $("#pl");
  pl.classList.remove("hide");
  const w = document.createElement("div");
  w.id = "epw"; w.style.cssText = "position:absolute;inset:0;z-index:6";
  pl.appendChild(w);
  const sw = document.createElement("div"); sw.id = "epSets"; pl.insertAdjacentElement("afterend", sw);
  const inst = {};
  inst.ep = S.ep = window.AlsahraBox.create(w, { send: m => { if (S.ep === inst.ep) epMsg(c, m); }, info: () => {}, setsHost: sw });
  S.ep.__c = c;
  return S.ep;
}
function inAppRestore(c, force, extra) {
  const t = c.kind === "itv" ? "itv" : (c.item.isSeries ? "series" : "vod");
  return { inApp: true, tab: S.tab, kind: c.kind, item: slim(t, c.item), force: force || null, startAt: (extra && extra.startAt) || null, pre: (extra && extra.pre) || null, noAud: (extra && extra.noAud) || c.noAud || "", vr: c.vr || 0,
    cmd: c.cmd, series: c.series, epLabel: c.epLabel || "", si: c.si || 0, ep: c.epIdx,
    genre: S.live.genre, q: S.live.q, fromLive: c.list === S.live.list, bm: S.backMatch || null, im: c.inMatch && S.curMatch ? S.curMatch : null,
    // عدادات المحاولات تنتقل مع التطبيق (كانت تضيع فيتكرر النقل بلا نهاية مع القنوات المتوقفة → إغلاق مفاجئ)
    st: { rt: c.resolveTried ? 1 : 0, nt: c.noTrials || {}, mv: (Date.now() - (c.movesAt || 0) < 90000 ? c.moves || 0 : 0) + 1, rc: c.rc || 0 } };
}
// صورة من الصفحة الحالية تُعرض فوراً بعد نقل التطبيق لخادم البث (بدون وميض)
function snapSheet() {
  try {
    const p = $("#spanel");
    if (!p || !$("#sheet").classList.contains("on")) return null;
    const c = p.cloneNode(true);
    const pl = c.querySelector("#pl");
    if (pl) { pl.classList.remove("hide"); pl.innerHTML = '<div class="pov trying"><div class="spin"></div><span>' + (S.cur && S.cur.kind === "itv" ? "جاري تشغيل البث…" : "جاري تجهيز الفيديو…") + '</span></div>'; }
    c.querySelectorAll("#epSets,video,script,#diag").forEach(x => x.remove());
    c.querySelectorAll("img[data-src]").forEach(i => { i.setAttribute("src", i.dataset.src); i.removeAttribute("data-src"); i.removeAttribute("data-w"); });
    const h = c.innerHTML;
    return h.length < 400000 ? { h, top: p.scrollTop } : null;
  } catch (e) { return null; }
}
async function playInApp(c, force, extra) {
  extra = extra || {};
  const tk = ++S.playTk;
  $("#pl").classList.remove("hide");
  const lm = c.kind === "itv" ? "جاري تشغيل البث…" : "جاري تجهيز الفيديو…";
  if (!S.ep) setPov("trying", lm); else S.ep.busy(lm);
  let R;
  // بعد نقل التطبيق نستخدم الرابط الذي جهّزناه قبل النقل (لا نطلب رابطاً جديداً يحوّل لخادم آخر فننتقل مرة ثانية)
  const pre = extra.pre;
  if (pre && pre.url && Date.now() - (pre.at || 0) < 90000 && normOrigin(pre.url) === normOrigin(location.href)) R = pre;
  else {
    try { R = await Bridge.call("streamInfo", Object.assign(linkOpts(c), { key: epKey(c), force: force || "", startAt: extra.startAt || null, noResume: c.fromStart && !extra.startAt ? 1 : 0, own: extra.own, resolve: !!extra.resolve, here: S.app ? "" : location.origin })); }
    catch (e) { if (tk === S.playTk && S.cur === c) { if (S.ep) S.ep.err(e.message); else setPov("error", e.message); } return; }
  }
  if (tk !== S.playTk || S.cur !== c) return;
  const here = normOrigin(location.href);
  // داخل تطبيق الآيفون: التطبيق يجلب البث من أي خادم بنفسه → التشغيل هنا مباشرة (بدون نقل = بدون لمعة)
  let o = S.app ? here : normOrigin(R.url);
  // مشغل iOS (MP4/HLS) يعمل مع أي خادم → لا حاجة لنقل التطبيق (لا وميض)
  const nat = force === "native" || force === "hls" || (!force && /^(mp4|hls|avi)$/.test(R.fmt));
  let trial = "";
  // خوادم تعطي كل مرة اسماً عشوائياً لنفس الخادم (abc.f22.site.me / xyz.f22.site.me): نجرّب نفس الرابط على الخادم الحالي بدون نقل
  if (o !== here && !nat && !extra.noSwap && !(c.noTrials || {}).swap && !(S.swapOK || {}).__off && !(c.kind === "itv" && S.hls2 !== 0 && !(c.noTrials || {}).hls) && sibHost(o, here) && (S.swapOK || {})[swapKey(o, here)] !== 0) {
    c.swapK = swapKey(o, here);
    const sw = x => { try { const u = new URL(x); u.protocol = location.protocol; u.host = location.host; return u.href; } catch (e) { return x; } };
    R = Object.assign({}, R, { url: sw(R.url), hls: R.hls ? sw(R.hls) : R.hls }); o = here; trial = "swap";
  }
  // البث المباشر بدون نقل التطبيق (= بدون لمعة): مشغل iOS لا يحتاج أن يكون التطبيق على خادم البث
  //  1) رابط HLS جديد من البوابة (m3u8)   2) رابط البث نفسه بمشغل iOS
  // كل تجربة تُجرّب مرة واحدة لكل اشتراك ونتذكر نتيجتها؛ إن فشلت كلها نرجع للطريقة العادية
  const no = c.noTrials || (c.noTrials = {});
  if (!trial && !force && !nat && c.kind === "itv" && o !== here) {
    if (!no.hls && S.hls2 !== 0) {
      let hr = null;
      try { hr = await Bridge.call("hlsLink", linkOpts(c)); } catch (e) {}
      if (tk !== S.playTk || S.cur !== c) return;
      if (hr && hr.url) { R = Object.assign({}, R, { url: hr.url, hls: hr.url, fmt: "hls" }); trial = "hls"; }
      else if (hr && hr.bad) { no.hls = 1; if (S.hls2 !== 1) { S.hls2 = 0; Bridge.call("portalFlag", { k: "hls2", v: 0 }).catch(() => {}); } }
    }
    if (!trial && !no.nts && S.nts !== 0) trial = "nts";
  }
  c.trial = trial;
  if (o !== here && !nat && !trial) {
    if (S.noMove[o]) { epKill(); openFS(c, 0, false, force); return; }
    if ((c.moves || 0) >= 3 && Date.now() - (c.movesAt || 0) < 90000) { const e = "تعذّر تشغيل هذه القناة الآن — الخادم لا يستجيب، جرّب لاحقاً أو قناة أخرى"; if (S.ep) S.ep.err(e); else setPov("error", e); return; }
    // ننقل التطبيق إلى خادم البث ثم يكمل التشغيل في نفس المربع تلقائياً
    if (S.ep) S.ep.busy(lm); else setPov("trying", lm);
    const rs = inAppRestore(c, force, Object.assign({}, extra, { pre: { url: R.url, origin: R.origin, fmt: R.fmt, hls: R.hls, opts: R.opts, mtsCached: R.mtsCached, at: Date.now() } }));
    rs.snap = snapSheet(); rs.bg = getComputedStyle(document.body).backgroundColor || "";
    Bridge.call("moveApp", { origin: o, restore: rs }).catch(() => { epKill(); openFS(c, 0, false, force); });
    return;
  }
  if (!nat && trial !== "hls" && (R.fmt === "ts" || R.fmt === "auto" || force === "mts") && !window.mpegts && (R.mtsCached || force === "mts")) { try { await loadLib("mpegts"); } catch (e) {} }
  if (tk !== S.playTk || S.cur !== c) return;
  const ep = epMount(c);
  const vod = c.kind !== "itv";
  const eps = vod && c.item.isSeries && c.eps && c.eps.length > 1 ? { prev: (c.epIdx || 0) > 0, next: (c.epIdx || 0) < c.eps.length - 1 } : null;
  const acc = getComputedStyle(document.documentElement).getPropertyValue("--acc2").trim();
  setPov("none");
  ep.play(R.url, c.dtitle || c.title, c.epLabel || "", R.hls, acc, Object.assign({}, R.opts, { eps, force: trial === "hls" || trial === "nts" ? "native" : (force || ""), trial, noAud: extra.noAud || c.noAud || "" }));
}
function epStep(c, d) {
  if (c.kind === "itv") { stepChannel(d); return; }
  const k = (c.epIdx || 0) + d;
  if (c.eps && c.eps[k]) playEpisode(k);
}
function epMsg(c, m) {
  const ep = S.ep;
  if (!ep || S.cur !== c) return;
  if (m.c === "state") {
    if (m.s === "playing") {
      c.rc = 0; c.resolveTried = false; c.moves = 0; npSet(c);
      if ((c.trial === "hls" || c.trial === "nts") && S[c.trial === "hls" ? "hls2" : "nts"] !== 1) { const k = c.trial === "hls" ? "hls2" : "nts"; S[k] = 1; Bridge.call("portalFlag", { k, v: 1 }).catch(() => {}); }
      if (c.trial === "swap" && c.swapK && (S.swapOK || {})[c.swapK] !== 1) { S.swapOK = Object.assign({}, S.swapOK, { [c.swapK]: 1 }); Bridge.call("portalFlag", { k: "swap", v: S.swapOK }).catch(() => {}); }
      if (!c.trial || c.trial === "swap") Bridge.call("playState", { kind: c.kind, eng: m.eng }).catch(() => {});
    }
    else if (m.s === "trialfail") {
      // التجربة بدون نقل لم تنجح → نتذكر ذلك ونشغّل بالطريقة العادية (برابط جديد)
      const t = c.trial; c.trial = "";
      (c.noTrials || (c.noTrials = {}))[t] = 1;
      if ((t === "hls" || t === "nts") && S[t === "hls" ? "hls2" : "nts"] !== 1) { const k = t === "hls" ? "hls2" : "nts"; S[k] = 0; Bridge.call("portalFlag", { k, v: 0 }).catch(() => {}); }
      if (t === "swap" && c.swapK && (S.swapOK || {})[c.swapK] !== 1) {
        const ok = Object.keys(S.swapOK || {}).some(k => S.swapOK[k] === 1);
        const same = c.swapK.split(">")[0] === c.swapK.split(">")[1];
        S.swapOK = Object.assign({}, S.swapOK, { [c.swapK]: 0 }, !ok && same ? { __off: 1 } : {});
        Bridge.call("portalFlag", { k: "swap", v: S.swapOK }).catch(() => {});
      }
      Bridge.call("log", { msg: "trial " + t + " failed: " + String(m.m || "").slice(0, 80) }).catch(() => {});
      playInApp(c, S.forceEng, { noSwap: !!c.noTrials.swap, resolve: true });
    }
    else if (m.s === "netfail") {
      if (c.resolveTried) { ep.err(m.m); return; }
      c.resolveTried = true; playInApp(c, S.forceEng, { resolve: true });
    }
    else if (m.s === "error" && c.inMatch) mFailover(c);
    return;
  }
  if (m.c === "pos") { c.fromStart = false; posLocal(epKey(c), m.t, m.d, !!m.end); progRefresh(c); Bridge.call("savePos", { kind: c.kind, key: epKey(c), t: m.t, d: m.d, end: !!m.end }).catch(() => {}); return; }
  if (m.c === "tr") { Bridge.call("trSubs", { texts: m.texts }).then(r => { if (S.ep === ep) ep.trRes(m.id, r); }).catch(() => { if (S.ep === ep) ep.trRes(m.id, null); }); return; }
  if (m.c === "subpref") { S.settings.subOn = !!m.on; Bridge.call("setSettings", { settings: { subOn: !!m.on } }).catch(() => {}); return; }
  if (m.c === "set") { S.settings[m.key] = m.val; Bridge.call("setSettings", { settings: { [m.key]: m.val } }).catch(() => {}); return; }
  if (m.c === "report") { Bridge.call("playReport", { kind: c.kind, name: c.title + (c.epLabel ? " — " + c.epLabel : ""), diag: m.diag, info: m.info }).then(() => ep.toast("تم نسخ التقرير ✓ أرسله لنا")).catch(() => {}); return; }
  if (m.c === "vlc") { startPlay("vlc"); return; }
  if (m.c === "retry") {
    const f = m.force !== undefined ? (m.force && m.force !== "auto" ? m.force : null) : S.forceEng;
    S.forceEng = f; c.resolveTried = false;
    $$(".engs .chip").forEach(b => b.classList.toggle("on", b.dataset.eng === (f || "auto")));
    playInApp(c, f, { startAt: m.t, own: m.own });
    return;
  }
  // فيلم/حلقة توقفت بخطأ بعد بدء المشاهدة → نكمل تلقائياً من نفس الموضع برابط جديد
  if (m.c === "recover") {
    const now = Date.now(), t = Math.max(0, +m.t || 0);
    if (!c.vrAt || now - c.vrAt > 120000 || Math.abs(t - (c.vrT || 0)) > 90) c.vr = 0;
    c.vr = (c.vr || 0) + 1; c.vrAt = now; c.vrT = t;
    if (c.vr >= 2 && m.dec && /^(ac-3|ec-3)$/.test(m.ac || "")) c.noAud = m.ac;
    if (c.vr > 3) { ep.err(m.m || "تعذّر إكمال التشغيل"); return; }
    playInApp(c, S.forceEng, { startAt: t + [0, 0, 4, 12][c.vr], resolve: true, noAud: c.noAud || "" });
    return;
  }
  if (m.c === "reconnect") {
    if (S.settings.autoRe === false || (c.rc = (c.rc || 0) + 1) > 3) { ep.err("انقطع البث"); return; }
    setTimeout(() => { if (S.cur === c) playInApp(c, S.forceEng); }, 800);
    return;
  }
  if (m.c === "next" || m.c === "prev") epStep(c, m.c === "next" ? 1 : -1);
}

function openFS(c, pick, afterFail, force) {
  setPov("trying", "جاري فتح مشغل السهرة…");
  const t = c.kind === "itv" ? "itv" : (c.item.isSeries ? "series" : "vod");
  let items, index = 0;
  if (c.kind === "itv") {
    const list = c.list || [c.item], i0 = Math.max(0, c.idx - 40);
    items = list.slice(i0, c.idx + 41).map(x => ({ id: x.id, name: x.name, num: x.num, cmd: x.cmd, tmp: x.tmp, lb: x.lb, logo: x.logo || "" }));
    index = c.idx - i0;
  } else {
    const eps = c.item.isSeries && c.eps && c.eps.length ? c.eps : null, se = c.seasons && c.seasons[c.si];
    const sname = se && se.name !== "الحلقات" ? se.name + " · " : "";
    if (eps) {
      items = eps.map(e => ({ id: c.item.id + "|" + (se ? se.id : "") + "|" + e.num, name: c.title, sub: sname + e.name, cmd: e.cmd, series: e.series }));
      index = Math.max(0, eps.findIndex(e => e.cmd === c.cmd && String(e.series || "") === String(c.series || "")));
    } else items = [{ id: c.item.id, name: c.title + (c.epLabel ? " — " + c.epLabel : ""), sub: [c.item.year, c.item.genres].filter(Boolean).join(" · "), cmd: c.cmd, series: c.series }];
  }
  const restore = c.kind === "itv"
    ? { listOnly: true, tab: S.tab, kind: c.kind, genre: S.live.genre, q: S.live.q, fromLive: c.list === S.live.list, item: slim(t, c.item), lastId: c.item.id }
    : { vodBack: true, tab: S.tab, kind: c.kind, item: slim(t, c.item), si: c.si || 0, ep: index };
  const acc = getComputedStyle(document.documentElement).getPropertyValue("--acc2").trim();
  const meta = c.kind === "itv" ? null : { desc: c.item.desc || "", season: c.seasons && c.seasons[c.si] && c.seasons[c.si].name !== "الحلقات" ? c.seasons[c.si].name : "" };
  Bridge.call("playerOpen", { items, index, meta, force: force || null, kind: c.kind, pick: pick || 0, cfg: Object.assign({ enableWorker: false, lazyLoad: false, autoCleanupSourceBuffer: true }, (ACCEL[S.settings.accel] || ACCEL.balanced).mts), accent: acc, restore, afterFail: !!afterFail })
    .catch(e => setPov("error", e.message));
}
async function startPlay(ext, opt) {
  opt = opt || {};
  const c = S.cur;
  if (!c) return;
  if (!c.cmd) { toast("اختر حلقة أولاً"); return; }
  const pl = ext || S.settings.player;
  if (!opt.keepRc) { addRecent(c); c.rc = 0; }
  if (pl !== "internal") {
    toast("جاري الفتح في " + PN[pl] + "…\\nإذا لم يُفتح، ثبّت التطبيق من App Store");
    try { await Bridge.call("play", linkOpts(c, { ext: pl })); }
    catch (e) { toast(e.message, "bad"); }
    return;
  }
  if (!$("#vid")) return;
  $("#pl").classList.remove("hide");
  {
    const pm = c.kind === "itv" ? S.settings.pmode : S.settings.vmode;
    const force = validEng(c.kind, S.forceEng) || validEng(c.kind, pm);
    killEng();
    if (S.settings.inApp === false || !window.AlsahraBox) openFS(c, 0, false, force);
    else playInApp(c, force);
    return;
  }
  const tk = ++S.playTk;
  clearTimeout(S.wd); clearTimeout(S.stall); clearInterval(S.statT);
  const ps = $("#pstat"); if (ps) ps.innerHTML = "";
  killEng();
  S.resumeFn = null;
  S.trying = true;
  c.diag = []; c.probe = null;
  renderDiag(c, false);
  const plan = opt.only || playPlan(c);
  let nLinks = 2, step = 0;
  for (let i = 0; i < plan.length; i++) {
    const { eng, pick } = plan[i];
    if (pick >= nLinks) continue;
    if (eng === "fsp") { S.trying = false; openFS(c, pick, c.diag.length > 0); return; }
    step++;
    setPov("trying", opt.keepRc ? "جاري إعادة الاتصال…" : plan.length > 1 ? \`جاري التجربة \${step}: \${ENG[eng]}\${pick ? " (رابط بديل)" : ""}…\` : "جاري تجهيز البث…");
    const r = await tryEngine(eng, pick, c, tk);
    if (tk !== S.playTk) return;
    if (r.n) nLinks = r.n;
    c.diag.push({ eng, pick, ok: r.ok, err: r.err, url: r.url, src: r.src, fatal: r.fatal });
    if (r.ok) {
      S.trying = false;
      c.engine = eng; c.pick = pick;
      const key = eng + ":" + pick;
      if ((S.pm || {})[c.kind] !== key) { S.pm = Object.assign({}, S.pm, { [c.kind]: key }); Bridge.call("saveUser", { pm: { [c.kind]: key } }).catch(() => {}); }
      startStats();
      const v = $("#vid");
      if (v && !v.paused && v.readyState >= 2) setPov("none");
      else if (S.pov !== "tap") S.wd = setTimeout(() => {
        if (tk !== S.playTk || S.pov !== "trying") return;
        const vv = $("#vid");
        if (vv && !vv.paused) { setPov("none"); return; }
        S.resumeFn = () => { setPov("trying", "جاري التشغيل…"); (S.eng.mts ? S.eng.mts.play() : vv.play()).catch(() => {}); };
        setPov("tap");
      }, 3000);
      return;
    }
    // TS حجبه المتصفح (CORS) → نعيد فتح التطبيق من عنوان خادم البث نفسه ثم نكمل تلقائياً
    const so = originOf(r.url);
    if (r.cors && so && so !== String(location.origin).toLowerCase()) c.corsOrigin = so;
    if (false && eng === "mts" && r.cors && !opt.only && S.settings.sameOrigin === true && so && so !== String(location.origin).toLowerCase() && S.noOriginFor !== so) {
      setPov("trying", "تهيئة المشغل لخادم البث…");
      try { await Bridge.call("useOrigin", { origin: so, restore: restoreState(c, { eng, pick }) }); return; }
      catch (e) { S.noOriginFor = so; }
    }
    if (r.fatal) break;
    killEng();
    if (!r.skip) await new Promise(z => setTimeout(z, 700));
  }
  S.trying = false;
  const last = c.diag[c.diag.length - 1];
  setPov("error", last && last.fatal ? last.err : "تعذّر تشغيل البث داخل التطبيق");
  renderDiag(c, true);
  runProbe(c, tk);
}
async function copyLink() {
  const c = S.cur;
  if (!c || !c.cmd) { toast("اختر حلقة أولاً"); return; }
  try { await Bridge.call("copyLink", linkOpts(c, c.engine ? { pick: c.pick || 0 } : {})); toast("تم نسخ رابط البث ✓", "ok"); }
  catch (e) { toast(e.message, "bad"); }
}

/* ═════════ أين وصلت المشاهدة ═════════ */
const PK = key => "vod:" + String(key).slice(0, 120);
function progOf(key) { const p = S.pos[PK(key)]; return p && p.d > 60 && p.t > 0 ? { f: Math.min(1, p.t / p.d), t: p.t, d: p.d, ts: p.ts || 0 } : null; }
const seenAt = key => S.done[PK(key)] || 0;
const pbar = f => \`<i class="pbar"><b style="width:\${Math.max(4, Math.min(100, Math.round(f * 100)))}%"></b></i>\`;
function leftTxt(p) { const m = Math.max(1, Math.round((p.d - p.t) / 60)); return "متبقي " + (m >= 60 ? Math.floor(m / 60) + " س" + (m % 60 ? " و" + (m % 60) + " د" : "") : m + " د"); }
// نفس قاعدة التطبيق: قرب النهاية = شوهدت، أقل من 20 ثانية = لا شيء
function posLocal(key, t, d, end) {
  const k = PK(key); t = +t || 0; d = +d || 0;
  if (end || (d && t > d - Math.max(30, d * 0.05))) { delete S.pos[k]; S.done[k] = Date.now(); }
  else if (t < 20) delete S.pos[k];
  else S.pos[k] = { t, d, ts: Date.now() };
}
const epKeyOf = (c, e) => { const se = c && c.seasons && c.seasons[c.si]; return c.item.id + "|" + (se ? se.id : "") + "|" + (e.num != null ? e.num : ""); };
// آخر حلقة شاهدتها من المسلسل: { sid, num, p (لم تكتمل) أو next (اكتملت → التالية) }
function seriesLast(id) {
  const pre = PK(id + "|"); let b = null;
  for (const k in S.pos) if (k.startsWith(pre) && (!b || (S.pos[k].ts || 0) > b.ts)) b = { k, ts: S.pos[k].ts || 0, done: false };
  for (const k in S.done) if (k.startsWith(pre) && (!b || S.done[k] > b.ts)) b = { k, ts: S.done[k], done: true };
  if (!b) return null;
  const rest = b.k.slice(pre.length), j = rest.lastIndexOf("|");
  const sid = rest.slice(0, j), num = rest.slice(j + 1);
  return { sid, num, ts: b.ts, done: b.done, p: b.done ? null : progOf(b.k.slice(4)) };
}
function cardProg(m) {
  if (!m || !m.id) return "";
  if (m.isSeries) { const L = seriesLast(m.id); return L && L.p ? pbar(L.p.f) : ""; }
  const p = progOf(m.id);
  return p ? pbar(p.f) : seenAt(m.id) ? \`<em class="seen">\${ic("check")}</em>\` : "";
}
// بعد كل حفظ للموضع: نحدّث الخط في الصفحة المفتوحة مباشرة
function progRefresh(c) {
  if (!c || c !== S.cur || c.kind === "itv") return;
  if (c.item.isSeries) {
    const row = c.epIdx != null && $(\`#eps .ep[data-ep="\${c.epIdx}"]\`), e = c.eps && c.eps[c.epIdx];
    if (row && e) { const on = row.classList.contains("on"); row.outerHTML = epRow(e, c.epIdx, c); if (on) { const r2 = $(\`#eps .ep[data-ep="\${c.epIdx}"]\`); if (r2) r2.classList.add("on"); } }
    curEpLabel(c);
  } else {
    const b = $('#sheet.on .acts [data-act="play"]'); if (b) b.innerHTML = playLabel(c.item);
  }
}
function playLabel(m) {
  const p = progOf(m.id);
  return p ? \`\${ic("play")} متابعة · \${leftTxt(p)}\${pbar(p.f)}\` : \`\${ic("play")} \${seenAt(m.id) ? "شاهده مرة أخرى" : "تشغيل"}\`;
}
function curEpLabel(c, pre) {
  const ce = $("#curEp"); if (!ce || !c.epLabel) return;
  const e = c.eps && c.eps[c.epIdx], key = e ? epKeyOf(c, e) : null, p = key ? progOf(key) : null;
  ce.innerHTML = \`\${pre ? esc(pre) + " " : "▶ "}\${esc(c.epLabel)}\${p ? " · " + leftTxt(p) + pbar(p.f) : ""}\`;
}

/* ═════════ favorites & recent ═════════ */
const isFav = (t, id) => S.favs[t].some(x => x.id === id);
function slim(t, it) {
  if (t === "itv") return { id: it.id, name: it.name, num: it.num, cmd: it.cmd, logo: it.logo, g: it.g, tmp: it.tmp, lb: it.lb };
  return { id: it.id, type: it.type, name: it.name, oname: it.oname, poster: it.poster, cmd: it.cmd, year: it.year, rating: it.rating, genres: it.genres, desc: it.desc, time: it.time, director: it.director, actors: it.actors, series: it.series, isSeries: it.isSeries };
}
function toggleFav(t, it) {
  const a = S.favs[t];
  const i = a.findIndex(x => x.id === it.id);
  if (i >= 0) { a.splice(i, 1); toast("أُزيلت من المفضلة"); }
  else { a.unshift(slim(t, it)); toast("أُضيفت إلى المفضلة ⭐", "ok"); }
  Bridge.call("saveUser", { favs: S.favs }).catch(() => {});
  return i < 0;
}
function curFavType() { const c = S.cur; return c.kind === "itv" ? "itv" : (c.item.isSeries ? "series" : "vod"); }
function addRecent(c) {
  const t = curFavType();
  const it = slim(t, c.item);
  const key = t + ":" + it.id;
  S.recent = S.recent.filter(r => r.key !== key);
  S.recent.unshift({ key, t, item: it, label: c.epLabel || "", ts: Date.now() });
  S.recent = S.recent.slice(0, 40);
  Bridge.call("saveUser", { recent: S.recent }).catch(() => {});
}
function renderFavs() {
  const t = S.favTab, box = $("#favBox");
  $$("#favSeg button").forEach(b => b.classList.toggle("on", b.dataset.v === t));
  if (t === "itv") {
    const a = S.favs.itv;
    box.innerHTML = a.length ? \`<div class="list">\${a.map((c, i) => chRow(c, i)).join("")}</div>\` : emptyBox("star", "لا توجد قنوات مفضلة", "اضغط ⭐ بجانب أي قناة لإضافتها هنا");
  } else if (t === "vod" || t === "series") {
    const a = S.favs[t];
    box.innerHTML = a.length ? \`<div class="grid">\${a.map((m, i) => pCard(m, i)).join("")}</div>\` : emptyBox("star", t === "vod" ? "لا توجد أفلام مفضلة" : "لا توجد مسلسلات مفضلة", "افتح أي عمل واضغط ⭐ لإضافته");
    trTitles(a);
  } else {
    const a = S.recent;
    box.innerHTML = a.length ? \`<div class="list">\${a.map((r, i) => {
      const it = r.item, img = r.t === "itv" ? it.logo : it.poster;
      const ty = r.t === "itv" ? "قناة" : r.t === "series" ? "مسلسل" : "فيلم";
      const L = r.t === "series" ? seriesLast(it.id) : null, p = r.t === "vod" ? progOf(it.id) : L && L.p;
      const st = p ? " · " + leftTxt(p) : (r.t === "vod" && seenAt(it.id)) || (L && L.done) ? " · شوهدت ✓" : "";
      return \`<div class="ch" data-r="\${i}" style="--i:\${Math.min(i, 14)};position:relative;overflow:hidden"><div class="lg"><span class="ini">\${esc(initials(it.name))}</span>\${img ? \`<img data-src="\${esc(img)}" decoding="async" onerror="this.remove()" style="\${r.t === "itv" ? "" : "object-fit:cover;padding:0"}">\` : ""}</div><div class="nm">\${r.t === "itv" ? \`<b dir="auto">\${esc(it.name)}</b>\` : \`<b dir="auto" data-tn="\${esc(it.name)}">\${esc(showName(it.name))}</b>\`}<small dir="auto">\${ty}\${r.label ? " · " + esc(r.label) : ""}\${st}</small></div>\${ic("prev")}\${p ? pbar(p.f).replace('class="pbar"', 'class="pbar" style="left:14px;right:14px;bottom:5px;height:3px"') : ""}</div>\`;
    }).join("")}</div>\` : emptyBox("clock", "لا توجد مشاهدات بعد", "ما تشاهده يظهر هنا للعودة إليه بسرعة");
    trTitles(a.filter(r => r.t !== "itv").map(r => r.item));
  }
}

/* ═════════ movies & series ═════════ */
function pCard(m, i) {
  const dn = esc(showName(m.name)), on = esc(m.name), qb = qBadge(m.name);
  return \`<div class="pc" data-i="\${i}" style="--i:\${i % 18}"><div class="ps">\${qb}<span class="pt" dir="auto" data-tn="\${on}">\${dn}</span>\${m.poster ? \`<img data-src="\${esc(m.poster)}" decoding="async" onload="this.classList.add('ld')" onerror="this.remove()">\` : ""}\${m.rating ? \`<em class="rt">★ \${esc((+m.rating).toFixed(1))}</em>\` : ""}\${m.isSeries && m.type !== "series" ? \`<em class="sr">مسلسل</em>\` : ""}\${cardProg(m)}</div><div class="t" dir="auto" data-tn="\${on}">\${dn}</div></div>\`;
}
async function vodEnter(type, force) {
  const V = S.vod[type];
  if (V.loaded && !force) return;
  V.loaded = true;
  $("#cats-" + type).innerHTML = skelChips(5);
  $("#grid-" + type).innerHTML = skelPosters(9);
  try {
    const raw = normGenres(await Bridge.call("vodCats", { type, force: !!force }));
    V.raw = raw;
    V.cats = [{ id: "__home", title: "الرئيسية" }].concat(arrange(raw));
    if (!V.cat || !V.cats.some(x => x.id === V.cat)) V.cat = "__home";
    renderCats(type);
    catsAr(raw.map(x => x.title));
    await vodLoad(type, true);
  } catch (e) {
    V.loaded = false;
    $("#cats-" + type).innerHTML = "";
    $("#grid-" + type).innerHTML = \`<div style="grid-column:1/-1">\${emptyBox(type === "vod" ? "film" : "layers", type === "vod" ? "تعذّر تحميل الأفلام" : "تعذّر تحميل المسلسلات", e.message, type)}</div>\`;
  }
}
function renderCats(type) {
  const V = S.vod[type];
  $("#cats-" + type).innerHTML = V.cats.map((c, i) => \`<button class="chip \${c.id === V.cat && !V.q ? "on" : ""}" data-c="\${esc(c.id)}">\${c.id === "__home" ? ic("brand") : ""}<span dir="auto" data-co="\${esc(c.title)}">\${esc(catLabel(c.title))}</span></button>\` + (i === 0 ? cddChip(type) : "")).join("");
  const on = $("#cats-" + type + " .chip.on");
  if (on) on.scrollIntoView({ inline: "center", block: "nearest" });
}
function paintSearch(type, r, busy) {
  const V = S.vod[type], grid = $("#grid-" + type);
  V.page = 1; V.pages = 1; V.items = r.items || [];
  const sp = busy ? \`<span class="sbusy"> · <i class="spin sm"></i> نكمل البحث…</span>\` : "";
  if (!V.items.length) { grid.innerHTML = busy ? \`<div class="sresh" style="grid-column:1/-1">\${ic("search")}<span>جاري البحث…\${sp}</span></div>\` : \`<div style="grid-column:1/-1">\${emptyBox("search", "لا توجد نتائج", "جرّب جزءاً من الاسم فقط، أو اكتبه بالإنجليزي")}</div>\`; return; }
  let h = \`<div class="sresh" style="grid-column:1/-1">\${ic("search")}<span><b>\${V.items.length}</b> \${type === "vod" ? "فيلم" : "مسلسل"}\${r.ar ? \` · <b>\${r.ar}</b> عربي أولاً\` : ""}\${r.tq ? \` · بحثنا أيضاً عن «<span dir="auto">\${esc(r.tq)}</span>»\` : ""}\${sp}</span></div>\`;
  for (let i = 0; i < V.items.length; i++) h += pCard(V.items[i], i);
  grid.innerHTML = h;
  trTitles(V.items);
}
async function vodLoad(type, reset) {
  const V = S.vod[type], grid = $("#grid-" + type);
  if (reset && V.cat === "__home" && !V.q) return homeLoad(type);
  if (reset) { V.tk++; V.items = []; V.page = 0; V.pages = 1; V.loading = false; grid.innerHTML = skelPosters(9); $("#v-" + type).scrollTop = 0; }
  if (V.loading || V.page >= V.pages) return;
  const tk = V.tk;
  V.loading = true;
  try {
    // البحث على مرحلتين: نتائج فورية (الاسم وصيغ كتابته) ثم تكتمل بالترجمة، والعربي أولاً
    if (V.q) {
      const q0 = V.q;
      const r1 = await Bridge.call("vodSearch", { type, q: q0, fast: true });
      if (tk !== V.tk) return;
      paintSearch(type, r1, true);
      let r2 = r1; try { r2 = await Bridge.call("vodSearch", { type, q: q0 }); } catch (e) {}
      if (tk !== V.tk) return;
      const same = !r2.tq && (r2.items || []).length === (r1.items || []).length && (r2.items || []).every((x, i) => String(x.id) === String(r1.items[i].id));
      if (same) { const b = $("#grid-" + type + " .sbusy"); if (b) b.remove(); } else paintSearch(type, r2, false);
      return;
    }
    const r = await Bridge.call("vodList", { type, cat: V.cat, page: V.page + 1, q: "" });
    if (tk !== V.tk) return;
    V.page = r.page; V.pages = r.pages;
    const start = V.items.length;
    V.items = V.items.concat(r.items || []);
    if (start === 0) grid.innerHTML = "";
    if (!V.items.length) { grid.innerHTML = \`<div style="grid-column:1/-1">\${V.q ? emptyBox("search", "لا توجد نتائج", "جرّب جزءاً من الاسم فقط، أو اكتبه بالإنجليزي") : emptyBox(type === "vod" ? "film" : "layers", "القسم فارغ")}</div>\`; return; }
    let h = "";
    for (let i = start; i < V.items.length; i++) h += pCard(V.items[i], i);
    grid.insertAdjacentHTML("beforeend", h);
    trTitles(r.items || []);
    setTimeout(() => vodMore(type), 60);
  } catch (e) {
    if (tk !== V.tk) return;
    if (!V.items.length) grid.innerHTML = \`<div style="grid-column:1/-1">\${emptyBox("wifi", "تعذّر التحميل", e.message, type)}</div>\`;
    else toast(e.message, "bad");
  } finally {
    if (tk === V.tk) V.loading = false;
  }
}
function openVod(m) {
  stopVideo();
  const series = !!m.isSeries;
  S.cur = { kind: "vod", item: m, cmd: series ? "" : m.cmd, series: "", title: m.name };
  S.showOrig = false;
  const fav = isFav(series ? "series" : "vod", m.id);
  const nv = x => /^(n\\/?a|null|none|undefined|0|-+|unknown)$/i.test(String(x || "").trim()) ? "" : String(x || "").trim();
  const tm = nv(m.time) ? (/^\\d+$/.test(nv(m.time)) ? nv(m.time) + " دقيقة" : nv(m.time)) : "";
  const meta = [+m.rating > 0 ? \`<span class="rb">★ \${esc((+m.rating).toFixed(1))}</span>\` : "", esc(nv(m.year)), esc(tm)].filter(Boolean).join(" · ");
  const sp = splitCode(m.name);
  const bd = sp.tags.map(t => \`<span class="bdg\${/^(4K|8K)$/.test(t) ? " q" : ""}">\${esc(t)}</span>\`).concat(sp.cc && !sp.flag ? [\`<span class="bdg">\${esc(sp.adj)}</span>\`] : []).join("");
  const cast = splitPeople(m.actors);
  S.cast = cast.map(n => ({ n, k: "", img: "" }));
  openSheet(\`
    <div class="hero">
      <div class="hbg" style="\${m.poster ? \`background-image:url('\${cssUrl(m.poster)}')\` : "background:var(--grad)"}"></div>
      <div class="hin">
        <div class="hpo"><span>\${esc(initials(m.name))}</span>\${m.poster ? \`<img src="\${esc(m.poster)}" onerror="this.remove()">\` : ""}</div>
        <div class="hinfo"><h2 dir="auto" id="vName">\${esc(showName(m.name))}</h2><div class="trn hide" id="trName" dir="auto"></div>\${m.oname && m.oname !== m.name && !isFaText(m.oname) && m.oname !== sp.rest.trim() ? \`<div class="on" dir="auto">\${esc(m.oname)}</div>\` : ""}\${bd ? \`<div class="bdgs">\${bd}</div>\` : ""}\${meta ? \`<div class="meta">\${meta}</div>\` : ""}\${m.genres ? \`<div class="gen" dir="auto" id="vGen">\${esc(genLocal(m.genres) || m.genres)}</div>\` : ""}</div>
      </div>
    </div>
    \${playerHTML(series)}
    \${series
      ? \`<div class="acts"><button class="cur-ep" id="curEp" data-act="epgo">اختر حلقة للتشغيل</button><button class="btn sec sq \${fav ? "on" : ""}" data-act="favcur">\${ic("star")}</button></div>\`
      : \`<div class="acts"><button class="btn pri" data-act="play">\${playLabel(m)}</button>\${progOf(m.id) ? \`<button class="btn sec sq" data-act="restart" aria-label="من البداية">\${ic("refresh")}</button>\` : ""}<button class="btn sec sq \${fav ? "on" : ""}" data-act="favcur">\${ic("star")}</button></div>\`}
    \${series ? \`<div class="sec-t pad">المواسم والحلقات</div><div class="chips pad" id="seasons" style="padding-top:0">\${skelChips(4)}</div><div class="eps" id="eps">\${skelRows(4)}</div>\` : ""}
    \${m.desc ? \`<div class="dhead"><div class="sec-t">القصة</div><button class="trb hide" id="trBtn" data-act="trtoggle"></button></div><p class="desc" dir="auto" id="vDesc">\${esc(m.desc)}</p>\` : ""}
    <div class="sec-t pad castt\${cast.length ? "" : " hide"}" id="castT">طاقم العمل</div>
    <div class="castrow" id="castRow">\${cast.map((n, i) => personChip(n, i)).join("")}</div>
    \${nv(m.director) ? \`<div class="cast"><div><span>إخراج</span>\${esc(m.director)}</div></div>\` : ""}
    \${playersRow()}\`, { over: true, title: showName(m.name) });
  bindVideo();
  if (series) loadSeasons(m);
  translateVod(m);
  loadCast(m, cast);
}
/* ═════════ طاقم العمل وصفحة الممثل ═════════ */
function splitPeople(s) {
  const seen = new Set();
  return String(s || "").replace(/\\(.*?\\)/g, " ").split(/\\s*[,،;|\\/\\n]\\s*|\\s+-\\s+/)
    .map(x => x.replace(/^(بطولة|تمثيل|starring|cast)\\s*:?\\s*/i, "").replace(/\\s+/g, " ").trim())
    .filter(x => x.length >= 2 && x.length <= 40 && !/^(n\\/?a|null|none|unknown|[a-z])$/i.test(x) && !/^\\d+$/.test(x) && !seen.has(x.toLowerCase()) && seen.add(x.toLowerCase()))
    .slice(0, 15);
}
const pInit = n => { const w = String(n || "").trim().split(/\\s+/).filter(Boolean); return w.length ? (w[0][0] + (w[1] ? w[1][0] : "")).toUpperCase() : "?"; };
const personChip = (n, i, img) => \`<button class="cp" data-person="\${i}" style="--i:\${i}"><span class="ca"><i>\${esc(pInit(n))}</i>\${img ? \`<img src="\${esc(img)}" onload="this.classList.add('ld')" onerror="this.remove()">\` : ""}</span><b dir="auto">\${esc(n)}</b></button>\`;
function castImgs(list) {
  const row = $("#castRow"); if (!row) return;
  list.forEach((p, i) => {
    if (!p.img) return;
    const ca = row.querySelector(\`[data-person="\${i}"] .ca\`);
    if (!ca || ca.querySelector("img")) return;
    const im = new Image(); im.onload = () => im.classList.add("ld"); im.onerror = () => im.remove(); im.src = p.img; ca.appendChild(im);
  });
}
async function loadCast(m, cast) {
  const c = S.cur;
  try {
    if (cast.length) {
      const r = await Bridge.call("people", { names: cast });
      if (S.cur !== c) return;
      S.cast = (r.list || []).map(p => ({ n: p.n, k: p.k, img: p.img }));
      castImgs(S.cast);
    } else {
      const r = await Bridge.call("castOf", { name: m.name, oname: m.oname || "", year: m.year || "", series: !!m.isSeries });
      if (S.cur !== c || !r.list || !r.list.length) return;
      S.cast = r.list;
      const row = $("#castRow"); if (!row) return;
      row.innerHTML = S.cast.map((p, i) => personChip(p.n, i, p.img)).join("");
      $("#castT").classList.remove("hide");
    }
  } catch (e) {}
}
async function openPerson(p, back) {
  stopVideo();
  S.cur = null; S.curMatch = null;
  const tk = S.pTk = (S.pTk || 0) + 1;
  openSheet(\`<div class="person">
      <div class="pph"><i>\${esc(pInit(p.n))}</i>\${p.img ? \`<img src="\${esc(p.img)}" onerror="this.remove()">\` : ""}</div>
      <h2 dir="auto">\${esc(p.n)}</h2><div class="pdesc" id="pDesc" dir="auto"></div><div id="pCnt"></div>
    </div>
    <div class="sec-t pad" style="margin:20px 4px 0" id="pFoundT">أعماله في اشتراكك</div>
    <div id="pFound"><div class="grid pgrid">\${skelPosters(6)}</div><div class="pnote"><i class="spin sm"></i>جاري البحث عن أعماله في اشتراكك…</div></div>
    <div class="sec-t pad hide" id="pOtherT" style="margin:16px 4px 0">أعمال أخرى له</div><div class="pwl" id="pOther"></div>\`, { title: p.n });
  S.navBack = back || null;
  S.sheetKind = "person"; S.person = p; S.pWorks = []; S.pOther = [];
  let r;
  try { r = await Bridge.call("person", { n: p.n, k: p.k || "" }); }
  catch (e) { if (tk === S.pTk && S.sheetKind === "person") $("#pFound").innerHTML = emptyBox("wifi", "تعذّر التحميل", e.message); return; }
  if (tk !== S.pTk || S.sheetKind !== "person") return;
  if (r.img && !p.img) { const ph = $(".pph"); if (ph) ph.insertAdjacentHTML("beforeend", \`<img src="\${esc(r.img)}" onerror="this.remove()">\`); p.img = r.img; }
  if (r.desc) $("#pDesc").textContent = r.desc;
  const her = r.g === "f";
  if (her) { $("#pFoundT").textContent = "أعمالها في اشتراكك"; $("#pOtherT").textContent = "أعمال أخرى لها"; }
  const F = r.found || [];
  S.pWorks = F.map(f => f.item);
  $("#pCnt").innerHTML = F.length ? \`<span class="pcount">\${ic("play")} \${F.length} \${F.length === 1 ? "عمل" : F.length === 2 ? "عملان" : F.length <= 10 ? "أعمال" : "عملاً"} في اشتراكك</span>\` : "";
  $("#pFound").innerHTML = F.length
    ? \`<div class="grid pgrid">\${F.map((f, i) => pCard(f.item, i).replace(/ data-src=/g, " src=").replace('class="pc"', \`class="pc" data-pw="\${i}"\`)).join("")}</div>\`
    : \`<div class="pnote">\${ic("search")}\${(r.works || []).length ? (her ? "لم نجد أعمالها في اشتراكك" : "لم نجد أعماله في اشتراكك") : (her ? "لا توجد معلومات كافية عن أعمالها" : "لا توجد معلومات كافية عن أعماله")}</div>\`;
  trTitles(S.pWorks);
  const O = (r.works || []).filter(w => !w.has).slice(0, 30);
  S.pOther = O;
  if (O.length) {
    $("#pOtherT").classList.remove("hide");
    $("#pOther").innerHTML = O.map((w, i) => \`<button class="pw" data-pq="\${i}"><span class="pwi">\${ic(w.s ? "layers" : "film")}\${w.p ? \`<img src="\${esc(w.p)}" loading="lazy" onerror="this.remove()">\` : ""}</span><span class="pwt"><b dir="auto">\${esc(w.t)}</b><small>\${[w.s ? "مسلسل" : "فيلم", w.y, w.ot && w.ot !== w.t ? w.ot : ""].filter(Boolean).map(esc).join(" · ")}</small></span>\${ic("search", "chev")}</button>\`).join("");
  }
}

async function translateVod(m) {
  if (!S.settings.tr) return;
  const c = S.cur, p = splitCode(m.name), rest = p.rest.trim() || m.name;
  const gl = genLocal(m.genres);
  const [d, g, n] = await translateMany([m.desc, gl == null ? m.genres : "", rest]);
  if (S.cur !== c) return;
  c.tr = { desc: d, genres: gl == null ? g : gl };
  // العنوان: الترجمة العربية هي العنوان الرئيسي والأصل تحته بخط صغير
  if (n && n !== rest) {
    const full = (p.flag ? p.flag + " " : "") + n;
    c.dtitle = full;
    if (needTitleTr(m.name)) { TN[m.name] = full; applyNames(); }
    const h = $("#vName"); if (h) h.textContent = full;
    const el = $("#trName"); if (el) { el.textContent = m.name; el.classList.remove("hide"); }
  }
  if (gl == null && g && g !== m.genres && $("#vGen")) $("#vGen").textContent = g;
  if (d && d !== m.desc && $("#vDesc")) { $("#vDesc").textContent = d; const b = $("#trBtn"); b.innerHTML = ic("lang") + " مترجم تلقائياً · عرض الأصل"; b.classList.remove("hide"); }
}
async function loadSeasons(m) {
  const c = S.cur;
  let ss = [];
  try {
    if (m.series && m.series.length) ss = [{ id: "_", name: "الحلقات", cmd: m.cmd, eps: m.series }];
    else ss = await Bridge.call("seasons", { type: m.type || "vod", id: m.id });
  } catch (e) {
    if (S.cur !== c) return;
    $("#seasons").innerHTML = "";
    $("#eps").innerHTML = emptyBox("alert", "تعذّر تحميل المواسم", e.message);
    return;
  }
  if (S.cur !== c) return;
  if (!ss.length) {
    $("#seasons").innerHTML = "";
    if (m.cmd) { c.eps = [{ num: 1, name: m.name, cmd: m.cmd, series: "" }]; $("#eps").innerHTML = epRows(c.eps); }
    else $("#eps").innerHTML = emptyBox("layers", "لا توجد حلقات متاحة");
    return;
  }
  c.seasons = ss;
  if (S.wantSi == null && S.wantEp == null) {
    const L = seriesLast(m.id), si = L ? ss.findIndex(x => String(x.id) === L.sid) : -1;
    if (si >= 0) { S.wantSi = si; S.wantNum = { num: L.num, next: L.done }; }
  }
  const wsi = S.wantSi; S.wantSi = null;
  ss.forEach((s, i) => { s.name = arSE(s.name) || (s.id === "_" ? s.name : "الموسم " + (i + 1)); });
  $("#seasons").innerHTML = ss.map((s, i) => \`<button class="chip" data-season="\${i}"><span dir="auto">\${esc(s.name || "الموسم " + (i + 1))}</span>\${s.eps && s.eps.length ? \`<em>\${s.eps.length}</em>\` : ""}</button>\`).join("");
  selectSeason(wsi != null && wsi < ss.length ? wsi : 0);
}
function epRow(e, k, c) {
  const key = c && c.item ? epKeyOf(c, e) : null, p = key ? progOf(key) : null, sn = !p && key && seenAt(key);
  return \`<div class="ep\${sn ? " seen" : ""}" data-ep="\${k}" style="--i:\${Math.min(k, 12)}"><span class="en">\${esc(e.num)}</span><b dir="auto">\${esc(e.name)}</b>\${p ? \`<small class="epm">\${leftTxt(p)}</small>\` : sn ? \`<small class="epm ok">\${ic("check", "ck")} شوهدت</small>\` : ""}\${ic("play", "ep-pl")}\${p ? pbar(p.f) : ""}</div>\`;
}
const epRows = eps => eps.map((e, k) => epRow(e, k, S.cur)).join("");
async function selectSeason(i) {
  const c = S.cur, s = c.seasons[i];
  c.si = i;
  $$("#seasons .chip").forEach((b, k) => b.classList.toggle("on", k === i));
  const box = $("#eps");
  box.innerHTML = skelRows(4);
  let eps = [];
  if (s.eps && s.eps.length) eps = s.eps.map(n => ({ num: n, name: "الحلقة " + n, cmd: s.cmd, series: n }));
  else {
    try {
      const r = await Bridge.call("episodes", { type: c.item.type || "vod", id: c.item.id, season: s.id });
      eps = (r || []).map((e, k) => ({ num: e.num || k + 1, name: arSE(e.name) || "الحلقة " + (e.num || k + 1), cmd: e.cmd, series: "" }));
    } catch (e) {}
    if (!eps.length && s.cmd) eps = [{ num: 1, name: s.name, cmd: s.cmd, series: "" }];
  }
  if (S.cur !== c || c.si !== i) return;
  c.eps = eps;
  box.innerHTML = eps.length ? epRows(eps) : emptyBox("layers", "لا توجد حلقات في هذا الموسم");
  let we = S.wantEp; S.wantEp = null;
  const wn = S.wantNum; S.wantNum = null;
  let pre = "";
  if (we == null && wn) {
    const k = eps.findIndex(e => String(e.num) === String(wn.num));
    if (k >= 0 && !wn.next) { we = k; pre = "▶ تابع:"; }
    else if (k >= 0 && k + 1 < eps.length) { we = k + 1; pre = "▶ التالية:"; }
    else if (k >= 0 && c.si + 1 < c.seasons.length) { S.wantNum = { first: 1 }; return selectSeason(c.si + 1); }
  }
  if (we == null && wn && wn.first && eps.length) { we = 0; pre = "▶ التالية:"; }
  if (we != null && eps[we]) {
    const e = eps[we];
    c.cmd = e.cmd; c.series = e.series; c.epIdx = we; c.epNum = e.num; c.epLabel = (s.name && s.name !== "الحلقات" ? s.name + " · " : "") + e.name;
    const row = $$("#eps .ep")[we]; if (row) { row.classList.add("on"); setTimeout(() => row.scrollIntoView({ block: "center" }), 80); }
    curEpLabel(c, pre);
  }
}
function playEpisode(k) {
  const c = S.cur, e = c.eps && c.eps[k];
  if (!e) return;
  const sname = c.seasons && c.seasons[c.si] ? c.seasons[c.si].name : "";
  c.cmd = e.cmd; c.series = e.series; c.epIdx = k; c.epNum = e.num;
  c.epLabel = (sname && sname !== "الحلقات" ? sname + " · " : "") + e.name;
  $$("#eps .ep").forEach((el, j) => el.classList.toggle("on", j === k));
  curEpLabel(c);
  if (S.settings.player === "internal") { $("#pl").classList.remove("hide"); $("#spanel").scrollTo({ top: 0, behavior: "smooth" }); }
  startPlay();
}

/* ── Movies/Series home: hero + category rows ── */
function pCardH(m, k, i) {
  const dn = esc(showName(m.name)), on = esc(m.name), qb = qBadge(m.name);
  return \`<div class="pc" data-h="\${k}:\${i}" style="--i:\${Math.min(i, 8)}"><div class="ps">\${qb}<span class="pt" dir="auto" data-tn="\${on}">\${dn}</span>\${m.poster ? \`<img data-src="\${esc(m.poster)}" decoding="async" onload="this.classList.add('ld')" onerror="this.remove()">\` : ""}\${m.rating ? \`<em class="rt">★ \${esc((+m.rating).toFixed(1))}</em>\` : ""}\${cardProg(m)}</div><div class="t" dir="auto" data-tn="\${on}">\${dn}</div></div>\`;
}
// «تابع المشاهدة»: ما بدأته ولم تكمله (والمسلسلات: الحلقة التالية)
function contItems(type) {
  return (S.recent || []).filter(r => r.t === type && r.item && r.item.id).map(r => {
    if (type === "vod") { const p = progOf(r.item.id); return p ? { r, p, sub: leftTxt(p) } : null; }
    const L = seriesLast(r.item.id); if (!L) return null;
    return { r, p: L.p, sub: (r.label || "") + (L.p ? " · " + leftTxt(L.p) : L.done ? " · التالية" : "") };
  }).filter(Boolean).slice(0, 12);
}
function contRow(type) {
  const A = contItems(type); S.vod[type].cont = A.map(x => x.r.item);
  if (!A.length) return "";
  return \`<section class="hrow cw" id="hr-\${type}-cw"><div class="rowt"><span>\${ic("clock")} تابع المشاهدة</span></div><div class="rowx">\${A.map((x, i) => {
    const m = x.r.item, dn = esc(showName(m.name)), on = esc(m.name);
    return \`<div class="pc" data-cw="\${i}" style="--i:\${Math.min(i, 8)}"><div class="ps">\${qBadge(m.name)}<span class="pt" dir="auto" data-tn="\${on}">\${dn}</span>\${m.poster ? \`<img data-src="\${esc(m.poster)}" decoding="async" onload="this.classList.add('ld')" onerror="this.remove()">\` : ""}<span class="hplay">\${ic("play")}</span>\${x.p ? pbar(x.p.f) : ""}</div><div class="t" dir="auto" data-tn="\${on}">\${dn}</div><small class="cwt" dir="auto">\${esc(x.sub)}</small></div>\`;
  }).join("")}</div></section>\`;
}
async function homeLoad(type) {
  const V = S.vod[type], grid = $("#grid-" + type);
  const tk = ++V.tk;
  V.items = []; V.page = 1; V.pages = 1; V.loading = false; V.home = []; V.hero = null;
  $("#v-" + type).scrollTop = 0;
  const pool = V.cats.filter(c => c.id !== "__home" && c.id !== "*");
  let cats = pool.slice(0, 6);
  if (S.settings.arabic !== "off") {
    const ar = pool.filter(c => tier(c.title) === 0), dub = pool.filter(c => tier(c.title) === 1);
    const pick = ar.slice(0, dub.length ? 4 : 6).concat(dub.slice(0, 3));
    for (const c of ar.slice(pick.length && dub.length ? 4 : 6).concat(dub.slice(3), pool)) { if (pick.length >= 8) break; if (!pick.includes(c)) pick.push(c); }
    if (pick.length) cats = pick;
  }
  if (!cats.length) cats = [{ id: "*", title: "الكل" }];
  grid.innerHTML = \`<div class="home"><div class="hero2 sk" id="hero-\${type}"></div>\${contRow(type)}\${cats.map((c, k) => \`<section class="hrow" id="hr-\${type}-\${k}"><div class="rowt"><span dir="auto" data-co="\${esc(c.title)}">\${esc(catLabel(c.title))}</span><button data-cat="\${esc(c.id)}">عرض الكل</button></div><div class="rowx">\${Array.from({ length: 4 }, () => '<div class="pc"><div class="sk skp"></div></div>').join("")}</div></section>\`).join("")}</div>\`;
  let idx = 0;
  const worker = async () => {
    while (idx < cats.length) {
      const k = idx++;
      let items = [];
      try { items = ((await Bridge.call("vodList", { type, cat: cats[k].id, page: 1, q: "" })).items || []).slice(0, 12); } catch (e) {}
      if (tk !== V.tk) return;
      V.home[k] = { cat: cats[k], items };
      const sec = $("#hr-" + type + "-" + k);
      if (!sec) continue;
      if (!items.length) { sec.remove(); continue; }
      sec.querySelector(".rowx").innerHTML = items.map((m, i) => pCardH(m, k, i)).join("");
      trTitles(items);
      if (!V.hero || k < V.hero[0]) {
        const i = items.findIndex(m => m.poster);
        if (i >= 0) { V.hero = [k, i]; renderHero(type); }
      }
    }
  };
  await Promise.all([worker(), worker()]);
  if (tk === V.tk && !V.hero) { const h = $("#hero-" + type); if (h) h.remove(); }
}
function renderHero(type) {
  const V = S.vod[type], el = $("#hero-" + type);
  if (!el || !V.hero) return;
  const [k, i] = V.hero, m = V.home[k].items[i];
  el.className = "hero2";
  el.setAttribute("data-h", k + ":" + i);
  el.innerHTML = \`<div class="hb" style="background-image:url('\${cssUrl(m.poster)}')"></div><div class="hc">
    <span class="hk">\${ic("brand")} \${type === "vod" ? "فيلم مميز" : "مسلسل مميز"}</span>
    <h3 dir="auto" data-tn="\${esc(m.name)}">\${esc(showName(m.name))}</h3>
    <div class="hm">\${[m.year, m.rating ? "★ " + (+m.rating).toFixed(1) : "", genLocal(m.genres) || m.genres].filter(Boolean).map(esc).join(" · ")}</div>
    <div class="hbtns"><button class="btn w" data-hplay="\${k}:\${i}">\${ic("play")} \${m.isSeries ? "الحلقات" : "تشغيل"}</button><button class="btn g" data-h="\${k}:\${i}">التفاصيل</button></div></div>\`;
}
/* ═════════ قائمة التصنيفات المنسدلة (بجانب «الكل») ═════════ */
const cddChip = k => \`<button class="chip cdd" data-cdd="\${k}">\${ic("menu")}<span>التصنيفات</span>\${ic("down", "dn")}</button>\`;
function catMenuItems(k) {
  if (k === "live") { const L = S.live; return { cur: L.genre, list: L.genres.map(g => ({ id: g.id, t: g.title, n: L.mode === "all" ? (g.id === "*" ? allChannels().length : L.counts[g.id]) : 0 })) }; }
  const V = S.vod[k]; return { cur: V.q ? "" : V.cat, list: (V.cats || []).map(c => ({ id: c.id, t: c.title, n: 0 })) };
}
function openCatMenu(k) {
  closeCatMenu(true);
  const M = catMenuItems(k);
  if (!M.list.length) return;
  const el = document.createElement("div");
  el.id = "cdd";
  el.innerHTML = \`<div class="cdbg"></div><div class="cdp" role="dialog"><div class="cdh"><b>\${ic("menu")} التصنيفات <em>\${fmtN(M.list.length)}</em></b><button class="cdx" aria-label="إغلاق">\${ic("x")}</button></div>
    <div class="search cds"><span>\${ic("search")}</span><input type="search" placeholder="ابحث في التصنيفات" autocomplete="off" autocorrect="off" spellcheck="false"></div>
    <div class="cdl"></div></div>\`;
  document.body.appendChild(el);
  const st = $(".stick", $("#v-" + (k === "live" ? "live" : k)));
  const top = st ? Math.max(st.getBoundingClientRect().top + 52, 70) : 120;
  el.querySelector(".cdp").style.top = top + "px";
  const list = el.querySelector(".cdl"), inp = el.querySelector("input");
  const draw = q => {
    const qs = q ? chQs(q) : null;
    const rows = M.list.filter(x => !qs || qs.some(w => chN(catLabel(x.t) + " " + x.t).replace(/\\s+/g, "").includes(w.replace(/\\s+/g, ""))));
    list.innerHTML = rows.length ? rows.map(x => { const lb = catLabel(x.t); return \`<button class="cdi\${x.id === M.cur ? " on" : ""}" data-cid="\${esc(x.id)}"><span class="cdt"><b dir="auto">\${esc(lb)}</b>\${lb !== x.t ? \`<small dir="auto">\${esc(x.t)}</small>\` : ""}</span>\${x.n ? \`<em>\${fmtN(x.n)}</em>\` : ""}\${x.id === M.cur ? ic("check", "ck") : ""}</button>\`; }).join("") : \`<div class="cde">لا يوجد تصنيف بهذا الاسم</div>\`;
  };
  draw("");
  inp.addEventListener("input", debounce(() => draw(inp.value.trim()), 120));
  el.addEventListener("click", e => {
    if (e.target.closest(".cdbg,.cdx")) { closeCatMenu(); return; }
    const b = e.target.closest("[data-cid]"); if (!b) return;
    const id = b.dataset.cid;
    closeCatMenu();
    if (k === "live") { S.live.q = ""; $("#q-live").value = ""; $('[data-clr="q-live"]').classList.remove("on"); renderGenres(); selectGenre(id); }
    else selectCat(k, id);
  });
  requestAnimationFrame(() => { el.classList.add("on"); const on = list.querySelector(".cdi.on"); if (on) on.scrollIntoView({ block: "center" }); });
}
function closeCatMenu(now) {
  const el = $("#cdd"); if (!el) return;
  if (now) { el.remove(); return; }
  el.classList.remove("on"); setTimeout(() => el.remove(), 220);
}

function selectCat(t, id) {
  const V = S.vod[t];
  V.cat = id; V.q = "";
  $("#q-" + t).value = ""; $('[data-clr="q-' + t + '"]').classList.remove("on");
  renderCats(t);
  vodLoad(t, true);
}

/* ═════════ جدول المباريات (مثل 365) ═════════ */
const MT = { day: 0, live: false, major: true, data: null, tk: 0, timer: 0, liveN: 0, busy: false, ch: {}, chAt: {}, chBusy: false };
const MDAY = ["أمس", "اليوم", "غداً"];
const tz = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Riyadh"; } catch (e) { return "Asia/Riyadh"; } };
const ymd = d => d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
const dayAt = k => { const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + k); return d; };
const fmtHM = t => { try { return new Intl.DateTimeFormat("ar-u-nu-latn", { hour: "numeric", minute: "2-digit" }).format(new Date(t)); } catch (e) { return String(t).slice(11, 16); } };
const fmtDay = d => { try { return new Intl.DateTimeFormat("ar-u-nu-latn", { weekday: "long", day: "numeric", month: "long" }).format(d); } catch (e) { return ymd(d); } };
const imgTeam = (id, iv) => \`https://imagecache.365scores.com/image/upload/f_png,w_64,h_64,c_limit,q_auto:eco,dpr_2,d_Competitors:default1.png/v\${iv || 1}/Competitors/\${id}\`;
const imgComp = (id, iv, cc) => \`https://imagecache.365scores.com/image/upload/f_png,w_40,h_40,c_limit,q_auto:eco,dpr_2,d_Countries:Round:\${cc || 0}.png/v\${iv || 1}/Competitions/light/\${id}\`;
const ARABC = { 122: 1, 131: 2, 124: 3, 115: 4, 114: 5, 119: 6, 125: 7, 139: 8 };   // السعودية، مصر، الإمارات، قطر، العراق، الأردن، سوريا، الجزائر
function mDays() {
  $("#mDays").innerHTML = [-1, 0, 1, 2, 3, 4, 5].map(k => {
    const lb = k >= -1 && k <= 1 ? MDAY[k + 1] : new Intl.DateTimeFormat("ar-u-nu-latn", { weekday: "long" }).format(dayAt(k));
    return \`<button class="chip \${MT.day === k && !MT.live ? "on" : ""}" data-day="\${k}">\${lb}<em>\${dayAt(k).getDate()}</em></button>\`;
  }).join("");
  $("#mLive").classList.toggle("on", MT.live);
  $("#mMajor").classList.toggle("on", MT.major);
  $("#mMajor").style.display = MT.live ? "none" : "";
}
function mEnter() {
  mDays();
  if (!MT.data) $("#mList").innerHTML = skelRows(6);
  mLoad(false);
}
function mLeave() { clearTimeout(MT.timer); MT.chAgain = null; if (MT.chBusy && S.sheetKind !== "match") Bridge.call("matchStop").catch(() => {}); }
async function mLoad(quiet) {
  clearTimeout(MT.timer);
  const tk = ++MT.tk;
  if (!quiet) $("#mUpd").textContent = "جاري التحديث…";
  let d;
  try { d = await Bridge.call("matches", { date: ymd(dayAt(MT.day)), live: MT.live, major: MT.major, tz: tz() }); }
  catch (e) {
    if (tk !== MT.tk) return;
    if (!MT.data) $("#mList").innerHTML = emptyBox("wifi", "تعذّر تحميل المباريات", e.message, "matches");
    $("#mUpd").textContent = "";
    MT.timer = setTimeout(() => S.tab === "matches" && mLoad(true), 60000);
    return;
  }
  if (tk !== MT.tk) return;
  MT.data = d;
  mRender();
  if (MT.live || MT.day === 0) mChannels();
  const lv = d.games.some(g => g.sg === 3);
  if (S.tab === "matches") MT.timer = setTimeout(() => S.tab === "matches" && mLoad(true), lv || MT.live ? 30000 : 120000);
  if (S.sheetKind === "match" && S.curMatch) { const g = d.games.find(x => x.id === S.curMatch.id); if (g) { S.curMatch = g; mScoreUpd(g); } }
}
function mLiveBadge(n) {
  MT.liveN = n;
  const e = $("#mLiveN"); if (e) e.textContent = n ? n : "";
  const t = $('.tab[data-tab="matches"]'); if (t) t.classList.toggle("lv", n > 0);
}
// النتيجة: رقم صاحب الأرض على اليمين تحت اسمه (مثل 365 بالعربي)
const scr = (h, a, cls) => \`<b class="sc\${cls ? " " + cls : ""}"><span>\${h}</span><i>-</i><span>\${a}</span></b>\`;
const mins = g => esc(g.gtd || (g.gt > 0 ? Math.floor(g.gt) + "'" : g.sst || g.st));
function mScore(g) {
  if (g.sg === 3) return scr(g.h.s, g.a.s, "lv") + \`<small class="lv"><i></i><span dir="ltr">\${mins(g)}</span></small>\`;
  if (g.sg === 4 && g.h.s >= 0) return scr(g.h.s, g.a.s) + \`<small>\${esc(g.sst || g.st || "انتهت")}</small>\`;
  if (g.h.s >= 0 && g.a.s >= 0 && g.sg !== 2) return scr(g.h.s, g.a.s) + \`<small>\${esc(g.st)}</small>\`;
  return \`<b class="tm">\${esc(fmtHM(g.t))}</b><small>\${esc(g.sg === 2 ? (g.st && g.st !== "لم تبدأ" ? g.st : "") : g.st)}</small>\`;
}
const tLogo = (x, xl) => \`<span class="tl\${xl ? " xl" : ""}"><em>\${esc(String(x.n || "?").trim().replace(/^ال(?=\\S{2})/, "").charAt(0))}</em><img src="\${imgTeam(x.id, x.iv)}" loading="lazy" onload="this.parentNode.classList.add('ok')" onerror="this.remove()"></span>\`;
const mTeam = (x, side) => \`<div class="mt \${side}">\${tLogo(x)}<b dir="auto" class="\${x.w ? "win" : ""}">\${esc(x.n)}</b></div>\`;
function mRender() {
  const d = MT.data; if (!d) return;
  const box = $("#mList");
  let games = d.games.slice();
  if (MT.live) games = games.filter(g => g.sg === 3);
  mLiveBadge(d.games.filter(g => g.sg === 3).length);
  $("#mUpd").textContent = (MT.live ? "مباشر الآن · " : fmtDay(dayAt(MT.day)) + " · ") + games.length + " مباراة";
  if (!games.length) { box.innerHTML = MT.live ? emptyBox("ball", "لا توجد مباريات مباشرة الآن", "شغّل الزر مرة أخرى لاحقاً أو اختر يوماً لعرض الجدول") : emptyBox("ball", "لا توجد مباريات في هذا اليوم", MT.major ? "أوقف «المهمة فقط» لعرض كل البطولات" : ""); return; }
  const C = {}; d.comps.forEach(c => { C[c.id] = c; });
  const by = {}; games.forEach(g => { (by[g.cid] = by[g.cid] || []).push(g); });
  const order = Object.keys(by).map(Number).sort((a, b) => {
    const A = C[a] || {}, B = C[b] || {};
    const la = by[a].some(g => g.sg === 3) ? 1 : 0, lb = by[b].some(g => g.sg === 3) ? 1 : 0;
    if (MT.live && la !== lb) return lb - la;
    const ra = ARABC[A.cc] || 99, rb = ARABC[B.cc] || 99;
    if (ra !== rb) return ra - rb;
    return (B.r || 0) - (A.r || 0);
  });
  box.innerHTML = order.map((cid, k) => {
    const c = C[cid] || { n: (by[cid][0] || {}).cd || "", c: "" };
    const rows = by[cid].sort((x, y) => (x.sg === 3 ? 0 : 1) - (y.sg === 3 ? 0 : 1) || String(x.t).localeCompare(String(y.t))).map(g =>
      \`<div class="mrow\${g.sg === 3 ? " live" : ""}" data-mg="\${g.id}">\${mTeam(g.h, "h")}<div class="msc">\${mScore(g)}</div>\${mTeam(g.a, "a")}<div class="mtv" data-mtv="\${g.id}">\${mTv(g)}</div></div>\`).join("");
    return \`<section class="mcomp" style="--i:\${Math.min(k, 10)}"><div class="mch"><span class="cl"><img src="\${imgComp(cid, c.iv, c.cc)}" loading="lazy" onerror="this.parentNode.remove()"></span><b dir="auto">\${esc(c.n)}</b>\${c.c && c.c !== c.n ? \`<small dir="auto">\${esc(c.c)}</small>\` : ""}</div>\${rows}</section>\`;
  }).join("");
}
// ── القناة الناقلة: نبحث في اشتراكك (دليل البرامج + أسماء القنوات + 365) لكل مباراة مباشرة أو قريبة
const compOf = g => (MT.data && MT.data.comps.find(x => x.id === g.cid)) || {};
const mSlim = g => { const c = compOf(g); return { id: g.id, t: g.t, sg: g.sg, tv: g.tv, cd: g.cd, cn: c.n || "", cc: c.cc || 0, cy: c.c || "", intl: !!c.intl, h: { n: g.h.n, en: g.h.en || "" }, a: { n: g.a.n, en: g.a.en || "" } }; };
function mTv(g) {
  const R = MT.ch[g.id];
  if (!R) return MT.chBusy && g.sg === 3 ? \`<span class="mtvw"><i class="spin"></i>جاري البحث عن القناة الناقلة…</span>\` : "";
  let h = "";
  if (R.best.length) h += \`<button class="mtvb" data-mplay="\${g.id}">\${ic("play")}<span dir="auto">\${esc(R.best[0].name)}</span></button>\${R.best.length > 1 ? \`<em>+\${R.best.length - 1}</em>\` : ""}\`;
  else if (R.names.length) h += \`<span class="mtvn">\${ic("tv")}<span dir="auto">\${esc(R.names.slice(0, 3).join(" · "))}</span></span>\`;
  return h;
}
function mTvAll() { $$("[data-mtv]").forEach(el => { const g = MT.data && MT.data.games.find(x => String(x.id) === el.dataset.mtv); if (g) el.innerHTML = mTv(g); }); }
async function mChannels(list) {
  const solo = !!list && list.length <= 2;   // مباراة فتحها المستخدم: لا تنتظر انتهاء بحث القائمة
  if (MT.chBusy && !solo) { MT.chAgain = list || MT.chAgain || true; return; }
  const now = Date.now() / 1000;
  const want = (list || (MT.data ? MT.data.games : [])).filter(g => g.sg === 3 || (g.sg === 2 && Date.parse(g.t) / 1000 - now < 4 * 3600) || list).filter(g => !MT.ch[g.id] || Date.now() - (MT.chAt[g.id] || 0) > 180000).slice(0, 40);
  if (!want.length) return;
  MT.chN = (MT.chN || 0) + 1; MT.chBusy = true; mTvAll();
  try {
    const r = await Bridge.call("matchChannels", { games: want.map(mSlim) });
    Object.keys((r && r.byGame) || {}).forEach(id => {
      MT.ch[id] = r.byGame[id]; MT.chAt[id] = Date.now();
      // فهرس كل القنوات ما زال يُبنى → نعيد البحث لهذه المباراة بعد 12 ثانية (حتى 6 مرات)
      if (r.byGame[id].pending) { MT.pend = MT.pend || {}; const n = MT.pend[id] = (MT.pend[id] || 0) + 1; if (n <= 8) setTimeout(() => { const g = MT.data && MT.data.games.find(x => String(x.id) === String(id)) || (S.curMatch && String(S.curMatch.id) === String(id) ? S.curMatch : null); if (g && (S.tab === "matches" || S.sheetKind === "match")) { MT.chAt[id] = 0; mChannels([g]); } }, 7000); }
    });
    MT.sports = r ? r.sports : 0;
  } catch (e) {}
  MT.chN = Math.max(0, (MT.chN || 1) - 1); MT.chBusy = MT.chN > 0; mTvAll();
  if (S.sheetKind === "match" && S.curMatch) { mChRender(S.curMatch); mAuto(S.curMatch); }
  const again = MT.chAgain; MT.chAgain = null;
  if (again && (S.tab === "matches" || S.sheetKind === "match")) mChannels(again === true ? null : again);
}
function playMatch(id) {
  const R = MT.ch[id]; if (!R) return;
  const list = R.best.slice();
  if (!list.length) return;
  openChannel(list, 0);
}
function mScoreUpd(g) { const e = $("#mBig"); if (e) e.innerHTML = mScore(g); if (S.curMatch === g && Date.now() - (S.mLineAt || 0) > 120000) mLineLoad(g); }
/* ═════════ التشكيلة ═════════ */
const imgAth = (aid, iv) => \`https://imagecache.365scores.com/image/upload/f_png,w_76,h_76,c_limit,q_auto:eco,dpr_2,d_Athletes:default.png,r_max,c_thumb,g_face,z_0.65/v\${iv || 1}/Athletes/\${aid}\`;
async function mLineLoad(g) {
  S.mLineAt = Date.now();
  let v = null;
  try { v = await Bridge.call("matchInfo", { id: g.id }); } catch (e) { if (S.curMatch === g && !S.mLineOk) { const b = $("#mLine"); if (b) b.innerHTML = \`<div class="pnote">\${ic("wifi")}\${esc(e.message)}</div>\`; } return; }
  if (S.curMatch !== g) return;
  S.mLineOk = !!(v && (v.h || v.a));
  mLineRender(g, v);
}
// مواقع اللاعبين: من إحداثيات 365 إن وُجدت، وإلا حسب الخطوط (حارس، دفاع، وسط، هجوم)
function lineSpots(T) {
  const xi = T.xi.slice();
  if (xi.length && xi.every(p => p.fl >= 0 && p.fs >= 0)) return xi.map(p => ({ p, d: Math.max(0, Math.min(100, p.fl)), x: Math.max(0, Math.min(100, p.fs)) }));
  let lines = {};
  if (xi.some(p => p.line > 0)) xi.forEach(p => { (lines[p.line || 1] = lines[p.line || 1] || []).push(p); });
  else {
    const f = String(T.formation || "").split("-").map(Number).filter(n => n > 0);
    let i = 1; lines[1] = [xi[0]].filter(Boolean);
    f.forEach((n, k) => { lines[k + 2] = xi.slice(i, i + n); i += n; });
    if (i < xi.length) lines[f.length + 2] = xi.slice(i);
  }
  const keys = Object.keys(lines).map(Number).sort((a, b) => a - b), out = [];
  keys.forEach((k, li) => {
    const arr = lines[k].slice().sort((a, b) => (a.fp || 0) - (b.fp || 0)), d = keys.length > 1 ? li / (keys.length - 1) * 100 : 0;
    arr.forEach((p, i) => out.push({ p, d, x: (i + 1) / (arr.length + 1) * 100 }));
  });
  return out;
}
function mLineRender(g, v) {
  const box = $("#mLine"); if (!box || S.curMatch !== g) return;
  if (!v || (!v.h && !v.a) || !((v.h && v.h.xi.length) || (v.a && v.a.xi.length))) {
    box.innerHTML = \`<div class="pnote">\${ic("clock")}\${g.sg === 2 ? "تظهر التشكيلة عادة قبل بداية المباراة بساعة تقريباً" : "التشكيلة غير متوفرة لهذه المباراة"}</div>\`;
    return;
  }
  const rk = r => r ? \`<em class="rk \${r >= 8 ? "b" : r >= 7 ? "g" : r >= 6 ? "" : "r"}">\${r.toFixed(1)}</em>\` : "";
  const dot = (sp, aw, i) => {
    const p = sp.p, top = aw ? 9 + sp.d * 0.36 : 91 - sp.d * 0.36, left = 11 + (aw ? 100 - sp.x : sp.x) * 0.78;
    return \`<div class="pl\${aw ? " aw" : ""}" style="left:\${left.toFixed(1)}%;top:\${top.toFixed(1)}%;--i:\${i}"><span class="pa"><i>\${esc(p.num)}</i>\${p.aid ? \`<img src="\${imgAth(p.aid, p.iv)}" loading="lazy" onload="this.closest('.pl').classList.add('im')" onerror="this.remove()">\` : ""}</span>\${p.num !== "" && p.aid ? \`<i class="nb">\${esc(p.num)}</i>\` : ""}\${rk(p.r)}<b dir="auto">\${esc(p.sn || p.n)}</b></div>\`;
  };
  const head = (T, x, bot) => \`<div class="lhd\${bot ? " bot" : ""}">\${tLogo(x)}<b dir="auto">\${esc(x.n)}</b>\${T && T.formation ? \`<em>\${esc(T.formation)}</em>\` : ""}</div>\`;
  const st = (v.h || v.a).status || "";
  const conf = /مؤكد|confirm|official|رسمي/i.test(st);
  let h = \`<div class="lineup">\${st ? \`<div class="lsts">\${ic("check")}<b class="\${conf ? "" : "ex"}">\${conf ? "التشكيلة الرسمية" : esc(st)}</b><span>· من 365Scores</span></div>\` : ""}\`;
  h += head(v.a, g.a) + \`<div class="pitch"><i class="ln c1"></i><i class="ln c2"></i><i class="ln c3"></i><i class="ln c4"></i><i class="ln c5"></i><i class="ln c6"></i><i class="ln c7"></i>\`;
  if (v.a) h += lineSpots(v.a).map((sp, i) => dot(sp, true, i)).join("");
  if (v.h) h += lineSpots(v.h).map((sp, i) => dot(sp, false, i + 11)).join("");
  h += \`</div>\` + head(v.h, g.h, true);
  const col = (T, x) => T ? \`<div class="lsub"><h4>\${tLogo(x)}<span dir="auto">\${esc(x.n)}</span></h4>\${T.coach ? \`<div class="co">المدرب: <b dir="auto">\${esc(T.coach)}</b></div>\` : ""}\${T.subs.length ? T.subs.map(p => \`<div class="sb"><i>\${esc(p.num)}</i><span dir="auto">\${esc(p.n)}</span></div>\`).join("") : \`<div class="co">لا يوجد بدلاء</div>\`}</div>\` : "";
  h += \`<div class="sec-t" style="margin:18px 2px 0">البدلاء والمدربون</div><div class="lsubs">\${col(v.h, g.h)}\${col(v.a, g.a)}</div></div>\`;
  box.innerHTML = h;
}
function mChRender(g) {
  const box = $("#mCh"); if (!box || S.curMatch !== g) return;
  const R = MT.ch[g.id];
  if (!R) { box.innerHTML = \`<div class="mtvw pad"><i class="spin"></i>جاري البحث عن القناة الناقلة في اشتراكك…</div>\`; return; }
  S.mChs = [];
  const why = c => c.why === "epg" ? "حسب دليل البرامج" + (c.prog ? ": " + c.prog : "") : c.why === "name" ? "قناة المباراة" : c.why === "365" ? "القناة الناقلة الرسمية" : c.why === "mine" ? (R.names.length ? "اخترتها أنت لهذه القناة الناقلة" : "اخترتها أنت لهذه المباراة") : "";
  const cur = S.cur && S.cur.inMatch ? S.cur.item.id : null;
  const row = (ch, tag) => { const i = S.mChs.push(ch) - 1; return \`<div class="ch\${cur && ch.id === cur ? " on" : ""}" data-mch="\${i}"><div class="lg"><span class="ini">\${esc(initials(ch.name))}</span>\${ch.logo ? \`<img data-src="\${esc(ch.logo)}" decoding="async" onerror="this.remove()">\` : ""}</div><div class="nm"><b dir="auto">\${esc(ch.name)}</b><small dir="auto">\${esc(tag)}\${ch.ln ? \`<span class="lnb\${ch.lang === "ar" ? "" : " x"}">\${esc(ch.ln)}</span>\` : ""}</small></div>\${ic("play", "ep-pl")}</div>\`; };
  let h = "";
  const arB = R.best.filter(c => c.lang === "ar" || c.why === "mine"), otB = R.best.filter(c => !(c.lang === "ar" || c.why === "mine"));
  if (arB.length) h += \`<div class="mchg"><b class="ok">\${ic("check")} القناة الناقلة بالعربي</b>\${arB.map(ch => row(ch, why(ch))).join("")}</div>\`;
  if (otB.length) h += \`<div class="mchg"><b>\${arB.length ? "بلغات أخرى" : \`\${ic("check")} القناة الناقلة في اشتراكك\`}</b>\${!arB.length && R.pending ? \`<small class="mnote"><i class="spin sm"></i> جاري البحث عن النسخة العربية في كل الأقسام…</small>\` : ""}\${otB.map(ch => row(ch, why(ch))).join("")}</div>\`;
  if (R.names.length) h += \`<div class="mchg"><b>\${ic("tv")} تُنقل على</b><div class="mnames">\${R.names.map(n => \`<span dir="auto">\${esc(n)}</span>\`).join("")}</div>\${R.best.length ? "" : R.pending ? \`<small class="mnote"><i class="spin sm"></i> جاري البحث عنها في كل قنوات اشتراكك…</small>\` : \`<small class="mnote">لم نجدها تلقائياً في اشتراكك — ابحث عنها واخترها مرة واحدة وتظهر دائماً</small>\`}</div>\`;
  if (!R.best.length && !R.names.length) h += \`<div class="mchg"><small class="mnote">لا توجد معلومات مؤكدة عن القناة الناقلة لهذه المباراة حتى الآن. إذا كنت تعرفها ابحث عنها واخترها، ويتذكرها التطبيق.</small></div>\`;
  h += mSearchBox(R);
  box.innerHTML = h;
}
// البحث عن القناة داخل صفحة المباراة (في كل قنوات الاشتراك) — اختيارك يُحفظ لهذه القناة الناقلة
function mSearchBox(R) {
  const q = S.mSq != null ? S.mSq : (R.names[0] || "");
  return \`<button class="msbtn\${S.mSo ? " hide" : ""}" data-msopen="1">\${ic("search")} ابحث عن القناة في اشتراكك</button>
    <div class="msrch\${S.mSo ? "" : " hide"}" id="mSrch"><div class="search"><span>\${ic("search")}</span><input id="mSq" type="search" dir="auto" placeholder="اسم القناة مثل: Jordan Sport أو الأردن الرياضية" value="\${esc(q)}" autocomplete="off" autocorrect="off" spellcheck="false"></div><div class="msres" id="mSres"></div></div>\`;
}
async function mSearch(q) {
  const box = $("#mSres"); if (!box) return;
  q = String(q || "").trim(); S.mSq = q;
  if (!q) { box.innerHTML = ""; return; }
  const tk = S.mStk = (S.mStk || 0) + 1;
  const spin = \`<div class="mtvw"><i class="spin"></i>جاري إكمال البحث في كل القنوات…</div>\`;
  const row = (ch, i) => \`<div class="ch" data-msr="\${i}"><div class="lg"><span class="ini">\${esc(initials(ch.name))}</span>\${ch.logo ? \`<img src="\${esc(ch.logo)}" loading="lazy" onerror="this.remove()">\` : ""}</div><div class="nm"><b dir="auto">\${esc(ch.name)}</b><small dir="auto">\${esc(ch.num ? "#" + ch.num : "")}</small></div>\${ic("play", "ep-pl")}</div>\`;
  const show = (items, busy) => {
    if (tk !== S.mStk || !$("#mSres")) return false;
    S.mSr = items.slice(0, 30);
    $("#mSres").innerHTML = (S.mSr.length ? S.mSr.map(row).join("") : busy ? "" : \`<div class="pnote">\${ic("search")}لا توجد قناة بهذا الاسم في اشتراكك — جرّب اسماً آخر</div>\`) + (busy ? spin : "");
    return true;
  };
  // تحسين: نجرب الاسم بدون «Sport/الرياضية» إذا لم نجد شيئاً
  const q2 = q.replace(/\\b(sports?|tv|hd)\\b|الرياضيه|الرياضية|قناة/gi, " ").replace(/\\s+/g, " ").trim();
  const find = async (quick) => {
    let r = {}; try { r = (await Bridge.call("liveSearch", { q, build: true, quick })) || {}; } catch (e) {}
    if (!(r.items || []).length && q2 && q2 !== q) { try { const r2 = (await Bridge.call("liveSearch", { q: q2, build: true, quick })) || {}; if ((r2.items || []).length) r = r2; } catch (e) {} }
    return { items: r.items || [], ready: r.ready !== false };
  };
  const f = await find(true);                  // فوري: من الذاكرة (بلا شبكة)
  if (tk !== S.mStk) return;
  if (f.ready) { show(f.items, false); return; }
  show(f.items, true);                         // نتائج مبدئية الآن، والباقي يكمل
  const full = await find(false);
  if (tk !== S.mStk) return;
  show(full.items.length ? full.items : f.items, false);
}
// تشغيل قناة داخل صفحة المباراة نفسها (النتيجة تبقى ظاهرة تحتها)
// القناة الناقلة فشلت → نجرب التالية في القائمة (العربية أولاً) تلقائياً، حتى 5 محاولات
function mFailover(c) {
  if (S.sheetKind !== "match" || S.cur !== c || S.settings.autoNext === false) return;
  const tried = S.mTried || (S.mTried = {});
  tried[c.item.id] = 1;
  const next = (S.mChs || []).find(x => x && x.cmd && !tried[x.id]);
  const nw = $("#mNow");
  if (!next || Object.keys(tried).length >= 5) { if (nw) { nw.innerHTML = \`\${ic("alert")}<span>تعذّر تشغيل القنوات الناقلة — اختر قناة أخرى من القائمة أو ابحث عنها</span>\`; nw.classList.remove("hide"); } return; }
  if (nw) { nw.innerHTML = \`<i class="spin sm"></i><span>تعذّرت «\${esc(c.item.name)}» — نجرّب «\${esc(next.name)}»…</span>\`; nw.classList.remove("hide"); }
  setTimeout(() => { if (S.cur === c && S.sheetKind === "match") mPlayCh(next, false, true); }, 700);
}
function mPlayCh(ch, noStart, auto) {
  if (!ch || !ch.cmd) return;
  if (!auto) S.mTried = {};
  stopVideo();
  S.cur = { kind: "itv", item: ch, cmd: ch.cmd, series: "", list: [ch], idx: 0, title: ch.name, inMatch: 1 };
  const pl = $("#pl"); if (pl) pl.classList.remove("hide");
  $$("#mCh [data-mch]").forEach(e => { const c = (S.mChs || [])[+e.dataset.mch]; e.classList.toggle("on", !!c && c.id === ch.id); });
  const nw = $("#mNow"); if (nw) { nw.innerHTML = \`\${ic("tv")}<span>تشاهد الآن:</span><b dir="auto">\${esc(ch.name)}</b>\`; nw.classList.remove("hide"); }
  bindVideo();
  $("#spanel").scrollTo({ top: 0, behavior: "smooth" });
  if (!noStart) startPlay("internal");
}
async function openMatch(g) {
  stopVideo();
  S.cur = null;
  S.curMatch = g;
  const c = compOf(g);
  S.mSq = null; S.mSo = 0; S.mLineOk = false;
  const html = \`\${playerHTML(true)}<div class="mnow hide" id="mNow"></div><div class="mhero">
      <div class="mhc"><span class="cl"><img src="\${imgComp(g.cid, c.iv, c.cc)}" onerror="this.parentNode.remove()"></span><span dir="auto">\${esc(c.n || g.cd)}\${g.rn ? " · " + esc(g.rn) : ""}</span></div>
      <div class="mteams">
        <div class="mtb">\${tLogo(g.h, 1)}<b dir="auto">\${esc(g.h.n)}</b></div>
        <div class="msc big" id="mBig">\${mScore(g)}</div>
        <div class="mtb">\${tLogo(g.a, 1)}<b dir="auto">\${esc(g.a.n)}</b></div>
      </div>
      <div class="mwhen">\${ic("clock")} \${esc(fmtDay(new Date(g.t)))} · \${esc(fmtHM(g.t))}</div>
    </div>
    <div class="sec-t pad">شاهد المباراة</div>
    <div id="mCh" class="mchs"></div>
    <div class="sec-t pad" style="margin-top:22px">التشكيلة</div>
    <div id="mLine"><div class="mtvw pad"><i class="spin"></i>جاري تحميل التشكيلة…</div></div>
    <div class="about" style="margin:14px 16px 0;text-align:right">نعرض القناة الناقلة من مصادر مؤكدة فقط: 365Scores الرسمي، أو دليل برامج قنواتك حين يذكر الفريقين، أو القناة التي اخترتها أنت.</div>\`;
  if ($("#sheet").classList.contains("on")) { $("#spanel").innerHTML = sheetWrap(html, { title: "المباراة" }); $("#spanel").scrollTop = 0; }
  else openSheet(html, { title: "المباراة" });
  S.sheetKind = "match";
  bindVideo();
  mChRender(g);
  mLineLoad(g);
  if (!MT.ch[g.id]) mChannels([g]); else mAuto(g);
}
// مباراة مباشرة والقناة الناقلة معروفة → تبدأ في نفس الصفحة
function mAuto(g) {
  const R = MT.ch[g.id];
  if (!R || g.sg !== 3 || S.cur || S.sheetKind !== "match" || S.curMatch !== g || S.noAuto || S.settings.player !== "internal") return;
  const ch = ["mine", "365", "epg", "name"].map(w => R.best.find(x => x.why === w)).find(Boolean);
  if (ch) mPlayCh(ch);
}

/* ═════════ YouTube (ads skipped automatically) ═════════ */
const YT_CHIPS = [["أخبار", "أخبار اليوم"], ["رياضة", "ملخص مباريات اليوم"], ["مسلسلات", "مسلسلات عربية"], ["أطفال", "كرتون أطفال عربي"], ["قرآن", "قرآن كريم تلاوة خاشعة"], ["وثائقي", "وثائقي عربي"], ["طبخ", "وصفات طبخ"], ["تقنية", "مراجعة جوال"]];
const ytIdOf = s => { const m = String(s || "").match(/(?:youtu\\.be\\/|[?&]v=|\\/shorts\\/|\\/embed\\/|\\/live\\/)([\\w-]{11})/); return m ? m[1] : (/^[\\w-]{11}$/.test(String(s || "").trim()) ? String(s).trim() : ""); };
function ytRenderChips() {
  $("#ytChips").innerHTML = YT_CHIPS.map((c, i) => \`<button class="chip \${S.yt.q === c[1] ? "on" : ""}" data-yq="\${i}">\${esc(c[0])}</button>\`).join("");
}
function ytRender() {
  const box = $("#ytList"), Y = S.yt;
  if (!Y.items.length) { box.innerHTML = emptyBox("search", "لا توجد نتائج", "جرّب كلمة أخرى"); return; }
  box.innerHTML = Y.items.map((v, i) => \`<div class="yv" data-y="\${i}" style="--i:\${Math.min(i, 10)}">
    <div class="yth"><img data-src="\${esc(v.thumb)}" decoding="async" onload="this.classList.add('ld')" onerror="this.remove()">\${v.live ? \`<em class="live">● مباشر</em>\` : v.len ? \`<em>\${esc(v.len)}</em>\` : ""}<span class="ypl">\${ic("play")}</span></div>
    <div class="yi"><b dir="auto">\${esc(v.title)}</b><small dir="auto">\${esc([v.ch, v.views, v.ago].filter(Boolean).join(" · "))}</small></div></div>\`).join("");
}
async function ytSearch(q) {
  const Y = S.yt;
  q = String(q || "").trim();
  if (!q) return;
  const vid = ytIdOf(q);
  if (vid) { ytPlay({ id: vid, title: q }); return; }
  Y.q = q; Y.loaded = true;
  ytRenderChips();
  const tk = ++Y.tk;
  $("#ytList").innerHTML = Array.from({ length: 4 }, () => '<div><div class="sk" style="aspect-ratio:16/9;border-radius:16px"></div><div class="sk" style="height:14px;width:70%;margin-top:10px"></div></div>').join("");
  try {
    const items = await Bridge.call("ytSearch", { q });
    if (tk !== Y.tk) return;
    Y.items = items || [];
    ytRender();
    $("#v-yt").scrollTop = 0;
  } catch (e) {
    if (tk !== Y.tk) return;
    $("#ytList").innerHTML = emptyBox("wifi", "تعذّر جلب نتائج يوتيوب", e.message, "yt");
  }
}
function ytEnter() { if (!S.yt.loaded) ytSearch(YT_CHIPS[0][1]); }
function ytPlay(v) {
  toast("جاري فتح الفيديو… الإعلانات تُتخطى تلقائياً");
  const restore = { tab: "yt", yt: { q: S.yt.q, items: S.yt.items.slice(0, 40), scroll: $("#v-yt").scrollTop } };
  Bridge.call("ytPlay", { id: v.id, restore }).catch(e => toast(e.message, "bad"));
}

/* ═════════ theme & animation pickers ═════════ */
function themeTileVars(t) {
  const v = themeVars(t);
  return \`--tb:\${v["--bg"]};--tg:\${v["--grad"]};--tcard:\${t.st === 3 ? "rgba(0,0,0,.09)" : "rgba(255,255,255,.13)"};--tglow:\${v["--g1"]}\`;
}
function openThemes(filter) {
  S.thFilter = filter == null ? (S.thFilter == null ? -1 : S.thFilter) : filter;
  const f = S.thFilter, cur = +S.settings.theme;
  const order = THEMES.map((t, i) => i).sort((a, b) => (!!THEMES[b].nf - !!THEMES[a].nf) || (THEMES[b].st === 5) - (THEMES[a].st === 5) || a - b);
  const tiles = order.map(i => [THEMES[i], i]).map(([t, i]) => (f < 0 || t.st === f) ? \`<button class="th \${i === cur ? "on" : ""}" data-th="\${i}" style="--i:\${Math.min(i % 20, 16)}"><span class="thp" style="\${themeTileVars(t)}"><i></i><i></i><i></i><u></u></span><span>\${esc(t.name)}</span></button>\` : "").join("");
  const html = \`<button class="sx" data-act="close">\${ic("x")}</button>
    <div class="shtl">\${ic("palette")} الثيمات <em>\${THEMES.length}</em></div>
    <div class="shsub">الثيم الحالي: <b id="thCur">\${esc(THEMES[cur].name)}</b></div>
    <div class="chips pad">\${[["-1", "الكل"], ["5", "مميز ✦"]].concat(STYLES.map((s, i) => [String(i), s])).map(x => \`<button class="chip \${String(f) === x[0] ? "on" : ""}" data-thf="\${x[0]}">\${x[1]}</button>\`).join("")}</div>
    <div class="picks"><button class="btn sec" data-act="thrand">\${ic("dice")} ثيم عشوائي</button></div>
    <div class="thgrid">\${tiles}</div>\`;
  if ($("#sheet").classList.contains("on") && S.sheetKind === "themes") { const p = $("#spanel"), st = p.scrollTop; p.innerHTML = sheetWrap(html, { title: "الثيمات" }); p.scrollTop = filter == null ? st : 0; }
  else openSheet(html, { title: "الثيمات" });
  S.sheetKind = "themes";
}
function pickTheme(i) {
  S.settings.theme = i;
  applyTheme();
  $$(".th").forEach(b => b.classList.toggle("on", +b.dataset.th === i));
  const c = $("#thCur"); if (c) c.textContent = THEMES[i].name;
  Bridge.call("setSettings", { settings: { theme: i } }).catch(() => {});
}
const demoRows = () => [0, 1, 2, 3].map(k => \`<div class="ch" style="--i:\${k}"><div class="lg"><span class="ini">\${["MB", "AJ", "SS", "R"][k]}</span></div><div class="nm"><b>\${["MBC 1", "الجزيرة", "SSC Sport", "روتانا سينما"][k]}</b><div class="bar2"></div></div></div>\`).join("");
function openAnims(filter) {
  S.anFilter = filter == null ? (S.anFilter == null ? -1 : S.anFilter) : filter;
  const f = S.anFilter, cur = +S.settings.anim;
  const btns = ANIMS.map((a, i) => (f < 0 || a.g === f) ? \`<button class="an \${i === cur ? "on" : ""}" data-an="\${i}" style="--i:\${Math.min(i % 20, 12)}"><i>\${i + 1}</i><span>\${esc(a.fx)}<small>\${esc(a.vn)}</small></span></button>\` : "").join("");
  const html = \`<button class="sx" data-act="close">\${ic("x")}</button>
    <div class="shtl">\${ic("spark")} الحركات <em>\${ANIMS.length}</em></div>
    <div class="shsub">الحركة الحالية: <b id="anCur">\${esc(animName(ANIMS[cur]))}</b> — اضغط أي حركة لمعاينتها</div>
    <div class="demo" id="anDemo">\${demoRows()}</div>
    <div class="chips pad">\${[["-1", "الكل"]].concat(VARS.map((v, i) => [String(i), v[0]])).map(x => \`<button class="chip \${String(f) === x[0] ? "on" : ""}" data-anf="\${x[0]}">\${x[1]}</button>\`).join("")}</div>
    <div class="angrid">\${btns}</div>\`;
  if ($("#sheet").classList.contains("on") && S.sheetKind === "anims") { const p = $("#spanel"), st = p.scrollTop; p.innerHTML = sheetWrap(html, { title: "حركة الانتقال" }); p.scrollTop = filter == null ? st : 0; }
  else openSheet(html, { title: "حركة الانتقال" });
  S.sheetKind = "anims";
}
function pickAnim(i) {
  S.settings.anim = i;
  if (S.settings.motion === false) { S.settings.motion = true; Bridge.call("setSettings", { settings: { motion: true } }).catch(() => {}); }
  applyAnim();
  $$(".an").forEach(b => b.classList.toggle("on", +b.dataset.an === i));
  const c = $("#anCur"); if (c) c.textContent = animName(ANIMS[i]);
  const d = $("#anDemo"); if (d) { d.innerHTML = ""; requestAnimationFrame(() => { d.innerHTML = demoRows(); }); }
  Bridge.call("setSettings", { settings: { anim: i } }).catch(() => {});
}

/* ═════════ settings ═════════ */
function renderSettings() {
  const p = S.portal || {}, a = S.account || {}, st = S.settings;
  const seg = (key, opts) => \`<div class="seg" data-set="\${key}">\${opts.map(o => \`<button data-v="\${o[0]}" class="\${st[key] === o[0] ? "on" : ""}">\${o[1]}</button>\`).join("")}</div>\`;
  const th = THEMES[+st.theme] || THEMES[0], tv = themeVars(th);
  const connTxt = S.conn === "error" ? ["errc", "● غير متصل"] : S.conn === "connecting" ? ["waitc", "● جاري الاتصال"] : ["okc", "● متصل"];
  const CL = S.crashLog;
  $("#setBox").innerHTML = \`
    \${CL ? \`<div class="sec-t" style="margin-top:6px">تقرير آخر إغلاق مفاجئ</div>
    <div class="card crash"><div class="srow"><div class="grow"><b>\${ic("alert")} أُغلق التطبيق بشكل مفاجئ</b><small>انسخ التقرير وأرسله لي لنعرف السبب بدقة (\${CL.lines.length} حدث مسجّل)</small></div></div>
      <pre dir="ltr">\${esc(CL.lines.slice(-8).join("\\n"))}</pre>
      <div class="dbtns"><button data-act2="copycrash">\${ic("copy")} نسخ التقرير</button><button data-act2="hidecrash">إخفاء</button></div></div>\` : ""}
    <div class="sec-t" style="margin-top:6px">الاشتراك</div>
    <div class="card">
      <div class="acc-top"><div class="av">\${ic("server")}</div><div style="min-width:0"><b dir="auto">\${esc(p.name || "—")}</b><small dir="ltr" style="text-align:right">\${esc(p.url || "")}</small></div></div>
      <div class="kv"><span>عنوان MAC</span><b dir="ltr">\${esc(p.mac || "—")}</b></div>
      <div class="kv"><span>تاريخ الانتهاء</span><b dir="auto">\${esc(a.expiry || "—")}</b></div>
      \${a.tariff ? \`<div class="kv"><span>الباقة</span><b dir="auto">\${esc(a.tariff)}</b></div>\` : ""}
      <div class="kv"><span>الحالة</span><b class="\${connTxt[0]}">\${connTxt[1]}</b></div>
      \${S.live.loaded && S.live.mode === "all" ? \`<div class="kv"><span>عدد القنوات</span><b>\${fmtN(S.live.channels.length)}</b></div>\` : ""}
      <button class="btn sec wide" id="sPortals" style="margin-top:6px">\${ic("server")} إدارة البوابات</button>
    </div>
    <div class="sec-t">المظهر</div>
    <div class="card np">
      <button class="srow lnk" data-open="themes"><span class="swt" style="background:\${tv["--bg"]}"><i style="background:\${tv["--grad"]}"></i></span><span class="grow"><b>الثيم</b><small>\${esc(th.name)} · \${THEMES.length} ثيم</small></span>\${ic("next", "chev")}</button>
      <button class="srow lnk" data-open="anims"><span class="swa">\${ic("spark")}</span><span class="grow"><b>حركة الانتقال</b><small>\${st.motion === false ? "متوقفة" : esc(animName(ANIMS[+st.anim] || ANIMS[1]))} · 100 حركة</small></span>\${ic("next", "chev")}</button>
      <div class="srow"><div class="grow"><b>تشغيل الحركات</b><small>أوقفها لتصفح أسرع على الأجهزة القديمة</small></div><label class="sw"><input type="checkbox" id="swMotion" \${st.motion !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>الوضع الخفيف 🪶</b><small>يقلل استهلاك الذاكرة ويمنع الإغلاق المفاجئ (يوقف التأثيرات الثقيلة)</small></div><label class="sw"><input type="checkbox" id="swLite" \${st.lite ? "checked" : ""}><i></i></label></div>
    </div>
    <div class="sec-t">الترجمة التلقائية</div>
    <div class="card">
      <div class="srow"><div class="grow"><b>ترجمة تلقائية</b><small>يترجم القصص والعناوين ودليل البرامج إلى لغتك</small></div><label class="sw"><input type="checkbox" id="swTr" \${st.tr ? "checked" : ""}><i></i></label></div>
      <div class="chips" id="trLangs" style="padding-top:14px">\${LANGS.map(l => \`<button class="chip \${st.trLang === l[0] ? "on" : ""}" data-lang="\${l[0]}">\${l[1]}</button>\`).join("")}</div>
      <div class="srow"><div class="grow"><b>أسماء الأقسام بالعربي</b><small>مثل «EN | ACTION MOVIES» ← «أفلام أكشن أجنبية» و«IR | IRAN» ← «🇮🇷 إيراني»</small></div><label class="sw"><input type="checkbox" id="swCatAr" \${st.catAr !== false ? "checked" : ""}><i></i></label></div>
    </div>
    <div class="about" style="margin:10px 0 6px;text-align:right">ترجمة عناوين الأفلام والمسلسلات في القوائم</div>
    \${seg("trTitles", [["smart", "غير الإنجليزية (الفارسي وغيره)"], ["all", "كل العناوين"], ["off", "بدون"]])}
    <div class="sec-t">صور الممثلين وأعمالهم</div>
    <div class="card">
      <div class="srow"><div class="grow"><b>\${st.tmdbKey ? "المصدر: TMDB (مفتاحك)" : "المصدر: ويكيبيديا (مجاني)"}</b><small>\${st.tmdbKey ? "صور وأعمال أدق لكل الممثلين" : "لصور أكثر وأعمال كاملة: أنشئ حساباً مجانياً في themoviedb.org ثم الإعدادات ← API وانسخ «API Key» هنا"}</small></div></div>
      <input id="tmdbKey" type="text" dir="ltr" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="مفتاح TMDB (اختياري)" value="\${esc(st.tmdbKey || "")}" style="width:100%;margin-top:12px;height:44px;border-radius:12px;background:var(--input);border:1px solid var(--line);padding:0 12px;text-align:left">
    </div>
    <div class="sec-t">المشغل الافتراضي</div>
    \${seg("player", [["internal", "داخلي"], ["vlc", "VLC"], ["infuse", "Infuse"], ["nplayer", "nPlayer"]])}
    <div class="sec-t">المحتوى العربي</div>
    \${seg("arabic", [["first", "العربي والمدبلج أولاً"], ["only", "العربي والمدبلج فقط"], ["off", "الكل كما هو"]])}
    <div class="sec-t">المشغل الداخلي</div>
    <div class="about" style="margin:0 0 6px;text-align:right">البث المباشر</div>
    <div class="chips" data-set="pmode" style="padding-top:0">\${ENGS_LIVE.map(e => \`<button class="chip \${(validEng("itv", st.pmode) || "auto") === e[0] ? "on" : ""}" data-v="\${e[0]}">\${e[1]}</button>\`).join("")}</div>
    <div class="about" style="margin:10px 0 6px;text-align:right">الأفلام والمسلسلات</div>
    <div class="chips" data-set="vmode" style="padding-top:0">\${ENGS_VOD.map(e => \`<button class="chip \${(validEng("vod", st.vmode) || "auto") === e[0] ? "on" : ""}" data-v="\${e[0]}">\${e[1]}</button>\`).join("")}</div>
    <div class="about" style="margin-top:8px;text-align:right">كلها تعمل داخل مشغل السهرة. «تلقائي» يجرّب المحركات بالترتيب ويتذكر ما نجح مع بوابتك.</div>
    <div class="sec-t">التخزين المؤقت (Buffer)</div>
    \${seg("buf", [["low", "قليل"], ["normal", "متوازن"], ["high", "كبير"], ["max", "كبير جداً"]])}
    <div class="about" style="margin-top:8px;text-align:right">\${BUF_DESC[st.buf] || BUF_DESC.normal}</div>
    <div class="sec-t">مقاس الصورة</div>
    \${seg("fit", [["contain", "ملائم"], ["cover", "ملء (قص)"], ["fill", "تمديد"]])}
    <div class="sec-t">حجم الترجمة</div>
    \${seg("subSize", [["s", "صغير"], ["m", "متوسط"], ["l", "كبير"], ["xl", "كبير جداً"]])}
    <div class="sec-t">موضع الترجمة</div>
    \${seg("subPos", [["low", "أسفل الشاشة"], ["high", "أعلى قليلاً"]])}
    <div class="sec-t">الصوت المفضّل في الأفلام والقنوات</div>
    \${seg("audio", [["ar", "العربي أولاً"], ["orig", "الصوت الأصلي"]])}
    <div class="card np" style="margin-top:12px">
      <div class="srow"><div class="grow"><b>التشغيل داخل الصفحة</b><small>يشغّل في مربع صفحة التفاصيل نفسها بدل فتح صفحة مشغل منفصلة</small></div><label class="sw"><input type="checkbox" id="swInApp" \${st.inApp !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>إعادة الاتصال التلقائي</b><small>يعيد تشغيل البث عند الانقطاع أو التوقف</small></div><label class="sw"><input type="checkbox" id="swRe" \${st.autoRe !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>الحلقة التالية تلقائياً</b><small>يبدأ الحلقة التالية عند انتهاء الحالية</small></div><label class="sw"><input type="checkbox" id="swNext" \${st.autoNext !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>المتابعة من حيث توقفت</b><small>يكمل الفيلم أو الحلقة من آخر موضع</small></div><label class="sw"><input type="checkbox" id="swResume" \${st.resume !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>ترجمة الأفلام تلقائياً للعربية</b><small>إذا لم توجد ترجمة عربية يترجم ترجمة الملف</small></div><label class="sw"><input type="checkbox" id="swSubTr" \${st.subTr !== false ? "checked" : ""}><i></i></label></div>
      <div class="srow"><div class="grow"><b>إظهار السرعة والمخزون</b><small>سرعة التحميل وثواني التخزين أعلى المشغل</small></div><label class="sw"><input type="checkbox" id="swStats" \${st.stats !== false ? "checked" : ""}><i></i></label></div>
    </div>
    <div class="btns">
      <button class="btn sec wide" id="sReload">\${ic("refresh")} تحديث قائمة القنوات</button>
      <button class="btn ghost wide" id="sClear">مسح الذاكرة المؤقتة</button>
    </div>
    <div class="about">\${APPN} v\${esc(S.version)}<br>\${S.app ? "تطبيق آيفون" : "يعمل داخل Scriptable"} · بياناتك محفوظة على جهازك فقط</div>\`;
}
async function setSetting(key, val) {
  S.settings[key] = val;
  Bridge.call("setSettings", { settings: { [key]: val } }).catch(() => {});
  if (key === "arabic") {
    if (S.live.loaded || S.live.mode === "quick") { prepLive(); if (S.live.mode !== "all" && !S.live.byGenre[S.live.genre]) selectGenre(S.live.genre); else { liveCompute(); renderLive(true); } }
    ["vod", "series"].forEach(t => { const V = S.vod[t]; if (V.loaded && V.raw.length) { V.cats = [{ id: "__home", title: "الرئيسية" }].concat(arrange(V.raw)); renderCats(t); if (V.cat === "__home" && !V.q) homeLoad(t); } });
  }
  if (key === "motion" || key === "lite") { applyLite(); applyAnim(); }

  if (key === "tr" || key === "trLang") Object.keys(TR).forEach(k => delete TR[k]);
  if (["tr", "trLang", "catAr", "trTitles"].includes(key)) refreshNames();
  renderSettings();
}

// إعادة عرض أسماء الأقسام والعناوين بعد تغيير إعدادات الترجمة
function refreshNames() {
  Object.keys(CN).forEach(k => delete CN[k]); Object.keys(TN).forEach(k => delete TN[k]);
  const L = S.live;
  if (L.genres && L.genres.length && $("#liveGenres")) { renderGenres(); catsAr(L.genres.map(x => x.title)); }
  ["vod", "series"].forEach(t => {
    const V = S.vod[t];
    if (!V.loaded || !V.cats || !V.cats.length) return;
    renderCats(t); catsAr(V.cats.map(x => x.title));
    if (V.cat === "__home" && !V.q) { (V.home || []).forEach(h => h && trTitles(h.items)); }
    else trTitles(V.items);
  });
  applyNames();
}

/* ═════════ portals ═════════ */
const OUIS = ["001A79", "1027BE", "001EB8", "00A1F9", "A0BB3E", "D4CFF9", "001D9F", "ECB5D7", "000B78", "0030F1"];
function fmtMac(v) {
  let h = String(v || "").toUpperCase().replace(/[^0-9A-F]/g, "");
  while (h.length > 12 && OUIS.indexOf(h.slice(0, 6)) >= 0 && h.slice(0, 6) === h.slice(6, 12)) h = h.slice(6);
  if (h.length > 12) { let best = -1; for (let i = 0; i + 12 <= h.length; i++) if (OUIS.indexOf(h.substr(i, 6)) >= 0) best = i; h = best >= 0 ? h.substr(best, 12) : h.slice(-12); }
  return (h.match(/.{1,2}/g) || []).join(":");
}
function formHTML(p) {
  p = p || {};
  const f = (id, label, val, ph, ltr, hint) => \`<div class="fld"><label for="\${id}">\${label}</label><input id="\${id}" value="\${esc(val || "")}" placeholder="\${esc(ph || "")}" \${ltr ? 'dir="ltr" autocapitalize="off" autocorrect="off" spellcheck="false"' : ""}>\${hint ? \`<div class="hint" id="\${id}H">\${hint}</div>\` : ""}</div>\`;
  return \`<form class="card form" id="pForm" autocomplete="off">
    <h3>\${p.id ? "تعديل البوابة" : "إضافة بوابة"}</h3>
    <input type="hidden" id="fId" value="\${esc(p.id || "")}">
    \${f("fName", "اسم البوابة", p.name, "اشتراكي")}
    \${f("fUrl", "رابط البوابة", p.url, "http://example.com:8080/c/", true, "الرابط كما يعطيك إياه مزود الخدمة (Portal URL)")}
    \${f("fMac", "عنوان MAC", p.mac, "00:1A:79:XX:XX:XX", true, "الصق العنوان كاملاً — يتم تنسيقه تلقائياً")}
    <details><summary>إعدادات متقدمة (اختياري)</summary>
      \${f("fSn", "Serial Number", p.sn, "يُولّد تلقائياً", true)}
      \${f("fId1", "Device ID 1", p.id1, "يُولّد تلقائياً", true)}
      \${f("fId2", "Device ID 2", p.id2, "يُولّد تلقائياً", true)}
      \${f("fSig", "Signature", p.sig, "يُولّد تلقائياً", true)}
    </details>
    <div class="ferr" id="fErr"></div>
    <button class="btn pri wide" type="submit" id="fSave">\${ic("wifi")} حفظ واتصال</button>
    \${S.portals.length ? \`<button class="btn ghost wide" type="button" id="fCancel">إلغاء</button>\` : ""}
  </form>\`;
}
function showPortals(form, editId, err) {
  const box = $("#portals");
  const list = S.portals.map((p, i) => \`<div class="pcard \${p.id === S.activeId && S.connected ? "act" : ""}" data-pid="\${esc(p.id)}" style="--i:\${i}">
      <div class="pav">\${ic("server")}</div>
      <div class="pinfo"><b dir="auto">\${esc(p.name)}</b><small dir="ltr">\${esc(p.url)}</small><small dir="ltr">\${esc(p.mac)}</small></div>
      <button class="ibtn sm" data-pedit="\${esc(p.id)}">\${ic("edit")}</button>
      <button class="ibtn sm red" data-pdel="\${esc(p.id)}">\${ic("trash")}</button></div>\`).join("");
  const editing = editId ? S.portals.find(p => p.id === editId) : null;
  const showForm = form || !S.portals.length;
  box.innerHTML = \`<div class="pwrap">
    <div class="phero"><div class="logo xl">\${ic("brand")}</div><h1>\${APPN}</h1><p>سهرتك تبدأ هنا — شغّل اشتراك الـ MAC مباشرة على جهازك</p></div>
    \${err ? \`<div class="banner">\${esc(err)}</div>\` : ""}
    \${S.portals.length ? \`<div class="sec-t">البوابات المحفوظة — اضغط للاتصال</div><div class="plist">\${list}</div>\` : ""}
    \${showForm ? formHTML(editing) : \`<button class="btn sec wide" id="pAdd" style="margin-top:16px">\${ic("plus")} إضافة بوابة جديدة</button>\`}
    \${S.connected ? \`<button class="btn ghost wide" id="pBack" style="margin-top:10px">رجوع</button>\` : ""}
  </div>\`;
  box.classList.add("on");
  const mac = $("#fMac");
  if (mac) mac.addEventListener("input", () => {
    mac.value = fmtMac(mac.value);
    const h = $("#fMacH"), ok = mac.value.length === 17;
    if (h) { h.textContent = ok ? "✓ عنوان صحيح" : "الصق العنوان كاملاً — يتم تنسيقه تلقائياً"; h.className = "hint" + (ok ? " ok" : ""); }
  });
}
async function submitPortal() {
  const v = id => ($("#" + id) || {}).value || "";
  const f = { id: v("fId") || null, name: v("fName"), url: v("fUrl"), mac: fmtMac(v("fMac")), sn: v("fSn"), id1: v("fId1"), id2: v("fId2"), sig: v("fSig") };
  const err = $("#fErr");
  err.textContent = "";
  if (!f.url.trim()) { err.textContent = "أدخل رابط البوابة"; return; }
  if (f.mac.length !== 17) { err.textContent = "عنوان MAC يجب أن يتكون من 12 خانة"; return; }
  const btn = $("#fSave");
  btn.disabled = true;
  btn.innerHTML = '<span class="spin sm"></span> جاري الاتصال…';
  try {
    const r = await Bridge.call("savePortal", { portal: f });
    S.portals = r.portals;
    await connect(r.id);
  } catch (e) {
    err.textContent = e.message;
  } finally {
    const b = $("#fSave");
    if (b) { b.disabled = false; b.innerHTML = ic("wifi") + " حفظ واتصال"; }
  }
}
function resetData() {
  S.live = newLive();
  S.vod = { vod: newVod(), series: newVod() };
  ["liveList", "liveGenres", "grid-vod", "cats-vod", "grid-series", "cats-series"].forEach(id => { $("#" + id).innerHTML = ""; });
  $("#liveCount").textContent = "";
  ["q-live", "q-vod", "q-series"].forEach(id => { $("#" + id).value = ""; });
  $$(".clr").forEach(b => b.classList.remove("on"));
}
function loadAccount() {
  Bridge.call("account").then(a => { S.account = a; renderHeader(); if (S.tab === "settings") renderSettings(); }).catch(() => {});
}
async function connect(id, o) {
  o = o || {};
  const fg = !o.bg;
  const p = S.portals.find(x => x.id === id);
  if (fg) splash(true, "جاري الاتصال بـ " + (p ? p.name : "البوابة") + "…");
  S.conn = "connecting";
  renderHeader();
  try {
    const r = await Bridge.call("connect", { id });
    S.activeId = id; S.portal = r.portal; S.connected = true; S.conn = "ok";
    if (r.favs) S.favs = Object.assign({ itv: [], vod: [], series: [] }, r.favs);
    if (r.recent) S.recent = r.recent;
    S.pos = r.pos || {}; S.done = r.done || {};
    S.pm = r.pm || {};
    if (fg) {
      S.account = null;
      closeSheet(); resetData();
      $("#portals").classList.remove("on");
      switchTab("live");
      splash(false);
      toast("تم الاتصال بنجاح ✓", "ok");
    }
    renderHeader();
    loadAccount();
    if (fg || !o.cached) { if (r.hasCache) liveInit(false); else liveFirstLoad(r.genres); }
    else if (o.stale) liveInit(true, true);
    if (S.tab === "settings") renderSettings();
  } catch (e) {
    S.conn = "error";
    renderHeader();
    if (fg) { splash(false); showPortals(false, null, e.message); }
    else if (o.cached) toast(e.message, "bad");
    else { S.connected = false; showPortals(false, null, e.message); }
  }
}

/* ═════════ modal ═════════ */
function confirmBox(title, msg, okText) {
  return new Promise(res => {
    const m = $("#modal");
    m.innerHTML = \`<div class="mbg"></div><div class="mbox"><b>\${esc(title)}</b><p>\${esc(msg)}</p><div class="mbtns"><button class="btn sec" data-m="0">إلغاء</button><button class="btn danger" data-m="1">\${esc(okText)}</button></div></div>\`;
    requestAnimationFrame(() => m.classList.add("on"));
    m.onclick = e => {
      const b = e.target.closest("[data-m]");
      if (!b && !e.target.classList.contains("mbg")) return;
      m.classList.remove("on");
      res(!!b && b.dataset.m === "1");
    };
  });
}

/* ═════════ events ═════════ */
function nearEnd(viewId, sentId) {
  const v = $("#" + viewId), s = $("#" + sentId);
  return v && s && v.classList.contains("on") && s.getBoundingClientRect().top - v.getBoundingClientRect().bottom < 900;
}
function liveMore() { const L = S.live; if (L.shown && L.shown < L.list.length && nearEnd("v-live", "liveMore")) renderLive(false); }
function vodMore(t) { const V = S.vod[t]; if (V.page > 0 && V.page < V.pages && !V.loading && nearEnd("v-" + t, "more-" + t)) vodLoad(t, false); }

function bindEvents() {
  $$(".tab").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));
  $("#hdr").addEventListener("click", () => showPortals(false));
  $("#hRefresh").addEventListener("click", async () => {
    const b = $("#hRefresh");
    if (b.classList.contains("spin-ic")) return;
    if (S.conn === "error" && S.activeId) { connect(S.activeId, { bg: true, cached: S.live.loaded, stale: true }); return; }
    b.classList.add("spin-ic");
    try {
      if (S.tab === "live" || S.tab === "favs" || S.tab === "settings") { const g = S.live.genre; S.live = newLive(); S.live.genre = g; await liveInit(true); toast("تم تحديث القنوات ✓", "ok"); }
      else if (S.tab === "matches") { MT.data = null; await mLoad(false); }
      else if (S.vod[S.tab]) { const t = S.tab, c = S.vod[t].cat; S.vod[t] = newVod(); S.vod[t].cat = c; await vodEnter(t, true); }
    } finally { b.classList.remove("spin-ic"); }
  });

  const liveSearch = debounce(v => { S.live.q = v; liveCompute(); renderLive(true); if (S.live.mode !== "all" && v.trim()) remoteSearch(v.trim()); }, 260);
  $("#q-live").addEventListener("input", e => { $('[data-clr="q-live"]').classList.toggle("on", !!e.target.value); liveSearch(e.target.value); });
  // تجهيز فهرس البحث في الخلفية عند لمس خانة البحث (القوائم الضخمة فقط)
  $("#q-live").addEventListener("focus", () => { if (S.live.mode !== "all" && !S.live.idxAsked) { S.live.idxAsked = 1; Bridge.call("liveSearch", { q: "" }).catch(() => {}); } });
  ["vod", "series"].forEach(t => {
    const run = debounce(v => { const V = S.vod[t]; if (V.q === v.trim()) return; V.q = v.trim(); renderCats(t); vodLoad(t, true); }, 650);
    const inp = $("#q-" + t);
    inp.addEventListener("input", e => { $('[data-clr="q-' + t + '"]').classList.toggle("on", !!e.target.value); if (!S.vod[t].loaded) return; run(e.target.value); });
    inp.addEventListener("keydown", e => { if (e.key === "Enter") { inp.blur(); run(inp.value); } });
  });
  $$(".clr").forEach(b => b.addEventListener("click", () => { const i = $("#" + b.dataset.clr); i.value = ""; i.dispatchEvent(new Event("input")); b.classList.remove("on"); }));

  // المباريات
  const mReload = () => { MT.data = null; mDays(); $("#mList").innerHTML = skelRows(6); mLoad(false); };
  $("#mDays").addEventListener("click", e => { const b = e.target.closest("[data-day]"); if (!b) return; MT.day = +b.dataset.day; MT.live = false; mReload(); });
  $("#mLive").addEventListener("click", () => { MT.live = !MT.live; mReload(); });
  $("#mMajor").addEventListener("click", () => { MT.major = !MT.major; mReload(); });
  $("#mList").addEventListener("click", e => {
    if (e.target.closest('[data-retry="matches"]')) { mReload(); return; }
    const pb = e.target.closest("[data-mplay]");
    if (pb) { playMatch(pb.dataset.mplay); return; }
    const r = e.target.closest("[data-mg]");
    if (r && MT.data) { const g = MT.data.games.find(x => String(x.id) === r.dataset.mg); if (g) openMatch(g); }
  });
  $("#liveGenres").addEventListener("click", e => { if (e.target.closest("[data-cdd]")) { openCatMenu("live"); return; } const b = e.target.closest("[data-g]"); if (!b) return; S.live.q = ""; $("#q-live").value = ""; $('[data-clr="q-live"]').classList.remove("on"); selectGenre(b.dataset.g); });
  $("#liveList").addEventListener("click", e => {
    const f = e.target.closest("[data-fav]");
    if (f) { const c = S.live.list[+f.dataset.fav]; f.classList.toggle("on", toggleFav("itv", c)); return; }
    const r = e.target.closest(".ch");
    if (r) openChannel(S.live.list, +r.dataset.i);
  });

  ["vod", "series"].forEach(t => {
    $("#cats-" + t).addEventListener("click", e => { if (e.target.closest("[data-cdd]")) { openCatMenu(t); return; } const b = e.target.closest("[data-c]"); if (b) selectCat(t, b.dataset.c); });
    $("#grid-" + t).addEventListener("click", e => {
      const V = S.vod[t], at = x => { const [k, i] = x.split(":").map(Number); return V.home[k] && V.home[k].items[i]; };
      const hp = e.target.closest("[data-hplay]");
      if (hp) { const m = at(hp.dataset.hplay); if (m) { openVod(m); if (!m.isSeries) startPlay(); } return; }
      const ca = e.target.closest("[data-cat]");
      if (ca) { selectCat(t, ca.dataset.cat); return; }
      const cw = e.target.closest("[data-cw]");
      if (cw) { const m = (V.cont || [])[+cw.dataset.cw]; if (m) { openVod(m); if (!m.isSeries) startPlay(); } return; }
      const h = e.target.closest("[data-h]");
      if (h) { const m = at(h.dataset.h); if (m) openVod(m); return; }
      const c = e.target.closest(".pc"); if (c && c.dataset.i != null) openVod(V.items[+c.dataset.i]);
    });
  });

  document.addEventListener("click", e => {
    const b = e.target.closest("[data-retry]");
    if (!b) return;
    const r = b.dataset.retry;
    if (r === "live") liveInit(true);
    else if (r === "genre") selectGenre(S.live.genre, true);
    else if (r === "vod" || r === "series") { S.vod[r].loaded = false; vodEnter(r, true); }
    else if (r === "yt") ytSearch(S.yt.q || YT_CHIPS[0][1]);
  });

  $("#ytChips").addEventListener("click", e => { const b = e.target.closest("[data-yq]"); if (!b) return; $("#q-yt").value = ""; $('[data-clr="q-yt"]').classList.remove("on"); ytSearch(YT_CHIPS[+b.dataset.yq][1]); });
  $("#ytList").addEventListener("click", e => { const y = e.target.closest("[data-y]"); if (y) ytPlay(S.yt.items[+y.dataset.y]); });
  $("#q-yt").addEventListener("input", e => $('[data-clr="q-yt"]').classList.toggle("on", !!e.target.value));
  $("#q-yt").addEventListener("keydown", e => { if (e.key === "Enter") { e.target.blur(); ytSearch(e.target.value); } });
  $("#q-yt").addEventListener("paste", () => setTimeout(() => { const v = $("#q-yt").value; if (ytIdOf(v)) ytSearch(v); }, 50));
  $("#favSeg").addEventListener("click", e => { const b = e.target.closest("[data-v]"); if (!b) return; S.favTab = b.dataset.v; renderFavs(); });
  $("#favBox").addEventListener("click", e => {
    const t = S.favTab;
    if (t === "itv") {
      const f = e.target.closest("[data-fav]");
      if (f) { toggleFav("itv", S.favs.itv[+f.dataset.fav]); renderFavs(); return; }
      const r = e.target.closest(".ch"); if (r) openChannel(S.favs.itv.slice(), +r.dataset.i);
    } else if (t === "vod" || t === "series") {
      const c = e.target.closest(".pc"); if (c) openVod(S.favs[t][+c.dataset.i]);
    } else {
      const r = e.target.closest("[data-r]"); if (!r) return;
      const it = S.recent[+r.dataset.r];
      if (it.t === "itv") openChannel([it.item], 0); else openVod(it.item);
    }
  });

  $("#setBox").addEventListener("click", async e => {
    const a2 = e.target.closest("[data-act2]");
    if (a2) {
      const CL = S.crashLog;
      if (a2.dataset.act2 === "copycrash" && CL) Bridge.call("copyText", { text: [APPN + " v" + S.version + " — تقرير إغلاق مفاجئ", CL.dev].concat(CL.lines).join("\\n") }).then(() => toast("تم نسخ التقرير ✓ — أرسله لي", "ok")).catch(() => {});
      else { S.crashLog = null; renderSettings(); }
      return;
    }
    const sb = e.target.closest("[data-set] [data-v]");
    if (sb) { setSetting(sb.parentNode.dataset.set, sb.dataset.v); return; }
    const lg = e.target.closest("[data-lang]");
    if (lg) { setSetting("trLang", lg.dataset.lang); return; }
    const op = e.target.closest("[data-open]");
    if (op) { if (op.dataset.open === "themes") openThemes(); else openAnims(); return; }
    if (e.target.closest("#sPortals")) showPortals(false);
    else if (e.target.closest("#sReload")) { switchTab("live"); $("#hRefresh").click(); }
    else if (e.target.closest("#sClear")) {
      if (await confirmBox("مسح الذاكرة المؤقتة", "سيتم حذف قوائم القنوات والترجمات المحفوظة وإعادة تحميلها. المفضلة لن تتأثر.", "مسح")) {
        await Bridge.call("clearCache").catch(() => {});
        Object.keys(TR).forEach(k => delete TR[k]);
        toast("تم مسح الذاكرة المؤقتة ✓", "ok");
      }
    }
  });
  $("#setBox").addEventListener("change", e => {
    if (e.target.id === "swMotion") setSetting("motion", e.target.checked);
    else if (e.target.id === "swRe") setSetting("autoRe", e.target.checked);
    else if (e.target.id === "swLite") setSetting("lite", e.target.checked);
    else if (e.target.id === "swStats") setSetting("stats", e.target.checked);
    else if (e.target.id === "swNext") setSetting("autoNext", e.target.checked);
    else if (e.target.id === "swInApp") setSetting("inApp", e.target.checked);
    else if (e.target.id === "swResume") setSetting("resume", e.target.checked);
    else if (e.target.id === "swSubTr") setSetting("subTr", e.target.checked);

    else if (e.target.id === "swTr") setSetting("tr", e.target.checked);
    else if (e.target.id === "swCatAr") setSetting("catAr", e.target.checked);
    else if (e.target.id === "tmdbKey") { setSetting("tmdbKey", e.target.value.trim()); toast(e.target.value.trim() ? "تم حفظ مفتاح TMDB ✓" : "رجعنا لويكيبيديا", "ok"); }
  });

  $("#sheet .sbg").addEventListener("click", closeSheet);
  // الصفحة: يظهر الشريط العلوي عند التمرير + السحب من حافة الشاشة للرجوع (مثل تطبيقات iOS)
  {
    const sp = $("#spanel");
    sp.addEventListener("scroll", () => { const n = sp.firstElementChild; if (n && n.classList.contains("over")) n.classList.toggle("solid", sp.scrollTop > 150); }, { passive: true });
    let sx = -1, sy = 0, dx = 0, lock = 0;
    sp.addEventListener("touchstart", e => {
      const t = e.touches[0]; lock = 0; dx = 0;
      sx = t.clientX > innerWidth - 26 && !e.target.closest("input,.player,#pl,.rowx,.chips") ? t.clientX : -1; sy = t.clientY;
    }, { passive: true });
    sp.addEventListener("touchmove", e => {
      if (sx < 0) return;
      const t = e.touches[0]; dx = t.clientX - sx;
      if (!lock) { if (Math.abs(t.clientY - sy) > 14 && Math.abs(t.clientY - sy) > Math.abs(dx)) { sx = -1; return; } if (Math.abs(dx) > 10) lock = 1; }
      if (lock) { sp.classList.add("drag"); sp.style.transform = "translateX(" + Math.min(0, dx) + "px)"; }
    }, { passive: true });
    sp.addEventListener("touchend", () => {
      if (sx < 0) return;
      const back = lock && -dx > Math.min(110, innerWidth * .28);
      sp.classList.remove("drag"); sp.style.transform = "";
      sx = -1;
      if (back) sheetBack();
    }, { passive: true });
  }
  $("#spanel").addEventListener("input", debounce(e => { if (e.target && e.target.id === "mSq") mSearch(e.target.value); }, 160));
  $("#spanel").addEventListener("click", e => {
    const pe = e.target.closest("[data-person]");
    if (pe) {
      const p = (S.cast || [])[+pe.dataset.person]; if (!p) return;
      const m = S.cur && S.cur.item, prev = S.navBack;
      openPerson(Object.assign({}, p), m ? () => { openVod(m); S.navBack = prev; } : prev);
      return;
    }
    const pw = e.target.closest("[data-pw]");
    if (pw) {
      const it = (S.pWorks || [])[+pw.dataset.pw], p = S.person, back = S.navBack;
      if (!it || !p) return;
      openVod(it); S.navBack = () => openPerson(p, back);
      return;
    }
    const pq = e.target.closest("[data-pq]");
    if (pq) {
      const w = (S.pOther || [])[+pq.dataset.pq]; if (!w) return;
      const t = w.s ? "series" : "vod";
      closeSheet(); switchTab(t);
      setTimeout(() => { const q = $("#q-" + t); if (q) { q.value = w.t; q.dispatchEvent(new Event("input")); } }, 250);
      return;
    }
    const mc = e.target.closest("[data-mch]");
    if (mc) { mPlayCh((S.mChs || [])[+mc.dataset.mch]); return; }
    if (e.target.closest("[data-msopen]")) { S.mSo = 1; e.target.closest("[data-msopen]").classList.add("hide"); const b = $("#mSrch"); if (b) { b.classList.remove("hide"); const i = $("#mSq"); if (i) { mSearch(i.value); i.focus(); } } return; }
    const ms = e.target.closest("[data-msr]");
    if (ms) {
      const ch = (S.mSr || [])[+ms.dataset.msr], g = S.curMatch, R = g && MT.ch[g.id];
      if (!ch) return;
      const net = R && R.names && R.names[0];
      if (g) {
        Bridge.call("netLearn", net ? { net, ch } : { gid: g.id, ch }).catch(() => {});
        toast(net ? "تم ✓ ستظهر «" + ch.name + "» تلقائياً لمباريات " + net : "تم ✓ حفظنا «" + ch.name + "» لهذه المباراة", "ok");
        if (R) R.best = [Object.assign({}, ch, { why: "mine" })].concat(R.best.filter(x => x.id !== ch.id));
      }
      S.mSo = 0; mChRender(g); mPlayCh(ch);
      return;
    }
    if (e.target.closest('[data-retry="msearch"]')) { closeSheet(); switchTab("live"); const q = $("#q-live"); q.value = "beIN SPORTS"; q.dispatchEvent(new Event("input")); return; }
    const t = e.target.closest("[data-act],[data-ext],[data-ep],[data-season],[data-th],[data-thf],[data-an],[data-anf],[data-eng]");
    if (!t || t.disabled) return;
    const d = t.dataset;
    if (d.eng) {
      S.forceEng = d.eng === "auto" ? null : d.eng;
      $$(".engs .chip").forEach(b => b.classList.toggle("on", b.dataset.eng === d.eng));
      if (S.cur && S.cur.cmd) startPlay("internal"); else toast("اختر حلقة أولاً");
      return;
    }
    if (d.th != null) { pickTheme(+d.th); return; }
    if (d.thf != null) { openThemes(+d.thf); return; }
    if (d.an != null) { pickAnim(+d.an); return; }
    if (d.anf != null) { openAnims(+d.anf); return; }
    if (d.ext) { startPlay(d.ext); return; }
    if (d.season != null) { selectSeason(+d.season); return; }
    if (d.ep != null) { playEpisode(+d.ep); return; }
    const a = d.act;
    if (a === "play") startPlay();
    else if (a === "retry") startPlay("internal");
    else if (a === "trySO") {
      const c = S.cur; if (!c || !c.corsOrigin) return;
      setPov("trying", "تهيئة المشغل لخادم البث… إذا ظهرت شاشة سوداء انتظر ثواني وسيرجع التطبيق تلقائياً");
      Bridge.call("useOrigin", { origin: c.corsOrigin, restore: restoreState(c, { eng: "mts", pick: c.pick || 0 }) }).catch(() => { S.noOriginFor = c.corsOrigin; setPov("error", "هذه الطريقة غير متاحة لهذا الخادم"); });
    }
    else if (a === "epgo") { const c = S.cur; if (c && c.epIdx != null && c.eps && c.eps[c.epIdx]) playEpisode(c.epIdx); else if (c && c.eps && c.eps.length) playEpisode(0); else toast("اختر حلقة"); }
    else if (a === "restart") { if (S.cur) { S.cur.fromStart = true; startPlay(); } }
    else if (a === "resume") { if (S.resumeFn) S.resumeFn(); else { const v = $("#vid"); if (v) v.play().catch(() => {}); } }
    else if (a === "report") {
      const c = S.cur; if (!c) return;
      Bridge.call("copyText", { text: reportText(c) }).then(() => toast("تم نسخ التقرير ✓ — أرسله لي", "ok")).catch(() => {});
    }
    else if (a === "getvlc") Bridge.call("open", { url: "https://apps.apple.com/app/vlc-media-player/id650377962" }).catch(() => {});
    else if (a === "copy") copyLink();
    else if (a === "close") sheetBack();
    else if (a === "prev") stepChannel(-1);
    else if (a === "next") stepChannel(1);
    else if (a === "thrand") { let i; do { i = Math.floor(Math.random() * THEMES.length); } while (i === +S.settings.theme); pickTheme(i); toast("🎲 " + THEMES[i].name); const el = $('.th[data-th="' + i + '"]'); if (el) el.scrollIntoView({ block: "center", behavior: "smooth" }); }
    else if (a === "trtoggle") {
      const c = S.cur; if (!c || !c.tr) return;
      S.showOrig = !S.showOrig;
      $("#vDesc").textContent = S.showOrig ? c.item.desc : c.tr.desc;
      t.innerHTML = ic("lang") + (S.showOrig ? " عرض الترجمة" : " مترجم تلقائياً · عرض الأصل");
    }
    else if (a === "favcur") {
      const c = S.cur; if (!c) return;
      const on = toggleFav(curFavType(), c.item);
      t.classList.toggle("on", on);
      if (S.tab === "favs") renderFavs();
      const row = S.tab === "live" && c.kind === "itv" ? $('#liveList [data-fav="' + S.live.list.indexOf(c.item) + '"]') : null;
      if (row) row.classList.toggle("on", on);
    }
  });
  (function drag() {
    const p = $("#spanel");
    let y0 = null, dy = 0;
    p.addEventListener("touchstart", e => { if (p.scrollTop > 0 || e.target.closest("video,.chips")) { y0 = null; return; } y0 = e.touches[0].clientY; dy = 0; }, { passive: true });
    p.addEventListener("touchmove", e => { if (y0 == null) return; dy = e.touches[0].clientY - y0; if (dy > 0) { p.style.transition = "none"; p.style.transform = "translateY(" + dy + "px)"; } }, { passive: true });
    p.addEventListener("touchend", () => { if (y0 == null) return; p.style.transition = ""; p.style.transform = ""; if (dy > 120) closeSheet(); y0 = null; });
  })();

  $("#portals").addEventListener("click", async e => {
    const ed = e.target.closest("[data-pedit]"), del = e.target.closest("[data-pdel]");
    if (ed) { showPortals(true, ed.dataset.pedit); return; }
    if (del) {
      const p = S.portals.find(x => x.id === del.dataset.pdel);
      if (!(await confirmBox("حذف البوابة", "هل تريد حذف «" + (p ? p.name : "") + "» مع مفضلتها؟", "حذف"))) return;
      const r = await Bridge.call("deletePortal", { id: del.dataset.pdel });
      S.portals = r.portals;
      if (S.activeId === del.dataset.pdel) { S.activeId = null; S.connected = false; S.portal = null; S.account = null; S.conn = "idle"; resetData(); renderHeader(); }
      showPortals(false);
      return;
    }
    if (e.target.closest("#pAdd")) { showPortals(true); return; }
    if (e.target.closest("#pBack") || e.target.closest("#fCancel")) { if (S.connected) $("#portals").classList.remove("on"); else showPortals(false); return; }
    const card = e.target.closest("[data-pid]");
    if (card) connect(card.dataset.pid);
  });
  $("#portals").addEventListener("submit", e => { e.preventDefault(); submitPortal(); });

  $("#v-live").addEventListener("scroll", liveMore, { passive: true });
  ["vod", "series"].forEach(t => $("#v-" + t).addEventListener("scroll", () => vodMore(t), { passive: true }));
}

/* ═════════ boot (instant: data is injected by Scriptable) ═════════ */
function boot() {
  const B = window.__BOOT || {};
  S.app = !!B.app;
  if (S.app) document.documentElement.classList.add("app");
  S.hls2 = B.hls2 == null ? null : +B.hls2;
  S.nts = B.nts == null ? null : +B.nts;
  S.swapOK = B.swapOK && typeof B.swapOK === "object" ? B.swapOK : {};
  // نقطة حمراء على «مباريات» إذا كانت هناك مباريات مباشرة الآن
  setTimeout(() => { if (S.tab !== "matches") Bridge.call("matches", { live: true, tz: tz() }).then(d => mLiveBadge(((d && d.games) || []).length)).catch(() => {}); }, 6000);
  S.settings = Object.assign(S.settings, B.settings || {});
  // ثيم «نتفلكس» يُفعَّل مرة واحدة بعد التحديث (ويمكن تغييره من الإعدادات ← الثيمات)
  if (!S.settings.nf1) { const ni = THEMES.findIndex(t => t.nf); if (ni >= 0) { S.settings.theme = ni; S.settings.nf1 = 1; setTimeout(() => Bridge.call("setSettings", { settings: { theme: ni, nf1: 1 } }).catch(() => {}), 1200); } }
  applyTheme();
  applyLite();
  applyAnim();
  $$("[data-ic]").forEach(el => { el.innerHTML = ic(el.dataset.ic) + el.innerHTML; });
  bindEvents();
  $("#splash").addEventListener("click", () => { if (splash.done || !S.activeId) $("#splash").classList.remove("on"); });
  S.portals = B.portals || [];
  S.version = B.version || "";
  S.noOriginFor = B.noOrigin || "";
  S.noMove = Object.assign({}, B.noMove || {});
  S.crashLog = B.crashLog || null;
  const p = S.portals.find(x => x.id === B.activeId);
  if (!p) { splash(false); showPortals(true); return; }
  S.activeId = p.id; S.portal = p; S.connected = true;
  S.account = B.account || null;
  if (B.user) { S.favs = Object.assign({ itv: [], vod: [], series: [] }, B.user.favs || {}); S.recent = B.user.recent || []; S.pm = B.user.pm || {}; S.pos = B.user.pos || {}; S.done = B.user.done || {}; }
  const C = window.__CACHE;
  if (C && C.data) applyLive(C.data); else $("#liveList").innerHTML = skelRows(9);
  if (B.restore) { splash.done = true; $("#splash").classList.remove("on"); } else splash(false);
  if (B.connected) { S.conn = "ok"; renderHeader(); loadAccount(); if (!(C && C.data)) liveInit(false); }
  else connect(p.id, { bg: true, cached: !!(C && C.data), stale: !C || !C.ts || Date.now() - C.ts > 6 * 3600 * 1000 });
  if (B.restore) setTimeout(() => doRestore(B.restore), 40);
  else if (B.crashed) setTimeout(() => toast("أُغلق التطبيق بشكل مفاجئ آخر مرة — فعّلنا الوضع الخفيف 🪶\\nالتقرير في الإعدادات: انسخه وأرسله لي", "ok"), 1800);
}
let errN = 0;
window.addEventListener("error", e => { if (errN++ < 20) Bridge.call("log", { msg: "error: " + String(e.message || e).slice(0, 120) + " @" + (e.lineno || "") }).catch(() => {}); });
window.addEventListener("unhandledrejection", e => { if (errN++ < 20) Bridge.call("log", { msg: "rejection: " + String((e.reason && e.reason.message) || e.reason).slice(0, 120) }).catch(() => {}); });
function fatal(e) {
  try {
    const el = $("#splash");
    el.classList.add("on");
    $("#spSt").innerHTML = \`<div style="max-width:300px;margin-top:10px;line-height:1.7">حدث خطأ أثناء فتح التطبيق<br><small style="color:var(--mut)" dir="ltr">\${esc(String((e && e.message) || e).slice(0, 160))}</small></div><button class="btn sec" id="fatalReload" style="margin-top:14px;height:44px">\${ic("refresh")} إعادة التحميل</button>\`;
    const b = $("#fatalReload");
    if (b) b.onclick = () => Bridge.call("reloadApp").catch(() => {});
  } catch (x) {}
}
try { boot(); window.__ALSAHRA = true; window.__alsahraApp = { S: S }; } catch (e) { fatal(e); }
})();
</script>
</body>
</html>
`;

/* ───────────────────────── التشغيل ───────────────────────── */
const OUT = [];   // ردود جاهزة تُسلَّم للواجهة مع الاستطلاع التالي (تقييم واحد في كل مرة)
// داخل التطبيق: الصفحة توقظ الحلقة فوراً عند كل طلب، والرد الجاهز يوقظها أيضاً
let WAKE = null;
const wake = () => { const f = WAKE; WAKE = null; if (f) f(); };
const nap = ms => new Promise(r => { let t = null; const go = () => { clearTimeout(t); if (WAKE === go) WAKE = null; r(); }; t = setTimeout(go, ms); WAKE = go; });
async function handle(m) {
  let ok = true, res;
  const t0 = Date.now();
  if (m.action !== "log" && m.action !== "saveUser") crumb("→ " + m.action, /^(liveInit|liveGenre|lib|useOrigin|ytPlay|connect)$/.test(m.action));
  try {
    const fn = H[m.action];
    if (!fn) throw new Error("أمر غير معروف: " + m.action);
    res = await fn(m.data || {});
  } catch (e) {
    ok = false;
    res = String((e && e.message) || e);
    console.warn(m.action + " → " + res);
  }
  const payload = (ok && res && typeof res.__raw === "string")
    ? '{"id":' + m.id + ',"ok":true,"res":' + res.__raw + '}'
    : JSON.stringify({ id: m.id, ok, res: res === undefined ? null : res })
    .replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  if (m.action !== "log" && m.action !== "saveUser") crumb("← " + m.action + (ok ? "" : " ✗ " + String(res).slice(0, 60)) + " " + (Date.now() - t0) + "ms " + Math.round(payload.length / 1024) + "KB");
  OUT.push(payload);
  wake();
}

const safeJS = s => s.replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
function buildHTML(restore, noCache) {
  // بيانات الإقلاع تُحقن مباشرة في الصفحة → فتح فوري بدون انتظار
  const p = activePortal();
  const boot = { settings: DB.settings, portals: DB.portals.map(pub), activeId: p ? p.id : null, version: APP_VERSION, account: (p && p.account) || null, user: null,
    restore: restore || null, crashed: CRASHED, crashLog: CRASHED && PREV_LOG.length ? { dev: devInfo(), lines: PREV_LOG.slice(-60) } : null, connected: !!(ST && p && ST.p && ST.p.id === p.id), noOrigin: (p && DB.user[p.id] && DB.user[p.id].noOrigin) || "", noMove: (p && DB.user[p.id] && DB.user[p.id].noMove) || {}, hls2: p && DB.user[p.id] && DB.user[p.id].hls2 != null ? DB.user[p.id].hls2 : null, nts: p && DB.user[p.id] && DB.user[p.id].nts != null ? DB.user[p.id].nts : null, swapOK: p && DB.user[p.id] && DB.user[p.id].swap != null ? DB.user[p.id].swap : null };
  let cache = "null";
  if (p) {
    const u = userData(p.id);
    boot.user = { favs: u.favs, recent: u.recent, pm: u.pm || {}, pos: u.pos || {}, done: u.done || {} };
    const f = fp("live_" + p.id + ".json");
    try {
      if (!noCache && FM.fileExists(f)) {
        const raw = FM.readString(f) || "";
        if (raw.length < 3 * 1024 * 1024) {
          try { const j = JSON.parse(raw); if (j && j.data) cache = raw; else throw 0; }
          catch (e) { FM.remove(f); }   // ملف تالف → نحذفه ونحمّل القنوات من جديد
        }
      }
    } catch (e) {}
  }
  if (IN_APP) { boot.app = 1; boot.px = APP_PX; }
  const out = HTML
    .replace("/*__BOOT__*/null", () => safeJS(JSON.stringify(boot)))
    .replace("/*__CACHE__*/null", () => safeJS(cache));
  return IN_APP ? out.replace("<head>", () => "<head><script>" + APP_PX_JS + "</script>") : out;
}
// ملف داخل مجلد التطبيق تعرضه صفحة التطبيق (sahra://app/…)
function appFile(name, text) {
  const dir = FM.joinPath(FM.documentsDirectory(), "app");
  if (!FM.fileExists(dir)) FM.createDirectory(dir, true);
  const f = FM.joinPath(dir, name);
  FM.writeString(f, text);
  return f;
}
// فتح الواجهة: في التطبيق من ملف على عنوان التطبيق (فيعمل الجلب عبر التطبيق)، وفي Scriptable كالعادة
function loadUI(wv, html) {
  if (!IN_APP) return wv.loadHTML(html);
  return wv.loadFile(appFile("ui.html", html));
}

// هل الواجهة جاهزة فعلاً؟ (يحمي من الشاشة السوداء)
async function uiReady(wv, ms, origin) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try {
      const o = await wv.evaluateJavaScript("window.__ALSAHRA && window.Bridge ? String(location.origin) : ''", false);
      if (o) return origin ? originOfUrl(String(o)).toLowerCase() === originOfUrl(origin).toLowerCase() : true;
    } catch (e) {}
    await sleep(200);
  }
  return false;
}

// نقل التطبيق كما هو إلى عنوان خادم البث (بنفس طريقة صفحة المشغل التي تعمل على الجوال):
// نفتح صفحة على الخادم ثم نبني الواجهة داخلها ونشغّل سكربتاتها → يصبح التشغيل داخل الصفحة نفسها بلا حجب CORS
async function moveApp(wv, origin, restore) {
  crumb("move app → " + maskU(origin), true);
  const snap = restore && restore.snap;
  let html = buildHTML(snap ? Object.assign({}, restore, { snap: { top: snap.top || 0 } }) : restore, true);
  // بدون وميض: لا شاشة بداية، والصفحة الحالية (صورة منها) تظهر فوراً مفتوحة بلا حركة حتى يكمل التطبيق التشغيل
  html = html.replace('<div id="splash" class="screen on">', '<div id="splash" class="screen">');
  if (snap && snap.h) html = html.replace('<div id="sheet"><div class="sbg"></div><div class="spanel" id="spanel"></div></div>', () => '<div id="sheet" class="on inst"><div class="sbg"></div><div class="spanel" id="spanel">' + snap.h + '</div></div>');
  const top = snap && snap.top ? +snap.top : 0;
  const J = x => JSON.stringify(x).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  // الطريقة 1 (الأسرع وبلا صفحة الخادم البيضاء): تحميل الواجهة مباشرة بعنوان خادم البث
  if (!DB.noLoadB) {
    let ok = false;
    try {
      await Promise.race([wv.loadHTML(html, origin + "/"), sleep(8000)]);
      if (await uiReady(wv, 2500, origin)) {
        ok = !!(await Promise.race([wv.evaluateJavaScript("fetch(location.origin + '/alsahra-probe-" + Date.now().toString(36) + "', { method: 'HEAD', cache: 'no-store' }).then(function () { completion(1); }, function () { completion(0); })", true), sleep(6000).then(() => 0)]));
      }
    } catch (e) {}
    if (ok) {
      if (top) { try { await wv.evaluateJavaScript("(function(){var p=document.getElementById('spanel');if(p)p.scrollTop=" + top + ";return 1})()", false); } catch (e) {} }
      crumb("move: direct ok", true);
      return true;
    }
    DB.noLoadB = true; saveDB();
    crumb("move: direct failed → server page", true);
  }
  // الطريقة 2: فتح صفحة على الخادم ثم كتابة الواجهة داخلها
  const m = html.match(/<head>([\s\S]*?)<\/head>\s*<body([^>]*)>([\s\S]*)<\/body>/i);
  if (m) {
    const scripts = [];
    const body = m[3].replace(/<script>([\s\S]*?)<\/script>/gi, (x, code) => { scripts.push(code); return ""; });
    const bg = String((restore && restore.bg) || "#0b0d12").replace(/[^#\w(),.\s%]/g, "");
    try {
      // نراقب لحظة فتح صفحة الخادم ونلوّنها بلون التطبيق ونوقف تحميلها فوراً (قبل أن تظهر بيضاء)
      const tag = "alsahra-app-" + Date.now().toString(36);
      const dark = "(function(){try{if(location.href.indexOf(" + J(tag) + ")<0&&location.origin!==" + J(String(origin).replace(/:(80)$/, "").replace(/^(https:\/\/[^/]+):443$/, "$1")) + ")return 0;try{window.stop()}catch(e){}var d=document.documentElement;d.style.background=" + J(bg) + ";var st=document.createElement('style');st.textContent='html,body{background:" + bg.replace(/'/g, "") + "!important;color:transparent!important}body{visibility:hidden!important}';(document.head||d).appendChild(st);return 1}catch(e){return 0}})()";
      let loaded = false;
      const nav = Promise.race([wv.loadURL(origin + "/" + tag + ".html").then(() => { loaded = true; }, () => { loaded = true; }), sleep(10000)]);
      let early = false;
      for (const end = Date.now() + 10000; Date.now() < end && !loaded;) {
        try { if (await wv.evaluateJavaScript(dark, false)) { early = true; break; } } catch (e) {}
        await sleep(15);
      }
      await nav;
      // أولاً: لون التطبيق فوراً بدل صفحة الخادم البيضاء
      try { await wv.evaluateJavaScript(dark, false); } catch (e) {}
      crumb("move: server page " + (early ? "covered early" : "covered after load"), true);
      await wv.evaluateJavaScript("(function(){var d=document.documentElement;d.setAttribute('lang','ar');d.setAttribute('dir','rtl');d.innerHTML=" + J("<head>" + m[1] + "</head><body" + m[2] + ">" + body + "</body>") + ";var p=document.getElementById('spanel');if(p&&" + top + ")p.scrollTop=" + top + ";return 1})()", false);
      for (const code of scripts) await wv.evaluateJavaScript(code + "\n;0", false);
      if (await uiReady(wv, 8000, origin)) return true;
    } catch (e) { crumb("move error: " + String((e && e.message) || e).slice(0, 80), true); }
  }
  // تعذّر → نعود للواجهة العادية ونستخدم صفحة المشغل المنفصلة مع هذا الخادم
  const p = activePortal();
  if (p) { const u = userData(p.id); u.noMove = Object.assign({}, u.noMove || {}, { [origin]: 1 }); saveDB(); }
  try { await loadUI(wv, buildHTML(Object.assign({}, restore || {}, { moveFailed: origin, snap: null }), true)); } catch (e) {}
  await uiReady(wv, 8000);
  return false;
}

// تشغيل الواجهة من عنوان خادم البث (لتجاوز CORS) مع تحقق وتراجع تلقائي
async function switchOrigin(wv, pd) {
  const html = buildHTML(pd.restore, true);
  try {
    // الطريقة 1: فتح صفحة على الخادم نفسه ثم كتابة الواجهة داخلها
    await Promise.race([wv.loadURL(pd.origin + "/alsahra-" + Date.now().toString(36) + ".html"), sleep(10000)]);
    const js = JSON.stringify(html).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    await wv.evaluateJavaScript("document.open();document.write(" + js + ");document.close();0", false);
    if (await uiReady(wv, 6000, pd.origin)) return true;
  } catch (e) { console.warn("origin A: " + e); }
  try {
    // الطريقة 2: تحميل الواجهة مع عنوان أساسي
    await wv.loadHTML(html, pd.origin + "/");
    if (await uiReady(wv, 6000, pd.origin)) return true;
  } catch (e) { console.warn("origin B: " + e); }
  // فشل → نعود للواجهة العادية ولا نكرر المحاولة مع هذا الخادم
  const p = activePortal();
  if (p) { userData(p.id).noOrigin = pd.origin; saveDB(); }
  await loadUI(wv, buildHTML(Object.assign({}, pd.restore || {}, { originFailed: true }), true));
  return false;
}

function applyPreset() {
  if (!PRESET) return;
  const key = normUrl(PRESET.url) + "|" + normMac(PRESET.mac);
  if (DB.presetAdded === key) return;
  DB.presetAdded = key;
  let p = DB.portals.find(x => normUrl(x.url) === normUrl(PRESET.url) && normMac(x.mac) === normMac(PRESET.mac));
  if (!p) { p = { id: "p" + Date.now().toString(36), name: PRESET.name, url: normUrl(PRESET.url), mac: normMac(PRESET.mac), sn: "", id1: "", id2: "", sig: "" }; DB.portals.push(p); }
  DB.activeId = p.id;
  saveDB();
}

async function runApp() {
  applyPreset();
  // إغلاق مفاجئ في المرة السابقة؟ → نفعّل الوضع الخفيف لحماية الذاكرة
  if (CRASHED) { DB.settings.lite = true; }
  DB.session = "open"; saveDB();
  crumb("start v" + APP_VERSION + " · " + devInfo() + (CRASHED ? " · previous session crashed" : ""), true);
  const wv = new WebView();
  let mode = "app";
  if (IN_APP) wv.shouldAllowRequest = r => {
    const u = String((r && r.url) || "");
    if (/^alsahra-wake:/.test(u)) { wake(); return false; }
    // النظام أغلق عملية الصفحة (غالباً نفاد الذاكرة): في الواجهة نعيد بناءها ونكمل ما كان يعمل. (مشغل الصفحة المنفصل له مساره)
    if (/^alsahra-died:/.test(u) && mode === "app") {
      const now = Date.now(); DIED = DIED.filter(t => now - t < 10 * 60000); DIED.push(now);
      const resume = NOWPLAY && DIED.length <= 3 ? NOWPLAY : null;
      crumb("web process closed by the system · playing=" + (NOWPLAY ? NOWPLAY.t + ":" + (NOWPLAY.item && NOWPLAY.item.name) : "no") + " · deaths(10m)=" + DIED.length, true);
      NOWPLAY = null;
      PENDING = { reload: true, restore: { died: true, resume } };
      wake(); return false;
    }
    // صفحة المشغل المنفصل أُغلقت: لا نعيد تحميلها من البداية (يضيع الموضع) — الحلقة أدناه تستأنف من آخر موضع محفوظ
    if (/^alsahra-died:/.test(u) && mode === "player") { PDIED = true; crumb("player page: web process closed by the system", true); wake(); return false; }
    return true;
  };
  // الواجهة تُفتح دائماً بشكل عادي (بدون عنوان خارجي) — هذا يمنع الشاشة السوداء عند الفتح
  await loadUI(wv, buildHTML());
  let closed = false, idle = 0, ytRestore = null, lost = 0, recoveries = 0, PL = null, plost = 0;
  wv.present(true).then(() => { closed = true; DB.session = "closed"; saveDB(); crumb("closed by user", true); });
  if (!(await uiReady(wv, 8000))) { crumb("ui not ready → reload", true); try { await loadUI(wv, buildHTML(null, true)); } catch (e) {} }
  const reloadUI = async (why, restore) => {
    crumb("reload UI: " + why, true);
    OUT.length = 0;
    try { await loadUI(wv, buildHTML(restore || null, true)); } catch (e) {}
    await uiReady(wv, 8000);
  };
  while (!closed) {
    if (Date.now() - logFlushed > 1500) flushLog();
    if (PENDING) {
      const pd = PENDING;
      PENDING = null;
      await sleep(150);
      try {
        if (pd.reload) await reloadUI(pd.restore && pd.restore.died ? "web process closed" : "requested", pd.restore || null);
        else if (pd.player) {
          mode = "player"; PL = pd.player; plost = 0; PDIED = false; OUT.length = 0;
          if (PL.wait) await sleep(1200);   // نترك الخادم يغلق الاتصالات السابقة
          crumb("player start kind=" + PL.kind + " items=" + PL.items.length, true);
          const wasResume = !!PL.resumedAt && Date.now() - PL.resumedAt < 20000;
          if (await playerLoad(wv, PL, true)) {
            if (wasResume) { try { await wv.evaluateJavaScript("window.__alsahraP && __alsahraP.toast('أغلق النظام الصفحة لتوفير الذاكرة — أكملنا التشغيل ✓')", false); } catch (e) {} }
          } else {
            crumb("player failed: " + PL.err, true);
            mode = "app";
            await reloadUI("player failed", Object.assign({}, PL.restore || {}, { playerFailed: PL.err || "تعذّر فتح مشغل السهرة" }));
          }
        }
        else if (pd.move) { OUT.length = 0; const ok = await moveApp(wv, pd.move.origin, pd.move.restore); crumb("move app → " + (ok ? "ok" : "failed, fallback"), true); }
        else if (pd.yt) {
          crumb("youtube " + pd.yt, true);
          mode = "yt"; ytRestore = pd.restore; OUT.length = 0;
          await Promise.race([wv.loadURL("https://m.youtube.com/watch?v=" + pd.yt), sleep(12000)]);
          try { await wv.evaluateJavaScript(YT_JS, false); } catch (e) {}
        }
        else { crumb("switch origin " + pd.origin, true); OUT.length = 0; const ok = await switchOrigin(wv, pd); crumb("switch origin → " + (ok ? "ok" : "failed, reverted"), true); }
      } catch (e) { crumb("pending error " + e, true); mode = "app"; await reloadUI("error"); }
      continue;
    }
    if (mode === "player") {
      let raw = null;
      try { raw = await wv.evaluateJavaScript("window.__alsahraP ? __alsahraP.take() : '__gone'", false); } catch (e) { raw = null; }
      if (closed) break;
      if (raw === "__gone" || raw === null || raw === undefined || PDIED) {
        if (++plost >= 5 || PDIED) {
          PDIED = false;
          // النظام أغلق صفحة المشغل (غالباً لنفاد الذاكرة): نعيد التشغيل من آخر موضع محفوظ بدل الرجوع للقائمة
          if ((PL.resumes || 0) < 5) {
            PL.resumes = (PL.resumes || 0) + 1; plost = 0; PL.wait = true; PL.rc = 0; PL.resolveTried = false; PL.resumedAt = Date.now();
            crumb("player page closed by the system → resume " + PL.resumes + "/5", true);
            PENDING = { player: PL };
            continue;
          }
          mode = "app";
          await reloadUI("player page lost", Object.assign({}, PL.restore || {}, { playerFailed: "توقف مشغل السهرة" }));
        } else await sleep(300);
        continue;
      }
      plost = 0;
      let cmds = [];
      try { cmds = raw ? JSON.parse(raw) : []; } catch (e) {}
      let back = false;
      for (const m of cmds) { if ((await playerCmd(wv, PL, m)) === "back") back = true; }
      if (back) {
        const cur = PL.items[PL.index];
        mode = "app";
        await reloadUI("player back", Object.assign({}, PL.restore || {}, { lastId: cur && cur.id, playerFailed: null }));
        continue;
      }
      await sleep(300);
      continue;
    }
    if (mode === "yt") {
      let st = "";
      try { st = await wv.evaluateJavaScript("(function(){try{if(!window.__alsahraYT)return 'inject';return window.__alsahraBack?'back':'';}catch(e){return 'inject'}})()", false); } catch (e) { st = ""; }
      if (closed) break;
      if (st === "inject") { try { await wv.evaluateJavaScript(YT_JS, false); } catch (e) {} }
      else if (st === "back") { mode = "app"; await reloadUI("back from youtube", ytRestore); continue; }
      await sleep(400);
      continue;
    }
    // تقييم واحد فقط: يسلّم الردود الجاهزة ويستلم الطلبات الجديدة
    const batch = OUT.splice(0);
    const resp = batch.length ? "[" + batch.join(",") + "]" : "null";
    let raw = null, failed = false;
    try { raw = await wv.evaluateJavaScript("window.Bridge && window.Bridge.sync ? Bridge.sync(" + resp + ") : '__nobridge'", false); }
    catch (e) { failed = true; }
    if (closed) break;
    if (failed || raw === "__nobridge" || raw === undefined || raw === null) {
      // الصفحة اختفت (نفاد ذاكرة المتصفح أو رجوع من تطبيق آخر) → نعيدها تلقائياً
      if (failed && batch.length && lost === 0) OUT.unshift(...batch);
      if (++lost >= 10 && recoveries < 4) {
        lost = 0; recoveries++;
        DB.settings.lite = true; saveDB();
        await reloadUI(failed ? "evaluate failed" : "page lost", { recovered: true });
        continue;
      }
      await sleep(300);
      continue;
    }
    lost = 0;
    if (raw && typeof raw === "string") {
      idle = 0;
      let msgs = [];
      try { msgs = JSON.parse(raw); } catch (e) {}
      msgs.forEach(m => { handle(m); });
    } else idle++;
    if (IN_APP) await nap(OUT.length ? 5 : idle < 20 ? 150 : 500);
    else await sleep(OUT.length ? 30 : idle < 20 ? 100 : 300);
  }
  flushLog();
}

async function runWidget() {
  const w = new ListWidget();
  const g = new LinearGradient();
  g.colors = [new Color("#3a0a10"), new Color("#0b0b0b")];
  g.locations = [0, 1];
  w.backgroundGradient = g;
  w.setPadding(14, 14, 14, 14);
  const head = w.addText("☾ " + APP_NAME);
  head.font = Font.boldSystemFont(13);
  head.textColor = new Color("#ff4d57");
  w.addSpacer(8);
  const p = activePortal() || DB.portals[0];
  if (!p) {
    const t = w.addText("افتح السكربت لإضافة بوابة");
    t.font = Font.systemFont(12); t.textColor = Color.white();
  } else {
    const n = w.addText(p.name);
    n.font = Font.boldSystemFont(15); n.textColor = Color.white(); n.lineLimit = 1;
    w.addSpacer(4);
    try {
      const s = new Stalker(p);
      await s.auth();
      const a = await s.account();
      const st = w.addText("● متصل");
      st.font = Font.mediumSystemFont(11); st.textColor = new Color("#22c55e");
      if (a.expiry) {
        w.addSpacer(4);
        const e = w.addText("ينتهي: " + a.expiry);
        e.font = Font.systemFont(11); e.textColor = new Color("#cbd5e1"); e.lineLimit = 2; e.minimumScaleFactor = 0.6;
      }
    } catch (e) {
      const t = w.addText("● غير متصل");
      t.font = Font.mediumSystemFont(11); t.textColor = new Color("#ef4444");
    }
  }
  w.addSpacer();
  const df = new DateFormatter();
  df.dateFormat = "HH:mm";
  const f = w.addText("آخر تحديث " + df.string(new Date()));
  f.font = Font.systemFont(9); f.textColor = new Color("#64748b");
  w.refreshAfterDate = new Date(Date.now() + 60 * 60 * 1000);
  if (config.runsInWidget) Script.setWidget(w); else await w.presentSmall();
}

if (config.runsInWidget) await runWidget();
else await runApp();
Script.complete();
