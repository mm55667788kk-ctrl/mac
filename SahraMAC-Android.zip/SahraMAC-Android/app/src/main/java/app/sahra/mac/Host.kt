package app.sahra.mac

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

const val APP_HOST = "sahra.app"
const val CORE_HOST = "sahra.core"
private const val TAG = "SahraHost"

/**
 * الطبقة التي تحت المحرك (core.js): ما يفعله Runtime.swift على الآيفون وhost.js على الكمبيوتر.
 * المحرك يعمل في WebView مخفي، وكل دوال هذا الكائن يستدعيها عبر `AndroidN` (انظر shim-core.js).
 * ما يحتاج وقتاً (الشبكة) يعود بنتيجته عبر `__sahraCb(id)` ثم يسحبها السكربت بـ take().
 */
class Host(private val act: MainActivity, private val ui: WebView, private val core: WebView) {
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newCachedThreadPool()
    private val results = ConcurrentHashMap<Int, Array<String?>>()
    val docs: File = File(act.filesDir, "docs").apply { mkdirs() }
    private val tmp: File = File(act.cacheDir, "tmp").apply { mkdirs() }
    @Volatile private var pendingLoad = 0

    // ---------- مساعدات ----------
    private fun f(p: String): File? {
        return try {
            val c = File(p).canonicalFile
            val a = docs.canonicalPath
            val b = tmp.canonicalPath
            if (c.path == a || c.path.startsWith(a + File.separator) || c.path == b || c.path.startsWith(b + File.separator)) c else null
        } catch (e: Exception) { null }
    }

    private fun finish(id: Int, out: Array<String?>) {
        results[id] = out
        main.post { core.evaluateJavascript("window.__sahraCb($id)", null) }
    }

    private fun <T> onMain(def: T, fn: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) return fn()
        var out = def
        val latch = CountDownLatch(1)
        main.post {
            try { out = fn() } catch (e: Exception) { Log.w(TAG, e) } finally { latch.countDown() }
        }
        latch.await(2, TimeUnit.SECONDS)
        return out
    }

    private fun clip(): ClipboardManager = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    // ---------- من الصفحة إلى المحرك ----------
    fun fromPage(m: String) {
        main.post { core.evaluateJavascript("window.__sahraPost(" + Js.quote(m) + ")", null) }
    }

    // ---------- تحميل الصفحة (واجهة التطبيق) ----------
    private fun beginLoad(id: Int) {
        val old = pendingLoad
        pendingLoad = id
        if (old != 0) finish(old, arrayOf("superseded"))
    }

    fun onPageFinished() {
        val id = pendingLoad
        if (id != 0) { pendingLoad = 0; finish(id, arrayOf<String?>(null)) }
    }

    fun onPageError(msg: String) {
        val id = pendingLoad
        if (id != 0) { pendingLoad = 0; finish(id, arrayOf<String?>(msg)) }
    }

    // ---------- ما يستدعيه السكربت ----------
    @JavascriptInterface fun log(s: String) { Log.i("SahraCore", s) }
    @JavascriptInterface fun crash(s: String) {
        Log.e("SahraCore", "script crashed: $s")
        main.post { Toast.makeText(act, "تعطّل المحرك — أعد فتح التطبيق", Toast.LENGTH_LONG).show() }
    }
    @JavascriptInterface fun exit() { main.post { act.finish() } }

    @JavascriptInterface fun docsDir(): String = docs.path
    @JavascriptInterface fun tmpDir(): String = tmp.path + "/"
    @JavascriptInterface fun exists(p: String): Boolean = f(p)?.exists() ?: false
    @JavascriptInterface fun isDir(p: String): Boolean = f(p)?.isDirectory ?: false
    @JavascriptInterface fun mkdir(p: String) { f(p)?.mkdirs() }
    @JavascriptInterface fun readString(p: String): String? {
        val x = f(p) ?: return null
        return if (x.isFile) x.readText(Charsets.UTF_8) else null
    }
    @JavascriptInterface fun readB64(p: String): String {
        val x = f(p)
        return if (x != null && x.isFile) Base64.encodeToString(x.readBytes(), Base64.NO_WRAP) else ""
    }
    @JavascriptInterface fun writeString(p: String, s: String) {
        val x = f(p) ?: return
        x.parentFile?.mkdirs()
        x.writeText(s, Charsets.UTF_8)
    }
    @JavascriptInterface fun writeB64(p: String, b: String) {
        val x = f(p) ?: return
        x.parentFile?.mkdirs()
        x.writeBytes(Base64.decode(b, Base64.DEFAULT))
    }
    @JavascriptInterface fun remove(p: String) { f(p)?.deleteRecursively() }
    @JavascriptInterface fun move(a: String, b: String) {
        val x = f(a) ?: return
        val y = f(b) ?: return
        y.parentFile?.mkdirs()
        if (!x.renameTo(y)) { x.copyTo(y, true); x.delete() }
    }
    @JavascriptInterface fun copy(a: String, b: String) {
        val x = f(a) ?: return
        val y = f(b) ?: return
        y.parentFile?.mkdirs()
        x.copyTo(y, true)
    }
    @JavascriptInterface fun list(p: String): String {
        val names = f(p)?.list()?.sorted() ?: emptyList()
        return "[" + names.joinToString(",") { Js.quote(it) } + "]"
    }
    @JavascriptInterface fun size(p: String): Double = f(p)?.takeIf { it.isFile }?.length()?.toDouble() ?: 0.0
    @JavascriptInterface fun mtime(p: String): Double = f(p)?.takeIf { it.exists() }?.lastModified()?.toDouble() ?: 0.0

    /** الشبكة: النتيجة تُسحب بـ take(id,0)=خطأ، take(id,1)=ترويسات JSON، take(id,2)=المحتوى. الترويسات تصل بصيغة k\u0001v\u0002k\u0001v */
    @JavascriptInterface fun http(id: Int, url: String, method: String, headers: String, timeout: Double, hasBody: Boolean, body: String, follow: Boolean, kind: String) {
        pool.execute {
            val r = Net.fetch(url, method, Net.parseHeaders(headers), timeout, if (hasBody) body else null, follow)
            val out = arrayOfNulls<String>(3)
            if (r.error != null) {
                out[0] = r.error
            } else {
                out[1] = Net.respJson(r)
                out[2] = if (kind == "b64") Base64.encodeToString(r.body, Base64.NO_WRAP) else String(r.body, Charsets.UTF_8)
            }
            finish(id, out)
        }
    }

    @JavascriptInterface fun take(id: Int, i: Int): String? = results[id]?.getOrNull(i)
    @JavascriptInterface fun drop(id: Int) { results.remove(id) }

    @JavascriptInterface fun wvLoadFile(id: Int, p: String) {
        val root = docs.path
        val rel = (if (p.startsWith(root)) p.substring(root.length) else p).trimStart('/')
        val url = "https://$APP_HOST/" + rel.split('/').joinToString("/") { Uri.encode(it) }
        beginLoad(id)
        main.post { ui.loadUrl(url) }
    }
    @JavascriptInterface fun wvLoadURL(id: Int, u: String) {
        beginLoad(id)
        main.post { ui.loadUrl(u) }
    }
    @JavascriptInterface fun wvLoadHTML(id: Int, html: String, base: String) {
        beginLoad(id)
        main.post { ui.loadDataWithBaseURL(if (base.isEmpty()) null else base, html, "text/html", "utf-8", null) }
    }
    @JavascriptInterface fun wvEval(id: Int, js: String) {
        main.post { ui.evaluateJavascript(js) { r -> finish(id, arrayOf(null, r)) } }
    }

    @JavascriptInterface fun openURL(u: String) { main.post { openExternal(u) } }
    @JavascriptInterface fun copyText(s: String) {
        main.post { try { clip().setPrimaryClip(ClipData.newPlainText("link", s)) } catch (e: Exception) { Log.w(TAG, e) } }
    }
    @JavascriptInterface fun paste(): String = onMain("") {
        val c = clip().primaryClip
        if (c != null && c.itemCount > 0) c.getItemAt(0).coerceToText(act).toString() else ""
    }
    /** لوحة المفاتيح على التلفزيون: الصفحة تضغط OK على حقل نصّي فنُظهرها (التركيز الفعلي للصفحة هو ما يستقبل الكتابة). */
    fun showKeyboard() {
        main.post {
            try {
                ui.requestFocus()
                (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(ui, 0)
            } catch (e: Exception) { Log.w(TAG, e) }
        }
    }
    @JavascriptInterface fun device(): String = Build.VERSION.RELEASE + "|" + Build.MODEL
    @JavascriptInterface fun proxyBase(): String = "https://$APP_HOST/__proxy"

    // ---------- المشغلات الخارجية (Intents) ----------
    private fun toast(t: String) { Toast.makeText(act, t, Toast.LENGTH_LONG).show() }

    private fun openExternal(u: String) {
        when (val plan = Launch.plan(u)) {
            is Plan.Stream -> stream(plan)
            is Plan.Copy -> {
                try { clip().setPrimaryClip(ClipData.newPlainText("link", plan.url)) } catch (e: Exception) { Log.w(TAG, e) }
                toast("هذا المشغل غير متاح على أندرويد — نُسخ الرابط")
            }
            is Plan.Browse, is Plan.Other -> {
                val url = if (plan is Plan.Browse) plan.url else (plan as Plan.Other).url
                try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("لا يوجد تطبيق يفتح هذا الرابط") }
            }
            Plan.None -> { }
        }
    }

    private fun stream(plan: Plan.Stream) {
        val uri = Uri.parse(plan.url)
        for (pkg in plan.pkgs) {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "video/*")
                i.setPackage(pkg)
                act.startActivity(i)
                return
            } catch (e: ActivityNotFoundException) { /* التالي */ }
        }
        if (plan.chooser) {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(uri, "video/*")
                act.startActivity(Intent.createChooser(i, "اختر مشغلاً"))
                return
            } catch (e: Exception) { /* تحت */ }
        }
        try { clip().setPrimaryClip(ClipData.newPlainText("link", plan.url)) } catch (e: Exception) { Log.w(TAG, e) }
        toast((if (plan.name.isEmpty()) "لا يوجد مشغل فيديو" else plan.name + " غير مثبّت") + " — نُسخ الرابط")
    }
}

/** ما تستدعيه الصفحة (الواجهة): رسائلها إلى المحرك. */
class UiBridge(private val host: Host) {
    @JavascriptInterface fun post(m: String) { host.fromPage(m) }
    @JavascriptInterface fun kbd() { host.showKeyboard() }
}
