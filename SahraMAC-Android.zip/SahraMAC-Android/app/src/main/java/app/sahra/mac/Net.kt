package app.sahra.mac

import java.io.ByteArrayInputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/** رد جاهز للواجهة: الحالة + نوع المحتوى + الترويسات + التيار (يُحوَّل إلى WebResourceResponse في الطبقة التي تعرف أندرويد). */
class Resp(val status: Int, val reason: String, val mime: String, val headers: Map<String, String>, val body: InputStream)

/** نتيجة طلب المحرك (Request في السكربت). */
class Fetched(val error: String?, val status: Int, val url: String, val headers: Map<String, String>, val mime: String, val body: ByteArray)

object Js {
    /** سلسلة JSON/JS آمنة (تُدمج في سكربت أو JSON). */
    fun quote(s: String): String {
        val b = StringBuilder(s.length + 2)
        b.append('"')
        for (ch in s) {
            when {
                ch == '"' -> b.append("\\\"")
                ch == '\\' -> b.append("\\\\")
                ch == '\n' -> b.append("\\n")
                ch == '\r' -> b.append("\\r")
                ch == '\t' -> b.append("\\t")
                ch.code < 0x20 || ch == ' ' || ch == ' ' -> b.append(String.format("\\u%04x", ch.code))
                else -> b.append(ch)
            }
        }
        b.append('"')
        return b.toString()
    }
}

object Net {
    private val REDIRECTS = setOf(301, 302, 303, 307, 308)
    private val DROP_REQ = Regex("^(host|origin|referer|accept-encoding|connection|sec-|cookie|x-requested-with)", RegexOption.IGNORE_CASE)
    private val DROP_RESP = Regex("^(content-encoding|access-control-|set-cookie|transfer-encoding|connection|content-type|keep-alive)", RegexOption.IGNORE_CASE)

    /** "k\u0001v\u0002k\u0001v" → خريطة (هكذا يمرّر السكربت الترويسات بلا JSON). */
    fun parseHeaders(s: String): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        if (s.isEmpty()) return m
        for (pair in s.split('\u0002')) {
            val i = pair.indexOf('\u0001')
            if (i > 0) m[pair.substring(0, i)] = pair.substring(i + 1)
        }
        return m
    }

    fun titleCase(k: String): String = k.lowercase().split('-').joinToString("-") { p -> p.replaceFirstChar { c -> c.uppercase() } }

    fun respJson(r: Fetched): String =
        "{\"statusCode\":" + r.status + ",\"url\":" + Js.quote(r.url) + ",\"headers\":{" +
            r.headers.entries.joinToString(",") { Js.quote(it.key) + ":" + Js.quote(it.value) } +
            "},\"mimeType\":" + Js.quote(r.mime) + "}"

    private fun errCode(e: Throwable): String = when (e) {
        is UnknownHostException -> "ENOTFOUND " + (e.message ?: "")
        is SocketTimeoutException -> "ETIMEDOUT"
        is ConnectException -> "ECONNREFUSED " + (e.message ?: "")
        is SSLException -> "CERT " + (e.message ?: "")
        else -> (e.message ?: e.javaClass.simpleName)
    }

    private fun open(url: String, method: String, headers: Map<String, String>, connectMs: Int, readMs: Int, body: ByteArray?, acceptEncoding: String?): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        c.requestMethod = method
        for ((k, v) in headers) {
            if (acceptEncoding != null && k.equals("accept-encoding", true)) continue
            c.setRequestProperty(k, v)
        }
        if (acceptEncoding != null) c.setRequestProperty("Accept-Encoding", acceptEncoding)
        if (body != null && method != "GET" && method != "HEAD") {
            c.doOutput = true
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
        }
        return c
    }

    /** يتبع التحويلات يدوياً (HttpURLConnection لا يحوّل بين http و https). */
    private fun go(url0: String, method0: String, headers: Map<String, String>, connectMs: Int, readMs: Int, body0: ByteArray?, follow: Boolean, acceptEncoding: String?): Pair<HttpURLConnection, String> {
        var url = url0
        var method = method0
        var body = body0
        var hops = 0
        while (true) {
            val c = open(url, method, headers, connectMs, readMs, body, acceptEncoding)
            val code = c.responseCode
            if (follow && code in REDIRECTS && hops < 20) {
                val loc = c.getHeaderField("Location")
                if (loc != null) {
                    val next = URL(URL(url), loc).toString()
                    c.disconnect()
                    if (code == 303 || ((code == 301 || code == 302) && method == "POST")) { method = "GET"; body = null }
                    url = next
                    hops++
                    continue
                }
            }
            return Pair(c, url)
        }
    }

    /** طلب المحرك (Request.load*): يرجع كل شيء كاملاً في الذاكرة. */
    fun fetch(url: String, method: String, headers: Map<String, String>, timeoutSec: Double, body: String?, follow: Boolean): Fetched {
        return try {
            val ms = (if (timeoutSec > 0) timeoutSec * 1000 else 60000.0).toInt()
            val (c, finalUrl) = go(url, method.uppercase(), headers, minOf(ms, 30000), ms, body?.toByteArray(Charsets.UTF_8), follow, null)
            val code = c.responseCode
            val hs = LinkedHashMap<String, String>()
            for ((k, v) in c.headerFields) { if (k != null) hs[titleCase(k)] = v.joinToString(", ") }
            val mime = (c.contentType ?: "").substringBefore(';').trim().lowercase()
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val bytes = try { stream?.use { it.readBytes() } ?: ByteArray(0) } finally { c.disconnect() }
            Fetched(null, code, finalUrl, hs, mime, bytes)
        } catch (e: Throwable) {
            Fetched(errCode(e), 0, url, emptyMap(), "", ByteArray(0))
        }
    }

    private class ConnStream(private val c: HttpURLConnection, s: InputStream) : FilterInputStream(s) {
        override fun close() {
            try { super.close() } catch (e: Exception) { }
            try { c.disconnect() } catch (e: Exception) { }
        }
    }

    fun text(status: Int, reason: String, msg: String): Resp =
        Resp(status, reason, "text/plain", mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store"), ByteArrayInputStream(msg.toByteArray(Charsets.UTF_8)))

    /** وسيط العنوان /__proxy: يجلب أي رابط ويضيف ترويسات CORS (الواجهة وفيديو الصفحة يمرّون منه). */
    fun proxy(target: String, method: String, reqHeaders: Map<String, String>, ua: String?): Resp {
        if (!Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(target)) return text(400, "Bad Request", "bad url")
        val h = LinkedHashMap<String, String>()
        for ((k, v) in reqHeaders) if (!DROP_REQ.containsMatchIn(k)) h[k] = v
        if (!ua.isNullOrEmpty()) {
            h.keys.filter { it.equals("user-agent", true) }.forEach { h.remove(it) }
            h["User-Agent"] = ua
        }
        return try {
            val (c, finalUrl) = go(target, method.uppercase(), h, 20000, 60000, null, true, "identity")
            val code = c.responseCode
            if (code in 300..399) { c.disconnect(); return text(502, "Bad Gateway", "redirect without location") }
            val out = LinkedHashMap<String, String>()
            for ((k, v) in c.headerFields) {
                if (k == null || DROP_RESP.containsMatchIn(k)) continue
                out[k.lowercase()] = v.joinToString(", ")
            }
            out["access-control-allow-origin"] = "*"
            out["access-control-expose-headers"] = "x-sahra-url,content-range,content-length,accept-ranges"
            out["cache-control"] = "no-store"
            out["x-sahra-url"] = finalUrl
            val mime = (c.contentType ?: "application/octet-stream").substringBefore(';').trim().ifEmpty { "application/octet-stream" }
            val stream = (if (code >= 400) c.errorStream else c.inputStream) ?: ByteArrayInputStream(ByteArray(0))
            val reason = (c.responseMessage ?: "").ifEmpty { if (code == 200) "OK" else if (code == 206) "Partial Content" else "Status $code" }
            Resp(code, reason, mime, out, ConnStream(c, stream))
        } catch (e: Throwable) {
            text(502, "Bad Gateway", errCode(e))
        }
    }
}
