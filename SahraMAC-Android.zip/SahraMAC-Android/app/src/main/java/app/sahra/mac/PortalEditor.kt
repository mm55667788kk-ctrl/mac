package app.sahra.mac

import android.app.AlertDialog
import android.os.Build
import android.content.Context
import android.text.InputFilter
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/** Only the visible, first-party portal form can start or receive an edit. */
class PortalEditor(private val activity: MainActivity, private val web: WebView) {
    private val page = "https://$APP_HOST/app/ui.html"
    private var dialog: AlertDialog? = null
    private val titles = mapOf(
        "fName" to "اسم البوابة", "fUrl" to "رابط البوابة", "fMac" to "عنوان MAC",
        "fSn" to "Serial Number", "fId1" to "Device ID 1", "fId2" to "Device ID 2", "fSig" to "Signature"
    )
    private val keyboard get() = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    private fun dp(value: Int) = (activity.resources.displayMetrics.density * value + .5f).toInt()
    private fun active() = !activity.isFinishing && !activity.isDestroyed && web.url == page

    fun open(request: Int) {
        if (request <= 0 || !active() || dialog != null) return
        web.evaluateJavascript("window.SahraPortalInput && window.SahraPortalInput.read($request)") { result ->
            if (!active() || dialog != null) return@evaluateJavascript
            val data = try { JSONObject(result) } catch (_: Exception) { return@evaluateJavascript }
            val field = data.optString("field")
            val title = titles[field] ?: return@evaluateJavascript
            val input = EditText(activity).apply {
                setSingleLine(true)
                inputType = when (field) {
                    "fUrl" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                    "fMac" -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    "fName" -> InputType.TYPE_CLASS_TEXT
                    else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                }
                imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                textDirection = if (field == "fName") View.TEXT_DIRECTION_FIRST_STRONG_RTL else View.TEXT_DIRECTION_LTR
                filters = arrayOf(InputFilter.LengthFilter(max(4096, data.optString("value").length)))
                hint = data.optString("hint")
                setText(data.optString("value"))
            }
            val body = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(4), dp(18), 0)
                addView(input, -1, -2)
            }
            val toggle = Button(activity).apply { text = "لوحة الريموت" }
            body.addView(toggle, -1, -2)
            val keys = ScrollView(activity).apply { visibility = View.GONE; isFocusable = false }
            body.addView(keys, -1, -2)
            val form = AlertDialog.Builder(activity).setTitle(title).setView(body)
                .setPositiveButton("تم", null).setNegativeButton("إلغاء", null).create()
            dialog = form
            var accepted: String? = null
            fun accept() { accepted = input.text.toString(); form.dismiss() }
            form.setOnDismissListener {
                dialog = null
                if (active()) {
                    val value = accepted?.let(Js::quote) ?: "null"
                    web.requestFocus()
                    web.evaluateJavascript("window.SahraPortalInput && window.SahraPortalInput.finish($request,$value)", null)
                }
            }
            fun requestIme() {
                input.post {
                    if (!form.isShowing || !input.hasWindowFocus() || !input.hasFocus() || keys.visibility == View.VISIBLE) return@post
                    if (Build.VERSION.SDK_INT >= 30) input.windowInsetsController?.show(WindowInsets.Type.ime())
                    else keyboard.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
                }
            }
            fun showSystemKeyboard() {
                input.showSoftInputOnFocus = true
                input.requestFocus()
                requestIme()
            }
            // A TV window can get focus after onShow, when it can finally host the IME.
            input.viewTreeObserver.addOnWindowFocusChangeListener { focused -> if (focused) requestIme() }
            toggle.setOnClickListener {
                if (keys.visibility == View.VISIBLE) {
                    keys.visibility = View.GONE
                    toggle.text = "لوحة الريموت"
                    showSystemKeyboard()
                } else {
                    input.showSoftInputOnFocus = false
                    keyboard.hideSoftInputFromWindow(input.windowToken, 0)
                    keys.visibility = View.VISIBLE
                    toggle.text = "لوحة النظام"
                    if (keys.childCount == 0) populateKeys(keys, input, field)
                    keys.findViewWithTag<Button>("firstKey")?.requestFocus()
                }
            }
            form.setOnShowListener {
                form.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { accept() }
                form.window?.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
                form.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
                showSystemKeyboard()
                input.selectAll()
            }
            input.setOnEditorActionListener { _, action, event ->
                val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER
                if (action == EditorInfo.IME_ACTION_DONE || (enter && event?.action == KeyEvent.ACTION_UP)) {
                    accept(); true
                } else enter
            }
            form.show()
        }
    }

    private fun populateKeys(scroll: ScrollView, input: EditText, field: String) {
        val pad = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        scroll.addView(pad)
        val layouts = listOf(
            listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm", ".:/-_?&=%@"),
            listOf("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM", "#+!~$,*;[]"),
            listOf("ضصثقفغعهخح", "جشسيبلاتنم", "كطئءؤرلىةو", "زدظذأإآى،.")
        )
        var mode = if (field == "fName") 2 else 0
        fun insert(value: String, delete: Boolean = false) {
            val text = input.text
            var start = min(input.selectionStart, input.selectionEnd).coerceIn(0, text.length)
            val end = max(input.selectionStart, input.selectionEnd).coerceIn(start, text.length)
            if (delete && start == end && start > 0) start = Character.offsetByCodePoints(text, start, -1)
            text.replace(start, end, value)
        }
        fun draw() {
            pad.removeAllViews()
            fun row() = LinearLayout(activity).apply { pad.addView(this, -1, -2) }
            fun key(row: LinearLayout, label: String, click: () -> Unit): Button {
                return Button(activity).apply {
                    text = label; isAllCaps = false; textSize = 15f
                    minWidth = 0; minimumWidth = 0; setPadding(0, 0, 0, 0)
                    setOnClickListener { click() }
                    row.addView(this, LinearLayout.LayoutParams(0, dp(42), 1f))
                }
            }
            val rows = if (field == "fMac") listOf("0123456789", "ABCDEF:") else layouts[mode]
            for ((index, chars) in rows.withIndex()) {
                val r = row()
                chars.forEachIndexed { col, c ->
                    val b = key(r, c.toString()) { insert(c.toString()) }
                    if (index == 0 && col == 0) b.tag = "firstKey"
                }
            }
            val actions = row()
            if (field != "fMac") {
                key(actions, listOf("ABC", "عربي", "abc")[mode]) {
                    mode = (mode + 1) % layouts.size
                    draw()
                    pad.findViewWithTag<Button>("firstKey")?.requestFocus()
                }
                key(actions, "مسافة") { insert(" ") }
            }
            key(actions, "حذف") { insert("", true) }
            key(actions, "مسح الكل") { input.text.clear() }
        }
        draw()
    }

    val isOpen get() = dialog?.isShowing == true

    fun close() {
        dialog?.setOnDismissListener(null)
        dialog?.dismiss()
        dialog = null
    }
}
