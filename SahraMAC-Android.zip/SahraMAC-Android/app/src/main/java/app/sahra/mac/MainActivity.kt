package app.sahra.mac

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import java.io.ByteArrayInputStream
import java.io.InputStream

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var ui: WebView
    private lateinit var core: WebView
    private lateinit var host: Host
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    // جهاز تلفزيون (Android TV / Google TV): تنسيق عريض + تحكم بالريموت داخل الواجهة (SAHRA_TV)
    private val isTv: Boolean by lazy {
        try {
            (getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
                packageManager.hasSystemFeature("android.software.leanback")
        } catch (e: Exception) { false }
    }

    private val cache = HashMap<String, String>()
    @Synchronized private fun asset(name: String): String = cache.getOrPut(name) {
        assets.open(name).use { it.readBytes().toString(Charsets.UTF_8) }
    }

    private fun js(text: String): WebResourceResponse = WebResourceResponse("application/javascript", "utf-8", ByteArrayInputStream(text.toByteArray(Charsets.UTF_8)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) WebView.setWebContentsDebuggingEnabled(true)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        ui = WebView(this)
        core = WebView(this)
        root.addView(ui, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // المحرك: صفحة 1×1 شبه شفافة (تبقى «ظاهرة» فلا يخنق المتصفح مؤقّتاتها)
        root.addView(core, FrameLayout.LayoutParams(1, 1))
        core.alpha = 0.01f
        core.isFocusable = false
        core.isFocusableInTouchMode = false
        ui.isFocusable = true
        ui.isFocusableInTouchMode = true
        setContentView(root)

        host = Host(this, ui, core)
        setupUi()
        setupCore()
        core.loadUrl("https://$CORE_HOST/boot.html")
        ui.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        if (customView == null) ui.requestFocus()
    }

    private fun baseSettings(w: WebView) {
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.allowFileAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
    }

    private fun setupCore() {
        baseSettings(core)
        core.addJavascriptInterface(host, "AndroidN")
        core.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean { Log.d("SahraCoreJS", m.message() + " @" + m.lineNumber()); return true }
        }
        core.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, r: WebResourceRequest): WebResourceResponse {
                if (r.url.host == CORE_HOST) {
                    return when (r.url.path) {
                        "/boot.html" -> WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(
                            "<!doctype html><html><head><meta charset=\"utf-8\"><script src=\"/shim.js\"></script><script src=\"/prelude.js\"></script><script src=\"/run.js\"></script></head><body></body></html>".toByteArray()))
                        "/shim.js" -> js(asset("shim-core.js"))
                        "/prelude.js" -> js(asset("prelude.js"))
                        "/run.js" -> js(
                            "window.__done = function (e) { AndroidN.crash(String(e)); };\n" +
                                "window.__fin = function () { AndroidN.exit(); };\n" +
                                "(async () => {\nconst __sahraBundle = " + asset("bundled-addons.json") + ";\n" + asset("core.js") + "\n})().then(function () { __fin(); }, function (e) { __done(String(e) + \"\\n\" + ((e && e.stack) || \"\")); });\n")
                        else -> blocked()
                    }
                }
                return blocked()
            }
            override fun onRenderProcessGone(view: WebView, d: RenderProcessGoneDetail): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }
    }

    private fun blocked(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap<String, String>(), ByteArrayInputStream(ByteArray(0)))

    private fun hv(h: Map<String, String>, name: String): String? {
        for ((k, v) in h) if (k.equals(name, true)) return v
        return null
    }

    private fun toResponse(r: Resp): WebResourceResponse {
        val body: InputStream = r.body
        return WebResourceResponse(r.mime, null, r.status, r.reason, r.headers, body)
    }

    private fun serve(r: WebResourceRequest): WebResourceResponse {
        val path = r.url.path ?: "/"
        if (path == "/__assets/ui-pro.js") return js(asset("ui-pro.js"))
        if (path == "/__assets/ui-pro.css") return WebResourceResponse("text/css", "utf-8", ByteArrayInputStream(asset("ui-pro.css").toByteArray(Charsets.UTF_8)))
        val resp = when (path) {
            "/__ack" -> Resp(204, "No Content", "text/plain", mapOf("Access-Control-Allow-Origin" to "*"), ByteArrayInputStream(ByteArray(0)))
            "/__proxy" -> Net.proxy(r.url.getQueryParameter("u") ?: "", r.method ?: "GET", r.requestHeaders ?: emptyMap(), r.url.getQueryParameter("ua"))
            else -> Serve.file(host.docs, path, hv(r.requestHeaders ?: emptyMap(), "Range"), (if (isTv) "<script>window.SAHRA_TV=1</script>" else "") + "<script>" + asset("init-ui.js") + "</script><link rel=\"stylesheet\" href=\"/__assets/ui-pro.css\"><script src=\"/__assets/ui-pro.js\" defer></script>")
        }
        return toResponse(resp)
    }

    private fun setupUi() {
        baseSettings(ui)
        ui.setBackgroundColor(Color.BLACK)
        ui.addJavascriptInterface(UiBridge(host), "AndroidUI")
        ui.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (r.url.host == APP_HOST) serve(r) else null

            override fun shouldOverrideUrlLoading(view: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == APP_HOST) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) { }
                return true
            }

            override fun onPageFinished(view: WebView, url: String) { host.onPageFinished() }

            override fun onReceivedError(view: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) host.onPageError(e.description.toString())
            }

            override fun onRenderProcessGone(view: WebView, d: RenderProcessGoneDetail): Boolean {
                // الواجهة ماتت (غالباً ضغط الذاكرة): نعيد التطبيق كله، والمحرك يستأنف من قاعدة بياناته
                runOnUiThread { recreate() }
                return true
            }
        }
        ui.webChromeClient = chrome
    }

    private val chrome = object : WebChromeClient() {
        override fun onConsoleMessage(m: ConsoleMessage): Boolean { Log.d("SahraUI", m.message() + " @" + m.lineNumber()); return true }

        // ملء الشاشة للفيديو
        override fun onShowCustomView(view: View, cb: CustomViewCallback) {
            if (customView != null) { cb.onCustomViewHidden(); return }
            customView = view
            customCb = cb
            root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            view.requestFocus()   // مفاتيح الريموت تبقى تصل إلى الصفحة في ملء الشاشة
            immersive(true)
        }

        override fun onHideCustomView() {
            val v = customView ?: return
            root.removeView(v)
            customView = null
            try { customCb?.onCustomViewHidden() } catch (e: Exception) { }
            customCb = null
            immersive(false)
            ui.requestFocus()
        }

        // «استيراد من ملف…»
        override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = cb
            return try {
                val i = Intent(Intent.ACTION_GET_CONTENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.mode == FileChooserParams.MODE_OPEN_MULTIPLE)
                startActivityForResult(Intent.createChooser(i, "اختر ملفاً"), 77)
                true
            } catch (e: Exception) {
                fileCb = null
                cb.onReceiveValue(null)
                false
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 77) {
            val r: Array<Uri>? = if (resultCode == RESULT_OK && data != null) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            fileCb?.onReceiveValue(r)
            fileCb = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    @Suppress("DEPRECATION")
    private fun immersive(on: Boolean) {
        window.decorView.systemUiVisibility = if (on)
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        else View.SYSTEM_UI_FLAG_VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (customView != null) {
            val closePanel = "(function(){var done=document.querySelector('.ex-sets.on [data-close]');" +
                "if(!done)return false;done.click();return true;})()"
            ui.evaluateJavascript(closePanel) { handled ->
                if (handled != "true" && customView != null) chrome.onHideCustomView()
            }
            return
        }
        // زر الرجوع = رجوع الواجهة (إغلاق الصفحة المفتوحة)، وإن لم يوجد شيء نرسل التطبيق للخلفية
        val script = "(function(){try{if(typeof sahraBack==='function')return sahraBack()?1:0;if(document.fullscreenElement){document.exitFullscreen();return 1}" +
            "if(document.querySelector('#sheet.on')&&typeof sheetBack==='function'){sheetBack();return 1}}catch(e){}return 0})()"
        ui.evaluateJavascript(script) { r -> if (r != "1") moveTaskToBack(true) }
    }

    override fun onDestroy() {
        try { core.destroy() } catch (e: Exception) { }
        try { ui.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
