package app.sahra.mac

import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.RandomAccessFile

/** مقطع من ملف (لطلبات Range). */
class SliceStream(private val raf: RandomAccessFile, start: Long, private var left: Long) : InputStream() {
    init { raf.seek(start) }
    override fun read(): Int {
        if (left <= 0) return -1
        val b = raf.read()
        if (b >= 0) left--
        return b
    }
    override fun read(buf: ByteArray, off: Int, len: Int): Int {
        if (left <= 0) return -1
        val n = raf.read(buf, off, minOf(len.toLong(), left).toInt())
        if (n > 0) left -= n
        return n
    }
    override fun close() { try { raf.close() } catch (e: Exception) { } }
}

object Serve {
    private val MIME = mapOf(
        "html" to "text/html", "js" to "application/javascript", "json" to "application/json", "css" to "text/css",
        "mp4" to "video/mp4", "m4v" to "video/mp4", "mkv" to "video/x-matroska", "avi" to "video/x-msvideo", "ts" to "video/mp2t",
        "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "webp" to "image/webp", "svg" to "image/svg+xml",
        "srt" to "text/plain", "vtt" to "text/vtt", "txt" to "text/plain"
    )
    private val RANGE = Regex("bytes=(\\d*)-(\\d*)")
    private val HEAD = Regex("<head[^>]*>", RegexOption.IGNORE_CASE)
    const val SLICE = 8L * 1024 * 1024

    private fun hdr(extra: Map<String, String> = emptyMap()): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        m["Cache-Control"] = "no-store"
        m["Accept-Ranges"] = "bytes"
        m["Access-Control-Allow-Origin"] = "*"
        m.putAll(extra)
        return m
    }

    /** ملف من مجلد التطبيق. `path` مفكوك الترميز ويبدأ بـ /. الصفحات (html) يُحقن في أولها `inject`. */
    fun file(docs: File, path: String, range: String?, inject: String?): Resp {
        val root = docs.canonicalFile
        val f = try { File(root, "." + path).canonicalFile } catch (e: Exception) { return Net.text(404, "Not Found", "") }
        if (!f.path.startsWith(root.path + File.separator) || !f.isFile) return Net.text(404, "Not Found", "")
        val ext = f.name.substringAfterLast('.', "").lowercase()
        val mime = MIME[ext] ?: "application/octet-stream"
        if (ext == "html" && inject != null) {
            val src = f.readText(Charsets.UTF_8)
            val m = HEAD.find(src)
            val out = if (m != null) src.substring(0, m.range.last + 1) + inject + src.substring(m.range.last + 1) else inject + src
            val b = out.toByteArray(Charsets.UTF_8)
            return Resp(200, "OK", "text/html", hdr(mapOf("Content-Length" to b.size.toString())), ByteArrayInputStream(b))
        }
        val size = f.length()
        val rm = if (range != null) RANGE.find(range) else null
        if (rm != null && size > 0) {
            val g1 = rm.groupValues[1]
            val g2 = rm.groupValues[2]
            val a = if (g1.isEmpty()) maxOf(0L, size - (g2.toLongOrNull() ?: 0L)) else g1.toLong()
            var b = if (g1.isEmpty() || g2.isEmpty()) size - 1 else minOf(g2.toLong(), size - 1)
            b = minOf(b, a + SLICE - 1)
            if (a >= size || a > b) return Resp(416, "Range Not Satisfiable", mime, hdr(mapOf("Content-Range" to "bytes */$size")), ByteArrayInputStream(ByteArray(0)))
            val raf = RandomAccessFile(f, "r")
            return Resp(206, "Partial Content", mime, hdr(mapOf("Content-Range" to "bytes $a-$b/$size", "Content-Length" to (b - a + 1).toString())), SliceStream(raf, a, b - a + 1))
        }
        return Resp(200, "OK", mime, hdr(mapOf("Content-Length" to size.toString())), FileInputStream(f))
    }
}

/** ماذا نفعل بعنوان فتح مشغل خارجي (يأتي من السكربت بصيغ آيفون) على أندرويد. */
sealed class Plan {
    class Stream(val url: String, val pkgs: List<String>, val chooser: Boolean, val name: String) : Plan()
    class Copy(val url: String) : Plan()
    class Browse(val url: String) : Plan()
    class Other(val url: String) : Plan()
    object None : Plan()
}

object Launch {
    private fun dec(s: String): String = try { java.net.URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    fun plan(u: String): Plan {
        Regex("^vlc-x-callback://x-callback-url/stream\\?url=(.+)$").find(u)?.let {
            return Plan.Stream(dec(it.groupValues[1]), listOf("org.videolan.vlc"), false, "VLC")
        }
        Regex("^sahra-intent://([a-z]+)\\?url=(.+)$").find(u)?.let {
            val url = dec(it.groupValues[2])
            return when (it.groupValues[1]) {
                "mx" -> Plan.Stream(url, listOf("com.mxtech.videoplayer.pro", "com.mxtech.videoplayer.ad"), false, "MX Player")
                else -> Plan.Stream(url, emptyList(), true, "")
            }
        }
        if (Regex("^(infuse|nplayer|senplayer|outplayer)", RegexOption.IGNORE_CASE).containsMatchIn(u)) {
            val x = Regex("[?&]url=([^&]+)").find(u)?.groupValues?.get(1)
                ?: Regex("^nplayer-(https?://.+)$", RegexOption.IGNORE_CASE).find(u)?.groupValues?.get(1)
                ?: Regex("(https?://.+)$").find(u)?.groupValues?.get(1)
            return if (x != null) Plan.Copy(dec(x)) else Plan.None
        }
        if (Regex("^file:", RegexOption.IGNORE_CASE).containsMatchIn(u)) return Plan.None
        if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(u)) return Plan.Browse(u)
        if (Regex("^[a-z][a-z0-9+.\\-]*:", RegexOption.IGNORE_CASE).containsMatchIn(u) && !Regex("^(javascript|data|blob|content|intent):", RegexOption.IGNORE_CASE).containsMatchIn(u)) return Plan.Other(u)
        return Plan.None
    }
}
