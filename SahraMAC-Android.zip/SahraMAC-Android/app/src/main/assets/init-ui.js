/* يعمل في الصفحة قبل سكربتاتها (نفس init.js في نسخة الكمبيوتر): يجعلها تتصرف كما في WKWebView على الآيفون.
 *  - SAHRA_APP / SAHRA_ANDROID
 *  - sahra://app/<ملف> → عنوان التطبيق نفسه
 *  - webkit.messageHandlers.sahra.postMessage(m) → AndroidUI.post(m) (يوقظ حلقة السكربت) */
(function () {
  if (window.__sahraInit) return;
  window.__sahraInit = 1;
  window.SAHRA_APP = 1;
  window.SAHRA_ANDROID = 1;
  var own = function (u) { return typeof u === "string" && u.indexOf("sahra://app/") === 0 ? location.origin + "/" + u.slice(12) : u; };
  var F = window.fetch;
  window.fetch = function (i, o) { return F.call(this, own(i), o); };
  var X = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function () { var a = [].slice.call(arguments); a[1] = own(a[1]); return X.apply(this, a); };
  try {
    var d = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "src");
    Object.defineProperty(HTMLMediaElement.prototype, "src", { configurable: true, enumerable: d.enumerable, get: d.get, set: function (v) { d.set.call(this, own(v)); } });
    var SA = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function (k, v) { return SA.call(this, k, /^(src|poster)$/i.test(k) && typeof v === "string" ? own(v) : v); };
  } catch (e) {}
  window.webkit = { messageHandlers: { sahra: { postMessage: function (m) { try { window.AndroidUI.post(String(m)); } catch (e) {} } } } };
})();
