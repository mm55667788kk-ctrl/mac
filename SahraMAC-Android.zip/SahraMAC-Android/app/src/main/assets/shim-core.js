/* يبني `__native` (ما يقوم عليه prelude.js) فوق كائن أندرويد `AndroidN` (انظر Host.kt).
 * السكربت (core.js) يعمل في WebView مخفي؛ هذا الملف هو ما يقابل Runtime.swift على الآيفون وhost.js على الكمبيوتر.
 * الاستدعاءات القصيرة (ملفات…) متزامنة، وما يستغرق (شبكة، تحميل الصفحة، تقييم JS فيها) يعود بـ __sahraCb(id) ثم نسحب نتيجته بـ take(). */
(function (G) {
  "use strict";
  var A = G.AndroidN;
  var timer = G.setTimeout.bind(G);   // مؤقّت المتصفح الأصلي (prelude.js يعرّف setTimeout فوقه)
  var cbs = {}, seq = 0, wvObj = null;
  var str = function (v) { return v === null || v === undefined ? "" : String(v); };
  var wait = function (fn) { var id = ++seq; cbs[id] = function () { fn(id); }; return id; };
  G.__sahraCb = function (id) { var f = cbs[id]; if (f) { delete cbs[id]; f(); } };
  // رسائل الصفحة → السكربت (WebView.shouldAllowRequest)
  G.__sahraPost = function (m) {
    try { if (wvObj && typeof wvObj.shouldAllowRequest === "function") wvObj.shouldAllowRequest({ url: String(m), method: "GET" }); }
    catch (e) { A.log("post: " + e); }
  };
  var settle = function (ok, bad) {
    return function (id) { var e = A.take(id, 0); A.drop(id); if (e === null || e === undefined) ok(); else bad(String(e)); };
  };
  var N = {
    log: function (s) { A.log(str(s)); },
    fatal: function (s) { A.log("FATAL " + str(s)); },
    after: function (ms, fn) { timer(fn, Math.max(0, +ms || 0)); },
    docsDir: function () { return A.docsDir(); }, tmpDir: function () { return A.tmpDir(); }, libDir: function () { return A.docsDir(); },
    exists: function (p) { return A.exists(str(p)); }, isDir: function (p) { return A.isDir(str(p)); },
    mkdir: function (p) { A.mkdir(str(p)); },
    readString: function (p) { return A.readString(str(p)); },
    writeString: function (p, s) { A.writeString(str(p), str(s)); },
    readB64: function (p) { return A.readB64(str(p)); },
    writeB64: function (p, b) { A.writeB64(str(p), str(b)); },
    remove: function (p) { A.remove(str(p)); },
    move: function (a, b) { A.move(str(a), str(b)); },
    copy: function (a, b) { A.copy(str(a), str(b)); },
    list: function (p) { try { return JSON.parse(A.list(str(p))); } catch (e) { return []; } },
    size: function (p) { return +A.size(str(p)) || 0; },
    mtime: function (p) { return +A.mtime(str(p)) || 0; },
    http: function (optsJSON, kind, cb) {
      var o = JSON.parse(optsJSON), hs = [], h = o.headers || {};
      for (var k in h) hs.push(k + "\u0001" + String(h[k]));
      var id = wait(function (i) {
        var e = A.take(i, 0);
        if (e !== null && e !== undefined) { A.drop(i); cb(String(e), null, null); return; }
        var r = A.take(i, 1), p = A.take(i, 2);
        A.drop(i);
        cb(null, r, p);
      });
      A.http(id, str(o.url), str(o.method || "GET"), hs.join("\u0002"), +o.timeout || 60, o.body !== null && o.body !== undefined, str(o.body), o.follow !== false, kind === "b64" ? "b64" : "string");
    },
    wvCreate: function (id, obj) { wvObj = obj; },
    wvLoadFile: function (id, p, ok, bad) { A.wvLoadFile(wait(settle(ok, function (e) { bad(e); })), str(p)); },
    wvLoadURL: function (id, u, ok, bad) { A.wvLoadURL(wait(settle(ok, function (e) { bad(e); })), str(u)); },
    wvLoadHTML: function (id, h, base, ok, bad) { A.wvLoadHTML(wait(settle(ok, function (e) { bad(e); })), str(h), str(base)); },
    wvPresent: function (id, done) { /* النافذة هي الشاشة نفسها: تنتهي بإغلاق التطبيق */ },
    wvEval: function (id, js, cb) {
      var k = wait(function (i) {
        var raw = A.take(i, 1);
        A.drop(i);
        var r = null;
        try { r = raw === null || raw === undefined ? null : JSON.parse(raw); } catch (e) { r = raw; }
        cb(null, r);
      });
      A.wvEval(k, str(js));
    },
    openURL: function (u) { A.openURL(str(u)); },
    openInApp: function (u, done) { A.openURL(str(u)); done(); },
    openWeb: function (u, js, done) { A.openURL(str(u)); done(); },
    engines: function () { return ""; },
    nativePlay: function (e, j, done) { done(JSON.stringify({ error: "هذا المشغل غير مثبّت على هذا الجهاز" })); },
    copyText: function (s) { A.copyText(str(s)); },
    paste: function () { return A.paste(); },
    device: function () { return A.device(); },
    proxyBase: function () { return A.proxyBase(); }
  };
  G.__native = N;
})(globalThis);
