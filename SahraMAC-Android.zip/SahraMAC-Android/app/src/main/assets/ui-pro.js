/* SahraMAC 3.28 — responsive browsing, display preferences and addon status. */
(function () {
  "use strict";
  var api = window.__alsahraApp;
  if (!api || !api.S || !window.Bridge) return;
  var S = api.S, root = document.documentElement;
  var defaults = { layout: "auto", density: "comfortable", cardSize: "medium", contentWidth: "balanced", tvSafe: 4, badges: true, fit: "contain", videoZoom: 100 };
  var pollTimer = 0, polling = false, saving = false, resizeFrame = 0;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var prefs = function () { return Object.assign({}, defaults, S.settings); };
  var options = {
    layout: [["auto", "تلقائي"], ["phone", "جوال"], ["tablet", "تابلت"], ["tv", "تلفزيون"]],
    density: [["comfortable", "مريح"], ["compact", "مكثّف"]],
    cardSize: [["small", "صغير"], ["medium", "متوسط"], ["large", "كبير"]],
    contentWidth: [["balanced", "متوازن"], ["wide", "واسع"], ["full", "كامل"]],
    tvSafe: [[0, "0%"], [2, "2%"], [4, "4%"], [6, "6%"]],
    badges: [[true, "إظهار"], [false, "إخفاء"]],
    videoZoom: [[75, "75%"], [90, "90%"], [100, "100%"], [110, "110%"], [125, "125%"], [150, "150%"]]
  };
  function layoutFor(st) {
    if (/^(phone|tablet|tv)$/.test(st.layout)) return st.layout;
    if (window.SAHRA_TV) return "tv";
    return innerWidth >= 720 || (innerWidth >= 600 && innerHeight < 540) ? "tablet" : "phone";
  }
  function apply() {
    var st = prefs(), mode = layoutFor(st), rail = mode !== "phone";
    root.classList.add("sahra-pro");
    root.classList.toggle("tv", mode === "tv");
    root.classList.toggle("desk", rail);
    root.dataset.layout = mode;
    root.dataset.density = st.density === "compact" ? "compact" : "comfortable";
    var widths = mode === "phone" ? { small: 84, medium: 100, large: 126 } : mode === "tv" ? { small: 142, medium: 178, large: 215 } : { small: 118, medium: 146, large: 178 };
    root.style.setProperty("--poster", (widths[st.cardSize] || widths.medium) + "px");
    root.style.setProperty("--content-max", st.contentWidth === "full" ? "100%" : st.contentWidth === "wide" ? "1600px" : "1280px");
    root.style.setProperty("--rail", (innerWidth >= 1200 ? 174 : 86) + "px");
    var safe = mode === "tv" ? Math.max(0, Math.min(6, +st.tvSafe || 0)) / 100 : 0;
    root.style.setProperty("--safe-x", Math.round(innerWidth * safe) + "px");
    root.style.setProperty("--safe-y", Math.round(innerHeight * safe) + "px");
    var viewport = window.visualViewport;
    root.style.setProperty("--viewport-height", Math.round(viewport ? viewport.height : innerHeight) + "px");
    var note = document.getElementById("proViewport");
    if (note) note.textContent = innerWidth + " × " + innerHeight + " · " + ({ phone: "تخطيط الجوال", tablet: "تخطيط التابلت", tv: "تخطيط التلفزيون" })[mode];
    var nav = document.querySelector(".tabbar");
    if (nav) nav.setAttribute("aria-label", "التنقل الرئيسي");
    document.querySelectorAll(".tabbar .tab").forEach(function (b) { b.setAttribute("aria-current", b.classList.contains("on") ? "page" : "false"); });
  }
  function group(key, title, detail) {
    var current = prefs()[key];
    return '<div class="pro-group"><div><b>' + title + '</b>' + (detail ? '<small>' + detail + '</small>' : '') + '</div><div class="pro-options" role="group" aria-label="' + title + '">' + options[key].map(function (o) {
      var on = String(current) === String(o[0]);
      return '<button type="button" data-pro-set="' + key + '" data-value="' + o[0] + '" aria-pressed="' + on + '" class="' + (on ? 'on' : '') + '">' + o[1] + '</button>';
    }).join("") + '</div></div>';
  }
  function mountSettings() {
    var box = document.getElementById("setBox");
    if (!box || !box.children.length) return;
    var old = document.getElementById("proSettings");
    if (old) old.remove();
    var section = document.createElement("section");
    section.id = "proSettings"; section.className = "pro-panel";
    section.innerHTML = '<div class="pro-heading"><div><span class="pro-eyebrow">العرض والتصفّح</span><h2>مساحة تناسب شاشتك</h2><small id="proViewport"></small></div><span class="pro-version">' + esc(S.version || "3.29.0") + '</span></div>' +
      group("layout", "تخطيط الشاشة", "تلقائي يتكيّف مع دوران الجهاز وحجم النافذة.") +
      group("cardSize", "حجم البطاقات") + group("density", "كثافة التصفّح") +
      group("contentWidth", "عرض المحتوى") +
      group("tvSafe", "هوامش التلفزيون", "تعالج قصّ الحواف؛ تطبّق في تخطيط التلفزيون.") +
      group("videoZoom", "تكبير الفيديو", "نسبة الأبعاد من «مقاس الصورة» أو ترس المشغّل. التكبير فوق 100% يقصّ الحواف.") +
      group("badges", "شارات Elite Badges", "تعرض الجودة والصوت بحسب معلومات كل مصدر.") +
      '<div class="pro-footer"><button type="button" data-pro-reset>استعادة خيارات العرض</button><span id="proSaved" role="status" aria-live="polite">تُحفظ الخيارات على جهازك</span></div>';
    box.prepend(section); apply();
  }
  async function save(values) {
    if (saving) return;
    saving = true;
    var before = {};
    Object.keys(values).forEach(function (k) { before[k] = S.settings[k]; S.settings[k] = values[k]; });
    apply();
    document.querySelectorAll("[data-pro-set]").forEach(function (b) {
      var on = String(prefs()[b.dataset.proSet]) === b.dataset.value;
      b.classList.toggle("on", on); b.setAttribute("aria-pressed", String(on));
      b.disabled = true;
    });
    try {
      await Bridge.call("setSettings", { settings: values });
      var label = document.getElementById("proSaved"); if (label) label.textContent = "تم حفظ خيارات العرض ✓";
    } catch (e) {
      Object.assign(S.settings, before); apply(); mountSettings(); api.toast("تعذّر حفظ خيارات العرض. أعد المحاولة.", "bad");
    } finally {
      saving = false;
      document.querySelectorAll("[data-pro-set]").forEach(function (b) { b.disabled = false; });
    }
  }
  function addonStatus(a) {
    var state = a.on === false ? "off" : a.confReq ? "configure" : a.status;
    var labels = { off: "متوقفة", saved: "محفوظة · بانتظار التحقق", checking: "جاري التحقق…", ready: "تم التحقق من الإضافة", configure: "تحتاج إعدادًا", error: "تعذّر التحديث · إعادة المحاولة متاحة" };
    return '<i data-pro-status class="pro-status ' + esc(state || "ready") + '">' + (labels[state] || labels.ready) + '</i>';
  }
  function addonIntro() {
    var bundled = S.ad.addons.filter(function (a) { return a.bundled; });
    var names = bundled.map(function (a) { return '<bdi>' + esc(a.name) + '</bdi>'; }).join(' · ');
    return '<div class="pro-addon-intro"><div><h3>المصادر والشارات</h3><p>' + names + '</p>' +
      (bundled.some(function (a) { return a.confReq; }) ? '<small>للإضافة التي تحتاج إعدادًا، افتح «إعداد» ثم أضف رابط التثبيت الذي تحصل عليه.</small>' : '') +
      '<div class="pro-badge-source">Elite Badges · 31 قاعدة لشارات الجودة والصوت</div></div><button type="button" data-adrefreshall>تحديث الإضافات</button></div>';
  }
  function badgesHTML(list) {
    if (prefs().badges === false || !Array.isArray(list) || !list.length) return "";
    return '<span class="pro-badges">' + list.slice(0, 8).map(function (b) {
      var label = esc(b.name), url = /^https?:\/\//i.test(b.image || "") ? b.image : "";
      return '<span class="pro-badge" title="' + label + '">' + (url ? '<img loading="lazy" decoding="async" src="' + esc(url) + '" alt="' + label + '" onerror="this.hidden=true;this.nextElementSibling.hidden=false"><span hidden>' + label + '</span>' : '<span>' + label + '</span>') + '</span>';
    }).join("") + '</span>';
  }
  function updateStatusLabels() {
    document.querySelectorAll(".adli[data-adu]").forEach(function (li) {
      var a = S.ad.addons.find(function (x) { return x.url === li.dataset.adu; });
      var el = li.querySelector("[data-pro-status]");
      if (a && el) el.outerHTML = addonStatus(a);
    });
  }
  function watchAddons() {
    clearTimeout(pollTimer);
    if (!S.ad || !S.ad.addons.some(function (a) { return a.status === "checking"; })) return;
    pollTimer = setTimeout(async function () {
      if (polling || document.hidden) return;
      polling = true;
      try { api.adApply(await Bridge.call("addonList")); updateStatusLabels(); }
      catch (e) { /* Existing metadata and the manual retry button remain available. */ }
      finally { polling = false; watchAddons(); }
    }, 1600);
  }
  async function refreshAddons(url) {
    var buttons = document.querySelectorAll(url ? "[data-adrefresh]" : "[data-adrefreshall]");
    buttons.forEach(function (b) { b.disabled = true; });
    try {
      var r = await Bridge.call("addonRefresh", { url: url || "" }, 90000);
      api.adApply(r); S.ad.dirty = true;
      if (S.ad.tab === "mine") api.adMine();
      var failed = r.addons.filter(function (a) { return (!url || a.url === url) && a.status === "error"; }).length;
      api.toast(failed ? "تعذّر تحديث بعض الإضافات. يمكنك إعادة المحاولة." : "تم تحديث بيانات الإضافات ✓", failed ? "bad" : "ok");
    } catch (e) { api.toast("تعذّر تحديث الإضافات. أعد المحاولة.", "bad"); }
    finally { buttons.forEach(function (b) { b.disabled = false; }); }
  }
  window.SahraPro = { apply: apply, mountSettings: mountSettings, addonStatus: addonStatus, addonIntro: addonIntro, badgesHTML: badgesHTML, watchAddons: watchAddons, refreshAddons: refreshAddons };
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-pro-set]");
    if (b) {
      var key = b.dataset.proSet, value = b.dataset.value;
      if (key === "badges") value = value === "true";
      if (key === "tvSafe" || key === "videoZoom") value = +value;
      var next = {}; next[key] = value; save(next); return;
    }
    if (e.target.closest("[data-pro-reset]")) { save(Object.assign({}, defaults)); return; }
    var tab = e.target.closest(".tabbar .tab");
    if (tab) requestAnimationFrame(function () { apply(); tab.scrollIntoView({ block: "nearest", inline: "nearest" }); });
  });
  function resize() { cancelAnimationFrame(resizeFrame); resizeFrame = requestAnimationFrame(apply); }
  window.addEventListener("resize", resize);
  window.addEventListener("orientationchange", resize);
  if (window.visualViewport) window.visualViewport.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) { apply(); watchAddons(); } });
  apply(); mountSettings(); watchAddons();
})();
