/* Scriptable's objects, rebuilt on the app's native functions (__native, see Runtime.swift),
 * so «السهرة ماك» (SahraMAC.js) runs in the app exactly as it runs in Scriptable. */
(function (G) {
  "use strict";
  var N = G.__native;
  var str = function (v) { return v === null || v === undefined ? "" : String(v); };

  // ---- console ----
  var say = function () { N.log(Array.prototype.map.call(arguments, function (x) { try { return typeof x === "string" ? x : JSON.stringify(x); } catch (e) { return String(x); } }).join(" ")); };
  G.console = { log: say, info: say, warn: say, error: say, debug: say };

  // ---- timers ----
  var seq = 0, live = {};
  G.setTimeout = function (fn, ms) {
    var id = ++seq, a = Array.prototype.slice.call(arguments, 2);
    live[id] = 1;
    N.after(+ms || 0, function () { if (live[id]) { delete live[id]; fn.apply(null, a); } });
    return id;
  };
  G.clearTimeout = function (id) { delete live[id]; };
  G.setInterval = function (fn, ms) {
    var id = ++seq;
    live[id] = 1;
    var tick = function () { N.after(+ms || 0, function () { if (!live[id]) return; fn(); tick(); }); };
    tick();
    return id;
  };
  G.clearInterval = G.clearTimeout;
  // Scriptable's Timer: `new Timer()`, timeInterval in milliseconds, repeats, schedule(cb), invalidate()
  function Timer() { this.timeInterval = 0; this.repeats = false; this._on = false; }
  Timer.prototype.schedule = function (cb) {
    var t = this;
    t._on = true;
    var run = function () { N.after(+t.timeInterval || 0, function () { if (!t._on) return; if (!t.repeats) t._on = false; cb(); if (t.repeats && t._on) run(); }); };
    run();
  };
  Timer.prototype.invalidate = function () { this._on = false; };
  Timer.schedule = function (ms, repeats, cb) { var t = new Timer(); t.timeInterval = ms; t.repeats = !!repeats; t.schedule(cb); return t; };
  G.Timer = Timer;

  // ---- Data ----
  function DataObj(b64) { this._b = b64 || ""; }
  DataObj.prototype.toBase64String = function () { return this._b; };
  DataObj.prototype.toRawString = function () { try { return decodeURIComponent(escape(atob(this._b))); } catch (e) { return ""; } };
  Object.defineProperty(DataObj.prototype, "size", { get: function () { var b = this._b, p = b.endsWith("==") ? 2 : b.endsWith("=") ? 1 : 0; return Math.floor(b.length * 3 / 4) - p; } });
  G.Data = { fromBase64String: function (b) { return new DataObj(str(b)); } };

  // ---- FileManager ----
  var fm = {
    documentsDirectory: function () { return N.docsDir(); },
    libraryDirectory: function () { return N.libDir(); },
    temporaryDirectory: function () { return N.tmpDir(); },
    cacheDirectory: function () { return N.tmpDir(); },
    joinPath: function (a, b) { a = str(a); b = str(b); return (a.endsWith("/") ? a : a + "/") + b.replace(/^\/+/, ""); },
    fileExists: function (p) { return N.exists(str(p)); },
    isDirectory: function (p) { return N.isDir(str(p)); },
    createDirectory: function (p) { N.mkdir(str(p)); },
    readString: function (p) { return N.readString(str(p)); },
    writeString: function (p, s) { N.writeString(str(p), str(s)); },
    read: function (p) { return new DataObj(N.readB64(str(p))); },
    write: function (p, d) { N.writeB64(str(p), d && d.toBase64String ? d.toBase64String() : ""); },
    remove: function (p) { N.remove(str(p)); },
    move: function (a, b) { N.move(str(a), str(b)); },
    copy: function (a, b) { N.copy(str(a), str(b)); },
    listContents: function (p) { return N.list(str(p)); },
    fileSize: function (p) { return N.size(str(p)) / 1024; },
    modificationDate: function (p) { return new Date(N.mtime(str(p))); },
    creationDate: function (p) { return new Date(N.mtime(str(p))); },
    isFileStoredIniCloud: function () { return false; },
    isFileDownloaded: function () { return true; },
    downloadFileFromiCloud: function () { return Promise.resolve(); }
  };
  G.FileManager = { local: function () { return fm; }, iCloud: function () { return fm; } };

  // ---- Request (with Scriptable's onRedirect: return the request to follow it, null to stop) ----
  var hval = function (h, k) { for (var key in h || {}) if (key.toLowerCase() === k) return String(h[key]); return ""; };
  var absUrl = function (loc, base) {
    if (/^[a-z][a-z0-9+.-]*:\/\//i.test(loc)) return loc;
    if (/^\/\//.test(loc)) return (String(base).match(/^[a-z]+:/i) || ["http:"])[0] + loc;
    var o = (String(base).match(/^[a-z][a-z0-9+.-]*:\/\/[^\/?#]+/i) || [""])[0];
    if (loc.charAt(0) === "/") return o + loc;
    return String(base).replace(/[?#].*$/, "").replace(/[^\/]*$/, "") + loc;
  };
  function Request(url) {
    this.url = url; this.method = "GET"; this.headers = {}; this.body = null;
    this.timeoutInterval = 60; this.allowInsecureRequest = false; this.response = null; this.onRedirect = null;
  }
  Request.prototype._go = function (kind) {
    var self = this, url = str(self.url), method = str(self.method || "GET"), headers = self.headers || {}, hops = 0;
    var manual = typeof self.onRedirect === "function";
    return new Promise(function (resolve, reject) {
      var one = function () {
        var opts = { url: url, method: method, headers: headers, timeout: +self.timeoutInterval || 60,
          body: typeof self.body === "string" ? self.body : null, follow: !manual };
        N.http(JSON.stringify(opts), kind, function (err, resp, payload) {
          if (err) { reject(new Error(err)); return; }
          var r;
          try { r = JSON.parse(resp); } catch (e) { r = { statusCode: 0, headers: {} }; }
          r.cookies = [];
          if (manual && r.statusCode >= 300 && r.statusCode < 400 && hops < 10) {
            var loc = hval(r.headers, "location");
            if (loc) {
              var next = absUrl(loc, url), nr = null;
              hops++;
              try { nr = self.onRedirect({ url: next, method: method, headers: headers, body: null }); } catch (e) { nr = null; }
              if (nr) { url = str(nr.url || next); if (nr.method) method = str(nr.method); if (nr.headers) headers = nr.headers; one(); return; }
            }
          }
          self.response = r;
          resolve(payload);
        });
      };
      one();
    });
  };
  Request.prototype.loadString = function () { return this._go("string"); };
  Request.prototype.loadJSON = function () { return this._go("string").then(function (t) { return JSON.parse(t); }); };
  Request.prototype.load = function () { return this._go("b64").then(function (b) { return new DataObj(b); }); };
  G.Request = Request;

  // ---- WebView ----
  var wvSeq = 0, cbSeq = 0;
  function WebView() { this.__id = ++wvSeq; this.shouldAllowRequest = null; N.wvCreate(this.__id, this); }
  WebView.prototype.loadFile = function (p) { var id = this.__id; return new Promise(function (ok, bad) { N.wvLoadFile(id, str(p), function () { ok(); }, function (e) { bad(new Error(e)); }); }); };
  WebView.prototype.loadURL = function (u) { var id = this.__id; return new Promise(function (ok, bad) { N.wvLoadURL(id, str(u), function () { ok(); }, function (e) { bad(new Error(e)); }); }); };
  WebView.prototype.loadHTML = function (h, base) { var id = this.__id; return new Promise(function (ok, bad) { N.wvLoadHTML(id, str(h), str(base), function () { ok(); }, function (e) { bad(new Error(e)); }); }); };
  WebView.prototype.present = function () { var id = this.__id; return new Promise(function (done) { N.wvPresent(id, function () { done(); }); }); };
  // useCallback = true: the page code calls completion(value) when it is done (like Scriptable)
  WebView.prototype.evaluateJavaScript = function (js, useCallback) {
    var id = this.__id;
    if (!useCallback) return new Promise(function (ok, bad) { N.wvEval(id, str(js), function (e, r) { if (e) bad(new Error(e)); else ok(r); }); });
    var k = ++cbSeq;
    var wrapped = "(function(){window.__sc=window.__sc||{};var completion=function(v){window.__sc[" + k + "]={v:v===undefined?null:v}};try{" + str(js) + "\n}catch(e){completion(null)}})();0";
    var take = "(function(){var r=window.__sc&&window.__sc[" + k + "];if(!r)return '__wait';delete window.__sc[" + k + "];try{return JSON.stringify(r.v)}catch(x){return 'null'}})()";
    return new Promise(function (ok, bad) {
      N.wvEval(id, wrapped, function (e) {
        if (e) { bad(new Error(e)); return; }
        var tries = 0;
        var poll = function () {
          N.wvEval(id, take, function (e2, r) {
            if (e2) { bad(new Error(e2)); return; }
            if (r === "__wait") { if (++tries > 1200) { bad(new Error("timeout")); return; } N.after(25, poll); return; }
            try { ok(JSON.parse(r)); } catch (x) { ok(null); }
          });
        };
        poll();
      });
    });
  };
  WebView.prototype.waitForLoad = function () { return Promise.resolve(); };
  G.WebView = WebView;

  // ---- the rest of what the script touches ----
  G.Safari = {
    open: function (u) { N.openURL(str(u)); },
    openInApp: function (u) { return new Promise(function (done) { N.openInApp(str(u), function () { done(); }); }); }
  };
  var dev = N.device ? str(N.device()).split("|") : [];
  G.Device = {
    systemVersion: function () { return dev[0] || ""; }, model: function () { return dev[1] || "iPhone"; },
    name: function () { return dev[1] || "iPhone"; }, systemName: function () { return "iOS"; },
    isPhone: function () { return !/ipad/i.test(dev[1] || ""); }, isPad: function () { return /ipad/i.test(dev[1] || ""); },
    language: function () { return "ar"; }, locale: function () { return "ar_SA"; }
  };
  // the app's own extras: native engines, pages with a script that runs before the site's,
  // and the app's own connection (sahra://app/__proxy) that the page uses for any server
  var engines = N.engines ? str(N.engines()).split(",").filter(Boolean) : (N.hasVLC && N.hasVLC() ? ["vlc"] : []);
  G.__sahraApp = { vlc: engines.indexOf("vlc") >= 0, web: !!N.openWeb, engines: engines, px: N.proxyBase ? str(N.proxyBase()) : "sahra://app/__proxy" };
  function answer(done) { return function (r) { try { done(JSON.parse(str(r))); } catch (e) { done({ error: "bad answer" }); } }; }
  if (N.nativePlay) G.__sahraNative = function (engine, o) {
    return new Promise(function (done) { N.nativePlay(str(engine), JSON.stringify(o || {}), answer(done)); });
  };
  if (N.vlcPlay) G.__sahraVLC = function (o) {
    return new Promise(function (done) { N.vlcPlay(JSON.stringify(o || {}), answer(done)); });
  };
  // downloads: the app's own background downloader (movies and episodes, even with the phone locked)
  if (N.dlStart) G.__sahraDL = {
    start: function (id, url, ua, file, fresh) { N.dlStart(str(id), str(url), str(ua), str(file), !!fresh); },
    pause: function (id) { N.dlPause(str(id)); },
    remove: function (id) { N.dlRemove(str(id)); },
    info: function () { try { return JSON.parse(str(N.dlInfo())); } catch (e) { return []; } }
  };
  if (N.openWeb) G.__sahraWeb = function (url, js) { return new Promise(function (done) { N.openWeb(str(url), str(js), function () { done(); }); }); };
  G.Pasteboard = { copyString: function (s) { N.copyText(str(s)); }, copy: function (s) { N.copyText(str(s)); }, paste: function () { return N.paste(); }, pasteString: function () { return N.paste(); } };
  G.Script = { complete: function () {}, name: function () { return "SahraMAC"; }, setShortcutOutput: function () {}, setWidget: function () {} };
  G.config = { runsInApp: true, runsInWidget: false, runsWithSiri: false, runsInActionExtension: false, runsInNotification: false, runsFromHomeScreen: false, widgetFamily: null };
  G.args = { all: [], plainTexts: [], urls: [], fileURLs: [], images: [], queryParameters: {}, shortcutParameter: null, notification: null, widgetParameter: null };
})(globalThis);
