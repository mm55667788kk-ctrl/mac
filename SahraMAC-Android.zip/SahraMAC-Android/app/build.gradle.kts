plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.sahra.mac"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.sahra.mac"
        minSdk = 24
        targetSdk = 34
        versionCode = 332
        versionName = "3.26.0"
    }

    // مفتاح توقيع ثابت داخل المشروع: يبقى توقيع كل نسخة واحداً فيتحدّث التطبيق فوق القديم بدل أن يتعارض معه.
    signingConfigs {
        create("sahra") {
            storeFile = file("../sahra.jks")
            storePassword = "sahramac"
            keyAlias = "sahra"
            keyPassword = "sahramac"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("sahra")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
