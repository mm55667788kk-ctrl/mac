import UIKit

enum CinemaAction {
    case close
    case playPause
    case jump(Double)
    case seek(Double)
    case speed(Float)
    case tracks
    case episodes
    case next
    case aspect
    case pictureInPicture
}

@MainActor
final class CinemaControls: UIView, UIGestureRecognizerDelegate {
    var onAction: ((CinemaAction) -> Void)?
    private(set) var scrubbing = false

    private let chrome = UIView()
    private let shade = CAGradientLayer()
    private let titleLabel = UILabel()
    private let subtitleLabel = UILabel()
    private let elapsed = UILabel()
    private let remaining = UILabel()
    private let slider = UISlider()
    private let seekTime = UILabel()
    private let spinner = UIActivityIndicatorView(style: .medium)
    private let play = UIButton(type: .system)
    private let back = UIButton(type: .system)
    private let forward = UIButton(type: .system)
    private let speed = UIButton(type: .system)
    private let pip = UIButton(type: .system)
    private let unlock = UIButton(type: .system)
    private let upNext = UIButton(type: .system)

    private let live: Bool
    private let hasNext: Bool
    private var duration: Double = 0
    private var visible = true
    private var waiting = true
    private var paused = false
    private var locked = false
    private var hideTask: DispatchWorkItem?
    private let accent = UIColor(red: 0.90, green: 0.14, blue: 0.25, alpha: 1)

    init(options: EngineOpts, more: UIMenu, routePicker: UIView?) {
        live = options.live
        hasNext = options.hasNext
        super.init(frame: .zero)
        backgroundColor = .clear
        chrome.frame = bounds
        chrome.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(chrome)
        shade.colors = [UIColor.black.withAlphaComponent(0.85).cgColor, UIColor.clear.cgColor,
                        UIColor.clear.cgColor, UIColor.black.withAlphaComponent(0.92).cgColor]
        shade.locations = [0, 0.26, 0.63, 1]
        chrome.layer.insertSublayer(shade, at: 0)

        titleLabel.text = options.title
        titleLabel.font = .systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .right
        titleLabel.lineBreakMode = .byTruncatingTail
        titleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        subtitleLabel.text = options.live ? "مباشر" : options.subtitle
        subtitleLabel.font = .systemFont(ofSize: 12, weight: .medium)
        subtitleLabel.textColor = options.live ? accent : UIColor(white: 0.78, alpha: 1)
        subtitleLabel.textAlignment = .right
        subtitleLabel.lineBreakMode = .byTruncatingTail
        subtitleLabel.isHidden = !options.live && options.subtitle.isEmpty
        subtitleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        let titles = UIStackView(arrangedSubviews: [titleLabel, subtitleLabel])
        titles.axis = .vertical
        titles.spacing = 4

        let close = UIButton(type: .system)
        icon(close, "xmark", label: "إغلاق المشغّل", size: 44, glyph: 19)
        addAction(.close, to: close)
        let menu = UIButton(type: .system)
        icon(menu, "ellipsis", label: "خيارات التشغيل", size: 44, glyph: 20)
        menu.menu = more
        menu.showsMenuAsPrimaryAction = true
        menu.addAction(UIAction { [weak self] _ in self?.show() }, for: .touchDown)
        var headerItems: [UIView] = [close, titles, menu]
        if let routePicker = routePicker {
            routePicker.translatesAutoresizingMaskIntoConstraints = false
            routePicker.widthAnchor.constraint(equalToConstant: 44).isActive = true
            routePicker.heightAnchor.constraint(equalToConstant: 44).isActive = true
            headerItems.append(routePicker)
        }
        icon(pip, "pip.enter", label: "صورة داخل صورة", size: 44, glyph: 21)
        pip.isHidden = true
        addAction(.pictureInPicture, to: pip)
        headerItems.append(pip)
        let header = UIStackView(arrangedSubviews: headerItems)
        header.alignment = .center
        header.spacing = 6
        header.semanticContentAttribute = .forceRightToLeft

        icon(play, "pause.fill", label: "إيقاف مؤقت", size: 78, glyph: 37)
        icon(back, "gobackward.10", label: "رجوع 10 ثوانٍ", size: 54, glyph: 30)
        icon(forward, "goforward.10", label: "تقديم 10 ثوانٍ", size: 54, glyph: 30)
        addAction(.playPause, to: play)
        addAction(.jump(-10), to: back)
        addAction(.jump(10), to: forward)
        let transport = UIStackView(arrangedSubviews: live ? [play] : [back, play, forward])
        transport.alignment = .center
        transport.spacing = 22
        transport.semanticContentAttribute = .forceLeftToRight

        let tracks = footerButton("captions.bubble", "الصوت والترجمة")
        addAction(.tracks, to: tracks)
        let episodes = footerButton("list.bullet.rectangle", "الحلقات")
        addAction(.episodes, to: episodes)
        let lock = footerButton("lock", "قفل الشاشة")
        lock.addAction(UIAction { [weak self] _ in self?.setLocked(true) }, for: .touchUpInside)
        configureFooterButton(speed, "speedometer", "السرعة")
        speed.showsMenuAsPrimaryAction = true
        setSpeedMenu(1)
        var footerItems = [tracks, lock]
        if !live { footerItems.insert(speed, at: 0) }
        if !options.episodes.isEmpty { footerItems.insert(episodes, at: 0) }
        let tools = UIStackView(arrangedSubviews: footerItems)
        tools.distribution = .fillEqually
        tools.spacing = 6
        tools.semanticContentAttribute = .forceRightToLeft

        for label in [elapsed, remaining] {
            label.textColor = .white
            label.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
            label.text = "0:00"
            label.textAlignment = .center
            label.setContentHuggingPriority(.required, for: .horizontal)
            label.setContentCompressionResistancePriority(.required, for: .horizontal)
        }
        slider.minimumValue = 0
        slider.maximumValue = 1
        slider.minimumTrackTintColor = accent
        slider.maximumTrackTintColor = UIColor(white: 1, alpha: 0.32)
        slider.setThumbImage(thumb(diameter: 13), for: .normal)
        slider.setThumbImage(thumb(diameter: 17), for: .highlighted)
        slider.accessibilityLabel = "موضع التشغيل"
        slider.isEnabled = false
        slider.addTarget(self, action: #selector(beginScrub), for: .touchDown)
        slider.addTarget(self, action: #selector(scrubChanged), for: .valueChanged)
        slider.addTarget(self, action: #selector(endScrub), for: [.touchUpInside, .touchUpOutside])
        slider.addTarget(self, action: #selector(cancelScrub), for: .touchCancel)
        let timeline = UIStackView(arrangedSubviews: [elapsed, slider, remaining])
        timeline.spacing = 12
        timeline.alignment = .center
        timeline.semanticContentAttribute = .forceLeftToRight
        let footer = UIStackView(arrangedSubviews: live ? [tools] : [timeline, tools])
        footer.axis = .vertical
        footer.spacing = 7

        seekTime.textColor = .white
        seekTime.backgroundColor = UIColor(white: 0.06, alpha: 0.92)
        seekTime.font = .monospacedDigitSystemFont(ofSize: 14, weight: .semibold)
        seekTime.textAlignment = .center
        seekTime.layer.cornerRadius = 8
        seekTime.clipsToBounds = true
        seekTime.isHidden = true
        spinner.color = .white
        spinner.startAnimating()
        let overlays: [UIView] = [header, transport, footer, seekTime, spinner]
        for view in overlays {
            view.translatesAutoresizingMaskIntoConstraints = false
            chrome.addSubview(view)
        }
        let safe = safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: safe.topAnchor, constant: 7),
            header.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 12),
            header.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -12),
            transport.centerXAnchor.constraint(equalTo: safe.centerXAnchor),
            transport.centerYAnchor.constraint(equalTo: safe.centerYAnchor, constant: -6),
            spinner.centerXAnchor.constraint(equalTo: transport.centerXAnchor),
            spinner.bottomAnchor.constraint(equalTo: transport.topAnchor, constant: -9),
            footer.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 17),
            footer.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -17),
            footer.bottomAnchor.constraint(equalTo: safe.bottomAnchor, constant: -5),
            slider.heightAnchor.constraint(greaterThanOrEqualToConstant: 40),
            seekTime.centerXAnchor.constraint(equalTo: safe.centerXAnchor),
            seekTime.bottomAnchor.constraint(equalTo: footer.topAnchor, constant: -5),
            seekTime.heightAnchor.constraint(equalToConstant: 30),
            seekTime.widthAnchor.constraint(equalToConstant: 90)
        ])

        var unlockStyle = UIButton.Configuration.gray()
        unlockStyle.title = "فتح قفل الشاشة"
        unlockStyle.image = UIImage(systemName: "lock.open")
        unlockStyle.imagePadding = 7
        unlockStyle.baseForegroundColor = .white
        unlockStyle.baseBackgroundColor = UIColor(white: 0.18, alpha: 0.94)
        unlockStyle.cornerStyle = .capsule
        unlock.configuration = unlockStyle
        unlock.isHidden = true
        unlock.addAction(UIAction { [weak self] _ in self?.setLocked(false) }, for: .touchUpInside)
        var nextStyle = UIButton.Configuration.filled()
        nextStyle.title = "الحلقة التالية"
        nextStyle.image = UIImage(systemName: "forward.end.fill")
        nextStyle.imagePadding = 7
        nextStyle.baseBackgroundColor = .white
        nextStyle.baseForegroundColor = .black
        nextStyle.cornerStyle = .medium
        upNext.configuration = nextStyle
        upNext.isHidden = true
        addAction(.next, to: upNext)
        for button in [unlock, upNext] {
            button.translatesAutoresizingMaskIntoConstraints = false
            addSubview(button)
            button.heightAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
        }
        NSLayoutConstraint.activate([
            unlock.centerXAnchor.constraint(equalTo: safe.centerXAnchor),
            unlock.topAnchor.constraint(equalTo: safe.topAnchor, constant: 15),
            upNext.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -17),
            upNext.bottomAnchor.constraint(equalTo: footer.topAnchor, constant: -11)
        ])
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapped))
        tap.delegate = self
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTapped(_:)))
        doubleTap.numberOfTapsRequired = 2
        doubleTap.delegate = self
        tap.require(toFail: doubleTap)
        addGestureRecognizer(tap)
        addGestureRecognizer(doubleTap)
    }

    required init?(coder: NSCoder) { return nil }

    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        shade.frame = chrome.bounds
        CATransaction.commit()
    }

    private func icon(_ button: UIButton, _ symbol: String, label: String, size: CGFloat, glyph: CGFloat) {
        let config = UIImage.SymbolConfiguration(pointSize: glyph, weight: .semibold)
        button.setImage(UIImage(systemName: symbol, withConfiguration: config), for: .normal)
        button.tintColor = .white
        button.accessibilityLabel = label
        button.translatesAutoresizingMaskIntoConstraints = false
        button.widthAnchor.constraint(equalToConstant: size).isActive = true
        button.heightAnchor.constraint(equalToConstant: size).isActive = true
    }

    private func footerButton(_ symbol: String, _ title: String) -> UIButton {
        let button = UIButton(type: .system)
        configureFooterButton(button, symbol, title)
        return button
    }

    private func configureFooterButton(_ button: UIButton, _ symbol: String, _ title: String) {
        var config = UIButton.Configuration.plain()
        config.title = title
        config.image = UIImage(systemName: symbol)
        config.preferredSymbolConfigurationForImage = .init(pointSize: 18, weight: .semibold)
        config.imagePlacement = .top
        config.imagePadding = 4
        config.contentInsets = .init(top: 4, leading: 1, bottom: 4, trailing: 1)
        config.baseForegroundColor = .white
        config.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attributes in
            var updated = attributes
            updated.font = .systemFont(ofSize: 11, weight: .semibold)
            return updated
        }
        button.configuration = config
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.75
        button.accessibilityLabel = title
        button.heightAnchor.constraint(greaterThanOrEqualToConstant: 48).isActive = true
    }

    private func addAction(_ action: CinemaAction, to button: UIButton) {
        button.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.show()
            self.onAction?(action)
        }, for: .touchUpInside)
    }

    private func setSpeedMenu(_ current: Float) {
        speed.accessibilityValue = "\(current)×"
        speed.menu = UIMenu(title: "السرعة", children: ([0.5, 0.75, 1, 1.25, 1.5, 2] as [Float]).map { rate in
            UIAction(title: rate == 1 ? "عادية · 1×" : "\(rate)×", state: rate == current ? .on : .off) { [weak self] _ in
                self?.setSpeedMenu(rate)
                self?.show()
                self?.onAction?(.speed(rate))
            }
        })
    }

    private func thumb(diameter: CGFloat) -> UIImage {
        UIGraphicsImageRenderer(size: CGSize(width: diameter, height: diameter)).image { ctx in
            ctx.cgContext.setFillColor(accent.cgColor)
            ctx.cgContext.fillEllipse(in: CGRect(x: 0, y: 0, width: diameter, height: diameter))
        }
    }

    func setPictureInPictureAvailable(_ possible: Bool) {
        pip.isHidden = !possible
    }

    func update(position: Double, duration: Double, canSeek: Bool, paused: Bool, waiting: Bool) {
        self.duration = duration.isFinite && duration > 0 ? duration : 0
        let time = position.isFinite ? max(0, position) : 0
        slider.isEnabled = canSeek && self.duration > 0
        back.isEnabled = slider.isEnabled
        forward.isEnabled = slider.isEnabled
        if !live && !scrubbing {
            slider.value = self.duration > 0 ? Float(min(1, time / self.duration)) : 0
            renderTime(time)
        }
        if self.paused != paused {
            self.paused = paused
            let iconName = paused ? "play.fill" : "pause.fill"
            let config = UIImage.SymbolConfiguration(pointSize: 37, weight: .semibold)
            play.setImage(UIImage(systemName: iconName, withConfiguration: config), for: .normal)
            play.accessibilityLabel = paused ? "تشغيل" : "إيقاف مؤقت"
            show()
        }
        if self.waiting != waiting {
            self.waiting = waiting
            if waiting { spinner.startAnimating() } else { spinner.stopAnimating() }
            show()
        }
        let left = self.duration - time
        upNext.isHidden = !(hasNext && !locked && !waiting && left > 0 && left <= 25)
    }

    private func renderTime(_ time: Double) {
        elapsed.text = CinemaControls.timeString(time)
        remaining.text = duration > 0 ? "−\(CinemaControls.timeString(duration - time))" : "—"
        slider.accessibilityValue = elapsed.text
    }

    private static func timeString(_ value: Double) -> String {
        let time = Int(min(2_000_000, max(0, value.isFinite ? value : 0)))
        let hours = time / 3600
        let minutes = Int32(time / 60 % 60)
        let seconds = Int32(time % 60)
        if hours > 0 { return "\(hours):" + String(format: "%02d:%02d", minutes, seconds) }
        return String(format: "%d:%02d", minutes, seconds)
    }

    @objc private func beginScrub() {
        scrubbing = true
        seekTime.isHidden = false
        scrubChanged()
        show()
    }

    @objc private func scrubChanged() {
        let time = Double(slider.value) * duration
        seekTime.text = CinemaControls.timeString(time)
        renderTime(time)
        if !scrubbing { onAction?(.seek(Double(slider.value))) }
    }

    @objc private func endScrub() {
        if slider.isEnabled { onAction?(.seek(Double(slider.value))) }
        cancelScrub()
    }

    @objc private func cancelScrub() {
        scrubbing = false
        seekTime.isHidden = true
        show()
    }

    func show() {
        guard !locked else { return }
        setVisible(true)
        hideTask?.cancel()
        guard !paused, !waiting, !scrubbing, !UIAccessibility.isVoiceOverRunning else { return }
        let task = DispatchWorkItem { [weak self] in self?.setVisible(false) }
        hideTask = task
        DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: task)
    }

    private func setVisible(_ value: Bool) {
        guard visible != value else { return }
        visible = value
        chrome.isUserInteractionEnabled = value
        chrome.accessibilityElementsHidden = !value
        UIView.animate(withDuration: UIAccessibility.isReduceMotionEnabled ? 0 : 0.2, animations: {
            self.chrome.alpha = value ? 1 : 0
        })
    }

    private func setLocked(_ value: Bool) {
        locked = value
        unlock.isHidden = !value
        hideTask?.cancel()
        if value {
            upNext.isHidden = true
            setVisible(false)
        } else {
            show()
        }
    }

    @objc private func tapped() {
        if locked { unlock.isHidden.toggle(); return }
        if visible && !paused && !waiting { setVisible(false); hideTask?.cancel() }
        else { show() }
    }

    @objc private func doubleTapped(_ tap: UITapGestureRecognizer) {
        guard !locked, slider.isEnabled else { return }
        onAction?(.jump(tap.location(in: self).x < bounds.midX ? -10 : 10))
        show()
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        var node = touch.view
        while let view = node, view !== self {
            if view is UIControl { return false }
            node = view.superview
        }
        return true
    }
}
