import UIKit
import AVKit

private final class CinemaVideoSurface: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}

final class AVEngineController: PlaybackSessionController, AVPlayerViewControllerDelegate, AVPictureInPictureControllerDelegate {
    private lazy var playerScreen = AVPlayerViewController()
    private var player: AVPlayer?
    private var surface: CinemaVideoSurface?
    private var pipController: AVPictureInPictureController?
    private var pipObservation: NSKeyValueObservation?
    private var trackRequest: Task<Void, Never>?
    private var statusObservation: NSKeyValueObservation?
    private var notes: [NSObjectProtocol] = []
    private var timer: Timer?
    private var overlay: SubtitleOverlay?
    private var opened = false
    private var cinemaRate: Float = 1
    private var cinemaPaused = false
    private var cinemaSeekTarget: Double?
    private var cinemaSeekGeneration = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        if o.cinema {
            let surface = CinemaVideoSurface(frame: view.bounds)
            surface.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            surface.playerLayer.videoGravity = .resizeAspect
            self.surface = surface
            view.addSubview(surface)
            let route = AVRoutePickerView(frame: .zero)
            route.tintColor = .white
            route.activeTintColor = UIColor(red: 0.90, green: 0.14, blue: 0.25, alpha: 1)
            route.prioritizesVideoDevices = true
            installCinemaControls(routePicker: route)
            return
        }
        addChild(playerScreen)
        playerScreen.view.frame = view.bounds
        playerScreen.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(playerScreen.view)
        playerScreen.didMove(toParent: self)
        playerScreen.delegate = self
        playerScreen.allowsPictureInPicturePlayback = o.background
        playerScreen.canStartPictureInPictureAutomaticallyFromInline = o.background
        playerScreen.updatesNowPlayingInfoCenter = true
        addControls()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !opened, !finished else { return }
        opened = true
        guard let url = o.mediaURL else { finish(error: "رابط غير صالح"); return }
        var options: [String: Any] = [:]
        if #available(iOS 16.0, *), !o.ua.isEmpty {
            options[AVURLAssetHTTPUserAgentKey] = o.ua
        }
        let item = AVPlayerItem(asset: AVURLAsset(url: url, options: options))
        item.preferredForwardBufferDuration = o.profile.appleBuffer(live: o.live)
        if o.adaptive && o.profile == .saver {
            item.preferredPeakBitRate = 1_500_000
            item.preferredMaximumResolution = CGSize(width: 1280, height: 720)
        }
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = true
        player.allowsExternalPlayback = true
        if #available(iOS 15.0, *) {
            player.audiovisualBackgroundPlaybackPolicy = o.background ? .continuesIfPossible : .pauses
        }
        self.player = player
        if let surface = surface {
            surface.playerLayer.player = player
            configurePictureInPicture(layer: surface.playerLayer)
        } else {
            playerScreen.player = player
        }
        let subtitleHost: UIView?
        if let surface = surface { subtitleHost = surface }
        else { subtitleHost = playerScreen.contentOverlayView }
        if let subtitle = SubtitleOverlay(srt: o.subs), let host = subtitleHost {
            overlay = subtitle
            subtitle.attach(to: host, bottomInset: o.cinema ? 105 : 64)
        }

        statusObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] _, _ in
            DispatchQueue.main.async { self?.itemStatusChanged() }
        }
        let center = NotificationCenter.default
        notes.append(center.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            DispatchQueue.main.async { self?.didEnd() }
        })
        notes.append(center.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            DispatchQueue.main.async { self?.finish(error: "انقطع التشغيل في AVPlayer", retryable: true) }
        })
        if !o.live {
            notes.append(center.addObserver(forName: .AVPlayerItemTimeJumped, object: item, queue: .main) { [weak self] _ in
                DispatchQueue.main.async { self?.monitor.seek() }
            })
        }

        let timer = Timer(timeInterval: 0.33, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { self?.tick() }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
        // Restore the playhead before starting to avoid showing the beginning of a resumed title.
        if o.live || o.start < 1 { requestPlay(player) }
    }

    private func requestPlay(_ player: AVPlayer) {
        guard !o.cinema || !cinemaPaused else { return }
        if o.profile == .fast {
            player.playImmediately(atRate: cinemaRate)
        } else if cinemaRate == 1 {
            player.play()
        } else {
            player.rate = cinemaRate
        }
    }

    private var resumeRequested = false

    private func itemStatusChanged() {
        guard !finished, let player = player, let item = player.currentItem else { return }
        switch item.status {
        case .readyToPlay:
            guard !o.live, o.start >= 1, !resumeRequested else { return }
            resumeRequested = true
            let duration = item.duration.seconds
            guard !duration.isFinite || o.start < duration - 1 else { requestPlay(player); return }
            monitor.seek()
            let time = CMTime(seconds: o.start, preferredTimescale: 600)
            player.seek(to: time, toleranceBefore: .zero, toleranceAfter: CMTime(seconds: 1, preferredTimescale: 600)) { [weak self] _ in
                DispatchQueue.main.async {
                    guard let self = self, !self.finished, let player = self.player else { return }
                    self.requestPlay(player)
                }
            }
        case .failed:
            finish(error: "تعذّر تشغيل المصدر في AVPlayer", retryable: monitor.started)
        default:
            break
        }
    }

    private func tick() {
        guard !finished, let player = player, let item = player.currentItem else { return }
        let position = player.currentTime().seconds
        let duration = item.duration.seconds
        if position.isFinite && position >= 0 {
            lastPos = position
            overlay?.show(at: position)
        }
        if duration.isFinite && duration > 0 { lastDur = duration }
        let paused = cinemaPaused || monitor.started && player.timeControlStatus == .paused
        let suspended = UIApplication.shared.applicationState != .active || paused || cinemaControls?.scrubbing == true
        if let timeout = monitor.sample(position, suspended: suspended) {
            finish(error: timeout, retryable: true)
            return
        }
        let waiting = !paused && (!monitor.started || player.timeControlStatus == .waitingToPlayAtSpecifiedRate)
        cinemaControls?.update(position: cinemaSeekTarget ?? position, duration: lastDur, canSeek: cinemaCanSeek,
                               paused: paused, waiting: waiting)
    }

    private var cinemaCanSeek: Bool {
        !o.live && lastDur > 0 && player?.currentItem?.status == .readyToPlay
    }

    override func handleCinemaTransport(_ action: CinemaAction) {
        guard let player = player else { return }
        switch action {
        case .playPause:
            let isPaused = cinemaPaused || monitor.started && player.timeControlStatus == .paused
            cinemaPaused = !isPaused
            if cinemaPaused {
                player.pause()
            } else if resumeRequested || o.start < 1 || o.live {
                requestPlay(player)
            }
        case .jump(let seconds):
            seekCinema(to: (cinemaSeekTarget ?? lastPos) + seconds)
        case .seek(let fraction):
            seekCinema(to: lastDur * fraction)
        case .speed(let rate):
            cinemaRate = rate
            if !cinemaPaused && player.timeControlStatus != .paused { player.rate = rate }
        case .aspect:
            if let layer = surface?.playerLayer {
                layer.videoGravity = layer.videoGravity == .resizeAspect ? .resizeAspectFill : .resizeAspect
            }
        case .pictureInPicture:
            if let pip = pipController {
                if pip.isPictureInPictureActive { pip.stopPictureInPicture() }
                else if pip.isPictureInPicturePossible { pip.startPictureInPicture() }
            }
        default:
            break
        }
    }

    private func seekCinema(to position: Double) {
        guard cinemaCanSeek, position.isFinite, let player = player else { return }
        monitor.seek()
        let target = min(lastDur, max(0, position))
        cinemaSeekTarget = target
        cinemaSeekGeneration += 1
        let generation = cinemaSeekGeneration
        let time = CMTime(seconds: target, preferredTimescale: 600)
        let tolerance = CMTime(seconds: 0.4, preferredTimescale: 600)
        player.seek(to: time, toleranceBefore: tolerance, toleranceAfter: tolerance) { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self, generation == self.cinemaSeekGeneration else { return }
                self.cinemaSeekTarget = nil
            }
        }
    }

    override func showCinemaTracks() {
        guard trackRequest == nil else { return }
        guard let item = player?.currentItem, item.status == .readyToPlay else {
            showCinemaPicker(title: "الصوت والترجمة", sections: [
                CinemaSection(title: "المسارات المتاحة عند بدء العرض", choices: [], selected: nil)
            ]) { _, _ in }
            return
        }
        trackRequest = Task { @MainActor [weak self] in
            let audio = try? await item.asset.loadMediaSelectionGroup(for: .audible)
            let captions = try? await item.asset.loadMediaSelectionGroup(for: .legible)
            guard !Task.isCancelled, let self = self, self.player?.currentItem === item else { return }
            self.trackRequest = nil
            self.presentTrackChoices(item: item, audio: audio, captions: captions)
        }
    }

    private func presentTrackChoices(item: AVPlayerItem, audio: AVMediaSelectionGroup?, captions: AVMediaSelectionGroup?) {
        func choices(_ group: AVMediaSelectionGroup?) -> [CinemaChoice] {
            (group?.options ?? []).enumerated().map { CinemaChoice(id: $0.offset, name: $0.element.displayName) }
        }
        func selected(_ group: AVMediaSelectionGroup?) -> Int? {
            guard let group = group, let active = item.currentMediaSelection.selectedMediaOption(in: group) else { return nil }
            return group.options.firstIndex(of: active)
        }
        var subtitleChoices = choices(captions)
        if captions?.allowsEmptySelection == true || overlay != nil && captions == nil {
            subtitleChoices.insert(CinemaChoice(id: -1, name: "إيقاف الترجمة"), at: 0)
        }
        if overlay != nil {
            subtitleChoices.insert(CinemaChoice(id: -2, name: "الترجمة المرفقة"), at: 0)
        }
        let subtitleSelection = overlay?.label.isHidden == false ? -2 : selected(captions) ?? -1
        let sections = [
            CinemaSection(title: "الصوت", choices: choices(audio), selected: selected(audio)),
            CinemaSection(title: "الترجمة", choices: subtitleChoices, selected: subtitleSelection)
        ]
        showCinemaPicker(title: "الصوت والترجمة", sections: sections) { [weak self] section, id in
            guard let self = self, self.player?.currentItem === item else { return }
            self.player?.appliesMediaSelectionCriteriaAutomatically = false
            if section == 0 {
                if let audio = audio, audio.options.indices.contains(id) { item.select(audio.options[id], in: audio) }
            } else {
                self.overlay?.label.isHidden = id != -2
                if let captions = captions {
                    if captions.options.indices.contains(id) { item.select(captions.options[id], in: captions) }
                    else if captions.allowsEmptySelection { item.select(nil, in: captions) }
                }
            }
        }
    }

    private func configurePictureInPicture(layer: AVPlayerLayer) {
        guard o.background, AVPictureInPictureController.isPictureInPictureSupported(),
              let pip = AVPictureInPictureController(playerLayer: layer) else { return }
        pip.delegate = self
        pip.canStartPictureInPictureAutomaticallyFromInline = true
        pipController = pip
        pipObservation = pip.observe(\.isPictureInPicturePossible, options: [.initial, .new]) { [weak self] _, change in
            let possible = change.newValue ?? false
            DispatchQueue.main.async { self?.cinemaControls?.setPictureInPictureAvailable(possible) }
        }
    }

    private func didEnd() {
        guard !finished else { return }
        if monitor.started {
            if lastDur > 0 && !o.live { lastPos = lastDur }
            finish(next: !o.live && o.hasNext && o.autoNext, ended: true)
        } else {
            finish(error: "انتهى المصدر قبل بدء الفيديو")
        }
    }

    private func addControls() {
        let close = control("xmark", label: "إغلاق المشغّل")
        close.addTarget(self, action: #selector(closeTap), for: .touchUpInside)
        let options = control("ellipsis", label: "خيارات التشغيل")
        options.menu = optionsMenu()
        options.showsMenuAsPrimaryAction = true
        let safe = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            close.leadingAnchor.constraint(equalTo: safe.leadingAnchor, constant: 10),
            close.topAnchor.constraint(equalTo: safe.topAnchor, constant: 10),
            options.trailingAnchor.constraint(equalTo: safe.trailingAnchor, constant: -10),
            options.topAnchor.constraint(equalTo: safe.topAnchor, constant: 52)
        ])
    }

    private func control(_ symbol: String, label: String) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: symbol), for: .normal)
        button.tintColor = .white
        button.accessibilityLabel = label
        button.backgroundColor = UIColor.black.withAlphaComponent(0.55)
        button.layer.cornerRadius = 22
        button.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(button)
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: 44),
            button.heightAnchor.constraint(equalToConstant: 44)
        ])
        return button
    }

    @objc private func closeTap() { finish() }

    override func stopPlayback() {
        timer?.invalidate()
        timer = nil
        statusObservation?.invalidate()
        statusObservation = nil
        for note in notes { NotificationCenter.default.removeObserver(note) }
        notes.removeAll()
        trackRequest?.cancel()
        trackRequest = nil
        pipObservation?.invalidate()
        pipObservation = nil
        if let pip = pipController, pip.isPictureInPictureActive { pip.stopPictureInPicture() }
        pipController = nil
        player?.currentItem?.cancelPendingSeeks()
        player?.pause()
        player?.replaceCurrentItem(with: nil)
        player = nil
        if let surface = surface { surface.playerLayer.player = nil }
        else { playerScreen.player = nil }
    }

    func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool { false }

    func playerViewController(_ playerViewController: AVPlayerViewController,
                              restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(viewIfLoaded?.window != nil)
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController,
                                    restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) {
        completionHandler(viewIfLoaded?.window != nil)
    }
}
