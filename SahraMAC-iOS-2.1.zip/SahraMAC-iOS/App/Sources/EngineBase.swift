import UIKit

struct CinemaEpisode {
    let index: Int
    let title: String
}

/// What every native engine is told: the stream, where to start, what to show.
struct EngineOpts {
    var url: String
    var title: String
    var start: Double
    var ua: String
    var subs: String
    var hasNext: Bool
    var live: Bool
    var autoNext: Bool
    var profile: PlaybackProfile
    var adaptive: Bool
    var background: Bool
    var choices: [String]
    var cinema: Bool
    var subtitle: String
    var episodes: [CinemaEpisode]
    var episodeIndex: Int?

    static func parse(_ json: String) -> EngineOpts? {
        guard let data = json.data(using: .utf8),
              let d = (try? JSONSerialization.jsonObject(with: data, options: [])) as? [String: Any],
              let url = d["url"] as? String, !url.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return nil }
        let startValue = (d["start"] as? NSNumber)?.doubleValue ?? 0
        let episodes = (d["episodes"] as? [[String: Any]] ?? []).prefix(200).compactMap { row -> CinemaEpisode? in
            guard let index = row["index"] as? Int, index >= 0,
                  let title = row["title"] as? String, !title.isEmpty else { return nil }
            return CinemaEpisode(index: index, title: String(title.prefix(200)))
        }
        return EngineOpts(
            url: url.trimmingCharacters(in: .whitespacesAndNewlines),
            title: (d["title"] as? String) ?? "",
            start: startValue.isFinite ? min(max(0, startValue), 2_000_000) : 0,
            ua: (d["ua"] as? String) ?? "", subs: (d["subs"] as? String) ?? "",
            hasNext: (d["next"] as? Bool) ?? false, live: (d["live"] as? Bool) ?? false,
            autoNext: (d["autoNext"] as? Bool) ?? true,
            profile: PlaybackProfile(rawValue: d["profile"] as? String ?? "") ?? .balanced,
            adaptive: (d["adaptive"] as? Bool) ?? false,
            background: (d["background"] as? Bool) ?? true,
            choices: d["choices"] as? [String] ?? [],
            cinema: (d["cinema"] as? Bool) ?? false,
            subtitle: (d["subtitle"] as? String) ?? "",
            episodes: episodes,
            episodeIndex: d["episodeIndex"] as? Int
        )
    }

    var mediaURL: URL? {
        let candidate = URL(string: url) ?? URL(string: url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")
        guard let candidate, let scheme = candidate.scheme?.lowercased(),
              ["http", "https", "file"].contains(scheme) else { return nil }
        if scheme == "http" || scheme == "https" { guard candidate.host != nil else { return nil } }
        return candidate
    }

    /// the Arabic subtitles found by the app, as a file the engines can open
    func subtitleFile() -> URL? {
        if subs.isEmpty { return nil }
        let f = FileManager.default.temporaryDirectory.appendingPathComponent("sahra-\(UUID().uuidString).srt")
        return (try? subs.write(to: f, atomically: true, encoding: .utf8)) != nil ? f : nil
    }
}

/// The answer an engine gives back when it closes: the minute reached, whether the viewer asked for
/// the next one, or why it couldn't play (then the app tries the next engine).
func engineAnswer(pos: Double, dur: Double, next: Bool, error: String, started: Bool,
                  ended: Bool = false, retryable: Bool = false, engine: String? = nil,
                  profile: PlaybackProfile? = nil, busy: Bool = false, episode: Int? = nil) -> String {
    let p = pos.isFinite ? pos : 0, d = dur.isFinite ? dur : 0
    var answer: [String: Any] = ["pos": max(0, p), "dur": max(0, d), "next": next,
                                 "started": started, "ended": ended, "retryable": retryable, "busy": busy]
    if !error.isEmpty { answer["error"] = error }
    if let engine = engine { answer["engine"] = engine }
    if let profile = profile { answer["profile"] = profile.rawValue }
    if let episode = episode { answer["episode"] = episode }
    guard let data = try? JSONSerialization.data(withJSONObject: answer, options: [.fragmentsAllowed]),
          let json = String(data: data, encoding: .utf8) else { return "{}" }
    return json
}

/// Full-screen controls used by the native VLC player.
class EngineController: PlaybackSessionController {
    let videoView = UIView()
    private let topBar = UIView()
    private let bottomBar = UIView()
    private let titleLabel = UILabel()
    private let timeLabel = UILabel()
    private let lengthLabel = UILabel()
    let noteLabel = UILabel()
    private let slider = UISlider()
    private let playButton = UIButton(type: .system)
    private let spinner = UIActivityIndicatorView(style: .large)
    private var timer: Timer?
    private var hideAt = Date().addingTimeInterval(4)
    private var seeking = false
    private var fill = false
    private var rate: Float = 1
    private var opened = false
    private var pausedByUser = false

    // ---- what an engine provides ----
    func startPlayback(_ url: URL) {}
    func isPlaying() -> Bool { false }
    func isBusy() -> Bool { false }
    func hasEnded() -> Bool { false }
    func currentTime() -> Double { 0 }
    func duration() -> Double { 0 }
    func canSeek() -> Bool { !o.live && duration() > 0 }
    func setPaused(_ paused: Bool) {}
    func seek(toFraction f: Double) {}
    func jump(_ seconds: Double) {}
    func setRate(_ r: Float) {}
    func videoSize() -> CGSize { .zero }
    func audioTracks() -> [(String, Int)] { [] }
    func currentAudio() -> Int { -1 }
    func setAudio(_ id: Int) {}
    func subtitleTracks() -> [(String, Int)] { [] }
    func currentSubtitle() -> Int { -1 }
    func setSubtitle(_ id: Int) {}
    /// why the engine stopped, if it did ("" while all is well)
    func engineError() -> String { "" }
    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        videoView.frame = view.bounds
        videoView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoView.backgroundColor = .black
        view.addSubview(videoView)
        if o.cinema {
            installCinemaControls()
            return
        }
        let tap = UITapGestureRecognizer(target: self, action: #selector(toggleControls))
        videoView.addGestureRecognizer(tap)
        let dbl = UITapGestureRecognizer(target: self, action: #selector(doubleTap(_:)))
        dbl.numberOfTapsRequired = 2
        videoView.addGestureRecognizer(dbl)
        tap.require(toFail: dbl)

        spinner.color = .white
        spinner.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(spinner)
        spinner.startAnimating()
        noteLabel.textColor = .white
        noteLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        noteLabel.numberOfLines = 0
        noteLabel.textAlignment = .center
        noteLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(noteLabel)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            noteLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noteLabel.topAnchor.constraint(equalTo: spinner.bottomAnchor, constant: 16),
            noteLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -40)
        ])
        buildControls()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !opened, !finished else { return }
        opened = true
        guard let u = o.mediaURL else { finish(error: "رابط غير صالح"); return }
        startPlayback(u)
        let timer = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { self?.tick() }
        }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyFill()
        layoutVideo()
    }

    /// engines that draw into a layer resize it here
    func layoutVideo() {}

    // ---- controls ----
    private func button(_ symbol: String, _ action: Selector, size: CGFloat = 22) -> UIButton {
        let b = UIButton(type: .system)
        b.setImage(UIImage(systemName: symbol, withConfiguration: UIImage.SymbolConfiguration(pointSize: size, weight: .semibold)), for: .normal)
        b.tintColor = .white
        b.addTarget(self, action: action, for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.widthAnchor.constraint(equalToConstant: 46).isActive = true
        b.heightAnchor.constraint(equalToConstant: 46).isActive = true
        return b
    }

    private func buildControls() {
        for bar in [topBar, bottomBar] {
            bar.backgroundColor = UIColor(white: 0, alpha: 0.55)
            bar.translatesAutoresizingMaskIntoConstraints = false
            view.addSubview(bar)
        }
        titleLabel.text = o.title
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        titleLabel.lineBreakMode = .byTruncatingTail
        let badge = UILabel()
        badge.text = engineID == "vlc-sw" ? " VLC · CPU " : " VLC "
        badge.textColor = .black
        badge.backgroundColor = UIColor(red: 1, green: 0.62, blue: 0.18, alpha: 1)
        badge.font = UIFont.systemFont(ofSize: 11, weight: .heavy)
        badge.layer.cornerRadius = 5
        badge.clipsToBounds = true
        let close = button("xmark", #selector(closeTap))
        let audio = button("speaker.wave.2", #selector(audioTap))
        let subs = button("captions.bubble", #selector(subsTap))
        let more = button("ellipsis.circle", #selector(keepControlsVisible))
        more.accessibilityLabel = "خيارات التشغيل"
        more.menu = optionsMenu(extra: [
            UIAction(title: "ملء الشاشة", image: UIImage(systemName: "aspectratio")) { [weak self] _ in self?.aspectTap() },
            UIAction(title: "سرعة العرض", image: UIImage(systemName: "gauge")) { [weak self] _ in self?.speedTap() }
        ])
        more.showsMenuAsPrimaryAction = true
        let topStack = UIStackView(arrangedSubviews: [close, titleLabel, badge, subs, audio, more])
        topStack.axis = .horizontal
        topStack.alignment = .center
        topStack.spacing = 4
        topStack.translatesAutoresizingMaskIntoConstraints = false
        topBar.addSubview(topStack)
        titleLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        playButton.setImage(UIImage(systemName: "pause.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        playButton.tintColor = .white
        playButton.addTarget(self, action: #selector(playTap), for: .touchUpInside)
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        playButton.heightAnchor.constraint(equalToConstant: 46).isActive = true
        let back = button("gobackward.10", #selector(backTap))
        let fwd = button("goforward.10", #selector(fwdTap))
        for l in [timeLabel, lengthLabel] {
            l.textColor = .white
            l.font = UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
            l.text = "0:00"
        }
        slider.minimumTrackTintColor = UIColor(red: 1, green: 0.55, blue: 0.1, alpha: 1)
        slider.addTarget(self, action: #selector(seekStart), for: .touchDown)
        slider.addTarget(self, action: #selector(seekEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])
        var items: [UIView] = [back, playButton, fwd, timeLabel, slider, lengthLabel]
        if o.hasNext { items.append(button("forward.end.fill", #selector(nextTap))) }
        let bottomStack = UIStackView(arrangedSubviews: items)
        bottomStack.axis = .horizontal
        bottomStack.alignment = .center
        bottomStack.spacing = 6
        bottomStack.translatesAutoresizingMaskIntoConstraints = false
        bottomBar.addSubview(bottomStack)
        // left to right like a timeline, whatever the phone's language
        topStack.semanticContentAttribute = .forceLeftToRight
        bottomStack.semanticContentAttribute = .forceLeftToRight

        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            topBar.topAnchor.constraint(equalTo: view.topAnchor),
            topBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            topBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            topBar.bottomAnchor.constraint(equalTo: g.topAnchor, constant: 54),
            topStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            topStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            topStack.bottomAnchor.constraint(equalTo: topBar.bottomAnchor, constant: -4),
            bottomBar.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.topAnchor.constraint(equalTo: g.bottomAnchor, constant: -58),
            bottomStack.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 8),
            bottomStack.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -8),
            bottomStack.topAnchor.constraint(equalTo: bottomBar.topAnchor, constant: 6)
        ])
    }

    private func setControls(_ on: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.topBar.alpha = on ? 1 : 0
            self.bottomBar.alpha = on ? 1 : 0
        }
        if on { hideAt = Date().addingTimeInterval(4) }
    }

    @objc private func toggleControls() { setControls(topBar.alpha < 0.5) }

    @objc private func doubleTap(_ g: UITapGestureRecognizer) {
        guard canSeek() else { return }
        let x = g.location(in: videoView).x
        monitor.seek()
        jump(x < videoView.bounds.width / 2 ? -10 : 10)
        setControls(true)
    }

    // ---- state ----
    private func fmt(_ s: Double) -> String {
        let t = Int(min(2_000_000, max(0, s.isFinite ? s : 0)))
        let h = t / 3600, m = (t / 60) % 60, x = t % 60
        return h > 0 ? "\(h):" + String(format: "%02d:%02d", Int32(m), Int32(x)) : String(format: "%d:%02d", Int32(m), Int32(x))
    }

    private func tick() {
        guard !finished else { return }
        let err = engineError()
        if !err.isEmpty { finish(error: err, retryable: monitor.started); return }
        let t = currentTime(), len = duration()
        if t.isFinite && t > 0 { lastPos = t }
        if len.isFinite && len > 0 { lastDur = len }
        let playing = isPlaying()
        if monitor.started && !pausedByUser && hasEnded() {
            if !o.live && lastDur > 0 && lastPos < lastDur - 3 {
                finish(error: "انقطع الفيديو", retryable: true)
            } else {
                finish(next: !o.live && o.hasNext && o.autoNext, ended: true)
            }
            return
        }
        let isScrubbing = seeking || cinemaControls?.scrubbing == true
        if let timeout = monitor.sample(t, suspended: pausedByUser || isScrubbing || UIApplication.shared.applicationState != .active) {
            finish(error: timeout, retryable: true)
            return
        }
        let waiting = !pausedByUser && (isBusy() || !monitor.started)
        if let controls = cinemaControls {
            controls.update(position: t, duration: len, canSeek: canSeek(), paused: pausedByUser, waiting: waiting)
            return
        }
        noteLabel.text = waiting ? (monitor.started ? "جارٍ استعادة البث…" : o.profile.title) : nil
        if waiting { spinner.startAnimating() } else { spinner.stopAnimating() }
        if !seeking && len.isFinite && len > 0 && t.isFinite { slider.value = Float(min(1, max(0, t / len))) }
        slider.isEnabled = canSeek()
        timeLabel.text = fmt(t)
        lengthLabel.text = len > 0 ? fmt(len) : "مباشر"
        let sym = pausedByUser ? "play.fill" : "pause.fill"
        playButton.setImage(UIImage(systemName: sym, withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .bold)), for: .normal)
        if playing && topBar.alpha > 0.5 && Date() > hideAt { setControls(false) }
    }

    override func handleCinemaTransport(_ action: CinemaAction) {
        switch action {
        case .playPause:
            pausedByUser.toggle()
            setPaused(pausedByUser)
            if !pausedByUser && !o.live { setRate(rate) }
        case .jump(let seconds):
            guard canSeek() else { return }
            monitor.seek()
            jump(seconds)
        case .seek(let fraction):
            guard canSeek() else { return }
            monitor.seek()
            seek(toFraction: fraction)
        case .speed(let speed):
            rate = speed
            if !pausedByUser { setRate(speed) }
        case .aspect:
            aspectTap()
        default:
            break
        }
    }

    override func showCinemaTracks() {
        let audio = audioTracks().filter { $0.1 >= 0 }.map { CinemaChoice(id: $0.1, name: $0.0) }
        let captions = subtitleTracks().filter { $0.1 >= 0 }.map { CinemaChoice(id: $0.1, name: $0.0) }
        let off = CinemaChoice(id: -1, name: "إيقاف الترجمة")
        let subtitleChoices = captions.isEmpty ? [] : [off] + captions
        let groups = [
            CinemaSection(title: "الصوت", choices: audio, selected: currentAudio()),
            CinemaSection(title: "الترجمة", choices: subtitleChoices, selected: currentSubtitle())
        ]
        showCinemaPicker(title: "الصوت والترجمة", sections: groups) { [weak self] section, id in
            if section == 0 { self?.setAudio(id) }
            else { self?.setSubtitle(id) }
        }
    }

    // ---- actions ----
    @objc private func playTap() {
        pausedByUser.toggle()
        setPaused(pausedByUser)
        setControls(true)
    }
    @objc private func backTap() { if canSeek() { monitor.seek(); jump(-10) }; setControls(true) }
    @objc private func fwdTap() { if canSeek() { monitor.seek(); jump(10) }; setControls(true) }
    @objc private func nextTap() { finish(next: true) }
    @objc private func closeTap() { finish() }
    @objc private func keepControlsVisible() { setControls(true) }
    @objc private func seekStart() { seeking = true; hideAt = Date().addingTimeInterval(8) }
    @objc private func seekEnd() {
        if canSeek() { monitor.seek(); seek(toFraction: Double(slider.value)) }
        seeking = false
        setControls(true)
    }

    private func applyFill() {
        let vs = videoSize()
        guard fill, vs.width > 0, vs.height > 0, videoView.bounds.width > 0, videoView.bounds.height > 0 else {
            videoView.transform = .identity
            return
        }
        let sx = videoView.bounds.width / vs.width, sy = videoView.bounds.height / vs.height
        let s = max(sx, sy) / min(sx, sy)
        videoView.transform = CGAffineTransform(scaleX: s, y: s)
    }

    @objc private func aspectTap() {
        fill.toggle()
        UIView.animate(withDuration: 0.25) { self.applyFill() }
        setControls(true)
    }

    @objc private func speedTap() {
        let a = UIAlertController(title: "السرعة", message: nil, preferredStyle: .actionSheet)
        for r: Float in [0.75, 1, 1.25, 1.5, 2] {
            a.addAction(UIAlertAction(title: (r == rate ? "✓ " : "") + String(format: "%g×", r), style: .default) { _ in
                self.rate = r
                self.setRate(r)
            })
        }
        show(a)
    }

    @objc private func audioTap() { pick("الصوت", audioTracks(), current: currentAudio()) { self.setAudio($0) } }
    @objc private func subsTap() { pick("الترجمة", subtitleTracks(), current: currentSubtitle()) { self.setSubtitle($0) } }

    private func show(_ a: UIAlertController) {
        a.addAction(UIAlertAction(title: "إلغاء", style: .cancel, handler: nil))
        if let pop = a.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
        }
        present(a, animated: true, completion: nil)
        hideAt = Date().addingTimeInterval(8)
    }

    private func pick(_ title: String, _ tracks: [(String, Int)], current: Int, _ set: @escaping (Int) -> Void) {
        let a = UIAlertController(title: title, message: tracks.isEmpty ? "لا توجد مسارات" : nil, preferredStyle: .actionSheet)
        for (name, id) in tracks {
            a.addAction(UIAlertAction(title: (id == current ? "✓ " : "") + name, style: .default) { _ in set(id) })
        }
        show(a)
    }

    override func stopPlayback() {
        timer?.invalidate()
        timer = nil
    }
}
