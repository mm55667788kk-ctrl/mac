import UIKit
import AVKit

/// The native engines this build carries. AVPlayer is always there; VLCKit, MPVKit and KSPlayer only
/// when build-ipa.sh could build them in (it says which at the end of the GitHub Actions log).
enum NativeEngines {
    static var available: [String] {
        var a: [String] = []
        #if SAHRA_KS
        a.append("ks")
        #endif
        #if SAHRA_MPV
        a.append("mpv")
        #endif
        #if SAHRA_VLC
        a.append("vlc")
        #endif
        a.append("avplayer")
        return a
    }

    static func present(_ engine: String, json: String, from host: UIViewController?, done: @escaping (String) -> Void) {
        guard let host = host, let o = EngineOpts.parse(json) else {
            done(engineAnswer(pos: 0, dur: 0, next: false, error: "bad", started: false))
            return
        }
        var vc: UIViewController?
        if engine == "avplayer" { vc = AVEngineController(o, done: done) }
        #if SAHRA_VLC
        if engine == "vlc" { vc = VLCEngineController(o, done: done) }
        #endif
        #if SAHRA_MPV
        if engine == "mpv" { vc = MPVEngineController(o, done: done) }
        #endif
        #if SAHRA_KS
        if engine == "ks" { vc = KSEngineController(o, done: done) }
        #endif
        guard let player = vc else {
            done(engineAnswer(pos: 0, dur: 0, next: false, error: "missing", started: false))
            return
        }
        var top: UIViewController = host
        while let p = top.presentedViewController { top = p }
        top.present(player, animated: true, completion: nil)
    }
}

/// The app's own subtitles (found on the internet, or translated) drawn over a player that can't
/// load an SRT file itself.
final class SubtitleOverlay {
    private struct Cue { let a: Double; let b: Double; let text: String }
    private var cues: [Cue] = []
    private var shown = -2
    let label = UILabel()

    init?(srt: String) {
        if srt.isEmpty { return nil }
        let blocks = srt.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n\n")
        for b in blocks {
            let lines = b.components(separatedBy: "\n")
            guard let i = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let parts = lines[i].components(separatedBy: "-->")
            guard parts.count == 2, let a = SubtitleOverlay.time(parts[0]), let z = SubtitleOverlay.time(parts[1]) else { continue }
            var text = lines[(i + 1)...].joined(separator: "\n")
            text = text.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            text = text.replacingOccurrences(of: "\\{[^}]*\\}", with: "", options: .regularExpression)
            text = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { cues.append(Cue(a: a, b: z, text: text)) }
        }
        if cues.isEmpty { return nil }
        cues.sort { $0.a < $1.a }
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: UIDevice.current.userInterfaceIdiom == .pad ? 30 : 21, weight: .bold)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.shadowColor = UIColor(white: 0, alpha: 0.95)
        label.shadowOffset = CGSize(width: 1.5, height: 1.5)
        label.isUserInteractionEnabled = false
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    private static func time(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? ""
        let p = t.replacingOccurrences(of: ",", with: ".").components(separatedBy: ":")
        guard p.count >= 2 else { return nil }
        var v = 0.0
        for x in p {
            guard let n = Double(x) else { return nil }
            v = v * 60 + n
        }
        return v
    }

    func attach(to v: UIView) {
        v.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            label.bottomAnchor.constraint(equalTo: v.safeAreaLayoutGuide.bottomAnchor, constant: -64)
        ])
    }

    func show(at t: Double) {
        var lo = 0, hi = cues.count - 1, hit = -1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if cues[mid].a <= t { hit = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        let now = hit >= 0 && t <= cues[hit].b ? hit : -1
        if now == shown { return }
        shown = now
        label.text = now >= 0 ? cues[now].text : nil
    }
}

/// AVPlayer (AVFoundation): Apple's own player — the lightest on the battery, the phone's video chip,
/// picture-in-picture and AirPlay. Best with MP4/MOV and HLS (m3u8); MKV and raw TS go to the others.
final class AVEngineController: AVPlayerViewController, AVPlayerViewControllerDelegate {
    private let o: EngineOpts
    private let done: (String) -> Void
    private var observations: [NSKeyValueObservation] = []
    private var notes: [NSObjectProtocol] = []
    private var timeToken: Any?
    private var watchdog: Timer?
    private var overlay: SubtitleOverlay?
    private let deadline = Date().addingTimeInterval(25)
    private var started = false
    private var finished = false
    private var wantNext = false
    private var streamEnded = false
    private var seekedStart = false
    private var lastPos: Double = 0
    private var lastDur: Double = 0
    private var failure = ""

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
        view.backgroundColor = .black
        guard let u = o.mediaURL else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.fail("رابط غير صالح") }
            return
        }
        var options: [String: Any] = [:]
        if !o.ua.isEmpty { options["AVURLAssetHTTPHeaderFieldsKey"] = ["User-Agent": o.ua] }
        let item = AVPlayerItem(asset: AVURLAsset(url: u, options: options))
        item.preferredForwardBufferDuration = o.live ? 8 : 30
        let p = AVPlayer(playerItem: item)
        p.automaticallyWaitsToMinimizeStalling = true
        p.allowsExternalPlayback = true
        player = p
        allowsPictureInPicturePlayback = true
        updatesNowPlayingInfoCenter = true
        if #available(iOS 14.2, *) { canStartPictureInPictureAutomaticallyFromInline = true }

        observations.append(item.observe(\.status, options: [.new]) { [weak self] it, _ in
            DispatchQueue.main.async { self?.status(it) }
        })
        timeToken = p.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.25, preferredTimescale: 600), queue: .main) { [weak self] t in
            self?.progress(t.seconds)
        }
        notes.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.streamEnded = true
            if self.o.hasNext { self.wantNext = true }
            self.finish()
        })
        notes.append(NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: item, queue: .main) { [weak self] n in
            let e = n.userInfo?[AVPlayerItemFailedToPlayToEndTimeErrorKey] as? Error
            self?.fail(e?.localizedDescription ?? "انقطع التشغيل")
        })
        if let ov = SubtitleOverlay(srt: o.subs), let host = contentOverlayView {
            overlay = ov
            ov.attach(to: host)
        }
        p.play()
        watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.watch() }
    }

    private func status(_ item: AVPlayerItem) {
        switch item.status {
        case .readyToPlay:
            if o.start > 1 && !seekedStart {
                seekedStart = true
                player?.seek(to: CMTime(seconds: o.start, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: CMTime(seconds: 2, preferredTimescale: 600))
            }
        case .failed:
            fail(item.error?.localizedDescription ?? "AVPlayer لم يفتح هذا الرابط")
        default:
            break
        }
    }

    private func progress(_ t: Double) {
        guard t.isFinite else { return }
        if player?.timeControlStatus == .playing && t > 0.2 { started = true }
        if started { lastPos = t }
        if let d = player?.currentItem?.duration.seconds, d.isFinite, d > 0 { lastDur = d }
        overlay?.show(at: t)
    }

    private func watch() {
        if !started && Date() > deadline { fail("لم يبدأ خلال 25 ثانية") }
    }

    private func fail(_ why: String) {
        if finished || !failure.isEmpty { return }
        failure = why
        finish()
    }

    private func finish() {
        if finished { return }
        finished = true
        watchdog?.invalidate()
        watchdog = nil
        if let t = timeToken { player?.removeTimeObserver(t) }
        timeToken = nil
        observations.removeAll()
        for n in notes { NotificationCenter.default.removeObserver(n) }
        notes.removeAll()
        player?.pause()
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        if presentingViewController != nil && !isBeingDismissed {
            dismiss(animated: true) { self.done(answer) }
        } else {
            done(answer)
        }
        player = nil
    }

    // the viewer closed it with the player's own ✕
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || presentingViewController == nil { finish() }
    }

    // picture-in-picture keeps this screen (and its answer to the app) alive
    func playerViewControllerShouldAutomaticallyDismissAtPictureInPictureStart(_ playerViewController: AVPlayerViewController) -> Bool { false }
}
