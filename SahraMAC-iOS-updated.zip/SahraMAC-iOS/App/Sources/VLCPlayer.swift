#if SAHRA_VLC
import UIKit
import MobileVLCKit

/// VLCKit (MobileVLCKit): VideoLAN's engine inside the app. Plays what AVPlayer can't: MKV, AVI, HEVC,
/// AC-3/E-AC-3/DTS sound, live MPEG-TS, the file's own audio and subtitle tracks.
final class VLCEngineController: EngineController {
    private let player = VLCMediaPlayer()

    override func engineName() -> String { "VLC" }

    override func startPlayback(_ u: URL) {
        let media = VLCMedia(url: u)
        // a deeper network buffer and reconnecting: fewer stalls on IPTV servers
        media.addOption(":network-caching=" + (o.live ? "1800" : "2500"))
        media.addOption(":live-caching=1800")
        media.addOption(":http-reconnect")
        if o.live {
            // IPTV clocks drift: without these VLC drops frames and stutters on many channels
            media.addOption(":clock-jitter=0")
            media.addOption(":clock-synchro=0")
        }
        if !o.ua.isEmpty { media.addOption(":http-user-agent=" + o.ua) }
        if o.start > 1 { media.addOption(":start-time=" + String(Int(o.start))) }
        player.drawable = videoView
        player.media = media
        player.play()
        if let f = o.subtitleFile() { _ = player.addPlaybackSlave(f, type: .subtitle, enforce: true) }
    }

    override func stopPlayback() { player.stop() }
    override func isPlaying() -> Bool { player.isPlaying }
    override func isBusy() -> Bool {
        let st = player.state
        return !player.isPlaying && st != .paused && st != .ended && st != .error && st != .stopped
    }
    override func hasEnded() -> Bool { player.state == .ended || player.state == .stopped }
    override func engineError() -> String { player.state == .error ? "تعذّر فتح الرابط" : "" }

    // (works whether VLCKit's headers mark these optional or not)
    override func currentTime() -> Double {
        let tt: VLCTime? = player.time
        return Double(tt?.intValue ?? 0) / 1000
    }
    override func duration() -> Double {
        let m: VLCMedia? = player.media
        let lt: VLCTime? = m?.length
        return Double(lt?.intValue ?? 0) / 1000
    }

    override func setPaused(_ paused: Bool) { if paused { player.pause() } else { player.play() } }
    override func seek(toFraction f: Double) { player.position = Float(f) }
    override func jump(_ seconds: Double) {
        if seconds < 0 { player.jumpBackward(Int32(-seconds)) } else { player.jumpForward(Int32(seconds)) }
    }
    override func setRate(_ r: Float) { player.rate = r }
    override func videoSize() -> CGSize { player.videoSize }

    private func tracks(_ names: [Any]?, _ ids: [Any]?) -> [(String, Int)] {
        let n = (names as? [String]) ?? []
        let i = ((ids as? [NSNumber]) ?? []).map { $0.intValue }
        return zip(n, i).map { ($0.0, $0.1) }
    }
    override func audioTracks() -> [(String, Int)] { tracks(player.audioTrackNames, player.audioTrackIndexes) }
    override func currentAudio() -> Int { Int(player.currentAudioTrackIndex) }
    override func setAudio(_ id: Int) { player.currentAudioTrackIndex = Int32(id) }
    override func subtitleTracks() -> [(String, Int)] { tracks(player.videoSubTitlesNames, player.videoSubTitlesIndexes) }
    override func currentSubtitle() -> Int { Int(player.currentVideoSubTitleIndex) }
    override func setSubtitle(_ id: Int) { player.currentVideoSubTitleIndex = Int32(id) }
}
#endif
