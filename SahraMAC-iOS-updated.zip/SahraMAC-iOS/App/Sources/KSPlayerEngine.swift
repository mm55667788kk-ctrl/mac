#if SAHRA_KS
import UIKit
import KSPlayer

/// KSPlayer: an FFmpeg player (KSMEPlayer) with Metal drawing and its own full controls — audio and
/// subtitle tracks, speed, picture-in-picture, HDR. Good for MKV, HEVC and live TS.
final class KSEngineController: UIViewController {
    private let o: EngineOpts
    private let done: (String) -> Void
    private var playerView: IOSVideoPlayerView?
    private var overlay: SubtitleOverlay?
    private var watchdog: Timer?
    private let deadline = Date().addingTimeInterval(30)
    private var firstTime: Double = -1
    private var started = false
    private var finished = false
    private var wantNext = false
    private var streamEnded = false
    private var lastPos: Double = 0
    private var lastDur: Double = 0
    private var failure = ""

    init(_ o: EngineOpts, done: @escaping (String) -> Void) {
        self.o = o
        self.done = done
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        guard let u = o.mediaURL else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.fail("رابط غير صالح") }
            return
        }
        // FFmpeg first (AVPlayer is its own engine in the app)
        KSOptions.firstPlayerType = KSMEPlayer.self
        KSOptions.secondPlayerType = KSMEPlayer.self
        let options = KSOptions()
        // Prefer VideoToolbox hardware decoding when this device/codec supports it;
        // the FFmpeg player retains its software path as a compatibility fallback.
        options.hardwareDecode = true
        if !o.ua.isEmpty { options.appendHeader(["User-Agent": o.ua]) }
        if o.start > 1 { options.startPlayTime = o.start }
        // Keep live channel start-up quick and bound VOD memory use on iPhone.
        options.preferredForwardBufferDuration = o.live ? 2 : 5
        options.maxBufferDuration = o.live ? 18 : 60

        let pv = IOSVideoPlayerView()
        pv.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(pv)
        NSLayoutConstraint.activate([
            pv.topAnchor.constraint(equalTo: view.topAnchor),
            pv.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            pv.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pv.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        pv.backBlock = { [weak self] in self?.finish() }
        pv.playTimeDidChange = { [weak self] (current: TimeInterval, total: TimeInterval) in
            self?.progress(current, total)
        }
        playerView = pv

        if let ov = SubtitleOverlay(srt: o.subs) {
            overlay = ov
            ov.attach(to: view)
        }
        // a close button of our own too, whatever KSPlayer shows in this orientation
        let close = UIButton(type: .system)
        close.setImage(UIImage(systemName: "xmark.circle.fill", withConfiguration: UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold)), for: .normal)
        close.tintColor = UIColor(white: 1, alpha: 0.75)
        close.addTarget(self, action: #selector(closeTap), for: .touchUpInside)
        close.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(close)
        NSLayoutConstraint.activate([
            close.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            close.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 56),
            close.widthAnchor.constraint(equalToConstant: 44),
            close.heightAnchor.constraint(equalToConstant: 44)
        ])

        let definition = KSPlayerResourceDefinition(url: u, definition: o.title.isEmpty ? "KSPlayer" : o.title, options: options)
        pv.set(resource: KSPlayerResource(name: o.title, definitions: [definition]))
        watchdog = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.watch() }
    }

    private func progress(_ current: Double, _ total: Double) {
        guard current.isFinite else { return }
        if firstTime < 0 { firstTime = current } else if abs(current - firstTime) > 0.3 { started = true }
        if started { lastPos = current }
        if total.isFinite && total > 0 { lastDur = total }
        overlay?.show(at: current)
        if started && o.hasNext && total > 60 && current >= total - 1 {
            streamEnded = true
            wantNext = true
            finish()
        }
    }

    private func watch() {
        if !started && Date() > deadline { fail("لم يبدأ خلال 30 ثانية") }
    }

    @objc private func closeTap() { finish() }

    private func fail(_ why: String) {
        if finished || !failure.isEmpty { return }
        failure = why
        finish()
    }

    private func finish() {
        if finished { return }
        finished = true
        watchdog?.invalidate()
        watchdog = nil
        playerView?.pause()
        playerView?.removeFromSuperview()
        playerView = nil
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: wantNext, error: failure, started: started, ended: streamEnded)
        if presentingViewController != nil && !isBeingDismissed {
            dismiss(animated: true) { self.done(answer) }
        } else {
            done(answer)
        }
    }
}
#endif
