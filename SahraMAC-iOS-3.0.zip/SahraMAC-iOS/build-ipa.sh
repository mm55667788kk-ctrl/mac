#!/bin/bash
# Build an unsigned-for-distribution arm64 IPA. The device installer adds its own signing identity.
set -euo pipefail
cd "$(dirname "$0")"

for command in xcrun npm python3 curl; do
  if ! command -v "$command" >/dev/null; then
    echo "Building the IPA requires Xcode, Node.js (npm), Python 3 and curl on macOS." >&2
    exit 1
  fi
done
sdk="$(xcrun --sdk iphoneos --show-sdk-path)"
xcodebuild -version

out="$PWD/build"
app="$out/Payload/SahraMAC.app"
rm -rf -- "$out"
mkdir -p "$app" "$out/dependencies"
rm -f -- SahraMAC.ipa
cp App/Info.plist "$app/Info.plist"
cp App/Resources/* "$app/"
printf 'APPL????' > "$app/PkgInfo"
app_version="$(plutil -extract CFBundleShortVersionString raw -o - "$app/Info.plist")"
deployment="$(plutil -extract MinimumOSVersion raw -o - "$app/Info.plist")"

shaka_version=5.3.3
echo "Bundling Shaka Player $shaka_version"
(
  cd "$out/dependencies"
  npm pack --ignore-scripts --fetch-retries=2 --fetch-timeout=45000 --silent "shaka-player@$shaka_version"
  tar -xOf "shaka-player-$shaka_version.tgz" package/dist/shaka-player.compiled.js > "$app/shaka-player.compiled.js"
  tar -xOf "shaka-player-$shaka_version.tgz" package/LICENSE > "$app/Shaka-Player-LICENSE.txt"
)
test -s "$app/shaka-player.compiled.js"
test -s "$app/Shaka-Player-LICENSE.txt"

gst_version=1.28.8
echo "Preparing GStreamer $gst_version for iPhone"
if [ -n "${GSTREAMER_XCFRAMEWORK:-}" ]; then
  resources="$(cd "$GSTREAMER_XCFRAMEWORK" && pwd)"
else
  resources="$out/dependencies/gstreamer"
  mkdir -p "$resources"
  archive="gstreamer-$gst_version-xcframework.tar.xz"
  upstream="https://gstreamer.freedesktop.org/data/pkg/ios/$gst_version/$archive"
  (
    cd "$out/dependencies"
    curl -fSL --retry 2 --connect-timeout 20 --max-time 1200 -o "$archive" "$upstream"
    curl -fsSL --retry 2 --connect-timeout 20 --max-time 60 -o "$archive.sha256sum" "$upstream.sha256sum"
    shasum -a 256 -c "$archive.sha256sum"
    tar -xf "$archive" -C "$resources"
    rm -- "$archive" "$archive.sha256sum"
  )
fi

framework="$(python3 - "$resources" <<'PY'
from pathlib import Path
import plistlib
import sys

root = Path(sys.argv[1])
packages = [root] if root.name == "GStreamer.xcframework" else sorted(root.rglob("GStreamer.xcframework"))
for package in packages:
    with (package / "Info.plist").open("rb") as manifest:
        variants = plistlib.load(manifest)["AvailableLibraries"]
    for variant in variants:
        if variant["SupportedPlatform"] != "ios" or variant.get("SupportedPlatformVariant"):
            continue
        if "arm64" in variant["SupportedArchitectures"]:
            framework = package / variant["LibraryIdentifier"] / variant["LibraryPath"]
            if (framework / "GStreamer").is_file():
                print(framework)
                sys.exit(0)
sys.exit("GStreamer.xcframework is missing its physical iPhone arm64 framework.")
PY
)"
binary="$framework/GStreamer"
xcrun lipo -verify_arch arm64 "$binary"
xcrun nm -gjU "$binary" > "$out/dependencies/GStreamer.symbols"
python3 - "$out/dependencies" <<'PY'
from pathlib import Path
import sys

directory = Path(sys.argv[1])
symbols = set((directory / "GStreamer.symbols").read_text().splitlines())
# Register the plugins present in the SDK. Link only the plugins needed for playback.
required = ["coreelements", "playback", "typefindfunctions", "opengl", "applemedia", "matroska",
            "isomp4", "mpegtsdemux", "audioconvert", "audioresample", "osxaudio", "soup"]
optional = ["adaptivedemux2", "dash", "hls", "gio", "queue2", "autodetect", "audiofx",
            "volume", "videoconvertscale", "videoparsersbad", "audioparsers", "subparse", "pango",
            "libass", "libav", "faad", "a52dec", "dtsdec", "opus", "vorbis", "flac", "ogg", "wavparse",
            "lame", "mpg123", "av1parse", "dav1d", "vpx", "theora", "jpeg", "png", "interleave",
            "encoding", "tcp", "udp", "rtp", "rtpmanager", "rtsp", "deinterlace", "videorate"]
has_plugin = lambda name: f"_gst_plugin_{name}_register" in symbols
missing = [name for name in required if not has_plugin(name)]
if missing:
    sys.exit("Missing plugins in GStreamer iOS SDK: " + ", ".join(missing))
plugins = required + [name for name in optional if has_plugin(name)]
print("GStreamer plugins:", ", ".join(plugins))
gio = [name for name in ("gnutls", "openssl", "apple", "darwin", "proxy")
       if f"_g_io_module_{name}_load" in symbols]
code = ["#include <gio/gio.h>"]
code += [f"GST_PLUGIN_STATIC_DECLARE({name});" for name in plugins]
code += [f"extern void g_io_module_{name}_load(GIOModule *);" for name in gio]
code += ["static void SahraRegisterPlugins(void) {"]
code += [f"    GST_PLUGIN_STATIC_REGISTER({name});" for name in plugins]
code += ["}", "static void SahraLoadNetworkModules(void) {"]
code += [f"    g_io_module_{name}_load(NULL);" for name in gio]
code += ["}", "static void SahraSetTrustDatabase(const char *pem) {",
         "    GTlsBackend *backend = g_tls_backend_get_default();",
         "    if (!g_tls_backend_supports_tls(backend)) return;",
         "    GTlsDatabase *database = g_tls_file_database_new(pem, NULL);",
         "    if (database) { g_tls_backend_set_default_database(backend, database); g_object_unref(database); }", "}"]
(directory / "SahraPlugins.h").write_text("\n".join(code) + "\n")
PY

# Locate headers whether the SDK uses a flat or a versioned include directory.
header_flags=(-I "$out/dependencies" -I "$framework/Headers")
for header_name in gst.h glib.h glibconfig.h gio.h; do
  header="$(find -L "$framework/Headers" -name "$header_name" -type f -print | sed -n '1p')"
  if [ -z "$header" ]; then echo "GStreamer SDK header missing: $header_name" >&2; exit 1; fi
  dir="$(dirname "$header")"
  case "$header_name" in
    gst.h|gio.h) dir="$(dirname "$dir")" ;;
  esac
  header_flags+=(-I "$dir")
done
cert="$(find "$resources" -type f \( -name cacert.pem -o -name ca-certificates.crt \) -print | sed -n '1p')"
if [ -z "$cert" ]; then
  # Use a local root store when the SDK does not bundle one.
  cert=/etc/ssl/cert.pem
fi
if [ -s "$cert" ]; then cp "$cert" "$app/gstreamer-ca.pem"; fi

target="arm64-apple-ios$deployment"
echo "Compiling the GStreamer adapter"
xcrun --sdk iphoneos clang -target "$target" -isysroot "$sdk" -fobjc-arc -fmodules -O2 \
  -DGST_USE_UNSTABLE_API "${header_flags[@]}" -c App/Native/SahraGStreamer.m -o "$out/GStreamerAdapter.o"

swift_flags=(-swift-version 5 -parse-as-library -O -whole-module-optimization
  -target "$target" -sdk "$sdk" -import-objc-header App/Native/SahraGStreamer.h
  -F "$(dirname "$framework")" -framework GStreamer
  -Xlinker -no_compact_unwind -lc++ -lresolv -liconv -lz -lbz2 -lxml2)
for name in Foundation UIKit WebKit JavaScriptCore SafariServices QuartzCore CoreText CoreFoundation CoreGraphics \
  Security CFNetwork AudioToolbox CoreAudio AVFoundation CoreMedia CoreVideo CoreImage VideoToolbox \
  Accelerate OpenGLES Metal Network SystemConfiguration ImageIO MobileCoreServices AssetsLibrary; do
  if [ -d "$sdk/System/Library/Frameworks/$name.framework" ]; then swift_flags+=(-framework "$name"); fi
done
if xcrun otool -hv "$binary" | awk '$0 ~ /(^|[[:space:]])DYLIB([[:space:]]|$)/ { found=1 } END { exit !found }'; then
  swift_flags+=(-Xlinker -rpath -Xlinker @executable_path/Frameworks)
  mkdir -p "$app/Frameworks"
  cp -R "$framework" "$app/Frameworks/"
  rm -rf "$app/Frameworks/GStreamer.framework/Headers" "$app/Frameworks/GStreamer.framework/Modules"
  codesign --force --sign - --timestamp=none "$app/Frameworks/GStreamer.framework"
fi

echo "Compiling SahraMAC $app_version"
xcrun --sdk iphoneos swiftc "${swift_flags[@]}" App/Sources/*.swift "$out/GStreamerAdapter.o" -o "$app/SahraMAC"
plutil -lint "$app/Info.plist"
codesign --force --sign - --timestamp=none "$app"
codesign --verify --deep "$app"
(cd "$out" && zip -qry ../SahraMAC.ipa Payload)
echo "SahraMAC.ipa ($app_version) — GStreamer $gst_version + Shaka Player $shaka_version"
if [ -n "${GITHUB_STEP_SUMMARY:-}" ]; then
  echo "**SahraMAC.ipa ($app_version)** — GStreamer $gst_version + Shaka Player $shaka_version" >> "$GITHUB_STEP_SUMMARY"
fi
