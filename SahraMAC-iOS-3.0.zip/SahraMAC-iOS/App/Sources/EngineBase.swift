import Foundation

struct CinemaEpisode {
    let index: Int
    let title: String
}

struct EngineOpts {
    let url: String
    let download: DownloadParts?
    let title: String
    let start: Double
    let ua: String
    let subs: String
    let subtitleMode: String
    let audioLang: String
    let hasNext: Bool
    let live: Bool
    let autoNext: Bool
    let profile: PlaybackProfile
    var choices: [String]
    let skip: Double
    let rate: Double
    let subtitle: String
    let episodes: [CinemaEpisode]
    let episodeIndex: Int?

    static func parse(_ json: String) -> EngineOpts? {
        guard let data = json.data(using: .utf8),
              let dict = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { return nil }
        let start = (dict["start"] as? Double) ?? 0
        let skip = (dict["skip"] as? Double) ?? 10
        let rate = (dict["rate"] as? Double) ?? 1
        let episodes = (dict["episodes"] as? [[String: Any]] ?? []).prefix(200).compactMap { row -> CinemaEpisode? in
            guard let index = row["index"] as? Int, index >= 0,
                  let title = row["title"] as? String, !title.isEmpty else { return nil }
            return CinemaEpisode(index: index, title: String(title.prefix(200)))
        }
        return EngineOpts(
            url: ((dict["url"] as? String) ?? "").trimmingCharacters(in: .whitespacesAndNewlines),
            download: DownloadParts(dict["download"] as? [String: Any]),
            title: (dict["title"] as? String) ?? "",
            start: start.isFinite ? min(max(0, start), 2_000_000) : 0,
            ua: (dict["ua"] as? String) ?? "",
            subs: (dict["subs"] as? String) ?? "",
            subtitleMode: (dict["subtitleMode"] as? String) ?? "ar",
            audioLang: (dict["audioLang"] as? String) ?? "",
            hasNext: (dict["next"] as? Bool) ?? false,
            live: (dict["live"] as? Bool) ?? false,
            autoNext: (dict["autoNext"] as? Bool) ?? true,
            profile: PlaybackProfile(rawValue: dict["profile"] as? String ?? "") ?? .balanced,
            choices: (dict["choices"] as? [String]) ?? [],
            skip: [10, 15, 30].contains(skip) ? skip : 10,
            rate: rate.isFinite ? min(max(0.5, rate), 2) : 1,
            subtitle: (dict["subtitle"] as? String) ?? "",
            episodes: episodes,
            episodeIndex: dict["episodeIndex"] as? Int
        )
    }

    var mediaURL: URL? {
        guard let candidate = URL(string: url),
              let scheme = candidate.scheme?.lowercased(),
              ["http", "https"].contains(scheme), candidate.host != nil else { return nil }
        return candidate
    }
}

func engineAnswer(pos: Double, dur: Double, next: Bool, error: String, started: Bool,
                  ended: Bool = false, retryable: Bool = false, engine: String? = nil,
                  profile: PlaybackProfile? = nil, busy: Bool = false, episode: Int? = nil) -> String {
    var answer: [String: Any] = ["pos": pos.isFinite ? max(0, pos) : 0, "dur": dur.isFinite ? max(0, dur) : 0,
                                 "next": next, "started": started, "ended": ended,
                                 "retryable": retryable, "busy": busy]
    if !error.isEmpty { answer["error"] = error }
    if let engine = engine { answer["engine"] = engine }
    if let profile = profile { answer["profile"] = profile.rawValue }
    if let episode = episode { answer["episode"] = episode }
    guard let data = try? JSONSerialization.data(withJSONObject: answer),
          let json = String(data: data, encoding: .utf8) else { return "{}" }
    return json
}
