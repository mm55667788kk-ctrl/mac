import UIKit

final class GStreamerEngineController: PlaybackSessionController {
    private let surface = UIView()
    private var backend: SahraGStreamer?
    private var timer: Timer?
    private var assembly: Task<Void, Never>?
    private var localFile: URL?
    private var displaySubtitle: SubtitleOverlay?
    private var opened = false
    private var pausedByUser = false
    private var suspended = false
    private var cropping = false
    private var canSeek = false
    private var dimensions = CGSize.zero

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.clipsToBounds = true
        surface.backgroundColor = .black
        surface.isUserInteractionEnabled = false
        view.addSubview(surface)
        if let subtitle = SubtitleOverlay(srt: o.subs) {
            subtitle.attach(to: view)
            displaySubtitle = subtitle
        }
        installCinemaControls()
        cinemaControls?.setPictureInPictureAvailable(false)
        NotificationCenter.default.addObserver(self, selector: #selector(willPause),
                                               name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(didResume),
                                               name: UIApplication.didBecomeActiveNotification, object: nil)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let bounds = view.bounds
        guard cropping, dimensions.width > 0, dimensions.height > 0 else {
            surface.frame = bounds
            return
        }
        let scale = max(bounds.width / dimensions.width, bounds.height / dimensions.height)
        let size = CGSize(width: dimensions.width * scale, height: dimensions.height * scale)
        surface.frame = CGRect(x: bounds.midX - size.width / 2, y: bounds.midY - size.height / 2,
                               width: size.width, height: size.height)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !opened, !finished else { return }
        opened = true
        lastPos = o.start
        cinemaControls?.update(position: lastPos, duration: 0, canSeek: false, paused: false, waiting: true)
        if let file = o.download {
            assembly = Task { [weak self] in
                let work = Task.detached(priority: .userInitiated) { try file.prepare() }
                do {
                    let url = try await withTaskCancellationHandler(operation: { try await work.value },
                                                                    onCancel: { work.cancel() })
                    guard let self = self, !self.finished, !Task.isCancelled else {
                        try? FileManager.default.removeItem(at: url)
                        return
                    }
                    self.localFile = url
                    self.start(url)
                } catch {
                    guard let self = self, !self.finished, !Task.isCancelled else { return }
                    let downloadError = error as? DownloadParts.DownloadError
                    self.finish(error: downloadError?.localizedDescription ?? "تعذّر قراءة التنزيل")
                }
            }
        } else if let url = o.mediaURL {
            start(url)
        } else {
            finish(error: "رابط تشغيل غير صالح")
        }
    }

    private func start(_ url: URL) {
        let player = SahraGStreamer(surface: surface)
        backend = player
        let subtitleMode = displaySubtitle == nil ? o.subtitleMode : "off"
        player.open(url: url, userAgent: o.ua, buffer: o.profile.nativeBuffer(live: o.live),
                    bandwidth: o.profile == .saver ? 1500 : 0, start: o.live ? 0 : o.start,
                    rate: o.live ? 1 : o.rate, audio: o.audioLang, subtitles: subtitleMode)
        suspended = UIApplication.shared.applicationState != .active
        if suspended { player.setPlaying(false) }
        let clock = Timer(timeInterval: 0.35, repeats: true) { [weak self] _ in
            DispatchQueue.main.async { self?.tick() }
        }
        timer = clock
        RunLoop.main.add(clock, forMode: .common)
    }

    private func tick() {
        guard !finished, let state = backend?.snapshot else { return }
        let position = (state["position"] as? Double) ?? 0
        let duration = (state["duration"] as? Double) ?? 0
        if position > 0 { lastPos = position }
        if duration > 0 { lastDur = duration }
        canSeek = !o.live && (state["seekable"] as? Bool == true) && lastDur > 0
        let waiting = (state["waiting"] as? Bool ?? true) && !pausedByUser
        let size = CGSize(width: CGFloat((state["width"] as? Int) ?? 0),
                          height: CGFloat((state["height"] as? Int) ?? 0))
        if size != dimensions { dimensions = size; view.setNeedsLayout() }
        displaySubtitle?.show(at: lastPos)
        cinemaControls?.update(position: lastPos, duration: lastDur, canSeek: canSeek,
                               paused: pausedByUser, waiting: waiting && !suspended)
        if let error = state["error"] as? String, !error.isEmpty {
            finish(error: error, retryable: true)
        } else if state["ended"] as? Bool == true {
            if lastDur > 0 { lastPos = lastDur }
            finish(next: !o.live && o.autoNext && o.hasNext, ended: true)
        } else if let problem = monitor.sample(position, suspended: pausedByUser || suspended || cinemaControls?.scrubbing == true) {
            finish(error: problem, retryable: true)
        }
    }

    @objc private func willPause() {
        suspended = true
        // The iOS OpenGL video surface must be paused while the app is inactive.
        backend?.setPlaying(false)
    }

    @objc private func didResume() {
        suspended = false
        if !pausedByUser { backend?.setPlaying(true) }
    }

    override func handleCinemaTransport(_ action: CinemaAction) {
        switch action {
        case .playPause:
            pausedByUser.toggle()
            if !suspended { backend?.setPlaying(!pausedByUser) }
        case .jump(let seconds):
            guard canSeek else { return }
            seek(lastPos + (seconds < 0 ? -o.skip : o.skip))
        case .seek(let fraction):
            if canSeek { seek(fraction * lastDur) }
        case .speed(let rate):
            if !o.live { monitor.seek(); backend?.changeRate(Double(rate)) }
        case .aspect:
            cropping.toggle()
            view.setNeedsLayout()
        default:
            break
        }
    }

    private func seek(_ time: Double) {
        guard time.isFinite else { return }
        monitor.seek()
        let target = min(lastDur, max(0, time))
        lastPos = target
        backend?.seek(to: target)
    }

    override func showCinemaTracks() {
        guard let backend = backend else { return }
        let state = backend.snapshot
        let audio = state["audio"] as? [[String: String]] ?? []
        let text = state["subtitles"] as? [[String: String]] ?? []
        func title(_ track: [String: String], index: Int) -> String {
            let language = track["language"] ?? ""
            let locale = Locale(identifier: "ar")
            let label = language.isEmpty ? "مسار \(index + 1)" : locale.localizedString(forLanguageCode: language) ?? language
            return [label, track["codec"] ?? ""].filter { !$0.isEmpty }.joined(separator: " · ")
        }
        var groups: [CinemaSection] = []
        if !audio.isEmpty {
            groups.append(CinemaSection(title: "الصوت", choices: audio.enumerated().map {
                CinemaChoice(id: $0.offset, name: title($0.element, index: $0.offset))
            }, selected: audio.firstIndex { $0["id"] == (state["audioID"] as? String) }))
        }
        let external = displaySubtitle != nil ? [CinemaChoice(id: -2, name: "الترجمة العربية المحمّلة")] : []
        let selected = displaySubtitle?.label.isHidden == false ? -2 :
            (text.firstIndex { $0["id"] == (state["subtitleID"] as? String) } ?? -1)
        let subtitles = [CinemaChoice(id: -1, name: "إيقاف")] + external + text.enumerated().map {
            CinemaChoice(id: $0.offset, name: title($0.element, index: $0.offset))
        }
        let textSection = groups.count
        groups.append(CinemaSection(title: "الترجمة", choices: subtitles, selected: selected))
        showCinemaPicker(title: "الصوت والترجمة", sections: groups) { [weak self] section, index in
            guard let self = self else { return }
            if section == textSection {
                self.displaySubtitle?.label.isHidden = index != -2
                backend.selectSubtitle(text.indices.contains(index) ? text[index]["id"] : nil)
            } else if audio.indices.contains(index), let id = audio[index]["id"] {
                backend.selectAudio(id)
            }
        }
    }

    override func stopPlayback() {
        timer?.invalidate()
        timer = nil
        assembly?.cancel()
        assembly = nil
        NotificationCenter.default.removeObserver(self)
        let prepared = localFile
        localFile = nil
        backend?.stop {
            if let prepared = prepared { try? FileManager.default.removeItem(at: prepared) }
        }
        backend = nil
    }
}
