import UIKit

struct CinemaChoice {
    let id: Int
    let name: String
}

struct CinemaSection {
    let title: String
    let choices: [CinemaChoice]
    var selected: Int?
}

final class CinemaPicker: UITableViewController {
    private var sections: [CinemaSection]
    private let closeOnSelection: Bool
    private let selected: (Int, Int) -> Void

    init(title: String, sections: [CinemaSection], closeOnSelection: Bool,
         selected: @escaping (Int, Int) -> Void) {
        self.sections = sections
        self.closeOnSelection = closeOnSelection
        self.selected = selected
        super.init(style: .insetGrouped)
        self.title = title
    }

    required init?(coder: NSCoder) { return nil }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = UIColor(white: 0.065, alpha: 1)
        tableView.tintColor = UIColor(red: 0.90, green: 0.14, blue: 0.25, alpha: 1)
        tableView.semanticContentAttribute = .forceRightToLeft
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 50
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cinema-choice")
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "تم", style: .done, target: self, action: #selector(close)
        )
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if closeOnSelection, let group = sections.first,
           let index = group.choices.firstIndex(where: { $0.id == group.selected }) {
            tableView.scrollToRow(at: IndexPath(row: index, section: 0), at: .middle, animated: false)
        }
    }

    @objc private func close() { dismiss(animated: true) }

    override func numberOfSections(in tableView: UITableView) -> Int { sections.count }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        sections[section].title
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        max(1, sections[section].choices.count)
    }

    override func tableView(_ tableView: UITableView, cellForRowAt path: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cinema-choice", for: path)
        let group = sections[path.section]
        let choice = group.choices.isEmpty ? nil : group.choices[path.row]
        let checked = choice != nil && choice?.id == group.selected
        var config = cell.defaultContentConfiguration()
        config.text = choice?.name ?? "لا توجد خيارات لهذا المصدر"
        config.textProperties.color = choice == nil ? .secondaryLabel : .label
        config.textProperties.alignment = .natural
        config.textProperties.numberOfLines = 2
        cell.contentConfiguration = config
        cell.accessoryType = checked ? .checkmark : .none
        cell.selectionStyle = choice == nil ? .none : .default
        cell.backgroundColor = UIColor(white: 0.13, alpha: 1)
        if checked { cell.accessibilityTraits.insert(.selected) }
        else { cell.accessibilityTraits.remove(.selected) }
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt path: IndexPath) {
        tableView.deselectRow(at: path, animated: true)
        let section = path.section
        guard sections[section].choices.indices.contains(path.row) else { return }
        let id = sections[section].choices[path.row].id
        if closeOnSelection {
            dismiss(animated: true) { self.selected(section, id) }
        } else {
            sections[section].selected = id
            selected(section, id)
            tableView.reloadSections(IndexSet(integer: section), with: .none)
        }
    }
}
