import Foundation

/// Older and newly completed downloads are stored in numbered parts. Open a seekable
/// temporary file and copy parts one by one without holding the film in memory.
struct DownloadParts {
    let id: String
    let total: Int64
    let parts: Int
    let chunkSize: Int

    init?(_ json: [String: Any]?) {
        guard let json = json, let id = json["id"] as? String,
              id.range(of: "^d[0-9a-f]{12}$", options: .regularExpression) != nil,
              let count = json["parts"] as? Int, (1...100_000).contains(count),
              let chunk = json["chunkSize"] as? Int, chunk == 4 * 1024 * 1024,
              let size = json["total"] as? Int64, size > 0,
              (size - 1) / Int64(chunk) + 1 == Int64(count) else { return nil }
        self.id = id
        total = size
        parts = count
        chunkSize = chunk
    }

    func prepare() throws -> URL {
        let fs = FileManager.default
        let documents = try fs.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let folder = documents.appendingPathComponent("sahra-mac/downloads", isDirectory: true)
            .appendingPathComponent(id, isDirectory: true)
        let directory = fs.temporaryDirectory
        if let free = try? directory.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
            .volumeAvailableCapacityForImportantUsage, free < total {
            throw DownloadError.space
        }
        let destination = directory.appendingPathComponent("sahra-offline-\(UUID().uuidString).video")
        guard fs.createFile(atPath: destination.path, contents: nil) else { throw DownloadError.space }
        var success = false
        defer { if !success { try? fs.removeItem(at: destination) } }
        let output = try FileHandle(forWritingTo: destination)
        defer { try? output.close() }
        var bytesLeft = total
        for index in 0..<parts {
            try Task.checkCancellation()
            try autoreleasepool {
                let name = String(format: "p%05d.bin", index)
                let part = folder.appendingPathComponent(name)
                let expected = Int(min(bytesLeft, Int64(chunkSize)))
                let file = try FileHandle(forReadingFrom: part)
                defer { try? file.close() }
                guard let data = try file.read(upToCount: expected + 1), data.count == expected else {
                    throw DownloadError.incomplete
                }
                try output.write(contentsOf: data)
                bytesLeft -= Int64(expected)
            }
        }
        try Task.checkCancellation()
        success = true
        return destination
    }

    enum DownloadError: LocalizedError {
        case space, incomplete
        var errorDescription: String? {
            switch self {
            case .space: return "المساحة غير كافية لتجهيز الملف"
            case .incomplete: return "أجزاء التنزيل غير مكتملة"
            }
        }
    }
}
