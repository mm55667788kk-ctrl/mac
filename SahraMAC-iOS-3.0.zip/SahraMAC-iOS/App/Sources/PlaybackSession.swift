import UIKit

enum PlaybackProfile: String, CaseIterable {
    case balanced, fast, stable, saver

    var title: String {
        switch self {
        case .balanced: return "متوازن"
        case .fast: return "بدء سريع"
        case .stable: return "بث ثابت"
        case .saver: return "توفير البيانات"
        }
    }

    func startupLimit(live: Bool) -> TimeInterval {
        switch self {
        case .fast: return live ? 9 : 13
        case .balanced, .saver: return live ? 13 : 18
        case .stable: return live ? 18 : 24
        }
    }

    var stallLimit: TimeInterval {
        switch self {
        case .fast: return 11
        case .balanced, .saver: return 16
        case .stable: return 23
        }
    }

    func nativeBuffer(live: Bool) -> TimeInterval {
        switch self {
        case .balanced: return live ? 3 : 6
        case .fast: return live ? 1.5 : 3
        case .stable: return live ? 8 : 16
        case .saver: return live ? 4 : 7
        }
    }
}

/// Detect actual playback progress. Pauses, seeks and time spent in the background
/// do not count against a stream.
struct PlaybackMonitor {
    let profile: PlaybackProfile
    let live: Bool
    private(set) var started = false
    private var lastTick = ProcessInfo.processInfo.systemUptime
    private var lastPosition: Double?
    private var idleFor: TimeInterval = 0
    private var seekingUntil: TimeInterval = 0

    init(profile: PlaybackProfile, live: Bool) {
        self.profile = profile
        self.live = live
    }

    mutating func seek() {
        lastPosition = nil
        idleFor = 0
        seekingUntil = ProcessInfo.processInfo.systemUptime + 4
    }

    mutating func sample(_ position: Double, suspended: Bool) -> String? {
        let now = ProcessInfo.processInfo.systemUptime
        let elapsed = min(now - lastTick, 1.5)
        lastTick = now
        if suspended || now < seekingUntil {
            lastPosition = nil
            idleFor = 0
            return nil
        }
        if position.isFinite && position >= 0 {
            defer { lastPosition = position }
            if let previous = lastPosition, position > previous + 0.03 {
                started = true
                idleFor = 0
                return nil
            }
        }
        idleFor += elapsed
        guard idleFor >= (started ? profile.stallLimit : profile.startupLimit(live: live)) else { return nil }
        return started ? "توقف تقدّم الفيديو" : "تأخر بدء التشغيل"
    }
}

class PlaybackSessionController: UIViewController {
    let o: EngineOpts
    let engineID: String
    private let done: (String) -> Void
    var monitor: PlaybackMonitor
    private(set) var finished = false
    var lastPos: Double = 0
    var lastDur: Double = 0
    private(set) var cinemaControls: CinemaControls?

    init(_ o: EngineOpts, engine: String, done: @escaping (String) -> Void) {
        self.o = o
        self.engineID = engine
        self.done = done
        self.monitor = PlaybackMonitor(profile: o.profile, live: o.live)
        super.init(nibName: nil, bundle: nil)
        modalPresentationStyle = .fullScreen
    }

    required init?(coder: NSCoder) { return nil }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }
    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        cinemaControls?.show()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || presentingViewController == nil {
            finish(dismissScreen: false)
        }
    }

    func stopPlayback() {}

    func finish(error: String = "", retryable: Bool = false, next: Bool = false,
                ended: Bool = false, engine: String? = nil, profile: PlaybackProfile? = nil,
                dismissScreen: Bool = true, episode: Int? = nil) {
        guard !finished else { return }
        finished = true
        let answer = engineAnswer(pos: lastPos, dur: lastDur, next: next,
                                  error: error, started: monitor.started, ended: ended,
                                  retryable: retryable, engine: engine, profile: profile, episode: episode)
        stopPlayback()
        if dismissScreen, let presenter = presentingViewController, !isBeingDismissed {
            presenter.dismiss(animated: true) { self.done(answer) }
        } else {
            DispatchQueue.main.async { self.done(answer) }
        }
    }

    func installCinemaControls(routePicker: UIView? = nil) {
        let aspect = UIAction(title: "تبديل ملء الشاشة", image: UIImage(systemName: "aspectratio")) { [weak self] _ in
            self?.handleCinemaTransport(.aspect)
        }
        let controls = CinemaControls(options: o, more: optionsMenu(extra: [aspect]), routePicker: routePicker)
        controls.onAction = { [weak self] action in self?.handleCinemaAction(action) }
        controls.frame = view.bounds
        controls.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(controls)
        cinemaControls = controls
    }

    private func handleCinemaAction(_ action: CinemaAction) {
        guard !finished else { return }
        switch action {
        case .close: finish()
        case .next: finish(next: true)
        case .tracks: showCinemaTracks()
        case .episodes: showCinemaEpisodes()
        default: handleCinemaTransport(action)
        }
    }

    func handleCinemaTransport(_ action: CinemaAction) {}
    func showCinemaTracks() {}

    private func showCinemaEpisodes() {
        guard !o.episodes.isEmpty else { return }
        let group = CinemaSection(title: "",
                                  choices: o.episodes.map { CinemaChoice(id: $0.index, name: $0.title) },
                                  selected: o.episodeIndex)
        showCinemaPicker(title: o.live ? "القنوات" : "الحلقات", sections: [group], closeOnSelection: true) { [weak self] _, index in
            guard let self = self, index != self.o.episodeIndex else { return }
            self.finish(episode: index)
        }
    }

    func showCinemaPicker(title: String, sections: [CinemaSection], closeOnSelection: Bool = false,
                          selected: @escaping (Int, Int) -> Void) {
        guard !finished, presentedViewController == nil, viewIfLoaded?.window != nil else { return }
        let picker = CinemaPicker(title: title, sections: sections, closeOnSelection: closeOnSelection, selected: selected)
        let nav = UINavigationController(rootViewController: picker)
        nav.overrideUserInterfaceStyle = .dark
        nav.modalPresentationStyle = .pageSheet
        nav.sheetPresentationController?.detents = [.medium(), .large()]
        nav.sheetPresentationController?.prefersGrabberVisible = true
        present(nav, animated: true)
    }

    func optionsMenu(extra: [UIMenuElement] = []) -> UIMenu {
        let engineActions = o.choices.compactMap { id -> UIAction? in
            guard let name = NativeEngines.titles[id] else { return nil }
            return UIAction(title: name, state: id == engineID ? .on : .off) { [weak self] _ in
                guard let self = self, id != self.engineID else { return }
                self.finish(engine: id)
            }
        }
        let profileActions = PlaybackProfile.allCases.map { profile in
            UIAction(title: profile.title, state: profile == o.profile ? .on : .off) { [weak self] _ in
                guard let self = self, profile != self.o.profile else { return }
                self.finish(engine: self.engineID, profile: profile)
            }
        }
        var items: [UIMenuElement] = [
            UIMenu(title: "الأداء", image: UIImage(systemName: "speedometer"), children: profileActions)
        ]
        if engineActions.count > 1 {
            items.append(UIMenu(title: "محرك التشغيل", image: UIImage(systemName: "play.rectangle"), children: engineActions))
        }
        if o.hasNext {
            items.append(UIAction(title: o.live ? "القناة التالية" : "الحلقة التالية", image: UIImage(systemName: "forward.end")) { [weak self] _ in
                self?.finish(next: true)
            })
        }
        return UIMenu(title: "", children: items + extra)
    }
}
