import UIKit

enum NativeEngines {
    static let titles = ["gst": "GStreamer", "shaka": "Shaka Player"]
    static let available = ["gst"]
    private static var active = false

    @MainActor
    static func present(_ engine: String, json: String, from host: UIViewController?, done: @escaping (String) -> Void) {
        guard !active, let host = host, host.viewIfLoaded?.window != nil, host.presentedViewController == nil else {
            done(engineAnswer(pos: 0, dur: 0, next: false, error: "", started: false, busy: true))
            return
        }
        guard engine == "gst", var opts = EngineOpts.parse(json), opts.mediaURL != nil || opts.download != nil else {
            done(engineAnswer(pos: 0, dur: 0, next: false, error: "رابط أو ملف غير صالح", started: false))
            return
        }
        opts.choices = opts.choices.filter { titles[$0] != nil }
        active = true
        let controller = GStreamerEngineController(opts, engine: engine) { answer in
            active = false
            done(answer)
        }
        host.present(controller, animated: true)
    }
}

final class SubtitleOverlay {
    private struct Cue { let a: Double; let b: Double; let text: String }
    private var cues: [Cue] = []
    private var shown = -2
    let label = UILabel()

    init?(srt: String) {
        if srt.isEmpty { return nil }
        let blocks = srt.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n\n")
        for b in blocks {
            let lines = b.components(separatedBy: "\n")
            guard let i = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let parts = lines[i].components(separatedBy: "-->")
            guard parts.count == 2, let a = SubtitleOverlay.time(parts[0]), let z = SubtitleOverlay.time(parts[1]) else { continue }
            var text = lines[(i + 1)...].joined(separator: "\n")
            text = text.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            text = text.replacingOccurrences(of: "\\{[^}]*\\}", with: "", options: .regularExpression)
            text = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if !text.isEmpty { cues.append(Cue(a: a, b: z, text: text)) }
        }
        if cues.isEmpty { return nil }
        cues.sort { $0.a < $1.a }
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: UIDevice.current.userInterfaceIdiom == .pad ? 30 : 21, weight: .bold)
        label.numberOfLines = 0
        label.textAlignment = .center
        label.shadowColor = UIColor(white: 0, alpha: 0.95)
        label.shadowOffset = CGSize(width: 1.5, height: 1.5)
        label.isUserInteractionEnabled = false
        label.translatesAutoresizingMaskIntoConstraints = false
    }

    private static func time(_ s: String) -> Double? {
        let t = s.trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? ""
        let p = t.replacingOccurrences(of: ",", with: ".").components(separatedBy: ":")
        guard p.count >= 2 else { return nil }
        var v = 0.0
        for x in p {
            guard let n = Double(x) else { return nil }
            v = v * 60 + n
        }
        return v
    }

    func attach(to v: UIView, bottomInset: CGFloat = 64) {
        v.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            label.trailingAnchor.constraint(equalTo: v.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            label.bottomAnchor.constraint(equalTo: v.safeAreaLayoutGuide.bottomAnchor, constant: -bottomInset)
        ])
    }

    func show(at t: Double) {
        var lo = 0, hi = cues.count - 1, hit = -1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if cues[mid].a <= t { hit = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        let now = hit >= 0 && t <= cues[hit].b ? hit : -1
        if now == shown { return }
        shown = now
        label.text = now >= 0 ? cues[now].text : nil
    }
}

