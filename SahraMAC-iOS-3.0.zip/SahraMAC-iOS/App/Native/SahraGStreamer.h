#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SahraGStreamer : NSObject

@property (atomic, copy, readonly) NSDictionary<NSString *, id> *snapshot;

- (instancetype)initWithSurface:(UIView *)surface NS_SWIFT_NAME(init(surface:));
- (void)open:(NSURL *)url
   userAgent:(NSString *)userAgent
      buffer:(double)buffer
   bandwidth:(unsigned int)bandwidth
       start:(double)start
        rate:(double)rate
       audio:(NSString *)audio
   subtitles:(NSString *)subtitles
    NS_SWIFT_NAME(open(url:userAgent:buffer:bandwidth:start:rate:audio:subtitles:));
- (void)setPlaying:(BOOL)playing NS_SWIFT_NAME(setPlaying(_:));
- (void)seekTo:(double)seconds NS_SWIFT_NAME(seek(to:));
- (void)changeRate:(double)rate NS_SWIFT_NAME(changeRate(_:));
- (void)selectAudio:(NSString *)identifier NS_SWIFT_NAME(selectAudio(_:));
- (void)selectSubtitle:(nullable NSString *)identifier NS_SWIFT_NAME(selectSubtitle(_:));
- (void)stopWithCompletion:(void (^)(void))completion NS_SWIFT_NAME(stop(completion:));

@end

NS_ASSUME_NONNULL_END
