#import "SahraGStreamer.h"
#import <gst/gst.h>
#import <gst/play/gstplay.h>
#import <gst/play/gstplay-videooverlayvideorenderer.h>
#import <math.h>
#import "SahraPlugins.h"

static dispatch_queue_t PlaybackQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        queue = dispatch_queue_create("app.sahra.gstreamer", DISPATCH_QUEUE_SERIAL);
    });
    return queue;
}

static BOOL InitializeGStreamer(void) {
    static BOOL ready;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        // The iOS SDK ships static plugins. The build generates registration
        // calls for the plugins present in its physical-device slice.
        NSString *cache = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
        if (cache) g_setenv("XDG_CACHE_HOME", cache.fileSystemRepresentation, TRUE);
        SahraLoadNetworkModules();
        NSString *ca = [[NSBundle mainBundle] pathForResource:@"gstreamer-ca" ofType:@"pem"];
        if (ca) SahraSetTrustDatabase(ca.fileSystemRepresentation);
        ready = gst_init_check(NULL, NULL, NULL);
        if (ready) SahraRegisterPlugins();
    });
    return ready;
}

static double Seconds(GstClockTime time) {
    return GST_CLOCK_TIME_IS_VALID(time) ? (double)time / GST_SECOND : 0;
}

static NSString *TrackID(GstPlayStreamInfo *track) {
    if (!track) return @"";
    const gchar *value = gst_play_stream_info_get_stream_id(track);
    return value ? [NSString stringWithUTF8String:value] ?: @"" : @"";
}

static NSArray<NSDictionary *> *Tracks(const GList *streams, BOOL subtitles) {
    NSMutableArray *rows = [NSMutableArray array];
    for (const GList *node = streams; node; node = node->next) {
        GstPlayStreamInfo *track = GST_PLAY_STREAM_INFO(node->data);
        NSString *identifier = TrackID(track);
        if (!identifier.length) continue;
        const gchar *language = subtitles ?
            gst_play_subtitle_info_get_language(GST_PLAY_SUBTITLE_INFO(track)) :
            gst_play_audio_info_get_language(GST_PLAY_AUDIO_INFO(track));
        const gchar *codec = gst_play_stream_info_get_codec(track);
        [rows addObject:@{
            @"id": identifier,
            @"language": language ? [NSString stringWithUTF8String:language] ?: @"" : @"",
            @"codec": codec ? [NSString stringWithUTF8String:codec] ?: @"" : @""
        }];
    }
    return rows;
}

static BOOL MatchesLanguage(NSString *language, NSString *preferred) {
    NSString *lang = [[language lowercaseString] componentsSeparatedByString:@"-"].firstObject;
    if ([lang isEqualToString:@"ara"]) lang = @"ar";
    if ([lang isEqualToString:@"eng"]) lang = @"en";
    return preferred.length && [lang isEqualToString:preferred.lowercaseString];
}

@interface SahraGStreamer ()
@property (atomic, copy, readwrite) NSDictionary<NSString *, id> *snapshot;
@end

@implementation SahraGStreamer {
    UIView *_surface;
    GstPlay *_player;
    GstBus *_bus;
    dispatch_source_t _timer;
    GstPlayState _state;
    BOOL _closed, _ended, _seekable, _played, _positionKnown;
    BOOL _preferredAudioApplied, _preferredSubtitleApplied;
    double _position, _duration, _resumeAt, _resumeDeadline;
    int _width, _height;
    NSString *_error, *_audioPreference, *_subtitlePreference, *_audioID, *_subtitleID;
    NSArray<NSDictionary *> *_audio, *_subtitles;
}

// All GStreamer calls and ownership changes run on PlaybackQueue.
- (instancetype)initWithSurface:(UIView *)surface {
    if ((self = [super init])) {
        _surface = surface;
        _snapshot = @{};
        _audio = @[];
        _subtitles = @[];
        _error = @"";
        _audioID = @"";
        _subtitleID = @"";
        _state = GST_PLAY_STATE_STOPPED;
    }
    return self;
}

- (void)open:(NSURL *)url
   userAgent:(NSString *)userAgent
      buffer:(double)buffer
   bandwidth:(unsigned int)bandwidth
       start:(double)start
        rate:(double)rate
       audio:(NSString *)audio
   subtitles:(NSString *)subtitles {
    dispatch_async(PlaybackQueue(), ^{
        if (self->_closed || self->_player) return;
        if (!InitializeGStreamer()) {
            self->_error = @"تعذّر تهيئة GStreamer";
            [self publish];
            return;
        }
        GstElement *sink = gst_element_factory_make("glimagesink", NULL);
        if (!sink) {
            self->_error = @"تعذّر فتح سطح الفيديو في GStreamer";
            [self publish];
            return;
        }
        GstPlayVideoRenderer *renderer = gst_play_video_overlay_video_renderer_new_with_sink(
            (__bridge void *)self->_surface, sink);
        self->_player = gst_play_new(renderer);
        self->_bus = gst_play_get_message_bus(self->_player);
        self->_resumeAt = start;
        self->_audioPreference = audio;
        self->_subtitlePreference = subtitles;
        GstStructure *config = gst_play_get_config(self->_player);
        gst_play_config_set_position_update_interval(config, 250);
        gst_play_config_set_seek_accurate(config, FALSE);
        if (userAgent.length) gst_play_config_set_user_agent(config, userAgent.UTF8String);
        if (!gst_play_set_config(self->_player, config)) gst_structure_free(config);
        GstElement *pipeline = gst_play_get_pipeline(self->_player);
        if (pipeline) {
            if (g_object_class_find_property(G_OBJECT_GET_CLASS(pipeline), "buffer-duration")) {
                g_object_set(pipeline, "buffer-duration", (gint64)(buffer * GST_SECOND), NULL);
            }
            if (bandwidth && g_object_class_find_property(G_OBJECT_GET_CLASS(pipeline), "connection-speed")) {
                g_object_set(pipeline, "connection-speed", (guint64)bandwidth, NULL);
            }
            gst_object_unref(pipeline);
        }
        if ([subtitles isEqualToString:@"off"]) gst_play_set_subtitle_track_enabled(self->_player, FALSE);
        gst_play_set_uri(self->_player, url.absoluteString.UTF8String);
        gst_play_play(self->_player);
        if (rate != 1) gst_play_set_rate(self->_player, rate);

        dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, PlaybackQueue());
        dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 250 * NSEC_PER_MSEC, 25 * NSEC_PER_MSEC);
        __weak SahraGStreamer *weakSelf = self;
        dispatch_source_set_event_handler(timer, ^{ [weakSelf poll]; });
        self->_timer = timer;
        dispatch_resume(timer);
    });
}

- (void)loadTracks:(GstPlayMediaInfo *)info {
    _seekable = gst_play_media_info_is_seekable(info);
    _audio = Tracks(gst_play_media_info_get_audio_streams(info), NO);
    _subtitles = Tracks(gst_play_media_info_get_subtitle_streams(info), YES);
    if (!_preferredAudioApplied && _audio.count) {
        _preferredAudioApplied = YES;
        for (NSDictionary *row in _audio) {
            if (MatchesLanguage(row[@"language"], _audioPreference)) {
                [self applyTrack:row[@"id"] subtitle:NO];
                break;
            }
        }
    }
    if (!_preferredSubtitleApplied && _subtitles.count) {
        _preferredSubtitleApplied = YES;
        NSString *preferred = nil;
        if (![_subtitlePreference isEqualToString:@"off"]) {
            for (NSDictionary *row in _subtitles) {
                if (MatchesLanguage(row[@"language"], @"ar")) { preferred = row[@"id"]; break; }
            }
            if (!preferred && [_subtitlePreference isEqualToString:@"any"]) preferred = _subtitles.firstObject[@"id"];
        }
        [self applyTrack:preferred subtitle:YES];
    }
}

- (void)applyTrack:(NSString * _Nullable)identifier subtitle:(BOOL)subtitle {
    if (!_player || _closed) return;
    if (subtitle) {
        gst_play_set_subtitle_track_enabled(_player, identifier != nil);
        if (identifier) gst_play_set_subtitle_track_id(_player, identifier.UTF8String);
        _subtitleID = identifier ?: @"";
    } else if (identifier) {
        gst_play_set_audio_track_id(_player, identifier.UTF8String);
        _audioID = identifier;
    }
}

- (void)poll {
    if (!_player || _closed) return;
    GstMessage *message;
    while ((message = gst_bus_pop(_bus))) {
        if (gst_play_is_play_message(message)) {
            GstPlayMessage kind;
            gst_play_message_parse_type(message, &kind);
            switch (kind) {
                case GST_PLAY_MESSAGE_POSITION_UPDATED: {
                    GstClockTime time = GST_CLOCK_TIME_NONE;
                    gst_play_message_parse_position_updated(message, &time);
                    if (GST_CLOCK_TIME_IS_VALID(time)) { _position = Seconds(time); _positionKnown = YES; }
                    break;
                }
                case GST_PLAY_MESSAGE_DURATION_CHANGED: {
                    GstClockTime time = GST_CLOCK_TIME_NONE;
                    gst_play_message_parse_duration_changed(message, &time);
                    _duration = Seconds(time);
                    break;
                }
                case GST_PLAY_MESSAGE_STATE_CHANGED:
                    gst_play_message_parse_state_changed(message, &_state);
                    if (_state == GST_PLAY_STATE_PLAYING) _played = YES;
                    break;
                case GST_PLAY_MESSAGE_VIDEO_DIMENSIONS_CHANGED: {
                    guint width = 0, height = 0;
                    gst_play_message_parse_video_dimensions_changed(message, &width, &height);
                    _width = (int)width;
                    _height = (int)height;
                    break;
                }
                case GST_PLAY_MESSAGE_MEDIA_INFO_UPDATED: {
                    GstPlayMediaInfo *info = NULL;
                    gst_play_message_parse_media_info_updated(message, &info);
                    if (info) { [self loadTracks:info]; g_object_unref(info); }
                    break;
                }
                case GST_PLAY_MESSAGE_END_OF_STREAM:
                    _ended = YES;
                    break;
                case GST_PLAY_MESSAGE_ERROR:
                    _error = _played ? @"توقّف استقبال الفيديو" : @"تعذّر فتح المصدر في GStreamer";
                    break;
                default:
                    break;
            }
        }
        gst_message_unref(message);
    }
    if (_resumeAt > 0 && _played && _positionKnown) {
        double now = [NSProcessInfo processInfo].systemUptime;
        if (!_resumeDeadline) _resumeDeadline = now + 3;
        if (_seekable && _duration > 0) {
            if (_resumeAt < _duration - 1) gst_play_seek(_player, (GstClockTime)(_resumeAt * GST_SECOND));
            _resumeAt = 0;
        } else if (now > _resumeDeadline) {
            _resumeAt = 0;
        }
    }
    if (!_audioID.length && _audio.count) {
        GstPlayAudioInfo *track = gst_play_get_current_audio_track(_player);
        if (track) { _audioID = TrackID(GST_PLAY_STREAM_INFO(track)); g_object_unref(track); }
    }
    [self publish];
}

- (void)publish {
    self.snapshot = @{
        @"position": @(_position), @"duration": @(_duration), @"width": @(_width), @"height": @(_height),
        @"seekable": @(_seekable), @"waiting": @(_state == GST_PLAY_STATE_BUFFERING || !_played),
        @"ended": @(_ended), @"error": _error, @"audio": _audio, @"subtitles": _subtitles,
        @"audioID": _audioID, @"subtitleID": _subtitleID
    };
}

- (void)setPlaying:(BOOL)playing {
    dispatch_async(PlaybackQueue(), ^{
        if (!self->_player || self->_closed) return;
        if (playing) gst_play_play(self->_player);
        else gst_play_pause(self->_player);
    });
}

- (void)seekTo:(double)seconds {
    if (!isfinite(seconds) || seconds < 0) return;
    dispatch_async(PlaybackQueue(), ^{
        if (self->_player && self->_seekable && !self->_closed) {
            self->_resumeAt = 0;
            gst_play_seek(self->_player, (GstClockTime)(seconds * GST_SECOND));
        }
    });
}

- (void)changeRate:(double)rate {
    dispatch_async(PlaybackQueue(), ^{
        if (self->_player && !self->_closed) gst_play_set_rate(self->_player, rate);
    });
}

- (void)selectAudio:(NSString *)identifier {
    dispatch_async(PlaybackQueue(), ^{ [self applyTrack:identifier subtitle:NO]; [self publish]; });
}

- (void)selectSubtitle:(NSString * _Nullable)identifier {
    dispatch_async(PlaybackQueue(), ^{ [self applyTrack:identifier subtitle:YES]; [self publish]; });
}

- (void)stopWithCompletion:(void (^)(void))completion {
    dispatch_async(PlaybackQueue(), ^{
        if (!self->_closed) {
            self->_closed = YES;
            if (self->_timer) { dispatch_source_cancel(self->_timer); self->_timer = nil; }
            if (self->_bus) { gst_object_unref(self->_bus); self->_bus = NULL; }
            if (self->_player) {
                gst_play_stop(self->_player);
                g_object_unref(self->_player);
                self->_player = NULL;
            }
            // OpenGL holds a reference to the native surface until the pipeline tears down.
            dispatch_async(dispatch_get_main_queue(), ^{ self->_surface = nil; });
        }
        completion();
    });
}
@end
