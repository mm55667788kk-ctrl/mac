// Shaka handles manifests, segment retrieval, quality selection and MediaSource.
(() => {
  "use strict";
  const proxy = "sahra://app/__proxy?u=";
  const userAgent = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3";
  const viaApp = url => proxy + encodeURIComponent(url) + "&ua=" + encodeURIComponent(userAgent);
  const fallbackURL = url => /^https?:\/\//i.test(url) ? url : "";
  let library;

  function loadLibrary() {
    if (!library) {
      library = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "sahra://app/__player/shaka-player.compiled.js";
        script.onload = () => window.shaka ? resolve(window.shaka) : reject(new Error("تعذّر تحميل Shaka Player"));
        script.onerror = () => { script.remove(); reject(new Error("تعذّر تحميل Shaka Player")); };
        document.head.appendChild(script);
      }).then(shaka => {
        shaka.polyfill.installAll();
        const request = (uri, params, type, progress, headersReceived) => {
          const xhr = new XMLHttpRequest();
          const ErrorType = shaka.util.Error;
          const networkError = (code, ...data) => new ErrorType(
            ErrorType.Severity.RECOVERABLE, ErrorType.Category.NETWORK, code, ...data
          );
          const promise = new Promise((resolve, reject) => {
            if (!fallbackURL(uri)) { reject(networkError(ErrorType.Code.HTTP_ERROR, uri)); return; }
            xhr.open(params.method || "GET", viaApp(uri));
            xhr.responseType = "arraybuffer";
            xhr.timeout = params.retryParameters.timeout || 12000;
            for (const key of Object.keys(params.headers || {})) {
              if (/^(range|accept)$/i.test(key)) xhr.setRequestHeader(key, params.headers[key]);
            }
            let lastTime = performance.now(), lastBytes = 0;
            const headers = () => {
              const fields = {};
              xhr.getAllResponseHeaders().trim().split(/\r?\n/).forEach(line => {
                const end = line.indexOf(":");
                if (end > 0) fields[line.slice(0, end).toLowerCase()] = line.slice(end + 1).trim();
              });
              return fields;
            };
            xhr.onreadystatechange = () => {
              if (xhr.readyState === XMLHttpRequest.HEADERS_RECEIVED && headersReceived) headersReceived(headers());
            };
            xhr.onprogress = event => {
              const now = performance.now();
              if (event.loaded <= lastBytes || now - lastTime < 100 && event.loaded !== event.total) return;
              progress(Math.max(1, now - lastTime), event.loaded - lastBytes,
                event.lengthComputable ? Math.max(0, event.total - event.loaded) : 0);
              lastTime = now;
              lastBytes = event.loaded;
            };
            xhr.onload = () => {
              const fields = headers();
              if (xhr.status < 200 || xhr.status >= 300) {
                reject(networkError(ErrorType.Code.BAD_HTTP_STATUS, uri, xhr.status, "", fields, type));
                return;
              }
              resolve({
                uri: fallbackURL(fields["x-sahra-source"] || "") || uri,
                originalUri: uri, headers: fields, data: xhr.response || new ArrayBuffer(0)
              });
            };
            xhr.onerror = () => reject(networkError(ErrorType.Code.HTTP_ERROR, uri, type));
            xhr.ontimeout = () => reject(networkError(ErrorType.Code.TIMEOUT, uri, type));
            xhr.onabort = () => reject(networkError(ErrorType.Code.OPERATION_ABORTED));
            xhr.send();
          });
          return new shaka.util.AbortableOperation(promise, () => {
            xhr.abort();
            return Promise.resolve();
          });
        };
        for (const scheme of ["http", "https"]) {
          shaka.net.NetworkingEngine.registerScheme(scheme, request, shaka.net.NetworkingEngine.PluginPriority.APPLICATION, true);
        }
        return shaka;
      }).catch(error => { library = null; throw error; });
    }
    return library;
  }

  const available = () => !!(window.SAHRA_SHAKA && (window.ManagedMediaSource || window.MediaSource));

  async function identify(url) {
    if (!fallbackURL(url) || !available()) return "";
    const signal = new AbortController();
    const timer = setTimeout(() => signal.abort(), 4000);
    try {
      const response = await fetch(viaApp(url), { method: "HEAD", signal: signal.signal });
      const type = response.ok ? (response.headers.get("content-type") || "").toLowerCase() : "";
      if (/mpegurl/.test(type)) return "application/x-mpegurl";
      if (/dash\+xml/.test(type)) return "application/dash+xml";
    } catch (_) {
      // Content-type inference is optional for URLs without an extension.
    } finally { clearTimeout(timer); }
    return "";
  }

  function session(video, target, options, failed) {
    let player = null, stopped = false, quality = null;
    const stop = () => {
      if (stopped) return Promise.resolve();
      stopped = true;
      return player ? player.destroy() : Promise.resolve();
    };
    const ready = (async () => {
      const shaka = await loadLibrary();
      if (stopped) return;
      if (!available() || !shaka.Player.isBrowserSupported()) throw new Error("Shaka يتطلب MediaSource على هذا الجهاز");
      video.disableRemotePlayback = true;
      video.setAttribute("disableremoteplayback", "");
      player = new shaka.Player();
      const retries = { maxAttempts: 2, baseDelay: 750, timeout: 12000, stallTimeout: 7000, connectionTimeout: 6000 };
      const audio = options.audio ? [{ language: options.audio }] : [];
      player.configure({
        preferredAudio: audio,
        preferredText: options.subs === "off" ? [] : [{ language: "ar" }],
        abr: { enabled: true, defaultBandwidthEstimate: options.saver ? 600000 : 1800000,
          restrictions: options.saver ? { maxHeight: 540 } : {} },
        manifest: { retryParameters: retries },
        streaming: {
          retryParameters: retries, rebufferingGoal: options.startBuffer, bufferingGoal: options.buffer,
          bufferBehind: 20, preferNativeHls: false, useNativeHlsForFairPlay: false
        }
      });
      if ("fallbackToNativeHlsOnMseError" in player.getConfiguration().streaming) {
        player.configure("streaming.fallbackToNativeHlsOnMseError", false);
      }
      player.addEventListener("error", event => {
        const error = event.detail;
        if (!stopped && error && error.severity === shaka.util.Error.Severity.CRITICAL) {
          failed("تعذّر قراءة قائمة البث أو مقاطعها · " + error.code);
        }
      });
      player.addEventListener("buffering", event => {
        if (!stopped && options.buffering) options.buffering(event.buffering);
      });
      await player.attach(video);
      if (stopped) return;
      await player.load(target.url, options.at > 0 ? options.at : undefined, target.type);
      if (stopped) return;
      if (player.getLoadMode() !== shaka.Player.LoadMode.MEDIA_SOURCE) throw new Error("تعذّر فتح مسار MediaSource");
      if (options.subs === "off" || options.external) player.selectTextTrack(null);
      else if (options.subs === "any" && !player.getTextTracks().some(track => track.active)) {
        const first = player.getTextTracks()[0];
        if (first) player.selectTextTrack(first);
      }
    })();
    const sizes = () => {
      const tracks = player ? player.getVariantTracks() : [];
      const language = tracks.find(track => track.active)?.language;
      const rows = tracks.filter(track => !language || track.language === language).sort((a, b) => a.bandwidth - b.bandwidth);
      return [...new Map(rows.map(track => [(track.height || 0) + ":" + Math.round(track.bandwidth / 50000), track])).values()];
    };
    return {
      ready, stop, sizes,
      quality: () => quality,
      setQuality(index) {
        if (!player) return;
        const track = sizes().find(track => track.id === index);
        quality = track ? track.id : null;
        player.configure("abr.enabled", !track);
        if (track) player.selectVariantTrack(track, true, 4);
      },
      audio: () => player ? player.getAudioTracks() : [],
      setAudio(index) {
        if (!player) return;
        const track = player.getAudioTracks()[index];
        if (!track) return;
        player.selectAudioTrack(track, 4);
        quality = null;
        player.configure("abr.enabled", true);
      },
      text: () => player ? player.getTextTracks() : [],
      setText(index) {
        if (player) player.selectTextTrack(index === -1 ? null : player.getTextTracks()[index] || null);
      },
      stats: () => player ? player.getStats() : null
    };
  }

  window.SahraAdaptive = { available, identify, session };
})();
