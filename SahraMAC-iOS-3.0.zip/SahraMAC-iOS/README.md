# سهرة MAC 3.0 · iPhone وiPad

## بناء ملف IPA

1. فك ضغط `SahraMAC-iOS-3.0.zip`.
2. انسخ **محتويات** مجلد `SahraMAC-iOS` إلى جذر مستودعك. فعّل إظهار الملفات المخفية لكي تنسخ أيضًا `.github/workflows/build-ipa.yml`.
3. في GitHub افتح **Actions → Build SahraMAC 3.0 IPA → Run workflow**.
4. بعد نجاح البناء افتح **Artifacts** وحمّل `SahraMAC-ipa`. داخله `SahraMAC.ipa`. وقّعه بأداة التثبيت التي تستخدمها.

يمكن استخدام ZIP في جذر المستودع مع ملف الـworkflow المرفق. يتحقق ملف البناء الآلي من رقم النسخة ووجود مصدر GStreamer قبل البناء.

للبناء محليًا على Mac، ثبّت Xcode وNode.js وPython 3، ثم شغّل `bash build-ipa.sh`. ينزّل البناء حزمة Shaka 5.3.3 وحزمة iOS الرسمية لـGStreamer 1.28.8، ويتحقق من بصمة حزمة GStreamer. تنزيل SDK حجمه نحو 1.1 غيغابايت. لتخطي إعادة تنزيله يمكنك تعيين `GSTREAMER_XCFRAMEWORK` إلى مسار الحزمة الرسمية المفكوكة على جهازك. البناء يستهدف جهازًا فعليًا بمعمارية arm64.

## اختيار المشغّل

| الخيار | الاستخدام |
| --- | --- |
| سينما سهرة · تلقائي | يبدأ بـShaka عندما يكون الرابط HLS أو DASH. يبدأ بـGStreamer للروابط المباشرة وملفات الفيديو. يجرب المحرك التالي عند توفر مسار مناسب للمصدر. |
| GStreamer | روابط HTTP وHTTPS، وملفات MKV وMP4 وMPEG-TS، ومسارات صوت وترجمة داخلية. يستخدم فك ترميز الفيديو العتادي عند توفر برنامج فك الترميز والصيغة المناسبة. |
| Shaka Player | HLS وMPEG-DASH عبر MediaSource، مع جودة تلقائية واختيار يدوي. على iPhone يحتاج iOS 17.1 فأحدث ودعم ManagedMediaSource. |

القائمتان في الإعدادات تتحكمان في المحرك المستخدم للبث المباشر وللأفلام والمسلسلات. يمكن تبديل المحرك أثناء المشاهدة والمتابعة من الموضع السابق في المحتوى القابل للتقديم. يتيح وضع الأداء الاختيار بين بدء سريع، متوازن، بث ثابت، وتوفير البيانات. تعتمد استفادة توفير البيانات على توفر أكثر من جودة للبث.

التنزيلات تعمل عبر GStreamer بعد اكتمالها. تجهيز ملف مقسّم يحتاج مساحة مؤقتة تساوي حجم الملف تقريبًا. تُزال النسخة المؤقتة عند إغلاق المشغّل.

## مصادر المكتبات

- [GStreamer 1.28.8 iOS SDK](https://gstreamer.freedesktop.org/data/pkg/ios/1.28.8/) · [المصدر](https://gitlab.freedesktop.org/gstreamer/gstreamer/-/tree/1.28.8) · [الترخيص](https://gstreamer.freedesktop.org/documentation/frequently-asked-questions/licensing.html)
- [Shaka Player 5.3.3](https://github.com/shaka-project/shaka-player/releases/tag/v5.3.3) · يضم البناء ملف الترخيص مع المكتبة.
